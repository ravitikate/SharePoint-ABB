declare const _spPageContextInfo: any;
import Swal from "sweetalert2";
import * as XLSX from 'xlsx-js-style';
import "../styles/common.css";
import "../styles/collection.css";

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead?: string;
}

interface SortConfig {
  column: string;
  direction: 'asc' | 'desc';
  subColumn?: string;
  monthIndex?: number; // Add this to track which month column
}

let currentSortConfig: SortConfig = {
  column: '',
  direction: 'asc'
};
 
interface CollectionItem {
  Id: number;
  Title: string;
  Project?: { 
    Id: number;
    Title: string;
  };
  ProfitCentre?: string;
  OBL?: number;
  CollectionData?: string;
  RevenueActual?: string;
  Remarks?: string | null;
  CreatedDate?: string;
  UpdatedDate?: string;
  
  // OBL Breakdown Fields - ADD THESE
  NormalDue?: number;
  NormalOverdue?: number;
  RetentionDue?: number;
  RetentionOverdue?: number;
  GSTTDS?: number;
  WHT?: number;
  
  [key: string]: any;
}

interface OBLBreakdown {
  normalDue: number;
  normalOverdue: number;
  retentionDue: number;
  retentionOverdue: number;
  gstTds: number;
  wht: number;
}

 

interface SharePointResponse<T> {
  d: {
    results: T[];
  };
}

interface CollectionCategory {
  name: string;
  plan: number;
  actual: number;
  forecast?: number;  // Add this
  date?: string;      // Add this
}

interface CollectionMonthData {
  plan: number;
  actual: number;
  forecast?: number;  // Add this
  date?: string;      // Add this
  items?: {
    [categoryName: string]: CollectionCategory;
  };
}

interface YearlyCollectionData {
  [year: string]: {
    plan: number;
    actual: number;
    items?: {  // Add this property
      [categoryName: string]: CollectionCategory;
    };
  };
}

interface CollectionData {
  [monthKey: string]: CollectionMonthData | YearlyCollectionData | undefined;
  yearly?: YearlyCollectionData;
}

interface UserContext {
  loginName: string;
  displayName: string;
  groups: string[];
  isSuperAdmin: boolean;
  isGroupHead: boolean;
  isProjectManager: boolean;
  userGroups?: string[];
  managedProjects?: string[];
  managedGroups?: string[];
}

// Add PERFORMANCE_CONFIG constant at the top level
const PERFORMANCE_CONFIG = {
  DEBOUNCE_DELAY: 300,
  CACHE_DURATION: 300000, // 5 minutes
  MAX_TABLE_ROWS: 50,
  VIRTUAL_SCROLL_THRESHOLD: 1000,
  BATCH_SIZE: 100
};



export default {
  content: `
<div class="collection-page fade-in">
  <section class="table-section card">
    <div class="page-header">
      <h1>Collection Management</h1>
      <button class="btn-primary show-form-btn">+ Add Collection</button>
    </div>
    
    <div class="table-actions">
      <div class="table-actions-row">
        <div class="tableColp4">
          <label for="filterProject">Project</label>
          <select id="filterProject"><option value="">All Projects</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterCustomer">Customer</label>
          <select id="filterCustomer"><option value="">All Customers</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterProjectManager">Project Manager</label>
          <select id="filterProjectManager"><option value="">All Managers</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterGroupHead">Group Head</label>
          <select id="filterGroupHead"><option value="">All Group Heads</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterProjectReference">Project Reference</label>
          <select id="filterProjectReference"><option value="">All References</option></select>
        </div>
        <div class="tableColp4"> 
          <label>&nbsp;</label>
          <button class="btn-secondary clear-filters-btn" title="Clear All Filters">Reset Filter</button> 
        </div>
      </div>
      
      <div class="table-actions-row">
        <div class="tableColp4">
          <label for="filterYear">Year</label>
          <select id="filterYear"><option value="">All Years</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterMonth">Month</label>
          <select id="filterMonth"><option value="">All Months</option></select>
        </div>
        <div class="tableColp4"> 
          <label>&nbsp;</label>
          <button class="btn-secondary import-actual-btn">📥 Import Actual</button>
        </div>
        <div class="tableColp4"> 
          <label>&nbsp;</label>
          <button class="btn-secondary export-btn">📊 Export Excel</button>
        </div>
      </div>
    </div>
       
    <div class="table-container">
      <div style="overflow-x:auto;">
        <table class="month-columns-table">
          <thead id="totalsHeader"></thead> <!-- ADD THIS LINE -->
          <thead id="monthColumnsHeader"></thead>
          <tbody class="collection-table-body"></tbody>
        </table>
      </div>
       
      <!-- Pagination -->
<div class="pagination-container">
  <div class="pagination-controls">
    <div class="pagination-size-selector">
      <label for="pageSize">Show:</label>
      <select id="pageSize" class="page-size-select">
        <option value="10">10</option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100">100</option>
      </select> 
    </div>
    
    <div class="pagination-navigation">
      <button class="pagination-btn" id="firstPage" disabled>First</button>
      <button class="pagination-btn" id="prevPage" disabled>Previous</button>
      
      <div class="pagination-info">
        Page <span id="currentPage">1</span> of <span id="totalPages">1</span>
      </div>
      
      <div class="pagination-pages" id="pageNumbers"></div>
      
      <button class="pagination-btn" id="nextPage" disabled>Next</button>
      <button class="pagination-btn" id="lastPage" disabled>Last</button>
      
      <div class="pagination-info">
        Showing <span id="startItem">0</span>-<span id="endItem">0</span> of <span id="totalItems">0</span> records
      </div>
    </div>
  </div>
</div>
    </div>
  </section>

  <section class="form-section card" style="display:none;">
    <div class="page-header">
      <h1 id="formTitle">Add / Edit Collection</h1>
    </div>
    <form id="collectionForm">
      <div class="form-row">
        <div class="form-group from-group-box project-select-container">
          <label>Project</label>
          <select id="projectSelect" required></select>
        </div>
        <div id="projectDetails"></div>
      </div>
      
      <!-- OBL Section with Enhanced Validation --> 
       <div class="obl-section-container hidden-section">
  <div class="obl-main-section">
    <div class="form-group">
      <label>Receivable Value
        <span class="info-tooltip" title="For new projects, enter the initial OBL value. For existing projects, this will be auto-populated from last month's data.">ℹ️</span>
      </label>
      <input type="text" id="oblLastMonth" class="obl-input number-input" placeholder="Enter OBL" readonly />
      <div class="field-note">For new projects: Enter initial OBL value</div>
    </div>
    <div class="validation-summary">
      <div class="validation-item">
        <span class="validation-label">Total Current Value:</span>
        <span class="validation-value" id="totalCurrentValue">0</span>
      </div>
      <div class="validation-item">
        <span class="validation-label">Remaining Balance:</span>
        <span class="validation-value" id="remainingValue">0</span>
      </div>
      <div class="validation-line">
        <div class="line-fill" id="oblLineFill"></div>
      </div>
    </div>
  </div>
  
  <!-- OBL Breakdown Section -->
  <div class="obl-breakdown-section">
  <h4>Receivable Value Breakdown</h4>
  <div class="obl-breakdown-grid">
    <div class="obl-breakdown-item">
      <label>Normal Due</label>
      <input type="text" id="oblNormalDue" class="obl-breakdown-input number-input" readonly /> 
    </div>
    <div class="obl-breakdown-item">
      <label>Normal Overdue</label>
      <input type="text" id="oblNormalOverdue" class="obl-breakdown-input number-input" readonly /> 
    </div>
    <div class="obl-breakdown-item">
      <label>Retention Due</label>
      <input type="text" id="oblRetentionDue" class="obl-breakdown-input number-input" readonly /> 
    </div>
    <div class="obl-breakdown-item">
      <label>Retention Overdue</label>
      <input type="text" id="oblRetentionOverdue" class="obl-breakdown-input number-input" readonly /> 
    </div>
    <div class="obl-breakdown-item">
      <label>GST TDS</label>
      <input type="text" id="oblGstTds" class="obl-breakdown-input number-input" readonly /> 
    </div>
    <div class="obl-breakdown-item">
      <label>WHT</label>
      <input type="text" id="oblWht" class="obl-breakdown-input number-input" readonly /> 
    </div>
  </div>
</div>
  
  <div class="validation-message" id="oblValidationMessage">
    ✅ All values are within OBL limit
  </div>
</div>
      
      <!-- Historical Months (Last 3 Months - Readonly) -->
      <div class="collection-section hidden-section" id="historicalCollectionSection">
        <h3>Historical Data (Last 3 Months - Readonly)</h3>
        <div id="historicalContainer" class="historical-container"></div>
      </div>
      
      <!-- Current + Next 2 Months - Hidden by default -->
      <div class="collection-section hidden-section" id="detailedCollectionSection">
        <h3>Detailed Collection (Current + Next 2 Months)</h3>
        <div id="firstRowContainer" class="first-row-container"></div>
      </div>
      
      <!-- Next 15 Months - Hidden by default -->
      <div class="collection-section hidden-section" id="longtermCollectionSection">
        <h3>Long-term Collection (Next 16 Months)</h3>
        <div id="remainingContainer" class="remaining-container"></div>
      </div>

      <!-- 5-Year Collection Section - Hidden by default -->
      <div class="collection-section hidden-section" id="yearlyCollectionSection">
        <h3>4-Year Collection</h3>
        <div id="yearlyContainer" class="yearly-container"></div>
      </div>
      
      <div class="form-actions">
        <button type="submit" class="btn-primary">💾 Save Collection</button>
        <button type="button" class="btn-secondary back-to-table">⬅ Back</button>
      </div>
    </form>
  </section>
</div>
  `,

   

  script: () => {
    setTimeout(async () => {
      const siteUrl = typeof _spPageContextInfo !== "undefined" ? _spPageContextInfo.webAbsoluteUrl : window.location.origin + "/sites/Kriya";
      const listName = "Collection List";
      const projectListName = "Project List";

      const roleStyles = `
          .role-indicator {
            padding: 8px 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            display: inline-block;
          }

          .role-badge {
            display: flex;
            align-items: center;
            gap: 8px;
          }

          .hidden-by-role {
            display: none !important;
          }
            .page-number.dots {
  background-color: transparent;
  border: none;
  cursor: default;
  color: #6c757d;
}

.pagination-btn:focus,
.page-number:focus,
.page-size-select:focus {
  outline: 2px solid #007bff;
  outline-offset: 2px;
}

/* Loading state for table */
.table-loading {
  opacity: 0.7;
  pointer-events: none;
}

/* Animation for page transitions */
@keyframes fadeIn {
  from { opacity: 0.5; }
  to { opacity: 1; }
}

.revenue-table-body-rev tr {
  animation: fadeIn 0.3s ease-in;
}

/* Responsive table container */
.table-container-rev {
  overflow-x: auto;
  max-height: calc(100vh - 300px);
  position: relative;
}

.table-container-rev::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-container-rev::-webkit-scrollbar-track {
  background: #f1f1f1;
}

.table-container-rev::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 4px;
}

.table-container-rev::-webkit-scrollbar-thumb:hover {
  background: #555;
}

.pagination-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  padding: 15px;
  background-color: #f8f9fa;
  border-radius: 8px;
  border: 1px solid #dee2e6;
  flex-wrap: wrap;
  gap: 15px;
}

.pagination-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.pagination-right {
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
}

.page-size-selector {
  display: flex;
  align-items: center;
  gap: 8px;
}

.page-size-select {
  padding: 5px 10px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  background-color: white;
  font-size: 14px;
  cursor: pointer;
}

.page-size-select:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25);
}

.pagination-btn {
  padding: 6px 12px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.2s;
}

.pagination-btn:hover:not(:disabled) {
  background-color: #0056b3;
}

.pagination-btn:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
  opacity: 0.6;
}

.pagination-info {
  font-size: 14px;
  color: #495057;
  white-space: nowrap;
}

.pagination-pages {
  display: flex;
  gap: 5px;
}

.page-number {
  padding: 6px 12px;
  background-color: white;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s;
}

.page-number:hover:not(.active) {
  background-color: #f8f9fa;
  border-color: #007bff;
}

.page-number.active {
  background-color: #007bff;
  color: white;
  border-color: #007bff;
}

/* Responsive styles */
@media (max-width: 768px) {
  .pagination-container {
    flex-direction: column;
    align-items: stretch;
    gap: 15px;
  }
  
  .pagination-left, .pagination-right {
    justify-content: center;
    width: 100%;
  }
} 

/* Totals Header Styles */
.totals-header-table {
  margin-bottom: 10px;
  background-color: #f8f9fa;
  border-collapse: separate;
  border-spacing: 0;
}

.totals-header-table th {
  padding: 8px 5px;
  font-size: 12px;
  font-weight: bold;
  text-align: center;
  vertical-align: middle;
  border: 1px solid #dee2e6;
  border-bottom: 2px solid #007bff;
  background-color: #e9ecef;
}

.totals-header-table .totals-label {
  font-weight: 600;
  color: #495057;
  background-color: #f1f3f4 !important;
}

.totals-header-table .all-projects-total {
  background-color: #d1ecf1 !important;
  color: #0c5460;
}

.totals-header-table .filtered-total {
  background-color: #d4edda !important;
  color: #155724;
}

.totals-header-table .total-value {
  font-weight: bold;
  font-size: 13px;
}

/* Adjust main table margin */
.table-container-rev > div > table:last-child {
  margin-top: 0;
}

/* Ensure proper column alignment */
.totals-header-table th,
.month-columns-table-rev th {
  min-width: 100px;
  box-sizing: border-box;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .totals-header-table th {
    font-size: 10px;
    padding: 5px 3px;
  }
  
  .totals-header-table .total-value {
    font-size: 11px;
  }
}

tr.filtered-total {
    background-color: #00ffff;
}
tr.all-projects-total {
    background-color: #fff8dc;
}
    .role-indicator {
    display: none;
}
          `;

    const styleSheet = document.createElement("style");
    styleSheet.textContent = roleStyles;
    document.head.appendChild(styleSheet);

      // DOM Elements
      const tableBody = document.querySelector(".collection-table-body") as HTMLElement;
    const monthColumnsHeader = document.querySelector("#monthColumnsHeader") as HTMLElement;
    const formSection = document.querySelector(".form-section") as HTMLElement;
    const tableSection = document.querySelector(".table-section") as HTMLElement;
    const showFormBtn = document.querySelector(".show-form-btn") as HTMLButtonElement;
    const projectSelect = document.querySelector("#projectSelect") as HTMLSelectElement;
    const historicalContainer = document.querySelector("#historicalContainer") as HTMLElement;
    const firstRowContainer = document.querySelector("#firstRowContainer") as HTMLElement;
    const remainingContainer = document.querySelector("#remainingContainer") as HTMLElement;
    const yearlyContainer = document.querySelector("#yearlyContainer") as HTMLElement;
    const projectDetails = document.querySelector("#projectDetails") as HTMLElement;
    const backBtn = document.querySelector(".back-to-table") as HTMLButtonElement;
    const form = document.querySelector("#collectionForm") as HTMLFormElement;
    const exportBtn = document.querySelector(".export-btn") as HTMLButtonElement;
    const oblLastMonthInput = document.querySelector("#oblLastMonth") as HTMLInputElement;
    const totalCurrentValueSpan = document.querySelector("#totalCurrentValue") as HTMLSpanElement;
    const remainingValueSpan = document.querySelector("#remainingValue") as HTMLSpanElement;
    const oblLineFill = document.querySelector("#oblLineFill") as HTMLDivElement;
    const oblValidationMessage = document.querySelector("#oblValidationMessage") as HTMLSpanElement;
    const formTitle = document.querySelector("#formTitle") as HTMLElement;

    // Filter Elements
    const filterYear = document.querySelector("#filterYear") as HTMLSelectElement;
    const filterMonth = document.querySelector("#filterMonth") as HTMLSelectElement;
    const filterProject = document.querySelector("#filterProject") as HTMLSelectElement;
    const filterCustomer = document.querySelector("#filterCustomer") as HTMLSelectElement;
    const filterProjectManager = document.querySelector("#filterProjectManager") as HTMLSelectElement;
    const filterGroupHead = document.querySelector("#filterGroupHead") as HTMLSelectElement;
    const filterProjectReference = document.querySelector("#filterProjectReference") as HTMLSelectElement;

    // Action Buttons
    const importActualBtn = document.querySelector(".import-actual-btn") as HTMLButtonElement;
    const clearFiltersBtn = document.querySelector(".clear-filters-btn") as HTMLButtonElement;

    // Pagination Elements
    const pageSizeSelect = document.querySelector("#pageSize") as HTMLSelectElement;
    const firstPageBtn = document.querySelector("#firstPage") as HTMLButtonElement;
    const prevPageBtn = document.querySelector("#prevPage") as HTMLButtonElement;
    const nextPageBtn = document.querySelector("#nextPage") as HTMLButtonElement;
    const lastPageBtn = document.querySelector("#lastPage") as HTMLButtonElement;
    const currentPageSpan = document.querySelector("#currentPage") as HTMLSpanElement;
    const totalPagesSpan = document.querySelector("#totalPages") as HTMLSpanElement;
    const pageNumbersDiv = document.querySelector("#pageNumbers") as HTMLDivElement;
    const startItemSpan = document.querySelector("#startItem") as HTMLSpanElement;
    const endItemSpan = document.querySelector("#endItem") as HTMLSpanElement;
    const totalItemsSpan = document.querySelector("#totalItems") as HTMLSpanElement;

    let projects: ProjectItem[] = [];
    let collections: CollectionItem[] = [];
    let editingId: number | null = null;
    let allMonths: string[] = [];
  

    let currentPage = 1;
    let pageSize = 10;
    let totalPages = 1;
    let filteredData: CollectionItem[] = [];

    let currentUser: UserContext;
    let userGroups: string[] = [];
    let managedProjects: string[] = [];
    let managedGroups: string[] = [];

      // ========== UTILITY FUNCTIONS ==========

    const toast = (icon: any, title: string) => Swal.fire({ toast: true, icon, title, position: "top-end", timer: 2000, showConfirmButton: false });

    const getDigest = async (): Promise<string> => {
      const res = await fetch(`${siteUrl}/_api/contextinfo`, { 
        method: "POST", 
        headers: { Accept: "application/json;odata=verbose" } 
      });
      const data = await res.json();
      return data.d.GetContextWebInformation.FormDigestValue;
    };

    const getUserContext = async (): Promise<UserContext> => {
      try {
        // Get current user information
        const userRes = await fetch(`${siteUrl}/_api/web/currentuser`, {
          headers: { Accept: "application/json;odata=verbose" }
        });
        const userData = await userRes.json();
        const loginName = userData.d.LoginName;
        const displayName = userData.d.Title;

        // Get user's groups
        const groupsRes = await fetch(`${siteUrl}/_api/web/currentuser/groups`, {
          headers: { Accept: "application/json;odata=verbose" }
        });
        const groupsData = await groupsRes.json();
        userGroups = groupsData.d.results.map((g: any) => g.Title);
        
        // Check roles based on group membership
        const isSuperAdmin = userGroups.some(g => 
          g.toLowerCase().includes("super admin") || 
          g.toLowerCase() === "site owners" ||
          g === "Super Admin"
        );
        
        const isGroupHead = userGroups.some(g => 
          g.toLowerCase().includes("group head") || 
          g === "Group Head"
        );
        
        const isProjectManager = userGroups.some(g => 
          g.toLowerCase().includes("project manager") || 
          g === "Project Manager"
        );

        // If user is Group Head, get their managed groups
        if (isGroupHead) {
          const groupHeadName = displayName;
          managedGroups = [groupHeadName]; 
        }

        // If user is Project Manager, get their managed projects
        if (isProjectManager) {
          // Load projects where this user is the project manager
          const pmProjectsRes = await fetch(
            `${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$filter=ProjectManager/Title eq '${displayName}'&$select=Id,Title`,
            { headers: { Accept: "application/json;odata=verbose" } }
          );
          const pmProjectsData = await pmProjectsRes.json();
          managedProjects = pmProjectsData.d.results.map((p: any) => p.Title); 
        }
    
        return {
          loginName,
          displayName,
          groups: userGroups,
          isSuperAdmin,
          isGroupHead,
          isProjectManager,
          userGroups,
          managedProjects,
          managedGroups
        };
      } catch (error) {
        console.error("Error getting user context:", error);
        // Default to most restrictive access if error
        return {
          loginName: "",
          displayName: "",
          groups: [],
          isSuperAdmin: false,
          isGroupHead: false,
          isProjectManager: false,
          managedProjects: [],
          managedGroups: []
        };
      }
    };

    const filterDataByRole = (data: CollectionItem[]): CollectionItem[] => { 
      if (currentUser.isSuperAdmin) { 
        return data;
      }

      const filteredData = data.filter(collection => {
        const projectTitle = collection.Project?.Title;
        
        if (!projectTitle) { 
          return false;
        }

        const project = projects.find(p => p.Title === projectTitle);
        
        if (!project) { 
          return false;
        }

        if (currentUser.isGroupHead) {
          // Group Head can see projects in their managed groups
          const canAccess = currentUser.managedGroups?.some(group => 
            project.GroupHead === group
          ) || false;
          return canAccess;
        }

        if (currentUser.isProjectManager) {
          // Project Manager can see only their assigned projects
          const canAccess = currentUser.managedProjects?.includes(projectTitle) || false;
          return canAccess;
        }
          return false;
      });
      
      return filteredData;
    };

    const updateUIForRole = (): void => {
      const pageHeader = document.querySelector(".page-header") as HTMLElement;
      const roleIndicator = document.createElement("div");
      roleIndicator.className = "role-indicator";
      
      let roleText = "";
      if (currentUser.isSuperAdmin) {
        roleText = "Super Admin - Full Access";
        roleIndicator.style.backgroundColor = "#28a745"; // Green
      } else if (currentUser.isGroupHead) {
        roleText = `Group Head - ${currentUser.displayName}`;
        roleIndicator.style.backgroundColor = "#17a2b8"; // Blue
      } else if (currentUser.isProjectManager) {
        roleText = `Project Manager - ${currentUser.displayName}`;
        roleIndicator.style.backgroundColor = "#ffc107"; // Yellow
      } else {
        roleText = "Limited Access";
        roleIndicator.style.backgroundColor = "#6c757d"; // Gray
      }
      
      roleIndicator.innerHTML = `
        <span class="role-badge">👤 ${roleText}</span>
      `;
      
      // Insert role indicator after the header
      pageHeader.parentNode?.insertBefore(roleIndicator, pageHeader.nextSibling);

      // Apply role-based UI classes
      setTimeout(() => {
        applyRoleBasedUIClasses();
      }, 100);
    };

    const applyRoleBasedUIClasses = (): void => {
      if (currentUser.isSuperAdmin) {
        // Super Admin should see ALL columns
        document.querySelectorAll('.hidden-by-role').forEach(element => {
          element.classList.remove('hidden-by-role');
        });
        return;
      }
      
      // Apply classes to table header cells
      const tableHeaders = document.querySelectorAll('.month-columns-table th');
      
      tableHeaders.forEach(header => {
        const headerText = header.textContent?.toLowerCase() || '';
        
        // Project Manager column - hide for Project Manager login (they only see themselves)
        if (headerText.includes('project manager') || headerText.includes('manager')) {
          if (currentUser.isProjectManager) {
            header.classList.add('hidden-by-role');
          } else {
            header.classList.remove('hidden-by-role');
          }
        }
        
        // Group Head column - hide for Group Head login (they only see themselves)
        if (headerText.includes('group head') || headerText.includes('head')) {
          if (currentUser.isGroupHead) {
            header.classList.add('hidden-by-role');
          } else {
            header.classList.remove('hidden-by-role');
          }
        }
      });

      // Apply classes to filter elements
      const projectManagerFilter = document.querySelector('#filterProjectManager')?.closest('.tableColp4');
      const groupHeadFilter = document.querySelector('#filterGroupHead')?.closest('.tableColp4');
      
      if (projectManagerFilter) {
        if (currentUser.isProjectManager) {
          projectManagerFilter.classList.add('hidden-by-role');
        } else {
          projectManagerFilter.classList.remove('hidden-by-role');
        }
      }
      
      if (groupHeadFilter) {
        if (currentUser.isGroupHead) {
          groupHeadFilter.classList.add('hidden-by-role');
        } else {
          groupHeadFilter.classList.remove('hidden-by-role');
        }
      }
    };

    const filterProjectSelectByRole = (): void => {
      if (currentUser.isSuperAdmin) {
        return; // Super Admin sees all projects
      }

      const options = projectSelect.querySelectorAll("option");
      options.forEach((option, index) => {
        if (index === 0) return; // Skip "Select Project" option
        
        const projectId = parseInt(option.value);
        const project = projects.find(p => p.Id === projectId);
        
        if (!project) {
          option.style.display = "none";
          return;
        }

        let showOption = false;
        
        if (currentUser.isGroupHead) {
          showOption = currentUser.managedGroups?.some(group => 
            project.GroupHead === group
          ) || false;
        } else if (currentUser.isProjectManager) {
          showOption = currentUser.managedProjects?.includes(project.Title) || false;
        }
        
        option.style.display = showOption ? "" : "none";
      });

      // Reset selection if current selection is hidden
      if (projectSelect.value) {
        const selectedOption = projectSelect.selectedOptions[0];
        if (selectedOption.style.display === "none") {
          projectSelect.value = "";
          toast("warning", "Your current project selection is not accessible with your role");
        }
      }
    };

      // Safe JSON parsing function
    const safeJsonParse = (jsonString: string | undefined, fallback: any = {}): any => {
      try {
        if (!jsonString || jsonString.trim() === '') {
          return fallback;
        }
        const cleanedString = jsonString.trim();
        if (cleanedString === '""' || cleanedString === "null") {
          return fallback;
        }
        return JSON.parse(cleanedString);
      } catch (error) {
        console.error("JSON parse error:", error, "Input:", jsonString);
        return fallback;
      }
    };

       const formatMonthKey = (date: Date): string => {
          return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
        };

    const formatMonthLabel = (date: Date): string => {
      return date.toLocaleString("default", { month: "short", year: "2-digit" });
    };

      const generateCollectionTitle = (project: ProjectItem, collectionData: CollectionData): string => {
        const currentYear = new Date().getFullYear();
        let totalValue = 0;
        
        // Calculate total from monthly data only (exclude yearly)
        Object.keys(collectionData).forEach(key => {
          if (key.match(/^\d{4}-\d{2}$/)) {
            const monthData = collectionData[key] as CollectionMonthData;
            if (monthData) {
              totalValue += monthData.actual;
            }
          }
        });
        
        return `${project.Title} - ${currentYear} Collection - ${totalValue.toLocaleString()}`;
      };

      // Get current and next 2 months for display
       const getDisplayMonths = (): string[] => {
      const now = new Date();
      const months: string[] = [];
      for (let i = 0; i < 3; i++) {
        const month = new Date(now.getFullYear(), now.getMonth() + i, 1);
        months.push(formatMonthKey(month));
      }
      return months;
    };


      const getAllMonthsForStorage = (): string[] => {
        return generateIdealMonthStructure();
      };

      // Utility function to allow only numbers 0-9 in text inputs
      const allowOnlyNumbers = (input: HTMLInputElement): void => {
        input.addEventListener('input', function() {
          let value = this.value.replace(/[^\d]/g, '');
          
          if (value.length > 1 && value.startsWith('0')) {
            value = value.replace(/^0+/, '');
            if (value === '') value = '0';
          }
          
          this.value = value;
          
          if (value === '' || value === '0') {
            this.className = this.className.replace('input-with-value', 'input-empty');
          } else {
            this.className = this.className.replace('input-empty', 'input-with-value');
          }
        });
        
        input.addEventListener('keydown', function(e) {
          if ([8, 9, 13, 27, 46].includes(e.keyCode) || 
              (e.keyCode === 65 && e.ctrlKey === true) || 
              (e.keyCode === 67 && e.ctrlKey === true) ||
              (e.keyCode === 86 && e.ctrlKey === true) ||
              (e.keyCode === 88 && e.ctrlKey === true) ||
              (e.keyCode >= 35 && e.keyCode <= 39)) {
            return;
          }
          
          if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
          }
        });
        
        input.addEventListener('paste', function(e) {
          const clipboardData = e.clipboardData || (window as any).clipboardData;
          const pastedData = clipboardData?.getData('Text') || '';
          
          if (/[^\d]/.test(pastedData)) {
            e.preventDefault();
          }
        });
      };

      // Function to get numeric value from text input - 0 is placeholder
      const getNumericValue = (input: HTMLInputElement): number => {
        const value = input.value.trim();
        if (value === '' || value === '0') return 0;
        return parseInt(value) || 0;
      };

      // Function to set numeric value to text input - 0 shows as empty
      const setNumericValue = (input: HTMLInputElement, value: number): void => {
        if (value === 0) {
          input.value = '';
          input.className = input.className.replace('input-with-value', 'input-empty');
        } else {
          input.value = value.toString();
          input.className = input.className.replace('input-empty', 'input-with-value');
        }
      };

      // Enhanced OBL validation with toast notifications
      const showOBLErrorToast = (message: string, isWarning: boolean = false): void => {
        const existingToast = document.querySelector('.obl-error-toast');
        if (existingToast) existingToast.remove();
        
        const toast = document.createElement('div');
        toast.className = `obl-error-toast ${isWarning ? 'warning' : ''}`;
        toast.innerHTML = `
          ${message}
          <button class="toast-close">&times;</button>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
          if (toast.parentNode) {
            toast.remove();
          }
        }, 5000);
        
        toast.querySelector('.toast-close')?.addEventListener('click', () => {
          toast.remove();
        });
      };

      // ========== MONTH STRUCTURE FUNCTIONS ==========

      const createEmptyCategories = (): { [key: string]: CollectionCategory } => {
        return {
          "Normal": { name: 'Normal', plan: 0, actual: 0 },
          "Normal Overdue": { name: 'Normal Overdue', plan: 0, actual: 0 },
          "Retention": { name: 'Retention', plan: 0, actual: 0 },
          "Retention Overdue": { name: 'Retention Overdue', plan: 0, actual: 0 }
        };
      };

      const createSimpleCategories = (): { [key: string]: CollectionCategory } => {
        return {
          "Normal": { name: 'Normal', plan: 0, actual: 0 },
          "Retention": { name: 'Retention', plan: 0, actual: 0 }
        };
      };

const generateIdealMonthStructure = (): string[] => {
  const months: string[] = [];
  const currentDate = new Date();
   
  // Historical: 3 months before current (readonly)
  for (let i = -3; i < 0; i++) {
    const historicalDate = new Date(currentDate);
    historicalDate.setMonth(historicalDate.getMonth() + i);
    months.push(formatMonthKey(historicalDate));
  }
  
  // Detailed: Current + Next 2 months (editable with categories)
  for (let i = 0; i < 3; i++) {
    const detailedDate = new Date(currentDate);
    detailedDate.setMonth(detailedDate.getMonth() + i);
    months.push(formatMonthKey(detailedDate));
  }
  
  // Future: Next 16 months (simple inputs) - Changed from 15 to 16
  for (let i = 3; i < 19; i++) { // Changed from 18 to 19 to get 16 months (3 to 18 = 16 months)
    const futureDate = new Date(currentDate);
    futureDate.setMonth(futureDate.getMonth() + i);
    months.push(formatMonthKey(futureDate));
  }
    return months;
};

      // ========== YEARLY COLLECTION FUNCTIONS ==========

      
  

      const createFreshCollectionStructure = (): CollectionData => {
        const idealMonths = generateIdealMonthStructure();
        const freshData: CollectionData = {};
        
        idealMonths.forEach((monthKey, index) => {
          freshData[monthKey] = {
            plan: 0,
            actual: 0,
            items: (index >= 3 && index <= 5) ? createEmptyCategories() : createSimpleCategories()
          };
        });
        
        // Initialize yearly data dynamically
        const lastMonthKey = idealMonths[idealMonths.length - 1];
        freshData.yearly = createFreshYearlyStructure(lastMonthKey);
        
        return freshData;
      };

const checkIfNeedsProgression = (collectionData: CollectionData): boolean => {
  const months = Object.keys(collectionData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
  
  if (months.length === 0) return true;

  const idealMonths = generateIdealMonthStructure();
  const firstIdealMonth = idealMonths[0];
  const firstDataMonth = months[0];
  
  // Check if monthly progression is needed
  const monthlyProgressionNeeded = firstDataMonth !== firstIdealMonth;
  
  // ALWAYS check for yearly progression, even if monthly is not needed
  const currentYear = new Date().getFullYear();
  let yearlyProgressionNeeded = false;
  
  if (collectionData.yearly) {
    const years = Object.keys(collectionData.yearly).map(y => parseInt(y)).sort();
    yearlyProgressionNeeded = years.length > 0 && years[0] < currentYear;
  } else {
    yearlyProgressionNeeded = true; // Need progression if no yearly data
  }
  
  
  
  return monthlyProgressionNeeded || yearlyProgressionNeeded;
};

      // Type guard to check if data is CollectionMonthData
      const isCollectionMonthData = (data: any): data is CollectionMonthData => {
        return data && typeof data.plan === 'number' && typeof data.actual === 'number';
      };
 

const propagateMonthValues = (collectionData: CollectionData): CollectionData => {
  const now = new Date();
  const currentMonthKey = formatMonthKey(now);
   
  const originalMonths = Object.keys(collectionData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
  const idealMonths = generateIdealMonthStructure();
  
  // Check if progression is needed (month change)
  if (originalMonths[0] === idealMonths[0]) { 
    return collectionData;
  }

  const updatedData: CollectionData = {};

  // Create new structure with ideal months
  idealMonths.forEach((monthKey, index) => {
    const existingData = collectionData[monthKey];
    if (existingData && isCollectionMonthData(existingData)) {
      updatedData[monthKey] = JSON.parse(JSON.stringify(existingData));
    } else {
      updatedData[monthKey] = {
        plan: 0,
        actual: 0,
        items: (index >= 3 && index <= 5) ? createEmptyCategories() : createSimpleCategories()
      };
    }
  });

  // Apply value propagation only when month changes
  const currentMonthIndex = idealMonths.indexOf(currentMonthKey);
  
  idealMonths.forEach((monthKey, index) => {
    const monthData = updatedData[monthKey];
    
    if (monthData && isCollectionMonthData(monthData)) {
      const isCurrentOrFuture = index >= currentMonthIndex;
      
      if (isCurrentOrFuture) {
        const oldActual = monthData.actual;
        
        // Only propagate when month changes
        monthData.plan = oldActual;  // Current actual becomes plan
        monthData.actual = 0;        // Reset actual to 0
         
        // Apply to categories
        if (monthData.items && Object.keys(monthData.items).length > 0) {
          Object.keys(monthData.items).forEach(categoryKey => {
            const category = monthData.items![categoryKey];
            const oldCategoryActual = category.actual;
            
            category.plan = oldCategoryActual;
            category.actual = 0;
          });
        }
      }
    }
  });

  // Preserve yearly data
  if (collectionData.yearly) {
    updatedData.yearly = JSON.parse(JSON.stringify(collectionData.yearly));
  }

  return updatedData;
};

      // ========== DATA LOADING FUNCTIONS ==========

      const loadProjects = async (): Promise<void> => {
        try {
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$select=Id,Title,CustomerName,GroupHead,PC,ProjectReference,ProjectManager/Title&$expand=ProjectManager`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const data: SharePointResponse<ProjectItem> = await res.json();
          const rawProjects: ProjectItem[] = data.d?.results || [];
          
          projects = Array.from(new Map(rawProjects.map((p: ProjectItem) => [p.Title, p])).values());
          
          projectSelect.innerHTML = `<option value="">Select Project</option>` + 
            projects.map(p => `<option value="${p.Id}">${p.Title}</option>`).join("");
        } catch (error) {
          console.error("Error loading projects:", error);
          toast("error", "Failed to load projects");
        }        
      };

      const loadCollections = async (): Promise<void> => {
        try {
          // Include ALL OBL breakdown fields in the $select
          const res = await fetch(
            `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?` + 
            `$select=Id,Title,Project/Id,Project/Title,ProfitCentre,OBL,CollectionData,RevenueActual,Remarks,CreatedDate,UpdatedDate,` +
            `NormalDue,NormalOverdue,RetentionDue,RetentionOverdue,GSTTDS,WHT` + // Add OBL breakdown fields
            `&$expand=Project&$top=5000`, 
            {
              headers: { Accept: "application/json;odata=verbose" }
            }
          );
          
          const data: SharePointResponse<CollectionItem> = await res.json();
          
          collections = (data.d?.results || []).map(collection => ({
            ...collection,
            CollectionData: typeof collection.CollectionData === 'string' ? 
              collection.CollectionData : 
              JSON.stringify(collection.CollectionData || {}),
            RevenueActual: typeof collection.RevenueActual === 'string' ? 
              collection.RevenueActual : 
              JSON.stringify(collection.RevenueActual || {})
          }));
            
         
          
        } catch (error) {
          console.error("Error loading collections:", error);
          toast("error", "Failed to load collections");
        }
      };

         class PerformanceOptimizer {
               private static debounceTimers: Map<string, number> = new Map();
               private static cache: Map<string, { data: any, timestamp: number }> = new Map();
       
               static debounce(key: string, fn: Function, delay: number = PERFORMANCE_CONFIG.DEBOUNCE_DELAY): void {
                 clearTimeout(this.debounceTimers.get(key));
                 this.debounceTimers.set(key, setTimeout(() => fn(), delay));
               }
       
               static cacheSet(key: string, data: any): void {
                 this.cache.set(key, {
                   data,
                   timestamp: Date.now()
                 });
               }
       
               static cacheGet(key: string): any | null {
                 const cached = this.cache.get(key);
                 if (cached && Date.now() - cached.timestamp < PERFORMANCE_CONFIG.CACHE_DURATION) {
                   return cached.data;
                 }
                 this.cache.delete(key);
                 return null;
               }
       
               static batchProcess<T>(items: T[], batchSize: number, processFn: (batch: T[]) => void): void {
                 for (let i = 0; i < items.length; i += batchSize) {
                   const batch = items.slice(i, i + batchSize);
                   setTimeout(() => processFn(batch), 0);
                 }
               }
             }
       
             // ========== DOM ELEMENTS ==========
             const elements = {
               tableBody: document.querySelector("#collectionTableBody") as HTMLElement,
               monthColumnsHeader: document.querySelector("#monthColumnsHeader") as HTMLElement,
               formSection: document.querySelector(".form-section") as HTMLElement,
               tableSection: document.querySelector(".table-section") as HTMLElement,
               showFormBtn: document.querySelector(".show-form-btn") as HTMLButtonElement,
               projectSelect: document.querySelector("#projectSelect") as HTMLSelectElement,
               form: document.querySelector("#collectionForm") as HTMLFormElement,
              //  exportBtn: document.querySelector(".export-btn") as HTMLButtonElement,
               // Add other elements as needed
             };
       
             // ========== CORE UTILITIES ==========
             const utils = {
               toast: (icon: any, title: string) => Swal.fire({ 
                 toast: true, 
                 icon, 
                 title, 
                 position: "top-end", 
                 timer: 2000, 
                 showConfirmButton: false 
               }),
       
               getDigest: async (): Promise<string> => {
                 const cached = PerformanceOptimizer.cacheGet('formDigest');
                 if (cached) return cached;
       
                 const res = await fetch(`${siteUrl}/_api/contextinfo`, { 
                   method: "POST", 
                   headers: { Accept: "application/json;odata=verbose" } 
                 });
                 const data = await res.json();
                 PerformanceOptimizer.cacheSet('formDigest', data.d.GetContextWebInformation.FormDigestValue);
                 return data.d.GetContextWebInformation.FormDigestValue;
               },
       
               safeJsonParse: (jsonString: string | undefined, fallback: any = {}): any => {
                 try {
                   if (!jsonString || jsonString.trim() === '') return fallback;
                   const cleanedString = jsonString.trim();
                   if (cleanedString === '""' || cleanedString === "null") return fallback;
                   return JSON.parse(cleanedString);
                 } catch (error) {
                   console.error("JSON parse error:", error);
                   return fallback;
                 }
               },
       
               formatNumber: (num: number): string => {
                 return num.toLocaleString();
               },
       
               getNumericValue: (input: HTMLInputElement): number => {
                 const value = input.value.trim();
                 return value === '' || value === '0' ? 0 : parseInt(value) || 0;
               },
       
               setNumericValue: (input: HTMLInputElement, value: number): void => {
                 if (value === 0) {
                   input.value = '';
                   input.className = input.className.replace('input-with-value', 'input-empty');
                 } else {
                   input.value = value.toString();
                   input.className = input.className.replace('input-empty', 'input-with-value');
                 }
               }
             };
       
             // ========== DATA MANAGEMENT ==========
             class DataManager {
               private static instance: DataManager;
       
               static getInstance(): DataManager {
                 if (!DataManager.instance) {
                   DataManager.instance = new DataManager();
                 }
                 return DataManager.instance;
               }
       
               async loadProjects(): Promise<ProjectItem[]> {
                 const cacheKey = 'projects_data';
                 const cached = PerformanceOptimizer.cacheGet(cacheKey);
                 if (cached) {
                   projects = cached;
                   return projects;
                 }
       
                 try {
                   const res = await fetch(
                     `${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$select=Id,Title,CustomerName,GroupHead,PC,ProjectReference,ProjectManager/Title&$expand=ProjectManager&$top=5000`,
                     { headers: { Accept: "application/json;odata=verbose" } }
                   );
                   
                   const data: SharePointResponse<ProjectItem> = await res.json();
                   const rawProjects: ProjectItem[] = data.d?.results || [];
                   
                   projects = Array.from(new Map(rawProjects.map((p: ProjectItem) => [p.Title, p])).values());
                   PerformanceOptimizer.cacheSet(cacheKey, projects);
                   
                   return projects;
                 } catch (error) {
                   console.error("Error loading projects:", error);
                   utils.toast("error", "Failed to load projects");
                   return [];
                 }
               }
       
               async loadCollections(): Promise<CollectionItem[]> {
                 const cacheKey = 'collections_data';
                 const cached = PerformanceOptimizer.cacheGet(cacheKey);
                 if (cached) {
                   collections = cached;
                   return collections;
                 }
       
                 try {
                   const res = await fetch(
                     `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?` + 
                     `$select=Id,Title,Project/Id,Project/Title,ProfitCentre,OBL,CollectionData,RevenueActual,Remarks,CreatedDate,UpdatedDate,` +
                     `NormalDue,NormalOverdue,RetentionDue,RetentionOverdue,GSTTDS,WHT` +
                     `&$expand=Project&$top=50000`,
                     { headers: { Accept: "application/json;odata=verbose" } }
                   );
                   
                   const data: SharePointResponse<CollectionItem> = await res.json();
                   
                   collections = (data.d?.results || []).map(collection => ({
                     ...collection,
                     CollectionData: typeof collection.CollectionData === 'string' ? 
                       collection.CollectionData : 
                       JSON.stringify(collection.CollectionData || {}),
                     RevenueActual: typeof collection.RevenueActual === 'string' ? 
                       collection.RevenueActual : 
                       JSON.stringify(collection.RevenueActual || {})
                   }));
       
                   PerformanceOptimizer.cacheSet(cacheKey, collections);
                   return collections;
                 } catch (error) {
                   console.error("Error loading collections:", error);
                   utils.toast("error", "Failed to load collections");
                   return [];
                 }
               }
       
               async loadDataInBatches(): Promise<void> {
                 await Promise.all([
                   this.loadProjects(),
                   this.loadCollections()
                 ]);
               }
             }
       
             // ========== TABLE RENDERER WITH VIRTUAL SCROLLING ==========
             class TableRenderer {
               private visibleStartIndex = 0;
               private visibleEndIndex = PERFORMANCE_CONFIG.MAX_TABLE_ROWS;
               private rowHeight = 40;
       
               constructor() {
                 this.setupVirtualScrolling();
               }
       
               private setupVirtualScrolling(): void {
                 const tableContainer = document.querySelector('.table-scroll-container') as HTMLElement;
                 if (!tableContainer) return;
       
                 tableContainer.addEventListener('scroll', () => {
                   PerformanceOptimizer.debounce('virtualScroll', () => {
                     this.handleScroll(tableContainer);
                   }, 50);
                 });
               }
       
               private handleScroll(container: HTMLElement): void {
                 const scrollTop = container.scrollTop;
                 this.visibleStartIndex = Math.floor(scrollTop / this.rowHeight);
                 this.visibleEndIndex = this.visibleStartIndex + PERFORMANCE_CONFIG.MAX_TABLE_ROWS;
                 
                 if (filteredData.length > PERFORMANCE_CONFIG.VIRTUAL_SCROLL_THRESHOLD) {
                   this.renderVisibleRows();
                 }
               }
       
               private renderVisibleRows(): void {
                 const visibleData = filteredData.slice(this.visibleStartIndex, this.visibleEndIndex);
                 // Render only visible rows
                 this.renderTableBody(visibleData, this.visibleStartIndex);
               }
       
               renderTableWithMonthColumns(data: CollectionItem[], startIndex: number = 0): void {
                 if (data.length === 0) {
                   elements.tableBody.innerHTML = `<tr><td colspan="21" style="text-align:center;padding:20px;">No records found</td></tr>`;
                   return;
                 }
       
                 if (data.length > PERFORMANCE_CONFIG.VIRTUAL_SCROLL_THRESHOLD) {
                   this.renderVirtualTable(data, startIndex);
                 } else {
                   this.renderFullTable(data);
                 }
               }
       
               private renderVirtualTable(data: CollectionItem[], startIndex: number): void {
                 const visibleData = data.slice(startIndex, startIndex + PERFORMANCE_CONFIG.MAX_TABLE_ROWS);
                 this.renderTableBody(visibleData, startIndex);
                 
                 // Set table height for proper scrolling
                 const totalHeight = data.length * this.rowHeight;
                 elements.tableBody.style.height = `${totalHeight}px`;
               }
       
               private renderFullTable(data: CollectionItem[]): void {
                 this.renderTableBody(data, 0);
                 elements.tableBody.style.height = 'auto';
               }
       
               private renderTableBody(data: CollectionItem[], startIndex: number): void {
                 const displayMonths = this.getDisplayMonths();
                 const projectGroups = this.groupByProject(data);
                 const sortedProjectTitles = this.sortProjectGroups(projectGroups);
       
                 let html = '';
                 let currentIndex = startIndex;
       
                 sortedProjectTitles.forEach(projectTitle => {
                   const projectCollections = projectGroups[projectTitle];
                   const proj = projects.find(p => p.Title === projectTitle);
                   
                   const rowspan = projectCollections.length;
                   const projectRow = this.renderProjectRow(projectTitle, proj, projectCollections, rowspan, displayMonths, currentIndex);
                   html += projectRow;
                   
                   currentIndex += rowspan;
                 });
       
                 elements.tableBody.innerHTML = html;
                 this.attachTableEventListeners();
               }
       
               private renderProjectRow(
                 projectTitle: string, 
                 proj: ProjectItem | undefined, 
                 collections: CollectionItem[], 
                 rowspan: number, 
                 displayMonths: string[], 
                 startIndex: number
               ): string {
                 
                 const selectedYear = (document.querySelector("#filterYear") as HTMLSelectElement).value;
                 const selectedMonth = (document.querySelector("#filterMonth") as HTMLSelectElement).value;
                 const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
       
                 const totalReceivable = collections.reduce((sum, col) => sum + (col.OBL || 0), 0);
                 const totalCollection = selectedMonthKey ? 
                   collections.reduce((sum, col) => {
                     const revenueData = utils.safeJsonParse(col.RevenueActual, {});
                     return sum + (revenueData[selectedMonthKey] || 0);
                   }, 0) : 0;
       
                 return `
                   <tr data-project="${projectTitle}" data-index="${startIndex}">
                     <td rowspan="${rowspan}" class="project-info-cell">${proj?.ProjectReference || "-"}</td>
                     <td rowspan="${rowspan}" class="project-info-cell">${projectTitle}</td>
                     <td rowspan="${rowspan}" class="project-info-cell">${proj?.CustomerName || "-"}</td>
                     <td rowspan="${rowspan}" class="project-info-cell">${typeof proj?.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-"}</td>
                     <td rowspan="${rowspan}" class="project-info-cell">${proj?.GroupHead || "-"}</td>
                     <td rowspan="${rowspan}" class="project-info-cell receivable-cell">${utils.formatNumber(totalReceivable)}</td>
                     <td rowspan="${rowspan}" class="project-info-cell collection-cell">${utils.formatNumber(totalCollection)}</td>
                     ${displayMonths.map(monthKey => this.renderMonthColumns(collections[0], monthKey)).join('')}
                     <td rowspan="${rowspan}" class="actions-cell">
                       <div class="action-buttons-container">
                         ${collections.map((collection, idx) => 
                           `<button class="edit-action-btn" data-id="${collection.Id}" title="Edit Collection ${idx + 1}">
                             <span class="edit-icon">✏️</span>
                             <span class="edit-text">Edit</span>
                           </button>`
                         ).join('')}
                       </div>
                     </td>      
                   </tr>
                 `;
               }
       
               private renderMonthColumns(collection: CollectionItem, monthKey: string): string {
                 const collectionData = utils.safeJsonParse(collection?.CollectionData, {});
                 const monthData = collectionData[monthKey] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
                 const items = monthData.items || {};
                 
                 const normalPlan = (items.Normal?.plan || 0) + (items['Normal Overdue']?.plan || 0);
                 const retentionPlan = (items.Retention?.plan || 0) + (items['Retention Overdue']?.plan || 0);
                 const totalPlan = monthData.plan;
                 const normalActual = (items.Normal?.actual || 0) + (items['Normal Overdue']?.actual || 0);
                 const retentionActual = (items.Retention?.actual || 0) + (items['Retention Overdue']?.actual || 0);
                 const totalActual = monthData.actual;
                 
                 return `
                   <!-- Previous - Normal, Retention, Total -->
                   <td class="month-data-cell">${utils.formatNumber(normalPlan)}</td>
                   <td class="month-data-cell">${utils.formatNumber(retentionPlan)}</td>
                   <td class="month-data-cell total-cell">${utils.formatNumber(totalPlan)}</td>
                   <!-- Current - Normal, Retention, Total -->
                   <td class="month-data-cell">${utils.formatNumber(normalActual)}</td>
                   <td class="month-data-cell">${utils.formatNumber(retentionActual)}</td>
                   <td class="month-data-cell total-cell">${utils.formatNumber(totalActual)}</td>
                 `;
               }
       
               private groupByProject(data: CollectionItem[]): { [projectTitle: string]: CollectionItem[] } {
                 const groups: { [projectTitle: string]: CollectionItem[] } = {};
                 data.forEach(collection => {
                   const projectTitle = collection.Project?.Title || "-";
                   if (!groups[projectTitle]) {
                     groups[projectTitle] = [];
                   }
                   groups[projectTitle].push(collection);
                 });
                 return groups;
               }
       
               private sortProjectGroups(projectGroups: { [projectTitle: string]: CollectionItem[] }): string[] {
                 const projectTitles = Object.keys(projectGroups);
                 
                 if (!currentSortConfig.column) {
                   return projectTitles.sort();
                 }
       
                 return projectTitles.sort((a, b) => {
                   let valueA: any = 0;
                   let valueB: any = 0;
       
                   // Sorting logic based on currentSortConfig
                   // Implementation similar to your existing sort logic
                   // Optimized for performance
                   return this.compareValues(valueA, valueB);
                 });
               }
       
               private compareValues(a: any, b: any): number {
                 if (typeof a === 'number' && typeof b === 'number') {
                   return currentSortConfig.direction === 'asc' ? a - b : b - a;
                 } else {
                   const strA = String(a).toLowerCase();
                   const strB = String(b).toLowerCase();
                   return currentSortConfig.direction === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
                 }
               }
       
               private getDisplayMonths(): string[] {
                 const now = new Date();
                 const months: string[] = [];
                 for (let i = 0; i < 3; i++) {
                   const month = new Date(now.getFullYear(), now.getMonth() + i, 1);
                   months.push(this.formatMonthKey(month));
                 }
                 return months;
               }
       
               private formatMonthKey(date: Date): string {
                 return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
               }
       
               private attachTableEventListeners(): void {
                 elements.tableBody.querySelectorAll(".edit-action-btn").forEach(btn => {
                   btn.addEventListener("click", (e) => {
                     const button = e.currentTarget as HTMLButtonElement;
                     const id = parseInt(button.dataset.id!);
                     if (id && !isNaN(id)) {
                       this.editCollection(id);
                     }
                   });
                 });
               }
       
               private editCollection(id: number): void {
                 // Edit collection logic 
               }
             }
       
             // ========== PAGINATION MANAGER ==========
             class PaginationManager {
               updatePagination(): void {
                 totalPages = Math.ceil(filteredData.length / pageSize);
                 
                 if (currentPage > totalPages && totalPages > 0) {
                   currentPage = totalPages;
                 } else if (totalPages === 0) {
                   currentPage = 1;
                 }
                 
                 this.updatePaginationControls();
                 this.renderCurrentPage();
               }
       
               private updatePaginationControls(): void {
                 const currentPageSpan = document.querySelector("#currentPage") as HTMLSpanElement;
                 const totalPagesSpan = document.querySelector("#totalPages") as HTMLSpanElement;
                 const startItemSpan = document.querySelector("#startItem") as HTMLSpanElement;
                 const endItemSpan = document.querySelector("#endItem") as HTMLSpanElement;
                 const totalItemsSpan = document.querySelector("#totalItems") as HTMLSpanElement;
                 const dataSizeInfo = document.querySelector("#dataSizeInfo") as HTMLSpanElement;
       
                 currentPageSpan.textContent = currentPage.toString();
                 totalPagesSpan.textContent = totalPages.toString();
                 
                 const startItem = totalPages > 0 ? (currentPage - 1) * pageSize + 1 : 0;
                 const endItem = Math.min(currentPage * pageSize, filteredData.length);
                 
                 startItemSpan.textContent = utils.formatNumber(startItem);
                 endItemSpan.textContent = utils.formatNumber(endItem);
                 totalItemsSpan.textContent = utils.formatNumber(filteredData.length);
                 
                 // Update data size info
                 dataSizeInfo.textContent = `Total: ${utils.formatNumber(collections.length)} records`;
                 
                 this.updateButtonStates();
                 this.updatePageNumbers();
               }
       
               private updateButtonStates(): void {
                 const firstPageBtn = document.querySelector("#firstPage") as HTMLButtonElement;
                 const prevPageBtn = document.querySelector("#prevPage") as HTMLButtonElement;
                 const nextPageBtn = document.querySelector("#nextPage") as HTMLButtonElement;
                 const lastPageBtn = document.querySelector("#lastPage") as HTMLButtonElement;
       
                 firstPageBtn.disabled = currentPage === 1 || totalPages === 0;
                 prevPageBtn.disabled = currentPage === 1 || totalPages === 0;
                 nextPageBtn.disabled = currentPage === totalPages || totalPages === 0;
                 lastPageBtn.disabled = currentPage === totalPages || totalPages === 0;
               }
       
               private updatePageNumbers(): void {
                 const pageNumbersDiv = document.querySelector("#pageNumbers") as HTMLDivElement;
                 pageNumbersDiv.innerHTML = '';
                 
                 if (totalPages === 0) return;
                 
                 const maxVisiblePages = 5;
                 let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
                 let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
                 
                 if (endPage - startPage + 1 < maxVisiblePages) {
                   startPage = Math.max(1, endPage - maxVisiblePages + 1);
                 }
                 
                 if (startPage > 1) {
                   this.addPageButton(1, pageNumbersDiv);
                   if (startPage > 2) {
                     this.addEllipsis(pageNumbersDiv);
                   }
                 }
                 
                 for (let i = startPage; i <= endPage; i++) {
                   this.addPageButton(i, pageNumbersDiv);
                 }
                 
                 if (endPage < totalPages) {
                   if (endPage < totalPages - 1) {
                     this.addEllipsis(pageNumbersDiv);
                   }
                   this.addPageButton(totalPages, pageNumbersDiv);
                 }
               }
       
               private addPageButton(page: number, container: HTMLDivElement): void {
                 const pageBtn = document.createElement('button');
                 pageBtn.className = `page-number ${page === currentPage ? 'active' : ''}`;
                 pageBtn.textContent = page.toString();
                 pageBtn.addEventListener('click', () => this.goToPage(page));
                 container.appendChild(pageBtn);
               }
       
               private addEllipsis(container: HTMLDivElement): void {
                 const ellipsis = document.createElement('span');
                 ellipsis.className = 'pagination-ellipsis';
                 ellipsis.textContent = '...';
                 ellipsis.style.padding = '8px 6px';
                 ellipsis.style.color = '#666';
                 container.appendChild(ellipsis);
               }
       
               goToPage(page: number): void {
                 if (page < 1 || page > totalPages || page === currentPage || totalPages === 0) return;
                 
                 currentPage = page;
                 this.updatePagination();
                 
                 // Smooth scroll to top
                 const tableSection = document.querySelector('.table-section') as HTMLElement;
                 if (tableSection) {
                   tableSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                 }
               }
       
               renderCurrentPage(): void {
                 const startIndex = (currentPage - 1) * pageSize;
                 const endIndex = Math.min(startIndex + pageSize, filteredData.length);
                 const pageData = filteredData.slice(startIndex, endIndex);
                 
                 const tableRenderer = new TableRenderer();
                 tableRenderer.renderTableWithMonthColumns(pageData);
               }
             }
       
             // ========== FILTER MANAGER ==========
             class FilterManager {
               private filterState = {
                 year: '',
                 month: '',
                 project: '',
                 customer: '',
                 projectManager: '',
                 groupHead: '',
                 projectReference: ''
               };
       
               initializeFilters(): void {
                 this.initializeYearFilter();
                 this.initializeMonthFilter();
                 this.initializeProjectFilters();
                 this.attachFilterListeners();
               }
       
               private initializeYearFilter(): void {
                 const filterYear = document.querySelector("#filterYear") as HTMLSelectElement;
                 const currentYear = new Date().getFullYear();
                 
                 filterYear.innerHTML = '<option value="">All Years</option>';
                 for (let year = currentYear - 1; year <= currentYear + 2; year++) {
                   const selected = year === currentYear ? 'selected' : '';
                   filterYear.innerHTML += `<option value="${year}" ${selected}>${year}</option>`;
                 }
               }
       
               private initializeMonthFilter(): void {
                 const filterMonth = document.querySelector("#filterMonth") as HTMLSelectElement;
                 const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                 const currentMonth = new Date().getMonth() + 1;
                 
                 filterMonth.innerHTML = '<option value="">All Months</option>';
                 for (let month = 1; month <= 12; month++) {
                   const selected = month === currentMonth ? 'selected' : '';
                   filterMonth.innerHTML += `<option value="${month}" ${selected}>${monthNames[month - 1]}</option>`;
                 }
               }
       
               private initializeProjectFilters(): void {
                 this.updateProjectReferenceFilter();
                 this.updateProjectFilter();
                 this.updateCustomerFilter();
                 this.updateProjectManagerFilter();
                 this.updateGroupHeadFilter();
               }
       
               private updateProjectReferenceFilter(): void {
                 const filter = document.querySelector("#filterProjectReference") as HTMLSelectElement;
                 const uniqueReferences = [...new Set(projects.map(p => p.ProjectReference).filter(Boolean))].sort();
                 filter.innerHTML = '<option value="">All References</option>' + 
                   uniqueReferences.map(ref => `<option value="${ref}">${ref}</option>`).join("");
               }
       
               private updateProjectFilter(): void {
                 const filter = document.querySelector("#filterProject") as HTMLSelectElement;
                 const uniqueProjects = [...new Set(collections.map(f => f.Project?.Title).filter(Boolean))].sort();
                 filter.innerHTML = '<option value="">All Projects</option>' + 
                   uniqueProjects.map(project => `<option value="${project}">${project}</option>`).join("");
               }
       
               private updateCustomerFilter(): void {
                 const filter = document.querySelector("#filterCustomer") as HTMLSelectElement;
                 const uniqueCustomers = [...new Set(projects.map(p => p.CustomerName).filter(Boolean))].sort();
                 filter.innerHTML = '<option value="">All Customers</option>' + 
                   uniqueCustomers.map(customer => `<option value="${customer}">${customer}</option>`).join("");
               }
       
               private updateProjectManagerFilter(): void {
                 const filter = document.querySelector("#filterProjectManager") as HTMLSelectElement;
                 const uniqueManagers = [...new Set(projects.map(p => {
                   if (typeof p.ProjectManager === 'object') return p.ProjectManager?.Title;
                   return p.ProjectManager;
                 }).filter(Boolean))].sort();
                 filter.innerHTML = '<option value="">All Managers</option>' + 
                   uniqueManagers.map(manager => `<option value="${manager}">${manager}</option>`).join("");
               }
       
               private updateGroupHeadFilter(): void {
                 const filter = document.querySelector("#filterGroupHead") as HTMLSelectElement;
                 const uniqueGroupHeads = [...new Set(projects.map(p => p.GroupHead).filter(Boolean))].sort();
                 filter.innerHTML = '<option value="">All Group Heads</option>' + 
                   uniqueGroupHeads.map(head => `<option value="${head}">${head}</option>`).join("");
               }
       
               private attachFilterListeners(): void {
                 const filters = [
                   'filterYear', 'filterMonth', 'filterProject', 'filterCustomer',
                   'filterProjectManager', 'filterGroupHead', 'filterProjectReference'
                 ];
       
                 filters.forEach(filterId => {
                   const element = document.querySelector(`#${filterId}`) as HTMLSelectElement;
                   element.addEventListener('change', () => {
                     PerformanceOptimizer.debounce('filterTable', () => {
                       this.applyFilters();
                     });
                   });
                 });
               }
       
               private applyFilters(): void {
                 this.updateFilterState();
                 
                 PerformanceOptimizer.batchProcess(collections, PERFORMANCE_CONFIG.BATCH_SIZE, (batch) => {
                   const filteredBatch = batch.filter(collection => this.matchesFilters(collection));
                   filteredData.push(...filteredBatch);
                 });
       
                 // Reset to first page when filtering
                 currentPage = 1;
                 const paginationManager = new PaginationManager();
                 paginationManager.updatePagination();
               }
       
               private updateFilterState(): void {
                 this.filterState = {
                   year: (document.querySelector("#filterYear") as HTMLSelectElement).value,
                   month: (document.querySelector("#filterMonth") as HTMLSelectElement).value,
                   project: (document.querySelector("#filterProject") as HTMLSelectElement).value,
                   customer: (document.querySelector("#filterCustomer") as HTMLSelectElement).value,
                   projectManager: (document.querySelector("#filterProjectManager") as HTMLSelectElement).value,
                   groupHead: (document.querySelector("#filterGroupHead") as HTMLSelectElement).value,
                   projectReference: (document.querySelector("#filterProjectReference") as HTMLSelectElement).value
                 };
               }
       
               private matchesFilters(collection: CollectionItem): boolean {
                 let matches = true;
                 
                 // Year and Month filter
                 if (this.filterState.year && this.filterState.month) {
                   const selectedMonthKey = `${this.filterState.year}-${this.filterState.month.padStart(2, "0")}`;
                   const data: CollectionData = utils.safeJsonParse(collection.CollectionData, {});
                   const hasMonthData = Object.keys(data).some(key => 
                     key.match(/^\d{4}-\d{2}$/) && key === selectedMonthKey
                   );
                   if (!hasMonthData) matches = false;
                 }
                 
                 // Project filter
                 if (this.filterState.project && collection.Project?.Title !== this.filterState.project) {
                   matches = false;
                 }
                 
                 // Customer filter
                 if (this.filterState.customer) {
                   const proj = projects.find(p => p.Title === collection.Project?.Title);
                   if (!proj || proj.CustomerName !== this.filterState.customer) {
                     matches = false;
                   }
                 }
                 
                 // Project Manager filter
                 if (this.filterState.projectManager) {
                   const proj = projects.find(p => p.Title === collection.Project?.Title);
                   const managerName = typeof proj?.ProjectManager === 'object' ? proj.ProjectManager?.Title : proj?.ProjectManager;
                   if (!managerName || managerName !== this.filterState.projectManager) {
                     matches = false;
                   }
                 }
                 
                 // Group Head filter
                 if (this.filterState.groupHead) {
                   const proj = projects.find(p => p.Title === collection.Project?.Title);
                   if (!proj || proj.GroupHead !== this.filterState.groupHead) {
                     matches = false;
                   }
                 }
                 
                 // Project Reference filter
                 if (this.filterState.projectReference) {
                   const proj = projects.find(p => p.Title === collection.Project?.Title);
                   if (!proj || proj.ProjectReference !== this.filterState.projectReference) {
                     matches = false;
                   }
                 }
                 
                 return matches;
               }
       
               clearFilters(): void {
                 const filters = [
                   'filterYear', 'filterMonth', 'filterProject', 'filterCustomer',
                   'filterProjectManager', 'filterGroupHead', 'filterProjectReference'
                 ];
       
                 filters.forEach(filterId => {
                   const element = document.querySelector(`#${filterId}`) as HTMLSelectElement;
                   element.value = "";
                 });
       
                 currentPage = 1;
                 filteredData = [...collections];
                 
                 const paginationManager = new PaginationManager();
                 paginationManager.updatePagination();
                 
                 utils.toast("info", "All filters cleared");
               }
             }
       
             // ========== INITIALIZATION ==========
             class AppInitializer {
               private dataManager = DataManager.getInstance();
               private filterManager = new FilterManager();
               private paginationManager = new PaginationManager();
       
               async initialize(): Promise<void> {
                 try {
                   utils.toast("info", "Loading data...");
                   
                   await this.dataManager.loadDataInBatches();
                   
                   this.filterManager.initializeFilters();
                   
                   // Initial data setup
                   filteredData = [...collections];
                   this.paginationManager.updatePagination();
                   
                   this.attachEventListeners();
                   
                   utils.toast("success", "Application loaded successfully");
                   
                 } catch (error) {
                   console.error("Initialization error:", error);
                   utils.toast("error", "Failed to initialize application");
                 }
               }
       
               private attachEventListeners(): void {
                 // Page size change
                 const pageSizeSelect = document.querySelector("#pageSize") as HTMLSelectElement;
                 pageSizeSelect.addEventListener('change', (e) => {
                   const newSize = parseInt((e.target as HTMLSelectElement).value);
                   if (newSize !== pageSize) {
                     pageSize = newSize;
                     currentPage = 1;
                     this.paginationManager.updatePagination();
                     utils.toast("info", `Now showing ${pageSize} records per page`);
                   }
                 });
       
                 // Clear filters
                 const clearFiltersBtn = document.querySelector(".clear-filters-btn") as HTMLButtonElement;
                 clearFiltersBtn.addEventListener('click', () => {
                   this.filterManager.clearFilters();
                 });
       
                 // Pagination buttons
                 const firstPageBtn = document.querySelector("#firstPage") as HTMLButtonElement;
                 const prevPageBtn = document.querySelector("#prevPage") as HTMLButtonElement;
                 const nextPageBtn = document.querySelector("#nextPage") as HTMLButtonElement;
                 const lastPageBtn = document.querySelector("#lastPage") as HTMLButtonElement;
       
                 firstPageBtn.addEventListener("click", () => this.paginationManager.goToPage(1));
                 prevPageBtn.addEventListener("click", () => this.paginationManager.goToPage(currentPage - 1));
                 nextPageBtn.addEventListener("click", () => this.paginationManager.goToPage(currentPage + 1));
                 lastPageBtn.addEventListener("click", () => this.paginationManager.goToPage(totalPages));
       
                 // Export functionality
                 const exportBtn = document.querySelector(".export-btn") as HTMLButtonElement;
                 exportBtn.addEventListener('click', () => {
                   this.exportToExcel();
                 });
               }
       
               private exportToExcel(): void {
                 // Your existing export logic with performance optimizations
                
               }
             }
       
             // ========== START APPLICATION ==========
             const app = new AppInitializer();
             await app.initialize();
      // ========== EXPORT FUNCTIONS ==========

      const getMonthName = (monthNumber: string): string => {
        const months = [
          "Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        return months[parseInt(monthNumber) - 1] || "Month";
      };

      
 const exportToExcelWithFullStyle = (): void => {  
  
  const selectedYear = filterYear.value;
  const selectedMonth = filterMonth.value;
  
  if (!selectedYear || !selectedMonth) {
    toast("error", "Please select year and month to export");
    return;
  }

  const currentExportData = filteredData.length > 0 ? filteredData : collections;
  
  if (currentExportData.length === 0) {
    toast("error", "No data available to export");
    return;
  }

  try {
    const headerData = generateSelectedMonthHeaders(selectedYear, selectedMonth, currentExportData);
    const allMonthsAfterSelected = headerData.allMonthsAfterSelected;
    const nextFourYears = headerData.nextFourYears;
     
    // Prepare data for Excel
    const excelData = currentExportData.map(collection => {
      const projectTitle = collection.Project?.Title || "-";
      const proj = projects.find(p => p.Title === projectTitle);
      
      // Parse data from CollectionData
      const collectionData: CollectionData = safeJsonParse(collection.CollectionData, {});
      
      // Get OBL breakdown data using CORRECT field names
      const oblBreakdown = getOBLBreakdownForExport(collection);

      
      // Safer calculation with number conversion
      const safeOblTotal = Number(oblBreakdown.normalDue || 0) + 
                          Number(oblBreakdown.normalOverdue || 0) + 
                          Number(oblBreakdown.retentionDue || 0) + 
                          Number(oblBreakdown.retentionOverdue || 0) + 
                          Number(oblBreakdown.gstTds || 0) + 
                          Number(oblBreakdown.wht || 0);

       
      // Create row data with CORRECTED sequence
      const rowData: any = {
        // CORRECTED SEQUENCE:
        "Project Reference": proj?.ProjectReference || "-",
        "Project Name": projectTitle,
        "PC": collection.ProfitCentre || "-",
        "Customer Name": proj?.CustomerName || "-",
        "Group Head": proj?.GroupHead || "-",
        "Project Manager": typeof proj?.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-",
        "Normal Due": oblBreakdown.normalDue || 0,
        "Normal Overdue": oblBreakdown.normalOverdue || 0,
        "Retention Due": oblBreakdown.retentionDue || 0,
        "Retention Overdue": oblBreakdown.retentionOverdue || 0,
        "GST-TDS": oblBreakdown.gstTds || 0,
        "WHT": oblBreakdown.wht || 0,
        "Total (normal to wht)": safeOblTotal,
      };
      
      // Add individual months AFTER selected month (both plan and current values)
      allMonthsAfterSelected.forEach(monthKey => {
        const [year, month] = monthKey.split('-');
        const monthLabel = getMonthName(month);
        const displayLabel = `${monthLabel} ${year}`;
        
        const collectionMonthData = collectionData[monthKey] as CollectionMonthData || { plan: 0, actual: 0 };
        const collectionPlan = collectionMonthData.plan || 0;
        const collectionCurrent = collectionMonthData.actual || 0;
        
        rowData[`${displayLabel} (P)`] = collectionPlan;
        rowData[`${displayLabel} (C)`] = collectionCurrent;
      });
      
      // ADD NEXT 4 YEARS DATA starting from selected year (both plan and current values)
      nextFourYears.forEach(year => {
        const yearData = collectionData.yearly?.[year] || { plan: 0, actual: 0 };
        rowData[`${year} (P)`] = yearData.plan || 0;
        rowData[`${year} (C)`] = yearData.actual || 0;
      });

      // Calculate balance: Total (normal to wht) - Sum of ALL month current values shown in Excel
      let totalExcelMonthCurrent = 0;

      // Add individual months AFTER selected month current values
      allMonthsAfterSelected.forEach(monthKey => {
        const collectionMonthData = collectionData[monthKey] as CollectionMonthData || { plan: 0, actual: 0 };
        const collectionCurrent = collectionMonthData.actual || 0;
        totalExcelMonthCurrent += Number(collectionCurrent);
      });

      // Add yearly current values
      nextFourYears.forEach(year => {
        const yearData = collectionData.yearly?.[year] || { plan: 0, actual: 0 };
        totalExcelMonthCurrent += Number(yearData.actual || 0);
      });
 
      rowData["Balance"] = safeOblTotal - totalExcelMonthCurrent;
      
      return rowData;
    });

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(excelData, { header: headerData.headers });

    // Apply styles
    const headerStyle = {
      fill: { fgColor: { rgb: "FF0078D4" } },
      font: { name: "Arial", sz: 10, bold: true, color: { rgb: "FFFFFFFF" } },
      alignment: { horizontal: "center", vertical: "center" },
      border: {
        top: { style: "thin", color: { rgb: "FF000000" } },
        left: { style: "thin", color: { rgb: "FF000000" } },
        bottom: { style: "thin", color: { rgb: "FF000000" } },
        right: { style: "thin", color: { rgb: "FF000000" } }
      }
    };

    const dataStyle = {
      font: { name: "Arial", sz: 10 },
      alignment: { horizontal: "center", vertical: "center" },
      border: {
        top: { style: "thin", color: { rgb: "FFD0D0D0" } },
        left: { style: "thin", color: { rgb: "FFD0D0D0" } },
        bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
        right: { style: "thin", color: { rgb: "FFD0D0D0" } }
      }
    };

    const numberStyle = {
      ...dataStyle,
      alignment: { horizontal: "right", vertical: "center" }
    };

    // Apply styles to all cells
    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
    
    // Style header row
    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      if (!ws[cellAddress]) continue;
      
      if (!ws[cellAddress].s) ws[cellAddress].s = {};
      ws[cellAddress].s = headerStyle;
    }
    
    // Style data rows
    for (let row = range.s.r + 1; row <= range.e.r; row++) {
      for (let col = range.s.c; col <= range.e.c; col++) {
        const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
        if (!ws[cellAddress]) continue;
        
        // Determine if this is a number column (starting from Normal Due column)
        const isNumberColumn = col >= 6;
        const styleToApply = isNumberColumn ? numberStyle : dataStyle;
        
        if (!ws[cellAddress].s) ws[cellAddress].s = {};
        ws[cellAddress].s = styleToApply;
      }
    }

    // Set column widths
    const colWidths = headerData.headers.map((header: string) => {
      if (header.includes('Project Name')) return { wch: 25 };
      if (header.includes('Customer Name')) return { wch: 20 };
      if (header.includes('Project Reference')) return { wch: 15 };
      if (header.includes('Group Head') || header.includes('Project Manager')) return { wch: 15 };
      if (header.includes('PC') || header.includes('Profit Centre')) return { wch: 12 };
      if (header.includes('Normal Due') || header.includes('Normal Overdue') || 
          header.includes('Retention Due') || header.includes('Retention Overdue')) return { wch: 12 };
      if (header.includes('GST-TDS')) return { wch: 12 };
      if (header.includes('WHT')) return { wch: 10 };
      if (header.includes('Total (normal to wht)') || header.includes('Balance')) return { wch: 15 };
      if (header.includes('(P)') || header.includes('(C)')) return { wch: 10 };
      if (header.length <= 3) return { wch: 8 };
      return { wch: 10 };
    });
    ws['!cols'] = colWidths;

    // Freeze header row
    ws['!freeze'] = { x: 0, y: 1 };

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, "Collection");

    // Generate filename and export
    const monthName = getMonthName(selectedMonth);
    const fileName = `Collection_${monthName}_${selectedYear}_Detailed.xlsx`;
    
    XLSX.writeFile(wb, fileName);
      
    toast("success", `Exported ${currentExportData.length} records for ${monthName} ${selectedYear}`);
    
  } catch (error) {
    console.error("❌ Error during styled Excel export:", error);
    toast("error", "Failed to export data to Excel");
  }
};
 
const generateSelectedMonthHeaders = (selectedYear: string, selectedMonth: string, exportData: CollectionItem[]) => {
  // CORRECTED: New column sequence
  const baseHeaders = [
    "Project Reference",  // Moved to first
    "Project Name",       // Moved to second  
    "PC",                 // Moved to third
    "Customer Name",      // Moved to fourth
    "Group Head", 
    "Project Manager", 
    "Normal Due", 
    "Normal Overdue", 
    "Retention Due", 
    "Retention Overdue", 
    "GST-TDS", 
    "WHT", 
    "Total (normal to wht)"
  ];
  
  const allMonthKeys = new Set<string>();
  
  exportData.forEach(collection => {
    const collectionData = safeJsonParse(collection.CollectionData, {});
    
    Object.keys(collectionData).forEach(key => {
      if (key && key.match(/^\d{4}-\d{2}$/)) {
        allMonthKeys.add(key);
      }
    });
  });
  
  const sortedMonthKeys = Array.from(allMonthKeys).sort();
  const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
  
  // Get months after selected month (EXCLUDING selected month)
  const allMonthsAfterSelected = sortedMonthKeys.filter(monthKey => monthKey > selectedMonthKey);
  
  const individualMonthHeaders: string[] = [];
  allMonthsAfterSelected.forEach(monthKey => {
    const [year, month] = monthKey.split('-');
    const monthLabel = getMonthName(month);
    const displayLabel = `${monthLabel} ${year}`;
    individualMonthHeaders.push(`${displayLabel} (P)`, `${displayLabel} (C)`);
  });
  
  // Get the year from the LAST month in the headers
  let lastMonthYear = selectedYear;
  
  if (allMonthsAfterSelected.length > 0) {
    const lastMonthKey = allMonthsAfterSelected[allMonthsAfterSelected.length - 1];
    lastMonthYear = lastMonthKey.split('-')[0];
  }
  
  // Use the last month year to generate next 4 years
  const nextFourYears = getNextFourYears(lastMonthYear);
  const yearlyHeaders: string[] = [];
  nextFourYears.forEach(year => {
    yearlyHeaders.push(`${year} (P)`, `${year} (C)`);
  });
  
  // CORRECTED: Headers WITHOUT selected month columns
  const finalHeaders = [
    ...baseHeaders,
    ...individualMonthHeaders, // Only months after selected month (NO Nov 2025)
    ...yearlyHeaders,
    "Balance"
  ];
  
  return { 
    headers: finalHeaders, 
    allMonthsAfterSelected,
    nextFourYears
  };
};

const getNextFourYears = (lastMonthYear: string): string[] => {
  const startYear = parseInt(lastMonthYear);
  const years: string[] = [];
  
  // Generate 4 years: last month year + next 3 years
  for (let i = 0; i < 4; i++) {
    years.push((startYear + i).toString());
  }
   
  return years;
};



const diagnoseSharePointFields = async (): Promise<void> => {
  try { 
    const response = await fetch(
      `${siteUrl}/_api/web/lists/getbytitle('${listName}')/fields`,
      {
        headers: { Accept: "application/json;odata=verbose" }
      }
    );
    
    if (response.ok) {
      const data = await response.json();
      const fields = data.d.results;
       
      // fields.forEach((field: any) => {
      //   console.log(`📋 ${field.Title} (${field.InternalName}): ${field.TypeAsString}`);
      // });
      
      // Check specific OBL fields
      const oblFieldNames = [
        'NormalDue', 'NormalOverdue', 'RetentionDue', 'RetentionOverdue', 
        'GstTds', 'WHT', 'TDS', 'OBL', 'OBLBreakdown'
      ];
       
      oblFieldNames.forEach(fieldName => {
        const found = fields.find((f: any) => 
          f.InternalName === fieldName || 
          f.Title === fieldName ||
          f.InternalName.toLowerCase().includes(fieldName.toLowerCase())
        );
        console.log(found ? `✅ FOUND: ${fieldName}` : `❌ MISSING: ${fieldName}`);
      });
    }
  } catch (error) {
    console.error("Error diagnosing fields:", error);
  }
};
 
// diagnoseSharePointFields();

 // Enhanced OBL breakdown function with multiple fallbacks
const getOBLBreakdownForExport = (collection: CollectionItem): OBLBreakdown => {
  const defaultBreakdown: OBLBreakdown = {
    normalDue: 0,
    normalOverdue: 0,
    retentionDue: 0,
    retentionOverdue: 0,
    gstTds: 0,
    wht: 0
  };

  try { 
    // Use the exact field names from your database
    const breakdown: OBLBreakdown = {
      normalDue: getNumericFieldValue(collection, 'NormalDue'),
      normalOverdue: getNumericFieldValue(collection, 'NormalOverdue'),
      retentionDue: getNumericFieldValue(collection, 'RetentionDue'),
      retentionOverdue: getNumericFieldValue(collection, 'RetentionOverdue'),
      gstTds: getNumericFieldValue(collection, 'GSTTDS'), // This is one field in your DB
      wht: getNumericFieldValue(collection, 'WHT')
    };
 
    return breakdown;

  } catch (error) {
    console.error("Error in getOBLBreakdownForExport:", error);
    return defaultBreakdown;
  }
};
 
const getNumericFieldValue = (collection: CollectionItem, fieldName: string): number => {
  const value = collection[fieldName as keyof CollectionItem];
  
  if (value === undefined || value === null || value === '') {
    return 0;
  }
  
  // Handle different value types
  if (typeof value === 'number') {
    return value;
  }
  
  if (typeof value === 'string') {
    const num = parseFloat(value);
    return isNaN(num) ? 0 : num;
  }
  
  return 0;
};

  
      // Helper function to get last 5 years from data
      

      

      // ========== PAGINATION FUNCTIONS ==========

const initializePagination = (data: CollectionItem[]): void => {
  try {
    // Apply role filtering ONCE
    const roleFilteredData = filterDataByRole(data);
    filteredData = roleFilteredData;
    
    totalPages = Math.ceil(filteredData.length / pageSize);
    
    if (currentPage > totalPages && totalPages > 0) {
      currentPage = totalPages;
    } else if (totalPages === 0) {
      currentPage = 1;
    }
    
    updatePaginationControls();
    renderCurrentPage();
    
  } catch (error) {
    console.error("Error initializing pagination:", error);
    // Fallback: render table without pagination
    if (data.length > 0) {
      renderTableWithMonthColumns(data);
    } else {
      tableBody.innerHTML = `<tr><td colspan="21" style="text-align:center;padding:20px;">No records found</td></tr>`;
    }
  }
};

      const updatePagination = (): void => {
  totalPages = Math.ceil(filteredData.length / pageSize);
  
  // Ensure current page is within valid range
  if (currentPage > totalPages && totalPages > 0) {
    currentPage = totalPages;
  } else if (totalPages === 0) {
    currentPage = 1;
  }
  
  updatePaginationControls();
  renderCurrentPage();
};

const updatePaginationControls = (): void => {
  currentPageSpan.textContent = currentPage.toString();
  totalPagesSpan.textContent = totalPages.toString();
  
  const startItem = totalPages > 0 ? (currentPage - 1) * pageSize + 1 : 0;
  const endItem = Math.min(currentPage * pageSize, filteredData.length);
  
  startItemSpan.textContent = startItem.toString();
  endItemSpan.textContent = endItem.toString();
  totalItemsSpan.textContent = filteredData.length.toString();
  
  // Update button states
  firstPageBtn.disabled = currentPage === 1 || totalPages === 0;
  prevPageBtn.disabled = currentPage === 1 || totalPages === 0;
  nextPageBtn.disabled = currentPage === totalPages || totalPages === 0;
  lastPageBtn.disabled = currentPage === totalPages || totalPages === 0;
  
  updatePageNumbers();
};

const updatePageNumbers = (): void => {
  pageNumbersDiv.innerHTML = '';
  
  if (totalPages === 0) return;
  
  const maxVisiblePages = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
  let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
  
  // Adjust if we're at the beginning
  if (endPage - startPage + 1 < maxVisiblePages) {
    startPage = Math.max(1, endPage - maxVisiblePages + 1);
  }
  
  // Add first page and ellipsis if needed
  if (startPage > 1) {
    addPageButton(1);
    if (startPage > 2) {
      addEllipsis();
    }
  }
  
  // Add page numbers
  for (let i = startPage; i <= endPage; i++) {
    addPageButton(i);
  }
  
  // Add last page and ellipsis if needed
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      addEllipsis();
    }
    addPageButton(totalPages);
  }
};

// Helper function to add page button
const addPageButton = (page: number): void => {
  const pageBtn = document.createElement('button');
  pageBtn.className = `page-number ${page === currentPage ? 'active' : ''}`;
  pageBtn.textContent = page.toString();
  pageBtn.addEventListener('click', () => goToPage(page));
  pageNumbersDiv.appendChild(pageBtn);
};

// Helper function to add ellipsis
const addEllipsis = (): void => {
  const ellipsis = document.createElement('span');
  ellipsis.className = 'pagination-ellipsis';
  ellipsis.textContent = '...';
  ellipsis.style.padding = '8px 6px';
  ellipsis.style.color = '#666';
  pageNumbersDiv.appendChild(ellipsis);
};

// Navigate to specific page
const goToPage = (page: number): void => {
  if (page < 1 || page > totalPages || page === currentPage || totalPages === 0) return;
  
  currentPage = page;
  updatePagination();
  
  // Scroll to top of table for better UX
  const tableSection = document.querySelector('.table-section') as HTMLElement;
  if (tableSection) {
    tableSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
};

  const renderCurrentPage = (): void => {
  if (filteredData.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="21" style="text-align:center;padding:20px;border:1px solid #ddd;">No records found</td></tr>`;
    return;
  }
  
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, filteredData.length);
  const pageData = filteredData.slice(startIndex, endIndex);
  
  renderTableWithMonthColumns(pageData);
};

pageSizeSelect.addEventListener('change', (e) => {
  const newSize = parseInt((e.target as HTMLSelectElement).value);
  
  if (newSize !== pageSize) {
    pageSize = newSize;
    currentPage = 1; // Reset to first page when changing page size
    updatePagination();
    
    // Show notification
    toast("info", `Now showing ${pageSize} records per page`);
  }
});

      // ========== TABLE RENDERING FUNCTIONS ==========
// let currentSortColumn: string | null = null;
// let currentSortDirection: 'asc' | 'desc' = 'asc';

// ========== ENHANCED SORTING FUNCTIONS ==========

// Updated sorting function with month index support
const handleEnhancedSort = (column: string, direction: 'asc' | 'desc', subColumn?: string, monthIndex?: number): void => {
  // Update current sort state
  currentSortConfig = {
    column,
    direction,
    subColumn,
    monthIndex
  };

  const dataToSort = filteredData.length > 0 ? filteredData : collections;
  
  if (dataToSort.length === 0) return;

  const sortedData = [...dataToSort].sort((a, b) => {
    let valueA: any = 0;
    let valueB: any = 0;

    switch (column) {
      case 'receivable':
        valueA = a.OBL || 0;
        valueB = b.OBL || 0;
        break;
      
      case 'collection':
        const selectedYear = filterYear.value;
        const selectedMonth = filterMonth.value;
        const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
        
        if (selectedMonthKey) {
          const revenueA = safeJsonParse(a.RevenueActual, {});
          const revenueB = safeJsonParse(b.RevenueActual, {});
          valueA = revenueA[selectedMonthKey] || 0;
          valueB = revenueB[selectedMonthKey] || 0;
        } else {
          valueA = 0;
          valueB = 0;
        }
        break;
      
      case 'month':
        const displayMonths = getDisplayMonths();
        
        // Use the specific month index if provided, otherwise default to first month
        const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
        const monthKeyToUse = displayMonths[monthIndexToUse];
        
        const dataA = safeJsonParse(a.CollectionData, {});
        const dataB = safeJsonParse(b.CollectionData, {});
        const monthDataA = dataA[monthKeyToUse] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
        const monthDataB = dataB[monthKeyToUse] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
        
        const itemsA = monthDataA.items || {};
        const itemsB = monthDataB.items || {};
        
        if (subColumn) {
          switch (subColumn) {
            case 'normal-previous':
              valueA = (itemsA.Normal?.plan || 0) + (itemsA['Normal Overdue']?.plan || 0);
              valueB = (itemsB.Normal?.plan || 0) + (itemsB['Normal Overdue']?.plan || 0);
              break;
            case 'normal-current':
              valueA = (itemsA.Normal?.actual || 0) + (itemsA['Normal Overdue']?.actual || 0);
              valueB = (itemsB.Normal?.actual || 0) + (itemsB['Normal Overdue']?.actual || 0);
              break;
            case 'retention-previous':
              valueA = (itemsA.Retention?.plan || 0) + (itemsA['Retention Overdue']?.plan || 0);
              valueB = (itemsB.Retention?.plan || 0) + (itemsB['Retention Overdue']?.plan || 0);
              break;
            case 'retention-current':
              valueA = (itemsA.Retention?.actual || 0) + (itemsA['Retention Overdue']?.actual || 0);
              valueB = (itemsB.Retention?.actual || 0) + (itemsB['Retention Overdue']?.actual || 0);
              break;
            case 'total-previous':
              valueA = monthDataA.plan || 0;
              valueB = monthDataB.plan || 0;
              break;
            case 'total-current':
              valueA = monthDataA.actual || 0;
              valueB = monthDataB.actual || 0;
              break;
            default:
              valueA = monthDataA.actual || 0;
              valueB = monthDataB.actual || 0;
          }
        } else {
          valueA = monthDataA.actual || 0;
          valueB = monthDataB.actual || 0;
        }
        break;
      
      default:
        return 0;
    }

    if (direction === 'asc') {
      return valueA - valueB;
    } else {
      return valueB - valueA;
    }
  });

  if (filteredData.length > 0) {
    filteredData = sortedData;
  } else {
    collections = sortedData;
  }

  currentPage = 1;
  updatePagination();
  
  const sortDirectionText = direction === 'asc' ? 'Ascending' : 'Descending';
  let columnName = '';
  
  if (subColumn) {
    columnName = subColumn.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
  } else if (column === 'receivable') {
    columnName = 'Receivable';
  } else if (column === 'collection') {
    columnName = 'Collection';
  } else {
    const displayMonths = getDisplayMonths();
    const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
    const monthKey = displayMonths[monthIndexToUse];
    const monthDate = new Date(monthKey + "-01");
    columnName = formatMonthLabel(monthDate);
  }
  
  toast("info", `Sorted by ${columnName} (${sortDirectionText})`);
};

// Updated sort button listener
const attachSortButtonListeners = (): void => {
  document.querySelectorAll('.sort-btn[data-sort]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const button = e.currentTarget as HTMLButtonElement;
      const sortColumn = button.dataset.sort;
      const direction = button.dataset.direction as 'asc' | 'desc';
      const subColumn = button.dataset.subcolumn;
      const monthIndex = button.dataset.monthIndex ? parseInt(button.dataset.monthIndex) : undefined;
      
      if (sortColumn && direction) {
        handleEnhancedSort(sortColumn, direction, subColumn, monthIndex);
      }
    });
  });
};

// Updated project group sorting
// const sortProjectGroups = (projectGroups: {[projectTitle: string]: CollectionItem[]}): string[] => {
//   const projectTitles = Object.keys(projectGroups);
  
//   if (!currentSortConfig.column) {
//     return projectTitles.sort(); // Default sort by project title
//   }

//   return projectTitles.sort((a, b) => {
//     let valueA: any = 0;
//     let valueB: any = 0;

//     // Get values for sorting based on the column
//     switch (currentSortConfig.column) {
//       case 'receivable':
//         valueA = projectGroups[a].reduce((sum, col) => sum + (col.OBL || 0), 0);
//         valueB = projectGroups[b].reduce((sum, col) => sum + (col.OBL || 0), 0);
//         break;
      
//       case 'collection':
//         const selectedYear = filterYear.value;
//         const selectedMonth = filterMonth.value;
//         const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
        
//         valueA = projectGroups[a].reduce((sum, col) => {
//           const revenueData = safeJsonParse(col.RevenueActual, {});
//           return sum + (revenueData[selectedMonthKey] || 0);
//         }, 0);
        
//         valueB = projectGroups[b].reduce((sum, col) => {
//           const revenueData = safeJsonParse(col.RevenueActual, {});
//           return sum + (revenueData[selectedMonthKey] || 0);
//         }, 0);
//         break;
      
//       case 'month':
//         const displayMonths = getDisplayMonths();
//         const monthIndexToUse = currentSortConfig.monthIndex !== undefined ? currentSortConfig.monthIndex : 0;
//         const monthKeyToUse = displayMonths[monthIndexToUse];
        
//         valueA = projectGroups[a].reduce((sum, col) => {
//           const collectionData = safeJsonParse(col.CollectionData, {});
//           const monthData = collectionData[monthKeyToUse] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
//           const items = monthData.items || {};
          
//           if (currentSortConfig.subColumn) {
//             switch (currentSortConfig.subColumn) {
//               case 'normal-previous':
//                 return sum + ((items.Normal?.plan || 0) + (items['Normal Overdue']?.plan || 0));
//               case 'normal-current':
//                 return sum + ((items.Normal?.actual || 0) + (items['Normal Overdue']?.actual || 0));
//               case 'retention-previous':
//                 return sum + ((items.Retention?.plan || 0) + (items['Retention Overdue']?.plan || 0));
//               case 'retention-current':
//                 return sum + ((items.Retention?.actual || 0) + (items['Retention Overdue']?.actual || 0));
//               case 'total-previous':
//                 return sum + (monthData.plan || 0);
//               case 'total-current':
//                 return sum + (monthData.actual || 0);
//               default:
//                 return sum + (monthData.actual || 0);
//             }
//           } else {
//             return sum + (monthData.actual || 0);
//           }
//         }, 0);
        
//         valueB = projectGroups[b].reduce((sum, col) => {
//           const collectionData = safeJsonParse(col.CollectionData, {});
//           const monthData = collectionData[monthKeyToUse] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
//           const items = monthData.items || {};
          
//           if (currentSortConfig.subColumn) {
//             switch (currentSortConfig.subColumn) {
//               case 'normal-previous':
//                 return sum + ((items.Normal?.plan || 0) + (items['Normal Overdue']?.plan || 0));
//               case 'normal-current':
//                 return sum + ((items.Normal?.actual || 0) + (items['Normal Overdue']?.actual || 0));
//               case 'retention-previous':
//                 return sum + ((items.Retention?.plan || 0) + (items['Retention Overdue']?.plan || 0));
//               case 'retention-current':
//                 return sum + ((items.Retention?.actual || 0) + (items['Retention Overdue']?.actual || 0));
//               case 'total-previous':
//                 return sum + (monthData.plan || 0);
//               case 'total-current':
//                 return sum + (monthData.actual || 0);
//               default:
//                 return sum + (monthData.actual || 0);
//             }
//           } else {
//             return sum + (monthData.actual || 0);
//           }
//         }, 0);
//         break;
      
//       default:
//         // Fallback to project title
//         valueA = a;
//         valueB = b;
//     }

//     // Handle numeric vs string comparison
//     if (typeof valueA === 'number' && typeof valueB === 'number') {
//       return currentSortConfig.direction === 'asc' ? valueA - valueB : valueB - valueA;
//     } else {
//       // String comparison
//       const strA = String(valueA).toLowerCase();
//       const strB = String(valueB).toLowerCase();
//       return currentSortConfig.direction === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
//     }
//   });
// };

const checkEditPermission = (collection: CollectionItem): boolean => {
  if (currentUser.isSuperAdmin) { 
    return true;
  }

  const projectTitle = collection.Project?.Title;
  if (!projectTitle) return false;

  const project = projects.find(p => p.Title === projectTitle);
  if (!project) return false;

  if (currentUser.isGroupHead) { 
    // Group Head can edit projects in their managed groups
    return currentUser.managedGroups?.some(group => 
      project.GroupHead === group
    ) || false;
  }

  if (currentUser.isProjectManager) { 
    // Project Manager can edit only their assigned projects
    return currentUser.managedProjects?.includes(projectTitle) || false;
  }

  return false;
};

const renderTableWithMonthColumns = (data: CollectionItem[]): void => {
  // First filter data by role
  const roleFilteredData = filterDataByRole(data);
  
  if (!roleFilteredData.length) {
    tableBody.innerHTML = `<tr><td colspan="21" style="text-align:center;padding:20px;border:1px solid #ddd;">
      ${currentUser.isSuperAdmin ? 'No records found' : 
        currentUser.isGroupHead ? 'No records found in your groups' : 
        currentUser.isProjectManager ? 'No assigned projects found' : 
        'No access to view any records'}
    </td></tr>`;
    
    // Clear totals header
    const totalsHeader = document.querySelector("#totalsHeader") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = '';
    
    return;
  }

  const displayMonths = getDisplayMonths();
  const selectedYear = filterYear.value;
  const selectedMonth = filterMonth.value;
  const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';

  // Determine which columns to show based on role
  const showProjectManagerColumn = currentUser.isSuperAdmin ? true : !currentUser.isProjectManager;
  const showGroupHeadColumn = currentUser.isSuperAdmin ? true : !currentUser.isGroupHead;

  // 1. First, render the totals rows above the main header
  renderTotalsHeader(displayMonths, selectedMonthKey);

  // 2. Build main table header
  const headerHTML = `
    <tr>
      <th rowspan="3" class="project-info-cell">Project Ref</th>
      <th rowspan="3" class="project-info-cell">Project</th>
      <th rowspan="3" class="project-info-cell">Customer</th>
      ${showProjectManagerColumn ? '<th rowspan="3" class="project-info-cell">Project Manager</th>' : ''}
      ${showGroupHeadColumn ? '<th rowspan="3" class="project-info-cell">Group Head</th>' : ''}
      
      <!-- Receivable Column with Enhanced Sort -->
      <th rowspan="3" class="month-column-header">
        <div class="sort-header-container">
          <span class="header-label">Receivable</span>
          <div class="sort-buttons-container">
            <button class="sort-btn ${currentSortConfig.column === 'receivable' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                    data-sort="receivable" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn ${currentSortConfig.column === 'receivable' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                    data-sort="receivable" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Collection Column with Enhanced Sort -->
      <th rowspan="3" class="month-column-header">
        <div class="sort-header-container">
          <span class="header-label">Actual <br> Collection</span>
          <div class="sort-buttons-container">
            <button class="sort-btn ${currentSortConfig.column === 'collection' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                    data-sort="collection" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn ${currentSortConfig.column === 'collection' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                    data-sort="collection" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      ${displayMonths.map((month, monthIndex) => {
        const monthLabel = formatMonthLabel(new Date(month + "-01"));
        return `
          <th colspan="6" class="month-column-header">
            <div class="sort-header-container">
              <span class="header-label">${monthLabel}</span>
              <div class="sort-buttons-container">
                <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                        data-sort="month" data-direction="asc" data-month-index="${monthIndex}" title="Sort by Month Total Ascending">▲</button>
                <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                        data-sort="month" data-direction="desc" data-month-index="${monthIndex}" title="Sort by Month Total Descending">▼</button>
              </div>
            </div>
          </th>
        `;
      }).join('')}
      <th rowspan="3" class="actions-header">Actions</th>
    </tr>
    <tr>
      ${displayMonths.map(() => `
        <th colspan="3" class="month-subheader">Previous</th>
        <th colspan="3" class="month-subheader">Current</th>
      `).join('')}
    </tr>
    <tr>
      ${displayMonths.map((month, monthIndex) => `
        <!-- Previous Columns with Sorting -->
        <th class="month-subheader">
          <div class="sort-header-container">
            <span>Normal</span>
            <div class="sort-buttons-container">
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'normal-previous' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                      data-sort="month" data-direction="asc" data-subcolumn="normal-previous" data-month-index="${monthIndex}" title="Sort Normal Previous Ascending">▲</button>
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'normal-previous' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                      data-sort="month" data-direction="desc" data-subcolumn="normal-previous" data-month-index="${monthIndex}" title="Sort Normal Previous Descending">▼</button>
            </div>
          </div>
        </th>
        <th class="month-subheader">
          <div class="sort-header-container">
            <span>Retention</span>
            <div class="sort-buttons-container">
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'retention-previous' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                      data-sort="month" data-direction="asc" data-subcolumn="retention-previous" data-month-index="${monthIndex}" title="Sort Retention Previous Ascending">▲</button>
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'retention-previous' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                      data-sort="month" data-direction="desc" data-subcolumn="retention-previous" data-month-index="${monthIndex}" title="Sort Retention Previous Descending">▼</button>
            </div>
          </div>
        </th>
        <th class="month-subheader">
          <div class="sort-header-container">
            <span>Total</span>
            <div class="sort-buttons-container">
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total-previous' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                      data-sort="month" data-direction="asc" data-subcolumn="total-previous" data-month-index="${monthIndex}" title="Sort Total Previous Ascending">▲</button>
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total-previous' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                      data-sort="month" data-direction="desc" data-subcolumn="total-previous" data-month-index="${monthIndex}" title="Sort Total Previous Descending">▼</button>
            </div>
          </div>
        </th>
        
        <!-- Current Columns with Sorting -->
        <th class="month-subheader">
          <div class="sort-header-container">
            <span>Normal</span>
            <div class="sort-buttons-container">
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'normal-current' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                      data-sort="month" data-direction="asc" data-subcolumn="normal-current" data-month-index="${monthIndex}" title="Sort Normal Current Ascending">▲</button>
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'normal-current' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                      data-sort="month" data-direction="desc" data-subcolumn="normal-current" data-month-index="${monthIndex}" title="Sort Normal Current Descending">▼</button>
            </div>
          </div>
        </th>
        <th class="month-subheader">
          <div class="sort-header-container">
            <span>Retention</span>
            <div class="sort-buttons-container">
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'retention-current' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                      data-sort="month" data-direction="asc" data-subcolumn="retention-current" data-month-index="${monthIndex}" title="Sort Retention Current Ascending">▲</button>
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'retention-current' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                      data-sort="month" data-direction="desc" data-subcolumn="retention-current" data-month-index="${monthIndex}" title="Sort Retention Current Descending">▼</button>
            </div>
          </div>
        </th>
        <th class="month-subheader">
          <div class="sort-header-container">
            <span>Total</span>
            <div class="sort-buttons-container">
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total-current' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                      data-sort="month" data-direction="asc" data-subcolumn="total-current" data-month-index="${monthIndex}" title="Sort Total Current Ascending">▲</button>
              <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total-current' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                      data-sort="month" data-direction="desc" data-subcolumn="total-current" data-month-index="${monthIndex}" title="Sort Total Current Descending">▼</button>
            </div>
          </div>
        </th>
      `).join('')}
    </tr>
  `;

  monthColumnsHeader.innerHTML = headerHTML;

  // Attach sort listeners
  attachSortButtonListeners();

  // 3. Build table body
  let bodyHTML = '';

  roleFilteredData.forEach(collection => {
    const projectTitle = collection.Project?.Title || "-";
    const proj = projects.find(p => p.Title === projectTitle);
    
    // Calculate totals
    const totalReceivable = collection.OBL || 0;
    const totalCollection = selectedMonthKey ? 
      (safeJsonParse(collection.RevenueActual, {})[selectedMonthKey] || 0) : 0;

    // Build row with conditional columns
    let rowHTML = `
      <tr data-project="${projectTitle}">
        <td class="project-info-cell">${proj?.ProjectReference || "-"}</td>
        <td class="project-info-cell">${projectTitle}</td>
        <td class="project-info-cell">${proj?.CustomerName || "-"}</td>
    `;

    // Add Project Manager column if visible
    if (showProjectManagerColumn) {
      rowHTML += `<td class="project-info-cell">${proj ? (typeof proj.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-") : "-"}</td>`;
    }

    // Add Group Head column if visible
    if (showGroupHeadColumn) {
      rowHTML += `<td class="project-info-cell">${proj?.GroupHead || "-"}</td>`;
    }

    rowHTML += `
        <td class="project-info-cell receivable-cell">
          ${Math.round(totalReceivable || 0).toLocaleString('en-IN')}
        </td>
        <td class="project-info-cell collection-cell">
          ${Math.round(totalCollection || 0).toLocaleString('en-IN')}
        </td>
    `;

    // Add month columns data
    displayMonths.forEach((monthKey, monthIndex) => {
      const collectionData = safeJsonParse(collection.CollectionData, {});
      const monthData = collectionData[monthKey] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
      const items = monthData.items || {};
      
      const formatNumber = (value: number | null | undefined): string => {
        return Math.round(value ?? 0).toLocaleString('en-IN');
      };

      const normalPlan = (items.Normal?.plan || 0) + (items['Normal Overdue']?.plan || 0);
      const retentionPlan = (items.Retention?.plan || 0) + (items['Retention Overdue']?.plan || 0);
      const totalPlan = monthData.plan || 0;
      const normalActual = (items.Normal?.actual || 0) + (items['Normal Overdue']?.actual || 0);
      const retentionActual = (items.Retention?.actual || 0) + (items['Retention Overdue']?.actual || 0);
      const totalActual = monthData.actual || 0;

      rowHTML += `
        <!-- Previous - Normal, Retention, Total -->
        <td class="month-data-cell">${formatNumber(normalPlan)}</td>
        <td class="month-data-cell">${formatNumber(retentionPlan)}</td>
        <td class="month-data-cell total-cell">${formatNumber(totalPlan)}</td>

        <!-- Current - Normal, Retention, Total -->
        <td class="month-data-cell">${formatNumber(normalActual)}</td>
        <td class="month-data-cell">${formatNumber(retentionActual)}</td>
        <td class="month-data-cell total-cell">${formatNumber(totalActual)}</td>
      `;
    });

    // Add actions column - only show edit button if user has permission
    const canEdit = checkEditPermission(collection);
    rowHTML += `
        <td class="actions-cell">
          ${canEdit ? 
            `<button class="edit-action-btn" data-id="${collection.Id}" title="Edit Collection">
              <span class="edit-icon">✏️</span>
              <span class="edit-text">Edit</span>
            </button>` : 
            '<span class="no-edit-permission" title="You do not have permission to edit this record">🔒</span>'}
        </td>      
      </tr>
    `;

    bodyHTML += rowHTML;
  });

  tableBody.innerHTML = bodyHTML;
  attachTableEventListeners();
};

// Add this function to calculate and render totals
const renderTotalsHeader = (displayMonths: string[], selectedMonthKey: string): void => {
  const totalsHeader = document.querySelector("#totalsHeader") as HTMLElement;
  if (!totalsHeader) return;

  totalsHeader.innerHTML = '';

  // Get all data and apply role filtering
  const allData = collections;
  const roleFiltered = filterDataByRole(allData);
  const filtered = filteredData.length ? filteredData : roleFiltered;

  const allTotals = calculateTotals(allData, displayMonths, selectedMonthKey);
  const filteredTotals = calculateTotals(filtered, displayMonths, selectedMonthKey);

  const showPM = currentUser.isSuperAdmin || !currentUser.isProjectManager;
  const showGH = currentUser.isSuperAdmin || !currentUser.isGroupHead;

  const buildTotalsRow = (label: string, totals: any, css: string) => `
    <tr class="${css}">
      <!-- Project Ref -->
      <td class="totals-label">${label}</td>
      
      <!-- Project -->
      <td></td>
      
      <!-- Customer -->
      <td></td>
      
      ${showPM ? `<td></td>` : ''}
      ${showGH ? `<td></td>` : ''}
      
      <!-- Receivable -->
      <td class="total-value">${totals.receivable.toLocaleString('en-IN')}</td>
      
      <!-- Actual Collection -->
      <td class="total-value">${totals.actualCollection.toLocaleString('en-IN')}</td>
      
      <!-- Months -->
      ${displayMonths.map(m => {
        const t = totals.monthly[m] || { normalPrevious: 0, retentionPrevious: 0, totalPrevious: 0, normalCurrent: 0, retentionCurrent: 0, totalCurrent: 0 };
        return `
          <td>${t.normalPrevious}</td>
          <td>${t.retentionPrevious}</td>
          <td class="total-value">${t.totalPrevious}</td>
          <td>${t.normalCurrent}</td>
          <td>${t.retentionCurrent}</td>
          <td class="total-value">${t.totalCurrent}</td>
        `;
      }).join('')}
      
      <!-- Actions -->
      <td></td>
    </tr>
  `;

  totalsHeader.innerHTML = `
    <table class="totals-header-table" style="width: 100%;">
      ${buildTotalsRow(`All`, allTotals, 'all-projects-total')}
      ${buildTotalsRow(`Filtered (${filtered.length})`, filteredTotals, 'filtered-total')}
    </table>
  `;
};

// Add this helper function to calculate totals
const calculateTotals = (
  data: CollectionItem[],
  displayMonths: string[],
  selectedMonthKey: string
): any => {
  let dataToCalculate = currentUser.isSuperAdmin
    ? data
    : filterDataByRole(data);

  const totals = {
    receivable: 0,
    actualCollection: 0,
    monthly: {} as {
      [key: string]: { 
        normalPrevious: number; 
        retentionPrevious: number; 
        totalPrevious: number;
        normalCurrent: number; 
        retentionCurrent: number; 
        totalCurrent: number;
      }
    }
  };

  // Init months
  displayMonths.forEach(monthKey => {
    totals.monthly[monthKey] = { 
      normalPrevious: 0, 
      retentionPrevious: 0, 
      totalPrevious: 0,
      normalCurrent: 0, 
      retentionCurrent: 0, 
      totalCurrent: 0
    };
  });

  dataToCalculate.forEach(collection => {
    // ✅ ROUND Receivable
    totals.receivable += Math.round(Number(collection.OBL) || 0);

    // ✅ Actual Collection for selected month
    if (selectedMonthKey) {
      const revenueData = safeJsonParse(collection.RevenueActual, {});
      totals.actualCollection += Math.round(Number(revenueData[selectedMonthKey]) || 0);
    }

    const collectionData = safeJsonParse(collection.CollectionData, {});

    displayMonths.forEach(monthKey => {
      const m = collectionData[monthKey] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
      const items = m.items || {};

      // Previous values (plan)
      const normalPrevious = Math.round((items.Normal?.plan || 0) + (items['Normal Overdue']?.plan || 0));
      const retentionPrevious = Math.round((items.Retention?.plan || 0) + (items['Retention Overdue']?.plan || 0));
      const totalPrevious = Math.round(m.plan || 0);

      // Current values (actual)
      const normalCurrent = Math.round((items.Normal?.actual || 0) + (items['Normal Overdue']?.actual || 0));
      const retentionCurrent = Math.round((items.Retention?.actual || 0) + (items['Retention Overdue']?.actual || 0));
      const totalCurrent = Math.round(m.actual || 0);

      totals.monthly[monthKey].normalPrevious += normalPrevious;
      totals.monthly[monthKey].retentionPrevious += retentionPrevious;
      totals.monthly[monthKey].totalPrevious += totalPrevious;
      totals.monthly[monthKey].normalCurrent += normalCurrent;
      totals.monthly[monthKey].retentionCurrent += retentionCurrent;
      totals.monthly[monthKey].totalCurrent += totalCurrent;
    });
  });

  return totals;
};
 
// Update the attachTableEventListeners function
const attachTableEventListeners = (): void => {
  tableBody.querySelectorAll(".edit-action-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const button = e.currentTarget as HTMLButtonElement;
      const id = parseInt(button.dataset.id!);
      if (id && !isNaN(id)) {
        editCollection(id); // This is now properly called
      }
    });
  });
};

 
      // ========== FORM MANAGEMENT FUNCTIONS ==========

      const showForm = (isEditMode: boolean = false): void => {
        formSection.style.display = "block";
        tableSection.style.display = "none";
        showFormBtn.style.display = "none";
        
        if (isEditMode) {
          formSection.classList.add('edit-mode');
          projectSelect.disabled = true;
          formTitle.textContent = "Edit Collection";
        } else {
          formSection.classList.remove('edit-mode');
          projectSelect.disabled = false;
          formTitle.textContent = "Add Collection";
        }
      };

      const hideForm = (): void => {
        formSection.style.display = "none";
        tableSection.style.display = "block";
        showFormBtn.style.display = "inline-block";
        formSection.classList.remove('edit-mode');
        projectSelect.disabled = false;
      };

      const resetForm = (): void => {
        editingId = null;
        form.reset();
        projectSelect.value = "";
        projectDetails.innerHTML = "";
        historicalContainer.innerHTML = "";
        firstRowContainer.innerHTML = "";
        remainingContainer.innerHTML = "";
        yearlyContainer.innerHTML = "";
        
        // Hide all collection sections
        toggleCollectionSections(false);
        
        const oblContainer = document.querySelector('.obl-section-container') as HTMLElement;
        oblContainer.className = 'obl-section-container hidden-section';
        oblLastMonthInput.removeAttribute('readonly');
        oblLastMonthInput.placeholder = "Enter OBL";
        setNumericValue(oblLastMonthInput, 0);
        
        const fieldNote = oblContainer.querySelector('.field-note') as HTMLElement;
        if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
        
        oblValidationMessage.textContent = "✅ All values are within OBL limit";
        oblValidationMessage.className = 'validation-message';
        
        updateOBLValidationDisplay();
      };

      // ========== VALIDATION FUNCTIONS ==========

const calculateTotalCurrentValue = (): number => {
  let total = 0;
  
  // Include monthly actual values from ALL editable months
  const editableMonths = allMonths.slice(3); // All months except historical
  
  editableMonths.forEach(monthKey => {
    const currentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]:not([readonly])`);
    if (currentInput) {
      total += getNumericValue(currentInput);
    }
  });
  
  // Include yearly actual values
  const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.yearly-current-input:not([readonly])`);
  yearlyCurrentInputs.forEach(input => {
    total += getNumericValue(input);
  });
  
   
  
  return total;
};

      const validateOBLLimit = (changedInput?: HTMLInputElement): boolean => {
        const oblValue = getNumericValue(oblLastMonthInput);
        const totalCurrent = calculateTotalCurrentValue();
        
        totalCurrentValueSpan.textContent = totalCurrent.toLocaleString();
        
        const remaining = oblValue - totalCurrent;
        remainingValueSpan.textContent = remaining.toLocaleString();
        
        if (oblValue === 0) {
          oblLineFill.style.width = `0%`;
          oblLineFill.className = 'line-fill';
          
          if (totalCurrent > 0) {
            showOBLErrorToast('⚠️ OBL is zero but current values exist. Please set OBL value.', true);
            blockAllCurrentInputs();
            return false;
          } else {
            const existingToast = document.querySelector('.obl-error-toast');
            if (existingToast) existingToast.remove();
            unblockAllCurrentInputs();
            return true;
          }
        }
        
        const percentage = Math.min((totalCurrent / oblValue) * 100, 100);
        oblLineFill.style.width = `${percentage}%`;
        
        oblLineFill.className = 'line-fill';
        if (percentage > 90) {
          oblLineFill.classList.add('danger');
        } else if (percentage > 75) {
          oblLineFill.classList.add('warning');
        }
        
        oblValidationMessage.className = 'validation-message';
        
        if (totalCurrent > oblValue) {
          const exceedAmount = totalCurrent - oblValue;
          showOBLErrorToast(`❌ Total current value exceeds OBL by ${exceedAmount.toLocaleString()}! Reduce values to continue.`);
          oblValidationMessage.classList.add('danger');
          blockIncreasingCurrentInputs(changedInput);
          return false;
        } else if (percentage > 90) {
          showOBLErrorToast('⚠️ OBL limit nearly reached! Consider reducing values.', true);
          oblValidationMessage.classList.add('warning');
          unblockAllCurrentInputs();
          return true;
        } else {
          const existingToast = document.querySelector('.obl-error-toast');
          if (existingToast) existingToast.remove();
          
          oblValidationMessage.textContent = '✅ All values are within OBL limit';
          unblockAllCurrentInputs();
          return true;
        }
      };

      const blockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input.main-current-input:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input:not([readonly])');
        
        currentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
      };

      const blockIncreasingCurrentInputs = (allowedInput?: HTMLInputElement): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input.main-current-input:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input:not([readonly])');
        
        currentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
        
        yearlyCurrentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
      };

      const unblockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input.main-current-input:not([data-month="0"])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input');
        
        currentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
      };

      const allowInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
        const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
        const isIncreasing = newValue > oldValue;
        
        if (!isIncreasing) {
          return true;
        }
        
        const oblValue = getNumericValue(oblLastMonthInput);
        const currentTotal = calculateTotalCurrentValue();
        const increaseAmount = newValue - oldValue;
        
        return (currentTotal + increaseAmount) <= oblValue;
      };

      const allowCategoryInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
        const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
        const isIncreasing = newValue > oldValue;
        
        if (!isIncreasing) {
          return true;
        }
        
        const monthKey = input.dataset.month!;
        const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
        
        if (!mainCurrentInput) return true;
        
        const mainCurrentValue = getNumericValue(mainCurrentInput);
        const categoryCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-month="${monthKey}"]`);
        
        let currentCategoriesTotal = 0;
        categoryCurrentInputs.forEach(categoryInput => {
          if (categoryInput === input) {
            currentCategoriesTotal += newValue;
          } else {
            currentCategoriesTotal += getNumericValue(categoryInput);
          }
        });
        
        return currentCategoriesTotal <= mainCurrentValue;
      };

const validateMonthCategoryTotals = (changedInput?: HTMLInputElement): boolean => {
  let allValid = true;
  
  // Check detailed months (current + next 2 months)
  for (let i = 3; i <= 5; i++) {
    if (i < allMonths.length) {
      const monthKey = allMonths[i];
      const monthValid = validateSingleMonthCategories(monthKey, changedInput);
      if (!monthValid) {
        allValid = false;
      }
    }
  }
  
  // Check simple months (remaining months)
  for (let i = 6; i < allMonths.length; i++) {
    const monthKey = allMonths[i];
    const monthValid = validateSingleMonthCategories(monthKey, changedInput);
    if (!monthValid) {
      allValid = false;
    }
  }
  
  return allValid;
};

const validateSingleMonthCategories = (monthKey: string, changedInput?: HTMLInputElement): boolean => {
  const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
  const categoryCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-month="${monthKey}"]`);
  
  if (!mainCurrentInput) return true;
  
  const mainCurrentValue = getNumericValue(mainCurrentInput);
  let categoriesTotal = 0;
  
  categoryCurrentInputs.forEach(input => {
    categoriesTotal += getNumericValue(input);
  });
  
  let validationDisplay = document.querySelector(`.month-total-validation[data-month="${monthKey}"]`) as HTMLDivElement;
  if (!validationDisplay) {
    validationDisplay = document.createElement('div');
    validationDisplay.className = 'month-total-validation';
    validationDisplay.setAttribute('data-month', monthKey);
    
    const monthBlock = mainCurrentInput.closest('.month-box, .detailed-month-box');
    if (monthBlock) {
      const existingValidation = monthBlock.querySelector('.month-total-validation');
      if (existingValidation) {
        existingValidation.remove();
      }
      monthBlock.appendChild(validationDisplay);
    }
  }
  
  // Get category names for this month type
  const monthIndex = allMonths.indexOf(monthKey);
  const isDetailedMonth = monthIndex >= 3 && monthIndex <= 5;
  
  // Calculate Normal and Retention totals safely
  const normalInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="Normal"][data-month="${monthKey}"]`);
  const normalOverdueInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="Normal Overdue"][data-month="${monthKey}"]`);
  const retentionInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="Retention"][data-month="${monthKey}"]`);
  const retentionOverdueInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="Retention Overdue"][data-month="${monthKey}"]`);
  
  const normalTotal = (normalInput ? getNumericValue(normalInput) : 0) + 
                     (isDetailedMonth && normalOverdueInput ? getNumericValue(normalOverdueInput) : 0);
  
  const retentionTotal = (retentionInput ? getNumericValue(retentionInput) : 0) + 
                        (isDetailedMonth && retentionOverdueInput ? getNumericValue(retentionOverdueInput) : 0);
  
  if (categoriesTotal > mainCurrentValue) {
    validationDisplay.textContent = `❌ Categories total (${categoriesTotal}) exceeds Month current (${mainCurrentValue})!`;
    validationDisplay.className = 'month-total-validation month-total-invalid';
    blockIncreasingMonthCategoryInputs(monthKey, changedInput);
    return false;
  } else if (categoriesTotal < mainCurrentValue) {
    validationDisplay.textContent = `⚠️ Categories total (${categoriesTotal}) less than Month current (${mainCurrentValue})`;
    validationDisplay.className = 'month-total-validation month-total-warning';
    unblockAllMonthCategoryInputs(monthKey);
    return true;
  } else {
    validationDisplay.innerHTML = `✅ Categories match Month: ${categoriesTotal}<br>
                                  📊 Normal: ${normalTotal} | Retention: ${retentionTotal}`;
    validationDisplay.className = 'month-total-validation month-total-valid';
    unblockAllMonthCategoryInputs(monthKey);
    return true;
  }
};

      const blockIncreasingMonthCategoryInputs = (monthKey: string, allowedInput?: HTMLInputElement): void => {
        const categoryInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-month="${monthKey}"]`);
        
        categoryInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
      };

      const unblockAllMonthCategoryInputs = (monthKey: string): void => {
        const categoryInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-month="${monthKey}"]`);
        
        categoryInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
      };

// Yearly category current inputs
document.querySelectorAll<HTMLInputElement>('.category-current-input[data-year]:not([readonly])').forEach(input => {
  input.addEventListener('input', function() {
    const currentValue = getNumericValue(this);
    const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
    
    this.setAttribute('data-old-value', currentValue.toString());
    
    const isIncreasing = currentValue > oldValue;
    
    if (isIncreasing) {
      const allowByOBL = allowInputIncrease(this, currentValue);
      const allowByYear = allowYearCategoryInputIncrease(this, currentValue);
      
      if (!allowByOBL || !allowByYear) {
        setNumericValue(this, oldValue);
        updateOBLValidationDisplay(this);
        return;
      }
    }
    
    if (currentValue === 0) {
      this.className = this.className.replace('input-with-value', 'input-empty');
    } else {
      this.className = this.className.replace('input-empty', 'input-with-value');
    }

    updateOBLValidationDisplay(this);
    validateYearlyCategoryTotals(this);
  });
});

// Helper function for yearly category validation
const allowYearCategoryInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
  const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
  const isIncreasing = newValue > oldValue;
  
  if (!isIncreasing) {
    return true;
  }
  
  const year = input.dataset.year!;
  const yearlyCurrentInput = document.querySelector<HTMLInputElement>(`input.yearly-current-input[data-year="${year}"]`);
  
  if (!yearlyCurrentInput) return true;
  
  const yearlyCurrentValue = getNumericValue(yearlyCurrentInput);
  const categoryInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-year="${year}"]`);
  
  let currentCategoriesTotal = 0;
  categoryInputs.forEach(categoryInput => {
    if (categoryInput === input) {
      currentCategoriesTotal += newValue;
    } else {
      currentCategoriesTotal += getNumericValue(categoryInput);
    }
  });
  
  return currentCategoriesTotal <= yearlyCurrentValue;
};

const updateOBLValidationDisplay = (changedInput?: HTMLInputElement): void => {
  const oblValid = validateOBLLimit(changedInput);
  const monthlyCategoriesValid = validateMonthCategoryTotals(changedInput);
  const yearlyCategoriesValid = validateYearlyCategoryTotals(changedInput);
  
  // Update overall validation message
  const oblValue = getNumericValue(oblLastMonthInput);
  const totalCurrent = calculateTotalCurrentValue();
  const percentage = oblValue > 0 ? (totalCurrent / oblValue) * 100 : 0;
  
  if (!oblValid) {
    oblValidationMessage.textContent = `❌ Total current value (${totalCurrent.toLocaleString()}) exceeds OBL (${oblValue.toLocaleString()})!`;
    oblValidationMessage.className = 'validation-message danger';
  } else if (!monthlyCategoriesValid) {
    oblValidationMessage.textContent = `⚠️ Some month categories don't match month totals`;
    oblValidationMessage.className = 'validation-message warning';
  } else if (!yearlyCategoriesValid) {
    oblValidationMessage.textContent = `⚠️ Some yearly categories don't match year totals`;
    oblValidationMessage.className = 'validation-message warning';
  } else if (percentage > 90) {
    oblValidationMessage.textContent = `⚠️ OBL limit nearly reached (${percentage.toFixed(1)}%)`;
    oblValidationMessage.className = 'validation-message warning';
  } else {
    oblValidationMessage.textContent = `✅ All valid | Used: ${totalCurrent.toLocaleString()}/${oblValue.toLocaleString()} (${percentage.toFixed(1)}%)`;
    oblValidationMessage.className = 'validation-message success';
  }
};
const validateFormSubmission = (): boolean => {
  const oblValue = getNumericValue(oblLastMonthInput);
  const totalCurrent = calculateTotalCurrentValue();
  
  // OBL Validation
  if (oblValue > 0 && totalCurrent > oblValue) {
    toast("error", `Total current value (${totalCurrent.toLocaleString()}) exceeds OBL (${oblValue.toLocaleString()})!`);
    return false;
  }
  
  // Month Category Validation
  const invalidMonths: string[] = [];
  
  for (let i = 3; i < allMonths.length; i++) {
    const monthKey = allMonths[i];
    const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
    
    if (mainCurrentInput) {
      const mainCurrentValue = getNumericValue(mainCurrentInput);
      const categoryInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-month="${monthKey}"]`);
      const categoriesTotal = Array.from(categoryInputs).reduce((sum, input) => sum + getNumericValue(input), 0);
      
      if (categoriesTotal > mainCurrentValue) {
        const monthDate = new Date(monthKey + "-01");
        invalidMonths.push(formatMonthLabel(monthDate));
      }
    }
  }
  
  if (invalidMonths.length > 0) {
    toast("error", `Categories exceed month totals in: ${invalidMonths.join(', ')}`);
    return false;
  }
  
  // Yearly Category Validation
  const invalidYears: string[] = [];
  const yearlyInputs = document.querySelectorAll<HTMLInputElement>('.yearly-current-input');

  yearlyInputs.forEach(input => {
    const year = input.dataset.year;
    if (year) {
      const yearlyCurrentValue = getNumericValue(input);
      const categoryInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-year="${year}"]`);
      const categoriesTotal = Array.from(categoryInputs).reduce((sum, categoryInput) => sum + getNumericValue(categoryInput), 0);
      
      if (categoriesTotal > yearlyCurrentValue) {
        invalidYears.push(year);
      }
    }
  });

  if (invalidYears.length > 0) {
    toast("error", `Categories exceed year totals in: ${invalidYears.join(', ')}`);
    return false;
  }
      
  return true;
};
if (!validateFormSubmission()) {
  return;
}

 
      // Add this function to show/hide collection sections
      const toggleCollectionSections = (show: boolean): void => {
        const sections = [
          '.obl-section-container',
          '#historicalCollectionSection',
          '#detailedCollectionSection', 
          '#longtermCollectionSection',
          '#yearlyCollectionSection'
        ];
        
        sections.forEach(selector => {
          const element = document.querySelector(selector) as HTMLElement;
          if (element) {
            if (show) {
              element.classList.remove('hidden-section');
              element.classList.add('visible-section');
            } else {
              element.classList.remove('visible-section');
              element.classList.add('hidden-section');
            }
          }
        });
      };

      // ========== COLLECTION FORM FUNCTIONS ==========

 // Enhanced OBL Breakdown calculation that fetches from database
const calculateOBLBreakdown = async (projectId: number): Promise<OBLBreakdown> => {
  const breakdown: OBLBreakdown = {
    normalDue: 0,
    normalOverdue: 0,
    retentionDue: 0,
    retentionOverdue: 0,
    gstTds: 0,
    wht: 0
  };

  try {
    const project = projects.find(p => p.Id === projectId);
    if (!project) { 
      return breakdown;
    } 
    // Find the collection item for this project
    const collection = collections.find(f => f.Project?.Id === projectId);
    if (!collection) { 
      return breakdown;
    } 
    // Use the CORRECT field names from your database
    return {
      normalDue: getNumericFieldValue(collection, 'NormalDue'),
      normalOverdue: getNumericFieldValue(collection, 'NormalOverdue'),
      retentionDue: getNumericFieldValue(collection, 'RetentionDue'),
      retentionOverdue: getNumericFieldValue(collection, 'RetentionOverdue'),
      gstTds: getNumericFieldValue(collection, 'GSTTDS'), // Single field for GST+TDS
      wht: getNumericFieldValue(collection, 'WHT')
    };

  } catch (error) {
    console.error("❌ Error in calculateOBLBreakdown:", error);
    return breakdown;
  }
};

 const renderOBLBreakdown = (breakdown: OBLBreakdown): void => { 
  
  const setBreakdownValue = (elementId: string, value: number) => {
    const element = document.getElementById(elementId) as HTMLInputElement;
    if (element) {
      // Always show the actual value (0 if no data)
      setNumericValue(element, value); 
    } else {
      console.error(`Element not found: ${elementId}`);
    }
  };

  setBreakdownValue('oblNormalDue', breakdown.normalDue);
  setBreakdownValue('oblNormalOverdue', breakdown.normalOverdue);
  setBreakdownValue('oblRetentionDue', breakdown.retentionDue);
  setBreakdownValue('oblRetentionOverdue', breakdown.retentionOverdue);
  setBreakdownValue('oblGstTds', breakdown.gstTds);  
  setBreakdownValue('oblWht', breakdown.wht);
};

const onProjectChange = async (projectId: number, existingCollection?: CollectionItem): Promise<void> => {
  const project = projects.find(p => p.Id === projectId);
  if (!project) return;

  // Show all collection sections when project is selected
  toggleCollectionSections(true);

  renderProjectDetails(project);
  
  let collectionData: CollectionData = {};
  if (existingCollection) {
    collectionData = safeJsonParse(existingCollection.CollectionData, {});
  }

  const isNewProject = !existingCollection;
  
  const oblContainer = document.querySelector('.obl-section-container') as HTMLElement;
  const fieldNote = oblContainer.querySelector('.field-note') as HTMLElement;
  
  if (isNewProject) {
    oblContainer.className = 'obl-section-container visible-section new-project';
    oblLastMonthInput.removeAttribute('readonly');
    oblLastMonthInput.placeholder = "Enter initial OBL for new project";
    if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
    oblValidationMessage.textContent = "Enter initial OBL value for new project";
    oblValidationMessage.className = 'validation-message';
    
    const defaultOBL = project.PC ? 100000 : 0;
    setNumericValue(oblLastMonthInput, defaultOBL);
    
    // For new projects, get breakdown from Collection List
    const breakdown = await calculateOBLBreakdown(projectId);
    renderOBLBreakdown(breakdown);
  } else {
    oblContainer.className = 'obl-section-container visible-section existing-project';
    oblLastMonthInput.setAttribute('readonly', 'true');
    
    const oblValue = existingCollection?.OBL || 0;
    setNumericValue(oblLastMonthInput, oblValue);
    
    oblLastMonthInput.placeholder = "Receivable value";
    if (fieldNote) fieldNote.textContent = "Receivable value record";
    
    if (oblValue > 0) {
      oblLastMonthInput.value = oblValue.toString();
      oblLastMonthInput.className = oblLastMonthInput.className.replace('input-empty', 'input-with-value');
    }
    
    // Get OBL breakdown directly from Collection List
    const breakdown = await calculateOBLBreakdown(projectId);
    renderOBLBreakdown(breakdown);
  }

  // Render collection interface only ONCE
  renderCollectionInterface(collectionData, getNumericValue(oblLastMonthInput), existingCollection);
  
  // Initialize validation after rendering
  initializeFormValidation();
};
// Function to create the OBL breakdown list in SharePoint (run once)
const createOBLBreakdownList = async (): Promise<void> => {
  try {
    const digest = await getDigest();
    
    // Check if list already exists
    const checkResponse = await fetch(`${siteUrl}/_api/web/lists/getbytitle('OBLBreakdown')`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose'
      }
    });

    if (checkResponse.ok) { 
      return;
    }

    // Create list only if it doesn't exist
    const listDefinition = {
      __metadata: { type: 'SP.List' },
      Title: 'OBLBreakdown',
      Description: 'Stores OBL breakdown details for projects',
      BaseTemplate: 100
    };

    const createListResponse = await fetch(`${siteUrl}/_api/web/lists`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose',
        'X-RequestDigest': digest
      },
      body: JSON.stringify(listDefinition)
    });

    if (createListResponse.ok) { 
      // Add fields to the list (your existing field creation code)
    } else { 
    }
  } catch (error) { 
  }
};

 
    

      const renderProjectDetails = (project: ProjectItem): void => { 
        projectDetails.innerHTML =
          `<p><b>Profit Center:</b> ${project.PC || "-"}</p>
           <p><b>Customer:</b> ${project.CustomerName || "-"}</p>
           <p><b>Project Ref:</b> ${project.ProjectReference || "-"}</p>
           <p><b>Group Head:</b> ${project.GroupHead || "-"}</p>
           <p><b>Project Manager:</b> ${typeof project.ProjectManager === "object" ? project.ProjectManager?.Title : project.ProjectManager || "-"}</p>`;
      };

      const getCollectionMonths = (): string[] => {
        return generateIdealMonthStructure();
      };

const renderCollectionInterface = (existingData: CollectionData, displayOBL: number, existingCollection?: CollectionItem): void => {
  allMonths = getCollectionMonths();
  
  setNumericValue(oblLastMonthInput, displayOBL);

  renderHistoricalMonths(allMonths.slice(0, 3), existingData);
  renderFirstRow(allMonths.slice(3, 6), existingData);
  renderRemainingMonths(allMonths.slice(6), existingData);
  
  // Get the last month from the long-term collection to determine yearly start
  const longTermMonths = allMonths.slice(6); // This is the long-term months
  const lastMonthKey = longTermMonths[longTermMonths.length - 1]; // Last month of long-term collection
   
  renderYearlyCollection(existingData.yearly || createFreshYearlyStructure(lastMonthKey));

  protectHistoricalElements();
  
  updateOBLValidationDisplay();
  attachCollectionEventListeners();
  
  // Initialize validation after rendering
  initializeFormValidation();
  
  // Initialize forecast validation
  setupForecastValidation();
};

const protectHistoricalElements = (): void => {
  // Remove any existing historical elements and replace with readonly versions
  document.querySelectorAll('.historical-month').forEach(monthElement => {
    // Clone the element to remove event listeners
    const newElement = monthElement.cloneNode(true) as HTMLElement;
    monthElement.parentNode?.replaceChild(newElement, monthElement);
    
    // Add readonly attributes to all inputs
    newElement.querySelectorAll('input').forEach(input => {
      input.setAttribute('readonly', 'true');
      input.style.backgroundColor = '#f8f9fa';
      input.style.cursor = 'not-allowed';
    });
  });
  
  // Add global event prevention
  document.querySelectorAll('.historical-month').forEach(section => {
    section.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      return false;
    });
    
    section.addEventListener('keydown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      return false;
    });
  });
};


 

// Force validation on form load
const initializeFormValidation = (): void => {
  setTimeout(() => { 
    // Validate all detailed months
    const detailedMonths = allMonths.slice(3, 6);
    detailedMonths.forEach(monthKey => {
      validateSingleMonthCategories(monthKey);
    });
    
    // Update OBL display
    updateOBLValidationDisplay();
     
  }, 500);
};


      const renderHistoricalMonths = (months: string[], existingData: CollectionData): void => {
        let html = '';

        months.forEach((monthKey, index) => {
          const monthDate = new Date(monthKey + "-01");
          const monthLabel = formatMonthLabel(monthDate);
          const data = existingData[monthKey] as CollectionMonthData || { plan: 0, actual: 0, items: {} };
          
          html += renderHistoricalMonthBox(monthKey, monthLabel, data, index);
        });

        historicalContainer.innerHTML = html;
      };

const renderHistoricalMonthBox = (monthKey: string, monthLabel: string, data: CollectionMonthData, index: number): string => {
  const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
  const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
  const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
  const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
  
  const categories = data.items || createEmptyCategories();
  
  return `
    <div class="month-box historical-month">
      <div class="month-header">${monthLabel} (Historical - Readonly)</div>
      
      <div class="month-block">
        <div class="main-inputs-container">
          <div class="main-input-group">
            <label>Previous</label>
            <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                  readonly class="main-plan-input ${planInputClass} number-input" />
          </div>
          <div class="main-input-group">
            <label>Current</label>
            <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                  readonly class="main-current-input ${actualInputClass} number-input" />
          </div>
        </div>
      </div>

      <div class="categories-section">
        <div class="categories-header">
          <div>Category</div>
          <div>Previous</div>
          <div>Current</div>
        </div>
        
        <!-- Normal Category -->
        <div class="category-row">
          <input type="text" value="Normal" data-category="Normal" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Normal?.plan > 0 ? categories.Normal.plan.toString() : ''}" 
                data-category-type="plan" data-category="Normal" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories.Normal?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Normal?.actual > 0 ? categories.Normal.actual.toString() : ''}" 
                data-category-type="actual" data-category="Normal" data-month="${monthKey}" 
                readonly class="category-current-input ${categories.Normal?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
        
        <!-- Normal Overdue Category -->
        <div class="category-row">
          <input type="text" value="Normal Overdue" data-category="Normal Overdue" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories['Normal Overdue']?.plan > 0 ? categories['Normal Overdue'].plan.toString() : ''}" 
                data-category-type="plan" data-category="Normal Overdue" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories['Normal Overdue']?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories['Normal Overdue']?.actual > 0 ? categories['Normal Overdue'].actual.toString() : ''}" 
                data-category-type="actual" data-category="Normal Overdue" data-month="${monthKey}" 
                readonly class="category-current-input ${categories['Normal Overdue']?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
        
        <!-- Retention Category -->
        <div class="category-row">
          <input type="text" value="Retention" data-category="Retention" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Retention?.plan > 0 ? categories.Retention.plan.toString() : ''}" 
                data-category-type="plan" data-category="Retention" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories.Retention?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Retention?.actual > 0 ? categories.Retention.actual.toString() : ''}" 
                data-category-type="actual" data-category="Retention" data-month="${monthKey}" 
                readonly class="category-current-input ${categories.Retention?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
        
        <!-- Retention Overdue Category -->
        <div class="category-row">
          <input type="text" value="Retention Overdue" data-category="Retention Overdue" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories['Retention Overdue']?.plan > 0 ? categories['Retention Overdue'].plan.toString() : ''}" 
                data-category-type="plan" data-category="Retention Overdue" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories['Retention Overdue']?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories['Retention Overdue']?.actual > 0 ? categories['Retention Overdue'].actual.toString() : ''}" 
                data-category-type="actual" data-category="Retention Overdue" data-month="${monthKey}" 
                readonly class="category-current-input ${categories['Retention Overdue']?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
      </div>
    </div>
  `;
};



const renderFirstRow = (months: string[], existingData: CollectionData): void => {
  let html = '';

  // Create single row container for all three months
  html += `<div class="detailed-months-row">`;
  
  // Current Month - 45%
  const currentMonth = months[0];
  if (currentMonth) {
    const monthDate = new Date(currentMonth + "-01");
    const monthLabel = formatMonthLabel(monthDate);
    const data = existingData[currentMonth] as CollectionMonthData || { plan: 0, actual: 0, items: createEmptyCategories() };
    
    html += `<div class="current-month-container">`;
    html += renderDetailedMonthBox(currentMonth, monthLabel, data, true); // true for current month
    html += `</div>`;
  }
  
  // Next 2 Months - 55% (split equally)
  html += `<div class="next-months-container">`;
  for (let i = 1; i <= 2; i++) {
    if (i < months.length) {
      const monthKey = months[i];
      const monthDate = new Date(monthKey + "-01");
      const monthLabel = formatMonthLabel(monthDate);
      const data = existingData[monthKey] as CollectionMonthData || { plan: 0, actual: 0, items: createEmptyCategories() };
      
      html += `<div class="next-month-box">`;
      html += renderDetailedMonthBox(monthKey, monthLabel, data, false); // false for non-current months
      html += `</div>`;
    }
  }
  html += `</div>`;
  
  html += `</div>`;

  firstRowContainer.innerHTML = html;
};

const renderRemainingMonths = (months: string[], existingData: CollectionData): void => {
  let html = '';

  // 16 months arranged in 4 rows of 4 months each (4×4 = 16)
  for (let row = 0; row < 4; row++) {
    html += `<div class="remaining-row">`;
    for (let col = 0; col < 4; col++) {
      const index = (row * 4) + col;
      if (index >= months.length) break;
      
      const monthKey = months[index];
      const monthDate = new Date(monthKey + "-01");
      const monthLabel = formatMonthLabel(monthDate);
      const data = existingData[monthKey] as CollectionMonthData || { plan: 0, actual: 0, items: createSimpleCategories() };
      
      html += renderSimpleMonthBox(monthKey, monthLabel, data);
    }
    html += `</div>`;
  }

  remainingContainer.innerHTML = html;
};

      const renderYearlyCollection = (yearlyData: YearlyCollectionData): void => {
        let html = '';

        const years = Object.keys(yearlyData).sort();
        
        years.forEach(year => {
          const data = yearlyData[year] || { plan: 0, actual: 0 };
          html += renderYearlyBox(year, data);
        });

        yearlyContainer.innerHTML = html;
      };

const renderYearlyBox = (year: string, data: { plan: number; actual: number, items?: { [key: string]: CollectionCategory } }): string => {
  const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
  const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
  const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
  const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
  
  const categories = data.items || {
    "Normal": { name: 'Normal', plan: 0, actual: 0 },
    "Retention": { name: 'Retention', plan: 0, actual: 0 }
  };

  return `
    <div class="yearly-box">
      <div class="yearly-header">${year}</div>
      
      <div class="yearly-inputs-container">
        <div class="yearly-input-group">
          <label>Previous</label>
          <input type="text" value="${displayPlanValue}" data-type="plan" data-year="${year}"
                readonly class="yearly-plan-input ${planInputClass} number-input" />
        </div>
        <div class="yearly-input-group">
          <label>Current</label>
          <input type="text" value="${displayActualValue}" data-type="actual" data-year="${year}"
                class="yearly-current-input ${actualInputClass} number-input" />
        </div>
      </div>

      <div class="categories-section">
        <div class="categories-header">
          <div>Category</div>
          <div>Previous</div>
          <div>Current</div>
        </div>
        
        <!-- Normal Category -->
        <div class="category-row">
          <input type="text" value="Normal" data-category="Normal" data-year="${year}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Normal?.plan > 0 ? categories.Normal.plan.toString() : ''}" 
                data-category-type="plan" data-category="Normal" data-year="${year}" 
                readonly class="category-plan-input ${categories.Normal?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Normal?.actual > 0 ? categories.Normal.actual.toString() : ''}" 
                data-category-type="actual" data-category="Normal" data-year="${year}" 
                class="category-current-input ${categories.Normal?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
        
        <!-- Retention Category -->
        <div class="category-row">
          <input type="text" value="Retention" data-category="Retention" data-year="${year}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Retention?.plan > 0 ? categories.Retention.plan.toString() : ''}" 
                data-category-type="plan" data-category="Retention" data-year="${year}" 
                readonly class="category-plan-input ${categories.Retention?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Retention?.actual > 0 ? categories.Retention.actual.toString() : ''}" 
                data-category-type="actual" data-category="Retention" data-year="${year}" 
                class="category-current-input ${categories.Retention?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
        
        <!-- Validation Display -->
        <div class="yearly-total-validation" data-year="${year}" style="margin-top: 10px; font-size: 11px; text-align: center;"></div>
      </div>
    </div>
  `;
};

const renderDetailedMonthBox = (monthKey: string, monthLabel: string, data: CollectionMonthData, isCurrentMonth: boolean = false): string => {
  const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
  const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
  const displayForecastValue = data.forecast || 0;
  const displayDateValue = data.date || '';
  
  const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
  const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
  const forecastInputClass = displayForecastValue > 0 ? 'input-with-value' : 'input-empty';
  const dateInputClass = displayDateValue ? 'input-with-value' : 'input-empty';
  
  const categories = data.items || createEmptyCategories();
  
  return `
    <div class="detailed-month-box ${isCurrentMonth ? 'current-month-box' : 'next-month-box'}">
      <div class="month-header">
        ${monthLabel}
        ${isCurrentMonth ? '<span class="current-month-indicator">Current</span>' : ''}
      </div>
      
      <div class="month-block">
        <div class="enhanced-inputs-container">
          <!-- Previous Column -->
          <div class="enhanced-input-group">
            <label>Previous</label>
            <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                  readonly class="main-plan-input ${planInputClass} number-input" />
          </div>
          
          <!-- Current Column - NUMERIC INPUT -->
          <div class="enhanced-input-group">
            <label>Current</label>
            <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                  class="main-current-input ${actualInputClass} number-input" 
                  onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                  (event.key >= '0' && event.key <= '9') || 
                  (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                  (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                  oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
          </div>
          
          <!-- Forecast Column - Only for Current Month - NUMERIC INPUT -->
          ${isCurrentMonth ? `
            <div class="enhanced-input-group">
              <label>Forecast</label>
              <input type="text" value="${displayForecastValue}" data-type="forecast" data-month="${monthKey}"
                    class="main-forecast-input ${forecastInputClass} number-input"
                    onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                    (event.key >= '0' && event.key <= '9') || 
                    (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                    (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                    oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
            </div>
            
            <!-- Date Column - Only for Current Month -->
            <div class="enhanced-input-group">
              <label>Date</label>
              <input type="date" value="${displayDateValue}" data-type="date" data-month="${monthKey}"
                    class="forecast-date-input ${dateInputClass}" />
            </div>
          ` : ''}
        </div>
        <div id="validation-${monthKey}" class="month-total-validation"></div>
      </div>

      <div class="categories-section">
        <div class="categories-header">
          <div>Category</div>
          <div>Previous</div>
          <div>Current</div>
          ${isCurrentMonth ? `
            <div>Forecast</div>
            <div>Date</div>
          ` : ''}
        </div>
        
        <!-- Normal Category -->
        <div class="category-row">
          <input type="text" value="Normal" data-category="Normal" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Normal?.plan > 0 ? categories.Normal.plan.toString() : ''}" 
                data-category-type="plan" data-category="Normal" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories.Normal?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Normal?.actual > 0 ? categories.Normal.actual.toString() : ''}" 
                data-category-type="actual" data-category="Normal" data-month="${monthKey}" 
                class="category-current-input ${categories.Normal?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input"
                onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                (event.key >= '0' && event.key <= '9') || 
                (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
          ${isCurrentMonth ? `
            <input type="text" value="${categories.Normal?.forecast || 0}" 
                  data-category-type="forecast" data-category="Normal" data-month="${monthKey}" 
                  class="category-forecast-input number-input"
                  onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                  (event.key >= '0' && event.key <= '9') || 
                  (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                  (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                  oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
            <input type="date" value="${categories.Normal?.date || ''}" 
                  data-category-type="date" data-category="Normal" data-month="${monthKey}" 
                  class="category-date-input" />
          ` : ''}
        </div>
        
        <!-- Normal Overdue Category -->
        <div class="category-row">
          <input type="text" value="Normal Overdue" data-category="Normal Overdue" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories['Normal Overdue']?.plan > 0 ? categories['Normal Overdue'].plan.toString() : ''}" 
                data-category-type="plan" data-category="Normal Overdue" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories['Normal Overdue']?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories['Normal Overdue']?.actual > 0 ? categories['Normal Overdue'].actual.toString() : ''}" 
                data-category-type="actual" data-category="Normal Overdue" data-month="${monthKey}" 
                class="category-current-input ${categories['Normal Overdue']?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input"
                onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                (event.key >= '0' && event.key <= '9') || 
                (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
          ${isCurrentMonth ? `
            <input type="text" value="${categories['Normal Overdue']?.forecast || 0}" 
                  data-category-type="forecast" data-category="Normal Overdue" data-month="${monthKey}" 
                  class="category-forecast-input number-input"
                  onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                  (event.key >= '0' && event.key <= '9') || 
                  (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                  (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                  oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
            <input type="date" value="${categories['Normal Overdue']?.date || ''}" 
                  data-category-type="date" data-category="Normal Overdue" data-month="${monthKey}" 
                  class="category-date-input" />
          ` : ''}
        </div>
        
        <!-- Retention Category -->
        <div class="category-row">
          <input type="text" value="Retention" data-category="Retention" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Retention?.plan > 0 ? categories.Retention.plan.toString() : ''}" 
                data-category-type="plan" data-category="Retention" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories.Retention?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Retention?.actual > 0 ? categories.Retention.actual.toString() : ''}" 
                data-category-type="actual" data-category="Retention" data-month="${monthKey}" 
                class="category-current-input ${categories.Retention?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input"
                onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                (event.key >= '0' && event.key <= '9') || 
                (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
          ${isCurrentMonth ? `
            <input type="text" value="${categories.Retention?.forecast || 0}" 
                  data-category-type="forecast" data-category="Retention" data-month="${monthKey}" 
                  class="category-forecast-input number-input"
                  onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                  (event.key >= '0' && event.key <= '9') || 
                  (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                  (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                  oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
            <input type="date" value="${categories.Retention?.date || ''}" 
                  data-category-type="date" data-category="Retention" data-month="${monthKey}" 
                  class="category-date-input" />
          ` : ''}
        </div>
        
        <!-- Retention Overdue Category -->
        <div class="category-row">
          <input type="text" value="Retention Overdue" data-category="Retention Overdue" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories['Retention Overdue']?.plan > 0 ? categories['Retention Overdue'].plan.toString() : ''}" 
                data-category-type="plan" data-category="Retention Overdue" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories['Retention Overdue']?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories['Retention Overdue']?.actual > 0 ? categories['Retention Overdue'].actual.toString() : ''}" 
                data-category-type="actual" data-category="Retention Overdue" data-month="${monthKey}" 
                class="category-current-input ${categories['Retention Overdue']?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input"
                onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                (event.key >= '0' && event.key <= '9') || 
                (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
          ${isCurrentMonth ? `
            <input type="text" value="${categories['Retention Overdue']?.forecast || 0}" 
                  data-category-type="forecast" data-category="Retention Overdue" data-month="${monthKey}" 
                  class="category-forecast-input number-input"
                  onkeydown="return event.key === 'Backspace' || event.key === 'Delete' || event.key === 'Tab' || 
                  (event.key >= '0' && event.key <= '9') || 
                  (event.key >= 'NumPad0' && event.key <= 'NumPad9') || 
                  (event.ctrlKey && (event.key === 'a' || event.key === 'c' || event.key === 'v' || event.key === 'x'))" 
                  oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
            <input type="date" value="${categories['Retention Overdue']?.date || ''}" 
                  data-category-type="date" data-category="Retention Overdue" data-month="${monthKey}" 
                  class="category-date-input" />
          ` : ''}
        </div>
      </div>
    </div>
  `;
};

     

const renderSimpleMonthBox = (monthKey: string, monthLabel: string, data: CollectionMonthData): string => {
  const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
  const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
  const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
  const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
  
  const categories = data.items || createSimpleCategories();
  
  return `
    <div class="month-box simple-month">
      <div class="month-header">${monthLabel}</div>
      
      <div class="main-inputs-container">
        <div class="main-input-group">
          <label>Previous</label>
          <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}" 
                readonly class="main-plan-input ${planInputClass} number-input" />
        </div>
        <div class="main-input-group">
          <label>Current</label>
          <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}" 
                class="main-current-input ${actualInputClass} number-input" />
        </div>
      </div>

      <div class="categories-section">
        <div class="categories-header">
          <div>Category</div>
          <div>Previous</div>
          <div>Current</div>
        </div>
        
        <!-- Normal Category -->
        <div class="category-row">
          <input type="text" value="Normal" data-category="Normal" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Normal?.plan > 0 ? categories.Normal.plan.toString() : ''}" 
                data-category-type="plan" data-category="Normal" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories.Normal?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Normal?.actual > 0 ? categories.Normal.actual.toString() : ''}" 
                data-category-type="actual" data-category="Normal" data-month="${monthKey}" 
                class="category-current-input ${categories.Normal?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
        
        <!-- Retention Category -->
        <div class="category-row">
          <input type="text" value="Retention" data-category="Retention" data-month="${monthKey}" 
                class="input-with-value" readonly />
          <input type="text" value="${categories.Retention?.plan > 0 ? categories.Retention.plan.toString() : ''}" 
                data-category-type="plan" data-category="Retention" data-month="${monthKey}" 
                readonly class="category-plan-input ${categories.Retention?.plan > 0 ? 'input-with-value' : 'input-empty'} number-input" />
          <input type="text" value="${categories.Retention?.actual > 0 ? categories.Retention.actual.toString() : ''}" 
                data-category-type="actual" data-category="Retention" data-month="${monthKey}" 
                class="category-current-input ${categories.Retention?.actual > 0 ? 'input-with-value' : 'input-empty'} number-input" />
        </div>
      </div>
      
      <!-- Validation display area -->
      <div class="month-total-validation" data-month="${monthKey}"></div>
    </div>
  `;
};


 

// Update the attachCollectionEventListeners function to include this:
const attachCollectionEventListeners = (): void => {
  document.querySelectorAll<HTMLInputElement>('.number-input').forEach(input => {
    allowOnlyNumbers(input);
  });

  // Set up focus handlers for all number inputs to store old values
  document.querySelectorAll<HTMLInputElement>('.number-input:not([readonly])').forEach(input => {
    input.addEventListener('focus', function() {
      this.setAttribute('data-old-value', getNumericValue(this).toString());
    });
  });

  // ===== MAIN CURRENT INPUTS =====
  document.querySelectorAll<HTMLInputElement>('.main-current-input:not([readonly])').forEach(input => {
    input.addEventListener('input', function() {
      const currentValue = getNumericValue(this);
      const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
      
      this.setAttribute('data-old-value', currentValue.toString());
      
      const isIncreasing = currentValue > oldValue;
      
      if (isIncreasing) {
        const allowByOBL = allowInputIncrease(this, currentValue);
        
        if (!allowByOBL) {
          setNumericValue(this, oldValue);
          updateOBLValidationDisplay(this);
          return;
        }
      }
      
      // Update visual state
      if (currentValue === 0) {
        this.className = this.className.replace('input-with-value', 'input-empty');
      } else {
        this.className = this.className.replace('input-empty', 'input-with-value');
      }

      // Trigger validation after a short delay
      setTimeout(() => {
        const monthKey = this.dataset.month;
        if (monthKey) {
          validateSingleMonthCategories(monthKey, this);
        }
        updateOBLValidationDisplay(this);
      }, 50);
    });
  });

  // ===== CATEGORY CURRENT INPUTS =====
  document.querySelectorAll<HTMLInputElement>('.category-current-input:not([readonly])').forEach(input => {
    input.addEventListener('input', function() {
      const currentValue = getNumericValue(this);
      const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
      
      this.setAttribute('data-old-value', currentValue.toString());
      
      const isIncreasing = currentValue > oldValue;
      
      if (isIncreasing) {
        const allowByOBL = allowInputIncrease(this, currentValue);
        const allowByMonth = allowCategoryInputIncrease(this, currentValue);
        
        if (!allowByOBL || !allowByMonth) {
          setNumericValue(this, oldValue);
          updateOBLValidationDisplay(this);
          return;
        }
      }
      
      // Update visual state
      if (currentValue === 0) {
        this.className = this.className.replace('input-with-value', 'input-empty');
      } else {
        this.className = this.className.replace('input-empty', 'input-with-value');
      }

      // Trigger validation after a short delay
      setTimeout(() => {
        const monthKey = this.dataset.month;
        if (monthKey) {
          validateSingleMonthCategories(monthKey, this);
        }
        updateOBLValidationDisplay(this);
      }, 50);
    });
  });

  // Apply validation to detailed months (current + next 2)
  const detailedMonths = allMonths.slice(3, 6); // Months 3,4,5
  detailedMonths.forEach(monthKey => {
    setupDetailedMonthValidation(monthKey);
  });

  // Global OBL validation for all inputs
  const allValidationInputs = document.querySelectorAll<HTMLInputElement>(`
    .main-current-input:not([readonly]),
    .category-current-input:not([readonly]),
    .yearly-current-input:not([readonly])
  `);

  allValidationInputs.forEach(input => {
    const existingHandler = input.getAttribute('data-validation-handler');
    if (!existingHandler) {
      input.setAttribute('data-validation-handler', 'true');
      input.addEventListener('input', function() {
        setTimeout(() => {
          updateOBLValidationDisplay(this);
        }, 100);
      });
    }
  });

  document.querySelectorAll<HTMLInputElement>('.main-forecast-input:not([readonly])').forEach(input => {
    input.addEventListener('input', function() {
      const currentValue = getNumericValue(this);
      // const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
      
      this.setAttribute('data-old-value', currentValue.toString());
      
      const monthKey = this.dataset.month;
      if (monthKey) {
        validateSingleMonthForecast(monthKey, this);
      }
    });
  });

  document.querySelectorAll<HTMLInputElement>('.category-forecast-input:not([readonly])').forEach(input => {
    input.addEventListener('input', function() {
      const currentValue = getNumericValue(this);
      // const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
      
      this.setAttribute('data-old-value', currentValue.toString());
      
      const monthKey = this.dataset.month;
      if (monthKey) {
        validateSingleMonthForecast(monthKey, this);
      }
    });
  });

  // Setup forecast validation
  setupForecastValidation();
};

const setupDetailedMonthValidation = (monthKey: string): void => {
  const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
  const categoryCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-month="${monthKey}"]`);

  if (mainCurrentInput) {
    // Remove existing listeners to avoid duplicates
    const newMainInput = mainCurrentInput.cloneNode(true) as HTMLInputElement;
    mainCurrentInput.parentNode?.replaceChild(newMainInput, mainCurrentInput);
    
    newMainInput.addEventListener('input', function() {
      setTimeout(() => {
        validateSingleMonthCategories(monthKey, this);
        updateOBLValidationDisplay(this);
      }, 50);
    });
  }

  categoryCurrentInputs.forEach(input => {
    // Remove existing listeners to avoid duplicates
    const newInput = input.cloneNode(true) as HTMLInputElement;
    input.parentNode?.replaceChild(newInput, input);
    
    newInput.addEventListener('input', function() {
      setTimeout(() => {
        validateSingleMonthCategories(monthKey, this);
        updateOBLValidationDisplay(this);
      }, 50);
    });
  });
};
   
      // ========== EDIT COLLECTION FUNCTION ==========
 
const editCollection = async (id: number): Promise<void> => {
  editingId = id;
  const collection = collections.find(f => f.Id === id);
  if (!collection) {
    toast("error", "Collection not found");
    return;
  }

  showForm(true);
  
  let collectionData: CollectionData = {};

  try {
    let collectionDataString = collection.CollectionData || "{}";
    collectionDataString = collectionDataString.trim();
    
    if (!collectionDataString || collectionDataString === '""' || collectionDataString === "null") {
      collectionDataString = "{}";
    }
    
    collectionData = JSON.parse(collectionDataString);
     
  } catch (e) { 
    collectionData = createFreshCollectionStructure();
    
    toast("warning", "Corrupted collection data detected. Loaded empty structure.");
  }
  
  collectionData = propagateMonthValues(collectionData);
  
   
  if (collection.Project) {
    projectSelect.value = String(collection.Project.Id);
    onProjectChange(collection.Project.Id, collection);
  }
  
  toast("info", `Editing collection for ${collection.Title}`);
};

 const createFreshYearlyStructure = (lastMonthKey?: string): YearlyCollectionData => {
  const yearlyData: YearlyCollectionData = {};
  
  let startYear: number;
  
  if (lastMonthKey) {
    // Use the year from the last month of long-term collection
    startYear = parseInt(lastMonthKey.split('-')[0]);
   } else {
    // Fallback: start from current year + 1
    startYear = new Date().getFullYear() + 1;
   }
  
  const endYear = startYear + 3; // 4 years total
  
  for (let year = startYear; year <= endYear; year++) {
    yearlyData[year.toString()] = {
      plan: 0,
      actual: 0,
      items: {
        "Normal": { name: 'Normal', plan: 0, actual: 0 },
        "Retention": { name: 'Retention', plan: 0, actual: 0 }
      }
    };
  }
  
  return yearlyData;
};

const applyAutoProgression = async (): Promise<void> => {
   
  if (collections.length === 0) {
     return;
  }

  const digest = await getDigest();
  let progressedCount = 0;
  let errorCount = 0;
  
  for (const collection of collections) {
    try {
      if (!collection.CollectionData) {
         continue;
      }
      
      const originalData = safeJsonParse(collection.CollectionData, {});
      
      if (checkIfNeedsProgression(originalData)) {
         
        // Use the enhanced progression that includes yearly progression
        const progressedData = propagateCollectionValues(originalData);
        
        const payload = {
          __metadata: { type: "SP.Data.Collection_x0020_ListListItem" },
          CollectionData: JSON.stringify(progressedData),
          UpdatedDate: new Date().toISOString()
        };
        
        const response = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${collection.Id})`, {
          method: "POST",
          headers: {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest,
            "IF-MATCH": "*",
            "X-HTTP-Method": "MERGE"
          },
          body: JSON.stringify(payload)
        });
        
        if (response.ok) {
          progressedCount++;
          } else {
          errorCount++;
          console.error(`❌ Failed to progress collection: ${collection.Id}`, response.status);
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      } else {
       }
    } catch (error) {
      errorCount++;
      console.error(`❌ Error progressing collection: ${collection.Id}`, error);
    }
  }
  
  if (progressedCount > 0) {
     await loadCollections();
    toast("success", `Monthly and yearly data progressed for ${progressedCount} collections`);
  } else if (errorCount > 0) {
     toast("warning", `Some errors occurred during monthly and yearly progression`);
  } else {
   }
};

const propagateCollectionValues = (collectionData: CollectionData): CollectionData => {
   
  const updatedData: CollectionData = { ...collectionData };
  
  // Ensure yearly data exists before propagation
  if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) {
     const longTermMonths = generateIdealMonthStructure().slice(6);
    const lastMonthKey = longTermMonths[longTermMonths.length - 1];
    updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
  }

  // Detect if it's a new month by checking current month structure
  const originalMonths = Object.keys(collectionData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
  const idealMonths = generateIdealMonthStructure();
  const isNewMonth = originalMonths[0] !== idealMonths[0];
   
  // Apply monthly progression (long-term collection)
  const monthlyProgressed = propagateMonthValues(updatedData);
  
  // Apply yearly progression only when month changes
  const yearlyProgressed = propagateYearlyValues(monthlyProgressed, isNewMonth); 
  return yearlyProgressed;
};

// ========== FIXED YEARLY PROPAGATION ==========

const propagateYearlyValues = (collectionData: CollectionData, isNewMonth: boolean = false): CollectionData => {
  if (!isNewMonth) { 
    return collectionData;
  }

  const updatedData: CollectionData = { ...collectionData };
  
  if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) { 
    return updatedData;
  }

  const yearlyData = updatedData.yearly; 
  const updatedYearlyData: YearlyCollectionData = {};

  // CORRECT LOGIC:
  // For each year, current ACTUAL values become the new PLAN values for the SAME YEAR
  // ACTUAL values reset to 0
  
  Object.keys(yearlyData).forEach(year => {
    const yearData = yearlyData[year];
    if (yearData) {
      updatedYearlyData[year] = {
        plan: yearData.actual, // Current actual becomes new plan for same year
        actual: 0, // Reset actual to 0
        items: {}
      };
      
      // Apply same logic to categories
      if (yearData.items) {
        Object.keys(yearData.items).forEach(categoryKey => {
          const category = yearData.items![categoryKey];
          updatedYearlyData[year].items![categoryKey] = {
            name: categoryKey,
            plan: category.actual, // Category actual becomes category plan
            actual: 0 // Reset category actual to 0
          };
        });
      }
    }
  });

  updatedData.yearly = updatedYearlyData; 
  return updatedData;
};
 

 
      // ========== IMPORT FUNCTIONALITY ==========

      const importActualData = (): void => { 
        const modalHTML = `
          <div class="import-modal">
            <div class="import-modal-content">
              <div class="import-modal-header">
                <h3>Import Monthly Actual Collection Data</h3>
                <button class="close-modal">&times;</button>
              </div> 
              <div class="import-section">
                <h4>Step 1: Download Template</h4>
                <button class="btn-primary" id="downloadTemplate">⬇️ Download Template</button>
              </div>

              <div class="import-section">
                <h4>Step 2: Upload Excel File</h4>
                <div class="file-upload-area" id="fileUploadArea">
                  <div class="upload-icon">📁</div>
                  <p>Click to upload or drag & drop Excel file</p>
                  <p><small>Supported format: Excel with Project Reference, Month, and Actual Collection columns</small></p>
                  <input type="file" id="excelFile" class="file-input" accept=".xlsx,.xls">
                  <div class="file-info" id="fileInfo"></div>
                </div>
              </div>

              <div class="import-section" id="previewSection" style="display:none;">
                <h4>Step 3: Preview & Import</h4>
                <div class="import-preview" id="importPreview"></div>
                <div class="import-actions">
                  <button class="btn-secondary" id="cancelImport">Cancel</button>
                  <button class="btn-primary" id="confirmImport">Import Data</button>
                </div>
                <div class="import-status" id="importStatus"></div>
              </div>
            </div>
          </div>
        `;

        document.body.insertAdjacentHTML("beforeend", modalHTML);
        const modal = document.querySelector(".import-modal") as HTMLElement;
        modal.style.display = "flex";

        // Elements
        const fileUploadArea = document.querySelector("#fileUploadArea") as HTMLElement;
        const excelFileInput = document.querySelector("#excelFile") as HTMLInputElement;
        const fileInfo = document.querySelector("#fileInfo") as HTMLElement;
        const previewSection = document.querySelector("#previewSection") as HTMLElement;
        const importPreview = document.querySelector("#importPreview") as HTMLElement;
        const confirmImport = document.querySelector("#confirmImport") as HTMLButtonElement;
        const cancelImport = document.querySelector("#cancelImport") as HTMLButtonElement;
        const closeModal = document.querySelector(".close-modal") as HTMLButtonElement;
        const importStatus = document.querySelector("#importStatus") as HTMLElement;
        const downloadTemplateBtn = document.querySelector("#downloadTemplate") as HTMLButtonElement;

        let importData: any[] = [];
        let listEntityType: string = "";

        // Month name to number mapping
        const monthMap: { [key: string]: number } = {
            'jan': 1, 'january': 1, 'jan-': 1,
            'feb': 2, 'february': 2, 'feb-': 2,
            'mar': 3, 'march': 3, 'mar-': 3,
            'apr': 4, 'april': 4, 'apr-': 4,
            'may': 5, 'may-': 5,
            'jun': 6, 'june': 6, 'jun-': 6,
            'jul': 7, 'july': 7, 'jul-': 7,
            'aug': 8, 'august': 8, 'aug-': 8,
            'sep': 9, 'september': 9, 'sep-': 9,
            'oct': 10, 'october': 10, 'oct-': 10,
            'nov': 11, 'november': 11, 'nov-': 11,
            'dec': 12, 'december': 12, 'dec-': 12
        };

        // Parse month string to YYYY-MM format
        const parseMonth = (monthStr: string): string => {
            if (!monthStr) return '';
            
            // If already in YYYY-MM format
            if (/^\d{4}-\d{2}$/.test(monthStr)) {
                return monthStr;
            }
            
            // Handle formats like "Nov-25", "November 2025", "Nov 2025"
            const match = monthStr.toLowerCase().match(/([a-z]+)[-\s]*'?(\d{2,4})?/);
            if (match) {
                const monthName = match[1];
                let year = match[2];
                
                const monthNum = monthMap[monthName];
                if (monthNum) {
                    // Handle year
                    if (!year) {
                        // If no year provided, use current year
                        year = new Date().getFullYear().toString();
                    } else if (year.length === 2) {
                        // Convert 2-digit year to 4-digit
                        const currentYear = new Date().getFullYear();
                        const century = Math.floor(currentYear / 100) * 100;
                        const yearNum = parseInt(year);
                        year = (century + yearNum).toString();
                    }
                    
                    return `${year}-${monthNum.toString().padStart(2, '0')}`;
                }
            }
            
            return '';
        };

        // Get correct List Entity Type
        const getListEntityType = async (): Promise<string> => {
            if (listEntityType) return listEntityType;
            const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`, {
                headers: { Accept: "application/json;odata=verbose" },
            });
            const data = await res.json();
            listEntityType = data.d.ListItemEntityTypeFullName; 
            return listEntityType;
        };

        // Update revenue data function for collections
        const updateRevenueData = (existingData: string, month: string, actualRevenue: number): string => { 
            let finalData: { [key: string]: number } = {};
            
            if (existingData && existingData.trim() !== '' && existingData !== '{}' && existingData !== 'null' && existingData !== 'undefined') {
                try {
                    const parsed = JSON.parse(existingData); 
                    finalData = { ...parsed };
                } catch (parseError) { 
                    finalData = {};
                }
            } else { 
                finalData = {};
            } 
            finalData[month] = actualRevenue; 
            const getFourMonthWindow = (): string[] => {
                const currentDate = new Date();
                const validMonths: string[] = [];
                
                for (let i = 0; i < 4; i++) {
                    const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
                    const yearStr = date.getFullYear();
                    const monthStr = (date.getMonth() + 1).toString().padStart(2, '0');
                    validMonths.push(`${yearStr}-${monthStr}`);
                }
                
                return validMonths.sort().reverse();
            };
            
            const fourMonthWindow = getFourMonthWindow(); 
            const resultData: { [key: string]: number } = {};
            
            fourMonthWindow.forEach(monthKey => {
                resultData[monthKey] = finalData[monthKey] !== undefined ? finalData[monthKey] : 0;
            }); 
            return JSON.stringify(resultData);
        };

        // File Upload Handling
        fileUploadArea.addEventListener("click", () => excelFileInput.click());
        fileUploadArea.addEventListener("dragover", (e) => {
            e.preventDefault();
            fileUploadArea.classList.add("dragover");
        });
        fileUploadArea.addEventListener("dragleave", () => fileUploadArea.classList.remove("dragover"));
        fileUploadArea.addEventListener("drop", (e) => {
            e.preventDefault();
            fileUploadArea.classList.remove("dragover");
            const files = e.dataTransfer?.files;
            if (files && files[0]) {
                excelFileInput.files = files;
                handleFileSelection(files[0]);
            }
        });
        excelFileInput.addEventListener("change", (e) => {
            const files = (e.target as HTMLInputElement).files;
            if (files && files[0]) handleFileSelection(files[0]);
        });

        // Handle Excel File Selection
        const handleFileSelection = async (file: File) => { 
            if (!file.name.toLowerCase().match(/\.(xlsx|xls)$/)) {
                toast("error", "Please select an Excel file (.xlsx or .xls)");
                return;
            }

            fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`;

            try {
                const parsedData = await parseExcelFile(file); 
                if (validateImportData(parsedData)) { 
                    importData = parsedData;
                    showImportPreview(parsedData);
                    previewSection.style.display = "block";
                    previewSection.style.opacity = "1"; 
                } else { 
                    toast("error", "Invalid Excel format. Please check the required columns.");
                }
            } catch (error) { 
                toast("error", "Error reading Excel file");
            }
        };

        // Parse Excel File
        const parseExcelFile = (file: File): Promise<any[]> => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const data = new Uint8Array(e.target?.result as ArrayBuffer);
                        const workbook = XLSX.read(data, { type: "array" });
                        const sheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[sheetName]; 
                        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); 
                        if (jsonData.length < 2) { 
                            return resolve([]);
                        } 
                        const headers = jsonData[0] as string[];  
                        const rows: any[] = []; 
                        for (let i = 1; i < jsonData.length; i++) {
                            const rowData = jsonData[i] as any[];
                            if (!rowData || rowData.length === 0) continue; 
                            const row: any = {}; 
                            headers.forEach((header, idx) => {
                                if (header && rowData[idx] !== undefined && rowData[idx] !== null) {
                                    row[header.trim()] = rowData[idx];
                                }
                            }); 
                            if (row["Month"] || row["month"]) {
                                let monthValue = row["Month"] || row["month"];
                                
                                if (typeof monthValue === "number") {
                                    const excelDate = new Date(Math.round((monthValue - 25569) * 86400 * 1000));
                                    const yyyy = excelDate.getFullYear();
                                    const mm = String(excelDate.getMonth() + 1).padStart(2, "0");
                                    monthValue = `${yyyy}-${mm}`;
                                }

                                const monthStr = monthValue.toString();
                                row.parsedMonth = parseMonth(monthStr); 
                            }

                            const hasProjectRef = row["Project Reference"] || row["project_reference"];
                            const hasMonth = row.parsedMonth;
                            
                            if (hasProjectRef && hasMonth) {
                                rows.push(row); 
                            } else {
                             }
                        } 
                        resolve(rows);
                    } catch (err) { 
                        reject(err);
                    }
                };
                reader.onerror = (error) => { 
                    reject(new Error("Failed to read file"));
                };
                reader.readAsArrayBuffer(file);
            });
        };

        // Validate Columns
        const validateImportData = (data: any[]): boolean => { 
            if (data.length === 0) { 
                return false;
            } 
            const first = data[0];
            const keys = Object.keys(first).map(k => k.toLowerCase()); 
            
            const hasProjectRef = keys.some(k => k.includes('project') && k.includes('reference'));
            const hasMonth = keys.some(k => k.includes('month'));
            
 

            return hasProjectRef && hasMonth;
        };

        // Show Preview
        const showImportPreview = (data: any[]) => { 
            const monthSummary: { [key: string]: number } = {};
            
            data.forEach(row => {
                const month = row.parsedMonth;
                if (month) {
                    monthSummary[month] = (monthSummary[month] || 0) + 1;
                }
            });

            const monthSummaryText = Object.keys(monthSummary)
                .map(month => {
                    return `${month}: ${monthSummary[month]} records`;
                })
                .join(', ');

            const previewHTML = `
                <div style="padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <h4 style="color: #28a745; margin-bottom: 15px;">✅ File Ready for Import</h4>
                    <p><strong>Found ${data.length} records to import:</strong></p>
                    <p><strong>Month Summary:</strong> ${monthSummaryText || 'No months found'}</p>
                    <div class="preview-table-container" style="max-height: 400px; overflow-y: auto;">
                        <table class="preview-table" style="width: 100%; border-collapse: collapse;">
                            <thead style="background: #007bff; color: white;">
                                <tr>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Project Reference</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Month</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Actual Collection</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Project Match</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data
                                    .slice(0, 10)
                                    .map((row, index) => {
                                        const projectRef = row["Project Reference"] || row["project_reference"] || 'N/A';
                                        const month = row["Month"] || row["month"] || 'N/A';
                                        const actualRevenue = row["Actual Collection"] || row["actual_collection"] || row["Actual"] || row["actual"] || '0';
                                        const project = projects.find((p) => p.ProjectReference === projectRef);
                                        
                                        return `
                                            <tr style="${index % 2 === 0 ? 'background: #f8f9fa;' : 'background: white;'}">
                                                <td style="padding: 8px; border: 1px solid #ddd;">${projectRef}</td>
                                                <td style="padding: 8px; border: 1px solid #ddd;">${month} (${row.parsedMonth || 'Invalid'})</td>
                                                <td style="padding: 8px; border: 1px solid #ddd;">${actualRevenue}</td>
                                                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${project ? "✅" : "❌"}</td>
                                            </tr>
                                        `;
                                    })
                                    .join("")}
                            </tbody>
                        </table>
                    </div>
                    ${data.length > 10 ? `<p style="margin-top: 10px; font-style: italic;">... and ${data.length - 10} more records</p>` : ''}
                    <div style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 5px;">
                        <p style="margin: 0; color: #0056b3;"><strong>Ready to import?</strong> Click the "Import Data" button below.</p>
                        <p style="margin: 5px 0 0 0; font-size: 12px;"><strong>Note:</strong> Only the imported month will be updated, all other data preserved</p>
                    </div>
                </div>`;
            
            importPreview.innerHTML = previewHTML; 
        };

        // Perform Import
        const performImport = async () => {
            confirmImport.disabled = true;
            confirmImport.textContent = "Importing...";
            importStatus.style.display = "block";
            importStatus.textContent = "Updating Collection Data...";

            let success = 0, error = 0, notFound = 0, invalidMonth = 0, skipped = 0;
            const entityType = await getListEntityType();
 
            for (const row of importData) {
                const projectRef = row["Project Reference"] || row["project_reference"];
                const month = row.parsedMonth;
                const actualRevenue = parseFloat(
                    row["Actual Collection"] || row["actual_collection"] || row["Actual"] || row["actual"] || 0
                );
               if (!month) { 
                    invalidMonth++;
                    continue;
                }

                const project = projects.find((p) => p.ProjectReference === projectRef);
                if (!project) { 
                    notFound++;
                    continue;
                }

                const collection = collections.find((f) => f.Project?.Title === project.Title);
                if (!collection?.Id) { 
                    notFound++;
                    continue;
                }

                try {
                    const digest = await getDigest(); 
                    const currentCollectionResponse = await fetch(
                        `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${collection.Id})?$select=Id,RevenueActual`,
                        {
                            method: "GET",
                            headers: { 
                                Accept: "application/json;odata=verbose",
                            },
                        }
                    );
                    
                    if (!currentCollectionResponse.ok) {
                        throw new Error(`Failed to fetch current data: ${currentCollectionResponse.status}`);
                    }
                    
                    const currentData = await currentCollectionResponse.json();
                    const currentRevenueData = currentData.d.RevenueActual || "{}";
                     
                    const updatedRevenueData = updateRevenueData(currentRevenueData, month, actualRevenue); 
                    const payload = {
                        __metadata: { type: entityType },
                        RevenueActual: updatedRevenueData,
                        UpdatedDate: new Date().toISOString(),
                    };
 
                    const res = await fetch(
                        `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${collection.Id})`,
                        {
                            method: "POST",
                            headers: {
                                Accept: "application/json;odata=verbose",
                                "Content-Type": "application/json;odata=verbose",
                                "X-RequestDigest": digest,
                                "IF-MATCH": "*",
                                "X-HTTP-Method": "MERGE",
                            },
                            body: JSON.stringify(payload),
                        }
                    );

                    if (res.ok) {
                        success++; 
                    } else {
                        error++;
                        const text = await res.text();
                        console.warn(`⚠️ Failed for ${projectRef} (${month}):`, text);
                    }

                    await new Promise((r) => setTimeout(r, 100));
                } catch (err) {
                    error++;
                    console.error(`❌ Error updating ${projectRef} (${month}):`, err);
                }
            }

            skipped = importData.length - (success + error + notFound + invalidMonth);
 
            importStatus.className = "import-status success";
            importStatus.innerHTML = `
                <strong>Import Complete!</strong><br>
                ✅ Success: ${success} records imported<br>
                ❌ Errors: ${error} records<br>
                🔍 Project Not Found: ${notFound} records<br>
                📅 Invalid Month: ${invalidMonth} records<br>
                ⏭️ Skipped: ${skipped} records<br>
                <small>Only the imported month was updated, all other data preserved</small>
            `;

            await loadCollections();
            initializePagination(collections);

            confirmImport.disabled = false;
            confirmImport.textContent = "Import Data";
        };

        // Download Template
        downloadTemplateBtn.addEventListener("click", () => {
            if (!projects || projects.length === 0) {
                toast("error", "No projects available to create template");
                return;
            }

            const wsData = [["Project Reference", "Month", "Actual Collection"]];
            
            projects.forEach((p) => {
                wsData.push([p.ProjectReference || "", "", ""]);
            });

            const ws = XLSX.utils.aoa_to_sheet(wsData);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Collection Template");

            const fileName = `Collection_Import_Template.xlsx`;

            XLSX.writeFile(wb, fileName);
        });

        // Modal Controls
        const closeModalHandler = () => modal.remove();
        closeModal.addEventListener("click", closeModalHandler);
        cancelImport.addEventListener("click", closeModalHandler);
        modal.addEventListener("click", (e) => {
            if (e.target === modal) closeModalHandler();
        });

        confirmImport.addEventListener("click", performImport);
      };

      // ========== FILTER FUNCTIONS ==========

const initializeFilters = (): void => {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  
  // Year filter
  filterYear.innerHTML = '<option value="">All Years</option>';
  for (let year = currentYear - 1; year <= currentYear + 2; year++) {
    const selected = year === currentYear ? 'selected' : '';
    filterYear.innerHTML += `<option value="${year}" ${selected}>${year}</option>`;
  }
  
  // Month filter
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  filterMonth.innerHTML = '<option value="">All Months</option>';
  for (let month = 1; month <= 12; month++) {
    const selected = month === currentMonth ? 'selected' : '';
    filterMonth.innerHTML += `<option value="${month}" ${selected}>${monthNames[month - 1]}</option>`;
  }

  // Get role-filtered data
  const roleFilteredCollections = filterDataByRole(collections);
  const accessibleProjectTitles = roleFilteredCollections
    .map(f => f.Project?.Title)
    .filter((title): title is string => !!title);
  
  // Project filter - only accessible projects
  filterProject.innerHTML = '<option value="">All Projects</option>' + 
    [...new Set(accessibleProjectTitles)]
      .sort()
      .map(project => `<option value="${project}">${project}</option>`)
      .join("");

  // Project Reference filter - only from accessible projects
  const accessibleProjects = projects.filter(p => accessibleProjectTitles.includes(p.Title));
  const accessibleReferences = accessibleProjects
    .map(p => p.ProjectReference)
    .filter((ref): ref is string => !!ref);
    
  filterProjectReference.innerHTML = '<option value="">All References</option>' + 
    [...new Set(accessibleReferences)]
      .sort()
      .map(ref => `<option value="${ref}">${ref}</option>`)
      .join("");

  // Customer filter - only customers from accessible projects
  const accessibleCustomers = accessibleProjects
    .map(p => p.CustomerName)
    .filter((customer): customer is string => !!customer);
    
  filterCustomer.innerHTML = '<option value="">All Customers</option>' + 
    [...new Set(accessibleCustomers)]
      .sort()
      .map(customer => `<option value="${customer}">${customer}</option>`)
      .join("");

  // Project Manager filter - based on role
  let accessibleManagers: string[] = [];
  
  // Helper function to extract manager name
  const getManagerName = (project: ProjectItem): string | undefined => {
    if (!project.ProjectManager) return undefined;
    
    if (typeof project.ProjectManager === 'string') {
      return project.ProjectManager;
    }
    
    return project.ProjectManager.Title;
  };
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all managers
    accessibleManagers = projects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isGroupHead) {
    // Group Head sees managers in their groups
    const groupHeadProjects = projects.filter(p => 
      currentUser.managedGroups?.some(group => p.GroupHead === group)
    );
    accessibleManagers = groupHeadProjects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isProjectManager) {
    // Project Manager sees only themselves
    accessibleManagers = [currentUser.displayName];
  }
  
  // Remove duplicates and sort
  accessibleManagers = [...new Set(accessibleManagers)].sort();
  
  filterProjectManager.innerHTML = '<option value="">All Managers</option>' + 
    accessibleManagers.map(manager => `<option value="${manager}">${manager}</option>`).join("");

  // Group Head filter - based on role
  let accessibleGroupHeads: string[] = [];
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all group heads
    accessibleGroupHeads = projects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  } else if (currentUser.isGroupHead) {
    // Group Head sees only themselves
    accessibleGroupHeads = [currentUser.displayName];
  } else if (currentUser.isProjectManager) {
    // Project Manager sees group heads of their projects
    const pmProjects = projects.filter(p => 
      currentUser.managedProjects?.includes(p.Title)
    );
    accessibleGroupHeads = pmProjects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  }
  
  // Remove duplicates and sort
  accessibleGroupHeads = [...new Set(accessibleGroupHeads)].sort();
  
  filterGroupHead.innerHTML = '<option value="">All Group Heads</option>' + 
    accessibleGroupHeads.map(head => `<option value="${head}">${head}</option>`).join("");
};
       
// Pagination button event listeners
firstPageBtn.addEventListener("click", () => goToPage(1));
prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
nextPageBtn.addEventListener("click", () => goToPage(currentPage + 1));
lastPageBtn.addEventListener("click", () => goToPage(totalPages));

// Update your existing filterTable function to use new pagination
const filterTable = (): void => {
  const year = filterYear.value;
  const month = filterMonth.value;
  const project = filterProject.value;
  const customer = filterCustomer.value;
  const projectManager = filterProjectManager.value;
  const groupHead = filterGroupHead.value;
  const projectReference = filterProjectReference.value;
 
  let filtered = [...collections]; // Create a copy

  // Apply additional filters
  filtered = filtered.filter(collection => {
    let matches = true;
    
    // Year and Month filter
    if (year && month) {
      const selectedMonthKey = `${year}-${month.padStart(2, "0")}`;
      const data: CollectionData = safeJsonParse(collection.CollectionData, {});
      
      const hasMonthData = Object.keys(data).some(key => 
        key.match(/^\d{4}-\d{2}$/) && key === selectedMonthKey
      );
      
      if (!hasMonthData) {
        matches = false;
      }
    }
    
    // Project filter
    if (project && collection.Project?.Title !== project) {
      matches = false;
    }
    
    // Customer filter
    if (customer) {
      const proj = projects.find(p => p.Title === collection.Project?.Title);
      if (!proj || proj.CustomerName !== customer) {
        matches = false;
      }
    }
    
    // Project Manager filter
    if (projectManager) {
      const proj = projects.find(p => p.Title === collection.Project?.Title);
      const managerName = typeof proj?.ProjectManager === 'object' ? proj.ProjectManager?.Title : proj?.ProjectManager;
      if (!managerName || managerName !== projectManager) {
        matches = false;
      }
    }
    
    // Group Head filter
    if (groupHead) {
      const proj = projects.find(p => p.Title === collection.Project?.Title);
      if (!proj || proj.GroupHead !== groupHead) {
        matches = false;
      }
    }
    
    // Project Reference filter
    if (projectReference) {
      const proj = projects.find(p => p.Title === collection.Project?.Title);
      if (!proj || proj.ProjectReference !== projectReference) {
        matches = false;
      }
    }
    
    return matches;
  });
  
  // Apply role-based filtering LAST
  filtered = filterDataByRole(filtered);
  
  // Reset to first page when filtering
  currentPage = 1;
  
  if (filtered.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="21" style="text-align:center;padding:20px;">No records found for selected filters</td></tr>`;
    initializePagination([]);
  } else {
    initializePagination(filtered);
  }
};

// Enhanced clear filters function
const clearFilters = (): void => {
  filterYear.value = "";
  filterMonth.value = "";
  filterProject.value = "";
  filterCustomer.value = "";
  filterProjectManager.value = "";
  filterGroupHead.value = "";
  filterProjectReference.value = "";
  
  // Reset to first page and default page size
  currentPage = 1;
  pageSizeSelect.value = "10";
  pageSize = 10;
  
  // Clear sort configuration
  currentSortConfig = {
    column: '',
    direction: 'asc'
  };
  
  // Reinitialize with role-filtered data
  initializePagination(collections);
  
  // Reinitialize filters
  initializeFilters();
  
  toast("info", "All filters and sorting cleared");
};
 // ========== FORM SUBMISSION ==========

const getListItemType = async (): Promise<string> => {
  try {
    const response = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`, {
      headers: { 
        Accept: "application/json;odata=verbose",
        "Content-Type": "application/json;odata=verbose"
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to get list type: ${response.status}`);
    }
    
    const data = await response.json(); 
    return data.d.ListItemEntityTypeFullName;
  } catch (error) {
    console.error("❌ Error getting list item type:", error);
    return "SP.Data.Collection_x0020_ListListItem";
  }
};

form.addEventListener("submit", async (e: Event) => {
  e.preventDefault();
  
  const projectId = parseInt(projectSelect.value);
  const project = projects.find(p => p.Id === projectId);
  
  if (!project) {
    toast("error", "Please select a project");
    return;
  }

  const isNewProject = !editingId && !collections.some(f => f.Project?.Id === projectId);
  
  if (!isNewProject && collections.some(f => f.Project?.Id === projectId && f.Id !== editingId)) {
    toast("error", "Collection already exists for this project!");
    return;
  }

  const oblValue = getNumericValue(oblLastMonthInput);
  if (isNewProject && oblValue === 0) {
    const confirmZeroOBL = await Swal.fire({
      icon: "question",
      title: "Zero OBL Value",
      text: "You're setting OBL to zero for a new project. This means there's no budget limit. Continue?",
      showCancelButton: true,
      confirmButtonText: "Yes, Continue",
      cancelButtonText: "No, Set OBL"
    });
    
    if (!confirmZeroOBL.isConfirmed) {
      oblLastMonthInput.focus();
      return;
    }
  }

  // Add forecast validation
  if (!validateForecastData()) {
    return;
  }

  if (!validateFormSubmission()) {
    return;
  }

  try {
    const listItemType = await getListItemType();
    const digest = await getDigest();

    // Build collection data
    const collectionData: CollectionData = {};
    const allStorageMonths = getAllMonthsForStorage();
    
    // Process monthly data
    allStorageMonths.forEach(monthKey => {
      const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
      const mainPlanInput = document.querySelector<HTMLInputElement>(`input.main-plan-input[data-month="${monthKey}"]`);
      const mainForecastInput = document.querySelector<HTMLInputElement>(`input.main-forecast-input[data-month="${monthKey}"]`);
      const mainDateInput = document.querySelector<HTMLInputElement>(`input.forecast-date-input[data-month="${monthKey}"]`);
      
      if (mainCurrentInput && mainPlanInput) {
        const monthData: CollectionMonthData = {
          plan: getNumericValue(mainPlanInput),
          actual: getNumericValue(mainCurrentInput),
          items: {}
        };

        // Add forecast and date for current month (first detailed month)
        const monthIndex = allStorageMonths.indexOf(monthKey);
        if (monthIndex === 3) { // Current month only
          if (mainForecastInput) {
            monthData.forecast = getNumericValue(mainForecastInput);
          }
          if (mainDateInput) {
            monthData.date = mainDateInput.value;
          }
        }

        if (monthIndex >= 3 && monthIndex <= 5) {
          // Detailed months with all categories
          const categories = ["Normal", "Normal Overdue", "Retention", "Retention Overdue"];
          categories.forEach(categoryKey => {
            const categoryPlanInput = document.querySelector<HTMLInputElement>(`input.category-plan-input[data-category="${categoryKey}"][data-month="${monthKey}"]`);
            const categoryCurrentInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="${categoryKey}"][data-month="${monthKey}"]`);
            const categoryForecastInput = document.querySelector<HTMLInputElement>(`input.category-forecast-input[data-category="${categoryKey}"][data-month="${monthKey}"]`);
            const categoryDateInput = document.querySelector<HTMLInputElement>(`input.category-date-input[data-category="${categoryKey}"][data-month="${monthKey}"]`);
            
            if (categoryPlanInput && categoryCurrentInput) {
              const categoryData: CollectionCategory = {
                name: categoryKey,
                plan: getNumericValue(categoryPlanInput),
                actual: getNumericValue(categoryCurrentInput)
              };

              // Add forecast and date for current month categories only
              if (monthIndex === 3) {
                if (categoryForecastInput) {
                  categoryData.forecast = getNumericValue(categoryForecastInput);
                }
                if (categoryDateInput) {
                  categoryData.date = categoryDateInput.value;
                }
              }

              monthData.items![categoryKey] = categoryData;
            }
          });
        } else if (monthIndex >= 6) {
          // Simple months with basic categories
          const categories = ["Normal", "Retention"];
          categories.forEach(categoryKey => {
            const categoryPlanInput = document.querySelector<HTMLInputElement>(`input.category-plan-input[data-category="${categoryKey}"][data-month="${monthKey}"]`);
            const categoryCurrentInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="${categoryKey}"][data-month="${monthKey}"]`);
            
            if (categoryPlanInput && categoryCurrentInput) {
              monthData.items![categoryKey] = {
                name: categoryKey,
                plan: getNumericValue(categoryPlanInput),
                actual: getNumericValue(categoryCurrentInput)
              };
            }
          });
        }

        collectionData[monthKey] = monthData;
      }
    });

    // Process Yearly Data (existing code remains the same)
    const yearlyData: YearlyCollectionData = {};
    
    const yearlyInputs = document.querySelectorAll<HTMLInputElement>('.yearly-current-input, .yearly-plan-input');
    const yearlyYears = new Set<string>();
    
    yearlyInputs.forEach(input => {
      const year = input.dataset.year;
      if (year) yearlyYears.add(year);
    });
    
    Array.from(yearlyYears).forEach(year => {
      const yearlyPlanInput = document.querySelector<HTMLInputElement>(`input.yearly-plan-input[data-year="${year}"]`);
      const yearlyCurrentInput = document.querySelector<HTMLInputElement>(`input.yearly-current-input[data-year="${year}"]`);
      
      if (yearlyPlanInput && yearlyCurrentInput) {
        yearlyData[year] = {
          plan: getNumericValue(yearlyPlanInput),
          actual: getNumericValue(yearlyCurrentInput),
          items: {}
        };
        
        const categoryPlanInputs = document.querySelectorAll<HTMLInputElement>(`input.category-plan-input[data-year="${year}"]`);
        
        categoryPlanInputs.forEach(planInput => {
          const category = planInput.dataset.category;
          if (category) {
            const currentInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="${category}"][data-year="${year}"]`);
            
            if (currentInput) {
              yearlyData[year].items![category] = {
                name: category,
                plan: getNumericValue(planInput),
                actual: getNumericValue(currentInput)
              };
            }
          }
        });
      }
    });
    
    collectionData.yearly = yearlyData;
    
   // ========== YEARLY PROGRESSION FUNCTIONS ==========

 





// ========== ENHANCED YEARLY STRUCTURE CREATION ==========



// ========== ENHANCED COLLECTION DATA PROPAGATION ==========




// ========== ENHANCED AUTO PROGRESSION ==========



// ========== ENHANCED COLLECTION DATA PROPAGATION ==========

 

// ========== UPDATE THE EDIT COLLECTION FUNCTION ==========



// ========== ENHANCED YEARLY STRUCTURE CREATION ==========



// ========== UPDATE FORM SUBMISSION TO INCLUDE YEARLY PROPAGATION ==========

// In your form submission handler, replace the propagateMonthValues call with:
const propagatedData = propagateCollectionValues(collectionData);
    
    const payload: any = {
      __metadata: { 
        type: listItemType 
      },
      Title: generateCollectionTitle(project, propagatedData),
      ProjectId: project.Id.toString(),
      ProfitCentre: project.PC || "",
      CollectionData: JSON.stringify(propagatedData),
      Remarks: `Collection for ${project.Title}. Last updated: ${new Date().toLocaleDateString()}`,
      UpdatedDate: new Date().toISOString()
    };

    if (!editingId && isNewProject) {
      const oblValueToSave = getNumericValue(oblLastMonthInput);
      payload.OBL = oblValueToSave.toString();
    }

    if (!editingId) {
      payload.CreatedDate = new Date().toISOString();
    }

    const url = editingId 
      ? `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${editingId})`
      : `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;
    
    const headers: any = {
      Accept: "application/json;odata=verbose",
      "Content-Type": "application/json;odata=verbose",
      "X-RequestDigest": digest
    };
    
    if (editingId) {
      headers["IF-MATCH"] = "*";
      headers["X-HTTP-Method"] = "MERGE";
    }

    const res = await fetch(url, { 
      method: "POST", 
      headers, 
      body: JSON.stringify(payload) 
    });
    
    if (res.ok) {
      toast("success", editingId ? "Collection Updated!" : "Collection Added!");
      await loadCollections();
      initializePagination(collections);
      hideForm();
      resetForm();
    } else {
      const errorText = await res.text();
      console.error("❌ SharePoint Error Response:", errorText);
      
      try {
        const errorData = JSON.parse(errorText);
        if (errorData.error && errorData.error.message) {
          toast("error", `SharePoint Error: ${errorData.error.message.value}`);
        } else {
          toast("error", `Error saving collection: ${res.status}`);
        }
      } catch (parseError) {
        toast("error", `Error saving collection: ${res.status}`);
      }
    }
  } catch (error) {
    console.error("💥 Error saving collection:", error);
    toast("error", "Unexpected error saving collection!");
  }
});

// Forecast validation function
const validateForecastData = (): boolean => {
  let allValid = true;
  const invalidMonths: string[] = [];

  // Check current month (first detailed month) forecast validation
  const currentMonthKey = allMonths[3]; // Current month is at index 3
  
  if (currentMonthKey) {
    const mainForecastInput = document.querySelector<HTMLInputElement>(`input.main-forecast-input[data-month="${currentMonthKey}"]`);
    
    if (mainForecastInput) {
      const mainForecastValue = getNumericValue(mainForecastInput);
      let categoriesForecastTotal = 0;
      
      // Sum all category forecasts
      const categoryForecastInputs = document.querySelectorAll<HTMLInputElement>(`input.category-forecast-input[data-month="${currentMonthKey}"]`);
      categoryForecastInputs.forEach(input => {
        categoriesForecastTotal += getNumericValue(input);
      });
      
      // Validate that categories forecast doesn't exceed main forecast
      if (categoriesForecastTotal > mainForecastValue) {
        const monthDate = new Date(currentMonthKey + "-01");
        invalidMonths.push(`${formatMonthLabel(monthDate)} (Categories forecast: ${categoriesForecastTotal} > Main forecast: ${mainForecastValue})`);
        allValid = false;
      }
    }
  }

  if (!allValid) {
    toast("error", `Category forecasts exceed main forecast in: ${invalidMonths.join(', ')}`);
    return false;
  }
  
  return true;
};

// Real-time forecast validation for input changes
const setupForecastValidation = (): void => {
  // Current month forecast validation
  const currentMonthKey = allMonths[3];
  
  if (currentMonthKey) {
    const mainForecastInput = document.querySelector<HTMLInputElement>(`input.main-forecast-input[data-month="${currentMonthKey}"]`);
    const categoryForecastInputs = document.querySelectorAll<HTMLInputElement>(`input.category-forecast-input[data-month="${currentMonthKey}"]`);
    
    // Main forecast input change
    if (mainForecastInput) {
      mainForecastInput.addEventListener('input', function() {
        validateSingleMonthForecast(currentMonthKey, this);
      });
    }
    
    // Category forecast inputs change
    categoryForecastInputs.forEach(input => {
      input.addEventListener('input', function() {
        validateSingleMonthForecast(currentMonthKey, this);
      });
    });
  }
};

// Validate forecast for a single month
const validateSingleMonthForecast = (monthKey: string, changedInput?: HTMLInputElement): void => {
  const mainForecastInput = document.querySelector<HTMLInputElement>(`input.main-forecast-input[data-month="${monthKey}"]`);
  const categoryForecastInputs = document.querySelectorAll<HTMLInputElement>(`input.category-forecast-input[data-month="${monthKey}"]`);
  
  if (!mainForecastInput) return;
  
  const mainForecastValue = getNumericValue(mainForecastInput);
  let categoriesForecastTotal = 0;
  
  categoryForecastInputs.forEach(input => {
    categoriesForecastTotal += getNumericValue(input);
  });
  
  // Update forecast validation display
  let forecastValidationDisplay = document.querySelector(`.forecast-validation[data-month="${monthKey}"]`) as HTMLDivElement;
  if (!forecastValidationDisplay) {
    forecastValidationDisplay = document.createElement('div');
    forecastValidationDisplay.className = 'forecast-validation';
    forecastValidationDisplay.setAttribute('data-month', monthKey);
    
    const monthBlock = mainForecastInput.closest('.detailed-month-box');
    if (monthBlock) {
      const existingValidation = monthBlock.querySelector('.forecast-validation');
      if (existingValidation) {
        existingValidation.remove();
      }
      monthBlock.appendChild(forecastValidationDisplay);
    }
  }
  
  if (categoriesForecastTotal > mainForecastValue) {
    forecastValidationDisplay.textContent = `❌ Categories forecast (${categoriesForecastTotal}) exceeds Main forecast (${mainForecastValue})!`;
    forecastValidationDisplay.className = 'forecast-validation month-total-invalid';
    blockIncreasingForecastInputs(monthKey, changedInput);
  } else if (categoriesForecastTotal < mainForecastValue) {
    forecastValidationDisplay.textContent = `⚠️ Categories forecast (${categoriesForecastTotal}) less than Main forecast (${mainForecastValue})`;
    forecastValidationDisplay.className = 'forecast-validation month-total-warning';
    unblockAllForecastInputs(monthKey);
  } else {
    forecastValidationDisplay.textContent = `✅ Forecast categories match: ${categoriesForecastTotal}`;
    forecastValidationDisplay.className = 'forecast-validation month-total-valid';
    unblockAllForecastInputs(monthKey);
  }
};

// Block increasing forecast inputs when limit reached
const blockIncreasingForecastInputs = (monthKey: string, allowedInput?: HTMLInputElement): void => {
  const categoryForecastInputs = document.querySelectorAll<HTMLInputElement>(`input.category-forecast-input[data-month="${monthKey}"]`);
  
  categoryForecastInputs.forEach(input => {
    if (input === allowedInput) {
      input.style.backgroundColor = '';
      input.style.cursor = '';
      input.removeAttribute('readonly');
    } else {
      input.setAttribute('data-block-increase', 'true');
      input.style.backgroundColor = '#fff3cd';
      input.style.cursor = 'not-allowed';
    }
  });
};

// Unblock all forecast inputs
const unblockAllForecastInputs = (monthKey: string): void => {
  const categoryForecastInputs = document.querySelectorAll<HTMLInputElement>(`input.category-forecast-input[data-month="${monthKey}"]`);
  
  categoryForecastInputs.forEach(input => {
    input.style.backgroundColor = '';
    input.style.cursor = '';
    input.removeAttribute('data-block-increase');
    input.removeAttribute('readonly');
  });
};

// Debug helper to check data types
const debugDataTypes = (data: any, path: string = ''): void => {
  if (typeof data === 'object' && data !== null) {
    Object.keys(data).forEach(key => {
      const value = data[key];
      const currentPath = path ? `${path}.${key}` : key; 
      if (typeof value === 'object' && value !== null) {
        debugDataTypes(value, currentPath);
      }
    });
  }
};

  

// Call this during initialization to check your field types
// testSharePointFields();

      // ========== INITIALIZATION ==========

const initialize = async (): Promise<void> => {
  try { 
    // Get user context first
    currentUser = await getUserContext();
    
    await loadProjects(); 
    await diagnoseSharePointFields();
    
    await loadCollections(); 
    if (collections.length > 0) { 
      await applyAutoProgression();
    }
    
    await createOBLBreakdownList();
    
    // Initialize UI for role
    updateUIForRole();
    
    // Initialize filters with role-based data
    initializeFilters();
    
    // Filter project select by role
    filterProjectSelectByRole();
    
    // Initialize pagination with role-filtered data
    initializePagination(collections);
    
  } catch (error) {
    console.error("Initialization error:", error);
    toast("error", "Failed to initialize application");
  }
};

      // ========== EVENT LISTENERS ==========

      showFormBtn.addEventListener("click", () => {
        resetForm();
        showForm(false);
      });    
      
      backBtn.addEventListener("click", hideForm);
      
      projectSelect.addEventListener("change", (e) => {
  const projectId = parseInt((e.target as HTMLSelectElement).value);
  
  if (!projectId) {
    // No project selected, reset form
    resetForm();
    return;
  }

  if (editingId) {
    toast("warning", "Cannot change project in edit mode");
    // Revert to the original project
    const collection = collections.find(f => f.Id === editingId);
    if (collection?.Project) {
      projectSelect.value = String(collection.Project.Id);
    }
    return;
  }

  const project = projects.find(p => p.Id === projectId);
  if (!project) return;

  const existingCollection = collections.find(f => f.Project?.Id === projectId);
  
  if (existingCollection) {
    // Project exists - automatically switch to edit mode
    editingId = existingCollection.Id;
    showForm(true);
    onProjectChange(projectId, existingCollection);
    
    // Show notification instead of confirmation dialog
    toast("info", `Editing existing collection for ${project.Title}`);
  } else {
    // New project - stay in add mode
    onProjectChange(projectId);
  }
});


const validateYearlyCategoryTotals = (changedInput?: HTMLInputElement): boolean => {
  let allValid = true;
  
  const yearlyInputs = document.querySelectorAll<HTMLInputElement>('.yearly-current-input');
  const yearlyYears = new Set<string>();
  
  yearlyInputs.forEach(input => {
    const year = input.dataset.year;
    if (year) yearlyYears.add(year);
  });
  
  Array.from(yearlyYears).forEach(year => {
    const yearValid = validateSingleYearCategories(year, changedInput);
    if (!yearValid) {
      allValid = false;
    }
  });
  
  return allValid;
};

const validateSingleYearCategories = (year: string, changedInput?: HTMLInputElement): boolean => {
  const yearlyCurrentInput = document.querySelector<HTMLInputElement>(`input.yearly-current-input[data-year="${year}"]`);
  const categoryCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-year="${year}"]`);
  
  if (!yearlyCurrentInput) return true;
  
  const yearlyCurrentValue = getNumericValue(yearlyCurrentInput);
  let categoriesTotal = 0;
  
  // ✅ Now properly using categoryCurrentInputs
  categoryCurrentInputs.forEach(input => {
    categoriesTotal += getNumericValue(input);
  });
  
  let validationDisplay = document.querySelector(`.yearly-total-validation[data-year="${year}"]`) as HTMLDivElement;
  if (!validationDisplay) {
    validationDisplay = document.createElement('div');
    validationDisplay.className = 'yearly-total-validation';
    validationDisplay.setAttribute('data-year', year);
    
    const yearBlock = yearlyCurrentInput.closest('.yearly-box');
    if (yearBlock) {
      const existingValidation = yearBlock.querySelector('.yearly-total-validation');
      if (existingValidation) {
        existingValidation.remove();
      }
      yearBlock.appendChild(validationDisplay);
    }
  }
  
  // Calculate Normal and Retention totals
  const normalInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="Normal"][data-year="${year}"]`);
  const retentionInput = document.querySelector<HTMLInputElement>(`input.category-current-input[data-category="Retention"][data-year="${year}"]`);
  
  const normalTotal = normalInput ? getNumericValue(normalInput) : 0;
  const retentionTotal = retentionInput ? getNumericValue(retentionInput) : 0;
  
  if (categoriesTotal > yearlyCurrentValue) {
    validationDisplay.textContent = `❌ Categories total (${categoriesTotal}) exceeds Year current (${yearlyCurrentValue})!`;
    validationDisplay.className = 'yearly-total-validation month-total-invalid';
    blockIncreasingYearCategoryInputs(year, changedInput);
    return false;
  } else if (categoriesTotal < yearlyCurrentValue) {
    validationDisplay.textContent = `⚠️ Categories total (${categoriesTotal}) less than Year current (${yearlyCurrentValue})`;
    validationDisplay.className = 'yearly-total-validation month-total-warning';
    unblockAllYearCategoryInputs(year);
    return true;
  } else {
    validationDisplay.innerHTML = `✅ Categories match Year: ${categoriesTotal}<br>
                                  📊 Normal: ${normalTotal} | Retention: ${retentionTotal}`;
    validationDisplay.className = 'yearly-total-validation month-total-valid';
    unblockAllYearCategoryInputs(year);
    return true;
  }
};

const blockIncreasingYearCategoryInputs = (year: string, allowedInput?: HTMLInputElement): void => {
  const categoryInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-year="${year}"]`);
  
  categoryInputs.forEach(input => {
    if (input === allowedInput) {
      input.style.backgroundColor = '';
      input.style.cursor = '';
      input.removeAttribute('readonly');
    } else {
      input.setAttribute('data-block-increase', 'true');
      input.style.backgroundColor = '#fff3cd';
      input.style.cursor = 'not-allowed';
    }
  });
};

const unblockAllYearCategoryInputs = (year: string): void => {
  const categoryInputs = document.querySelectorAll<HTMLInputElement>(`input.category-current-input[data-year="${year}"]`);
  
  categoryInputs.forEach(input => {
    input.style.backgroundColor = '';
    input.style.cursor = '';
    input.removeAttribute('data-block-increase');
    input.removeAttribute('readonly');
  });
};
 
      // Pagination event listeners
      firstPageBtn.addEventListener("click", () => goToPage(1));
      prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
      nextPageBtn.addEventListener("click", () => goToPage(currentPage + 1));
      lastPageBtn.addEventListener("click", () => goToPage(totalPages));

      // Filter event listeners
      filterYear.addEventListener("change", filterTable);
      filterMonth.addEventListener("change", filterTable);
      filterProject.addEventListener("change", filterTable);
      filterCustomer.addEventListener("change", filterTable);
      filterProjectManager.addEventListener("change", filterTable);
      filterGroupHead.addEventListener("change", filterTable);
      filterProjectReference.addEventListener("change", filterTable);

      // Action button event listeners
      exportBtn.addEventListener("click", exportToExcelWithFullStyle);
      clearFiltersBtn.addEventListener("click", clearFilters);
      importActualBtn.addEventListener("click", importActualData);

      // Initialize application
      initialize();
    }, 100);
  } 
};