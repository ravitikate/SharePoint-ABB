import Swal from "sweetalert2";
import * as XLSX from "xlsx-js-style";
import { saveAs } from "file-saver";
import "../styles/common.css";
import "../styles/procurement.css";
declare const _spPageContextInfo: any;

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead?: string;
}

interface ProcurementForecastItem {
  Description: string;
  FCMQuantity: number | null;
  EnggQuantity: number | null;
  Status: string;
  Make: string;
  Model: string;
  Remarks: string;

  RfqPlan: string;
  RfqActual: string;
  RfqForecast: string;
  OfferPlan: string;
  OfferActual: string;
  OfferForecast: string;
  TechPlan: string;
  TechActual: string;
  TechForecast: string;
  OrderPlan: string;
  OrderActual: string;
  OrderForecast: string;
  PRPlan: string;
  PRActual: string;
  PRForecast: string; 
  POPlan: string;
  POActual: string;
  POForecast: string;
  DocPlan: string;
  DocActual: string;
  DocForecast: string;
  MfgPlan: string;
  MfgActual: string;
  MfgForecast: string;
  InspPlan: string;
  InspActual: string;
  InspForecast: string;
  DispPlan: string;
  DispActual: string;
  DispForecast: string;
  DeliveryPlan: string;
  DeliveryActual: string;
  DeliveryForecast: string;
}

interface FieldMappings {
  ProcurementForecast: string;
  Project: string;
}

const procurementContent = `
<div class="project-page fade-in">
  <section class="table-section card">
    <div class="page-header">
      <h1>Procurement Tracker</h1>
      <div>
        <button class="btn-primary show-form-btn">+ Add Procurement</button>
      </div>
    </div>
    
    <div class="table-actions">
      <div class="tableColp4">
        <label for="filterProject">Project</label>
        <select id="filterProject"><option value="">All Projects</option></select>
      </div>
      <div class="tableColp4">
        <label for="filterCustomer">Customer</label>
        <select id="filterCustomer"><option value="">All Customers</option></select>
      </div>
      <div class="tableColp4">
        <label for="filterProjectManager">Project Manager</label>
        <select id="filterProjectManager"><option value="">All Managers</option></select>
      </div>
      <div class="tableColp4">
        <label for="filterGroupHead">Group Head</label>
        <select id="filterGroupHead"><option value="">All Group Heads</option></select>
      </div>
      <div class="tableColp4">
        <label for="filterProjectReference">Project Reference</label>
        <select id="filterProjectReference"><option value="">All References</option></select>
      </div>
      <div class="tableColp4">
        <label for="filterStatus">Status</label>
        <select id="filterStatus"><option value="">All Status</option></select>
      </div>
      <div class="tableColp4">
        <label for="filterMake">Make</label>
        <select id="filterMake"><option value="">All Makes</option></select>
      </div> 
      <div class="tableColp4"> 
        <label>Actions</label>
        <button class="btn-secondary clear-filters-btn">Reset Filter</button> 
      </div> 
      <div class="tableColp4"> 
        <label>&nbsp;</label>
        <button class="btn-secondary export-excel-btn">Export Excel</button>
      </div>
    </div>

    <div style="overflow-x:auto;">
      <table id="procurementTable" class="modern-table">
        <thead>
          <tr>
            <th rowspan="2">Project Reference</th>
            <th rowspan="2">Project</th>
            <th rowspan="2">Customer</th>
            <th rowspan="2">Project Manager</th>
            <th rowspan="2">Group Head</th>
            <th>RFQ Pending</th>
            <th>Offer Awaited</th>
            <th>TC Pending</th>
            <th>PR Pending</th>
            <th>PO Pending</th>
            <th>MFC Pending</th>
            <th>Cleared for Manufacturing</th>
            <th>Delivered</th>
            <th rowspan="2">Actions</th>
          </tr>
        </thead>
        <tbody id="procurementBody"></tbody>
      </table>
    </div>
    <div class="pagination"></div>
  </section>

  <section class="form-section card" style="display:none;">
    <div class="page-header">
      <h1 id="formTitle">Add Procurement</h1>
    </div>
    <form id="procurementForm">
          
      <div class="form-row">
        <div class="form-group from-group-box project-select-container">
          <label>Project</label>
          <select id="projectSelect" required></select>
        </div>
        <div id="projectDetails"></div>
      </div>
      
      <div id="existingDataAlert" class="alert alert-info" style="display: none; margin: 15px 0;">
        <strong>ℹ️ Existing Data Found!</strong> This project already has procurement data. You can view and edit it below.
      </div>
      
      <div class="procurement-inputs" id="procurementContainerTable" style="overflow-x:auto; display:none;">
        <table class="modern-table">
          <thead>
            <tr> 
              <th rowspan="2" style="z-index: 10;">Description</th>
              <th rowspan="2" style="z-index: 10;">FCM Quantity</th>
              <th rowspan="2" style="z-index: 10;">Engg Quantity</th>
              <th rowspan="2" style="z-index: 10;">Status</th>
              <th rowspan="2" style="z-index: 10;">Make</th>
              <th rowspan="2" style="z-index: 10;">Model</th> 
              <th colspan="3">RFQ / Engg</th>
              <th colspan="3">Vendor Offer / SCM</th>
              <th colspan="3">Technical Clearance / ENGG</th>
              <th colspan="3">Order Finalization / SCM</th>
              <th colspan="3">PR / PM</th>
              <th colspan="3">Purchase Order / SCM</th>
              <th colspan="3">Document Approval / ENGG</th>
              <th colspan="3">Manufacturing Clearance / ENGG</th>
              <th colspan="3">Inspection</th>
              <th colspan="3">Material Dispatch</th>
              <th colspan="3">Delivery at Site</th>
              <th rowspan="2">Remarks</th>
              <th rowspan="2">Actions</th>
            </tr>
            <tr>
              ${Array(11)
                .fill("<th>Plan</th><th>Actual</th><th>Forecast</th>")
                .join("")}
          </tr>
          </thead>
          <tbody id="procurementContainer"></tbody>
          <tfoot>
            <tr>
            <td colspan="6"><button type="button" class="add-procurement-row btn-secondary">+ Add More Procurement</button></td>
              <td colspan="49">
                
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn-primary">💾 Save Procurement</button>
        <button type="button" class="btn-secondary back-to-table">⬅ Back</button>
      </div>
    </form>
  </section>
</div>
`;

export default {
  content: procurementContent,
  style: `
.procurement-page .view-field {
  padding: 8px 12px;
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  min-height: 38px;
  display: flex;
  align-items: center;
}

.procurement-page .description-view {
  max-width: 200px;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  cursor: pointer;
  transition: all 0.3s ease;
}

.procurement-page .description-view:hover {
  position: relative;
  z-index: 1000;
  background: white;
  border: 1px solid #0078d4;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  max-width: 400px;
  white-space: normal;
  -webkit-line-clamp: unset;
  overflow: visible;
  word-wrap: break-word;
}

.procurement-page .view-mode .form-control {
  background-color: #f8f9fa !important;
  border-color: #e9ecef !important;
  cursor: not-allowed;
}

.procurement-page .status-badge {
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  text-align: center;
}

.procurement-page .remarks-view {
  max-width: 200px;
  word-wrap: break-word;
}

/* Status-specific badge colors */
.procurement-page .status-badge[data-status="RFQ Pending"] {
  background-color: #e3f2fd;
  color: #1976d2;
}

.procurement-page .status-badge[data-status="Offer Awaited"] {
  background-color: #fff3e0;
  color: #f57c00;
}

.procurement-page .status-badge[data-status="TC Pending"] {
  background-color: #e8f5e8;
  color: #388e3c;
}

.procurement-page .status-badge[data-status="PR Pending"] {
  background-color: #fce4ec;
  color: #c2185b;
}

.procurement-page .status-badge[data-status="PO Pending"] {
  background-color: #f3e5f5;
  color: #7b1fa2;
}

.procurement-page .status-badge[data-status="MFC Pending"] {
  background-color: #e0f2f1;
  color: #00796b;
}

.procurement-page .status-badge[data-status="Cleared for Manufacturing"] {
  background-color: #fff8e1;
  color: #ff8f00;
}

.procurement-page .status-badge[data-status="Delivered"] {
  background-color: #e8f5e8;
  color: #2e7d32;
}

/* Export progress styles */
.swal2-popup .swal2-title {
  font-size: 18px !important;
}

/* Import modal styles */
.import-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10000;
}

.import-modal-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  max-width: 800px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.import-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  border-bottom: 1px solid #e9ecef;
  padding-bottom: 15px;
}

.import-modal-header h3 {
  margin: 0;
  color: #0078d4;
}

.close-modal {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #6c757d;
}

.import-section {
  margin-bottom: 25px;
  padding: 15px;
  border: 1px solid #e9ecef;
  border-radius: 6px;
}

.file-upload-area {
  border: 2px dashed #0078d4;
  padding: 30px;
  text-align: center;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.file-upload-area:hover {
  background-color: #f8f9fa;
}

.file-upload-area.dragover {
  background-color: #e3f2fd;
  border-color: #1976d2;
}

.upload-icon {
  font-size: 48px;
  margin-bottom: 15px;
}

.import-actions {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}

.import-status {
  margin-top: 15px;
  padding: 10px;
  border-radius: 4px;
}

.import-status.success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.import-status.error {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}
`,

  script: () => {
    setTimeout(async () => {
      // Configuration
      const siteUrl =
        typeof _spPageContextInfo !== "undefined"
          ? _spPageContextInfo.webAbsoluteUrl
          : window.location.origin + "/sites/Kriya";

      const listName = "ProcurementTracker";
      const apiBase = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;

      // State variables
      let fieldMappings: FieldMappings = {
        ProcurementForecast: "ProcurementForecast",
        Project: "Project",
      };

      let listEntityTypeName: string = "";
      let projects: ProjectItem[] = [];
      let editingId: number | null = null;
      let procurementData: any[] = [];
      let currentPage = 1;
      const pageSize = 10;

      // Status options for counting
      const statusOptions = [
        "RFQ Pending",
        "Offer Awaited",
        "TC Pending",
        "PR Pending",
        "PO Pending",
        "MFC Pending",
        "Cleared for Manufacturing",
        "Delivered",
      ];

      // DOM Elements
      const projectSelect = document.getElementById("projectSelect") as HTMLSelectElement;
      const showFormBtn = document.querySelector(".show-form-btn") as HTMLButtonElement;
      const exportExcelBtn = document.querySelector(".export-excel-btn") as HTMLButtonElement;
      const formSection = document.querySelector(".form-section") as HTMLElement;
      const tableSection = document.querySelector(".table-section") as HTMLElement;
      const backBtn = document.querySelector(".back-to-table") as HTMLButtonElement;
      const projectDetails = document.getElementById("projectDetails") as HTMLElement;
      const procurementContainer = document.getElementById("procurementContainer") as HTMLElement;
      const procurementContainerTable = document.getElementById("procurementContainerTable") as HTMLElement;
      const tableBody = document.getElementById("procurementBody") as HTMLElement;
      const paginationDiv = document.querySelector(".pagination") as HTMLElement;
      const form = document.getElementById("procurementForm") as HTMLFormElement;
      const formTitle = document.getElementById("formTitle") as HTMLHeadingElement;
      const existingDataAlert = document.getElementById("existingDataAlert") as HTMLDivElement;

      // Filter Elements
      const filterProject = document.getElementById("filterProject") as HTMLSelectElement;
      const filterCustomer = document.getElementById("filterCustomer") as HTMLSelectElement;
      const filterProjectManager = document.getElementById("filterProjectManager") as HTMLSelectElement;
      const filterGroupHead = document.getElementById("filterGroupHead") as HTMLSelectElement;
      const filterProjectReference = document.getElementById("filterProjectReference") as HTMLSelectElement;
      const filterStatus = document.getElementById("filterStatus") as HTMLSelectElement;
      const filterMake = document.getElementById("filterMake") as HTMLSelectElement;
      const clearFiltersBtn = document.querySelector(".table-actions .btn-secondary") as HTMLButtonElement;

      // Add these checks after initializing all DOM elements
setTimeout(() => {
  if (filterProject) {
    filterProject.addEventListener("change", filterData);
  }
  if (filterCustomer) {
    filterCustomer.addEventListener("change", filterData);
  }
  if (filterProjectManager) {
    filterProjectManager.addEventListener("change", filterData);
  }
  if (filterGroupHead) {
    filterGroupHead.addEventListener("change", filterData);
  }
  if (filterProjectReference) {
    filterProjectReference.addEventListener("change", filterData);
  }
  if (filterStatus) {
    filterStatus.addEventListener("change", filterData);
  }
  if (filterMake) {
    filterMake.addEventListener("change", filterData);
  }
  if (clearFiltersBtn) {
    clearFiltersBtn.addEventListener("click", clearFilters);
  }
}, 500); // Small delay to ensure DOM is ready

      // Utility Functions
      const toast = (
        msg: string,
        type: "success" | "error" | "warning" = "success"
      ) => {
        Swal.fire({
          toast: true,
          position: "top-end",
          icon: type,
          title: msg,
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
        });
      };

      const showExportProgress = (message: string): void => {
        Swal.fire({
          title: "Exporting...",
          text: message,
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading();
          },
        });
      };

      const hideExportProgress = (): void => {
        Swal.close();
      };

      const getRequestDigest = async (): Promise<string> => {
        try {
          const res = await fetch(`${siteUrl}/_api/contextinfo`, {
            method: "POST",
            headers: {
              Accept: "application/json;odata=verbose",
              "Content-Type": "application/json;odata=verbose",
            },
          });
          if (!res.ok)
            throw new Error(`Failed to get request digest: ${res.status}`);
          const data = await res.json();
          return data.d.GetContextWebInformation.FormDigestValue;
        } catch (error) {
          console.error("Error getting request digest:", error);
          throw error;
        }
      };

      // Field discovery functions
      const discoverListFields = async (): Promise<{
        fields: any[];
        entityType: string;
      }> => {
        try {
          const listRes = await fetch(
            `${siteUrl}/_api/web/lists/getbytitle('${listName}')`,
            {
              headers: { Accept: "application/json;odata=verbose" },
            }
          );
          if (!listRes.ok)
            throw new Error(`Failed to get list: ${listRes.status}`);
          const listData = await listRes.json();
          const entityType = listData.d.ListItemEntityTypeFullName;

          const fieldsRes = await fetch(
            `${siteUrl}/_api/web/lists/getbytitle('${listName}')/fields`,
            {
              headers: { Accept: "application/json;odata=verbose" },
            }
          );
          if (!fieldsRes.ok)
            throw new Error(`Failed to get fields: ${fieldsRes.status}`);
          const fieldsData = await fieldsRes.json();
          const fields = fieldsData.d.results;
 
          // fields.forEach((field: any) => {
          //   console.log(
          //     `- ${field.Title} (InternalName: ${field.InternalName}, Type: ${field.TypeAsString})`
          //   );
          // });

          return { fields, entityType };
        } catch (error) {
          console.error("Error discovering fields:", error);
          throw error;
        }
      };

      const createFieldMappings = (fields: any[]): FieldMappings => {
        const mappings: FieldMappings = {
          ProcurementForecast: "ProcurementForecast",
          Project: "Project",
        };

        fields.forEach((field) => {
          const fieldTitle = field.Title?.toLowerCase().replace(/\s+/g, "");
          const internalName = field.InternalName;

          if (
            [
              "Id",
              "ID",
              "Title",
              "Created",
              "Modified",
              "Author",
              "Editor",
            ].includes(internalName)
          ) {
            return;
          }

          if (
            field.TypeAsString === "Note" &&
            (fieldTitle.includes("procurement") ||
              fieldTitle.includes("forecast") ||
              fieldTitle.includes("data"))
          ) { 
            mappings.ProcurementForecast = internalName;
          }

          if (
            field.TypeAsString === "Lookup" &&
            (fieldTitle.includes("project") ||
              field.InternalName.includes("Project"))
          ) { 
            mappings.Project = internalName;
          }
        });
 
        return mappings;
      };

      const testFieldMappings = async (): Promise<boolean> => {
        try {
          const testQuery = `${apiBase}?$select=Id,${fieldMappings.Project}/Id&$top=1&$expand=${fieldMappings.Project}`;
          const testRes = await fetch(testQuery, {
            headers: { Accept: "application/json;odata=verbose" },
          });

          if (testRes.ok) { 
            return true;
          } else {
            const error = await testRes.json();
            console.error("Field mappings test: FAILED", error);
            return false;
          }
        } catch (error) {
          console.error("Field mappings test error:", error);
          return false;
        }
      };

      const initApp = async (): Promise<void> => {
        try {
          const { fields, entityType } = await discoverListFields();
          listEntityTypeName = entityType;
          fieldMappings = createFieldMappings(fields);

          const mappingsValid = await testFieldMappings();
          if (!mappingsValid) {
            throw new Error(
              "Field mappings are invalid. Please check the field names in your SharePoint list."
            );
          }

          await loadProjects();
          await fetchData();

          // Initialize filters AFTER data is loaded
          initializeFilters();
          
          // Render table with initial data
          renderTable(procurementData);
          
          // Now attach event listeners
          attachFilterEventListeners();

          toast("Procurement tracker initialized successfully", "success");
        } catch (error) {
          console.error("Initialization error:", error);
          toast(
            "Failed to initialize application. Check console for details.",
            "error"
          );
        }
      };

      const attachFilterEventListeners = (): void => {
          filterProject.addEventListener("change", filterData);
          filterCustomer.addEventListener("change", filterData);
          filterProjectManager.addEventListener("change", filterData);
          filterGroupHead.addEventListener("change", filterData);
          filterProjectReference.addEventListener("change", filterData);
          filterStatus.addEventListener("change", filterData);
          filterMake.addEventListener("change", filterData);
          
          // Use the correct selector for clear filters button
          const clearFiltersBtn = document.querySelector(
            ".table-actions .btn-secondary:nth-child(1)"
          ) as HTMLButtonElement;
          
          if (clearFiltersBtn) {
            clearFiltersBtn.addEventListener("click", clearFilters);
          }
        };

      // Load Projects
      const loadProjects = async (): Promise<void> => {
        try {
          const res = await fetch(
            `${siteUrl}/_api/web/lists/getbytitle('Project List')/items?$select=Id,Title,CustomerName,GroupHead,PC,ProjectReference,ProjectManager/Title&$expand=ProjectManager`,
            { headers: { Accept: "application/json;odata=verbose" } }
          );
          if (!res.ok)
            throw new Error(`Failed to load projects: ${res.status}`);

          const data = await res.json();
          const allProjects: ProjectItem[] = data?.d?.results || [];

          const uniqueProjects = Array.from(
            new Map(allProjects.map((p: ProjectItem) => [p.Title, p])).values()
          );

          projects = uniqueProjects;

          projectSelect.innerHTML =
            '<option value="">Select Project</option>' +
            projects
              .map((p) => `<option value="${p.Id}">${p.Title}</option>`)
              .join("");

          filterProject.innerHTML =
            '<option value="">All Projects</option>' +
            projects
              .map((p) => `<option value="${p.Title}">${p.Title}</option>`)
              .join("");
        } catch (error) {
          console.error("Error loading projects:", error);
          toast("Failed to load projects", "error");
        }
      };

      // Parse JSON data from ProcurementForecast field
      const parseProcurementForecast = (
        procurementForecastJson: string
      ): ProcurementForecastItem[] | null => {
        if (!procurementForecastJson) return null;

        try {
          const parsed = JSON.parse(procurementForecastJson);
          // Handle both array and single object for backward compatibility
          return Array.isArray(parsed) ? parsed : [parsed];
        } catch (error) {
          console.error("Error parsing ProcurementForecast JSON:", error);
          return null;
        }
      };

      // Calculate status counts for a project
      const calculateProjectStatusCounts = (
        procurementItems: ProcurementForecastItem[]
      ): { [key: string]: number } => {
        const counts: { [key: string]: number } = {};

        // Initialize all status counts to 0
        statusOptions.forEach((status) => {
          counts[status] = 0;
        });

        // Count occurrences of each status in all procurement items
        procurementItems.forEach((item) => {
          if (item.Status && counts.hasOwnProperty(item.Status)) {
            counts[item.Status]++;
          }
        });

        return counts;
      };

      // Fetch Procurement Data
      const fetchData = async (): Promise<void> => {
        try {
          const selectFields = [
            "Id",
            "Title",
            fieldMappings.ProcurementForecast,
            `${fieldMappings.Project}/Id`,
            `${fieldMappings.Project}/Title`,
          ].filter((field) => field && !field.startsWith("_"));

          const query = `${apiBase}?$select=${selectFields.join(",")}&$expand=${
            fieldMappings.Project
          }&$top=5000`;

          const res = await fetch(query, {
            headers: { Accept: "application/json;odata=verbose" },
          });

          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

          const data = await res.json();
          procurementData = data.d.results || [];

          initializeFilters();
          renderTable(procurementData);
        } catch (error) {
          console.error("Error fetching data:", error);
          toast("Failed to fetch data", "error");
        }
      };

      // Initialize Filters
      const initializeFilters = (): void => {
        // Customer filter
        const uniqueCustomers = [
          ...new Set(projects.map((p) => p.CustomerName).filter(Boolean)),
        ].sort() as string[];
        filterCustomer.innerHTML =
          '<option value="">All Customers</option>' +
          uniqueCustomers
            .map(
              (customer) => `<option value="${customer}">${customer}</option>`
            )
            .join("");

        // Project Manager filter
        const uniqueManagers = [
          ...new Set(
            projects
              .map((p) => {
                if (typeof p.ProjectManager === "object")
                  return p.ProjectManager?.Title;
                return p.ProjectManager;
              })
              .filter(Boolean)
          ),
        ].sort() as string[];
        filterProjectManager.innerHTML =
          '<option value="">All Managers</option>' +
          uniqueManagers
            .map((manager) => `<option value="${manager}">${manager}</option>`)
            .join("");

        // Group Head filter
        const uniqueGroupHeads = [
          ...new Set(projects.map((p) => p.GroupHead).filter(Boolean)),
        ].sort() as string[];
        filterGroupHead.innerHTML =
          '<option value="">All Group Heads</option>' +
          uniqueGroupHeads
            .map((head) => `<option value="${head}">${head}</option>`)
            .join("");

        // Project Reference filter
        const uniqueReferences = [
          ...new Set(projects.map((p) => p.ProjectReference).filter(Boolean)),
        ].sort() as string[];
        filterProjectReference.innerHTML =
          '<option value="">All References</option>' +
          uniqueReferences
            .map((ref) => `<option value="${ref}">${ref}</option>`)
            .join("");

        // Status filter - get all unique statuses from all procurement items
        const uniqueStatuses: string[] = [];
        procurementData.forEach((item) => {
          const procurementItems =
            parseProcurementForecast(item[fieldMappings.ProcurementForecast]) ||
            [];
          procurementItems.forEach((procItem) => {
            if (procItem.Status) {
              uniqueStatuses.push(procItem.Status);
            }
          });
        });
        const filteredStatuses = [...new Set(uniqueStatuses)].sort();
        filterStatus.innerHTML =
          '<option value="">All Status</option>' +
          filteredStatuses
            .map((status) => `<option value="${status}">${status}</option>`)
            .join("");

        // Make filter - get all unique makes from all procurement items
        const uniqueMakes: string[] = [];
        procurementData.forEach((item) => {
          const procurementItems =
            parseProcurementForecast(item[fieldMappings.ProcurementForecast]) ||
            [];
          procurementItems.forEach((procItem) => {
            if (procItem.Make) {
              uniqueMakes.push(procItem.Make);
            }
          });
        });
        const filteredMakes = [...new Set(uniqueMakes)].sort();
        filterMake.innerHTML =
          '<option value="">All Makes</option>' +
          filteredMakes
            .map((make) => `<option value="${make}">${make}</option>`)
            .join("");
      };

      // Filter Data
      const filterData = (): void => {
        
         console.log("filterData called"); // Debug log
  
          const project = filterProject.value;
          const customer = filterCustomer.value;
          const projectManager = filterProjectManager.value;
          const groupHead = filterGroupHead.value;
          const projectReference = filterProjectReference.value;
          const status = filterStatus.value;
          const make = filterMake.value;

          console.log("Filter values:", { project, customer, status, make }); 

        const filtered = procurementData.filter((item) => {
          const projectTitle = item[fieldMappings.Project]?.Title;
          const projectData = projects.find((p) => p.Title === projectTitle);
          const procurementItems =
            parseProcurementForecast(item[fieldMappings.ProcurementForecast]) ||
            [];

          if (project && projectTitle !== project) return false;
          if (customer && projectData?.CustomerName !== customer) return false;
          if (projectManager) {
            const managerName =
              typeof projectData?.ProjectManager === "object"
                ? projectData.ProjectManager?.Title
                : projectData?.ProjectManager;
            if (managerName !== projectManager) return false;
          }
          if (groupHead && projectData?.GroupHead !== groupHead) return false;
          if (
            projectReference &&
            projectData?.ProjectReference !== projectReference
          )
            return false;

          // Check if any procurement item matches the status filter
          if (
            status &&
            !procurementItems.some((item) => item.Status === status)
          )
            return false;

          // Check if any procurement item matches the make filter
          if (make && !procurementItems.some((item) => item.Make === make))
            return false;

          return true;
        });

        currentPage = 1;
        renderTable(filtered);
      };

      // Clear Filters
      const clearFilters = (): void => {
        filterProject.value = "";
        filterCustomer.value = "";
        filterProjectManager.value = "";
        filterGroupHead.value = "";
        filterProjectReference.value = "";
        filterStatus.value = "";
        filterMake.value = "";

        currentPage = 1;
        renderTable(procurementData);
        toast("Filters cleared", "success");
      };

      // Format date for display
      const formatDate = (dateString: string): string => {
        if (!dateString) return "";
        try {
          const date = new Date(dateString);
          return isNaN(date.getTime())
            ? dateString
            : date.toLocaleDateString("en-GB");
        } catch {
          return dateString;
        }
      };

      // Format date for input (YYYY-MM-DD)
      const formatDateForInput = (dateString: string): string => {
        if (!dateString) return "";
        try {
          const date = new Date(dateString);
          return isNaN(date.getTime()) ? "" : date.toISOString().split("T")[0];
        } catch {
          return "";
        }
      };

      // Format date for Excel export (YYYY-MM-DD)
      const formatDateForExcel = (dateString: string): string => {
        if (!dateString) return "";
        try {
          const date = new Date(dateString);
          if (isNaN(date.getTime())) return "";
          return date.toISOString().split("T")[0]; // Returns YYYY-MM-DD
        } catch {
          return "";
        }
      };

      // Escape HTML to prevent XSS
      const escapeHtml = (unsafe: string | number): string => {
        const safeString = String(unsafe);
        return safeString
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
      };

      // Render Table Function
      const renderTable = (data: any[]): void => {
        const start = (currentPage - 1) * pageSize;
        const pageData = data.slice(start, start + pageSize);

        tableBody.innerHTML = "";

        if (pageData.length > 0) {
          pageData.forEach((item) => {
            const projectTitle = item[fieldMappings.Project]?.Title || "";
            const projectData = projects.find((p) => p.Title === projectTitle);
            const procurementItems =
              parseProcurementForecast(
                item[fieldMappings.ProcurementForecast]
              ) || [];

            // Calculate status counts for this project
            const statusCounts = calculateProjectStatusCounts(procurementItems);

            const row = document.createElement("tr");
            row.innerHTML = `
            <td>${escapeHtml(projectData?.ProjectReference || "")}</td>
            <td>${escapeHtml(projectTitle)}</td>
            <td>${escapeHtml(projectData?.CustomerName || "")}</td>
            <td>${escapeHtml(
              typeof projectData?.ProjectManager === "object"
                ? projectData.ProjectManager?.Title || ""
                : projectData?.ProjectManager || ""
            )}</td>
            <td>${escapeHtml(projectData?.GroupHead || "")}</td>
            <td style="text-align: center; font-weight: bold; background-color: #e3f2fd;">${
              statusCounts["RFQ Pending"]
            }</td>
            <td style="text-align: center; font-weight: bold; background-color: #fff3e0;">${
              statusCounts["Offer Awaited"]
            }</td>
            <td style="text-align: center; font-weight: bold; background-color: #e8f5e8;">${
              statusCounts["TC Pending"]
            }</td>
            <td style="text-align: center; font-weight: bold; background-color: #fce4ec;">${
              statusCounts["PR Pending"]
            }</td>
            <td style="text-align: center; font-weight: bold; background-color: #f3e5f5;">${
              statusCounts["PO Pending"]
            }</td>
            <td style="text-align: center; font-weight: bold; background-color: #e0f2f1;">${
              statusCounts["MFC Pending"]
            }</td>
            <td style="text-align: center; font-weight: bold; background-color: #fff8e1;">${
              statusCounts["Cleared for Manufacturing"]
            }</td>
            <td style="text-align: center; font-weight: bold; background-color: #e8f5e8;">${
              statusCounts["Delivered"]
            }</td>
            <td class="actions-cell">
              <button class="edit-btn" data-id="${item.Id}">✏️</button>
              <button class="view-btn" data-id="${item.Id}">👁️</button>
              <button class="delete-btn" data-id="${item.Id}">🗑️</button>
            </td>
          `;
            tableBody.appendChild(row);
          });
        } else {
          const noDataRow = document.createElement("tr");
          noDataRow.innerHTML = `<td colspan="15" style="text-align:center;padding:20px;">No records found</td>`;
          tableBody.appendChild(noDataRow);
        }

        // Add event listeners
        document.querySelectorAll(".edit-btn").forEach((btn) => {
          btn.addEventListener("click", () =>
            editData(Number((btn as HTMLElement).dataset.id))
          );
        });

        document.querySelectorAll(".view-btn").forEach((btn) => {
          btn.addEventListener("click", () =>
            viewData(Number((btn as HTMLElement).dataset.id))
          );
        });

        document.querySelectorAll(".delete-btn").forEach((btn) => {
          btn.addEventListener("click", () =>
            deleteData(Number((btn as HTMLElement).dataset.id))
          );
        });

        renderPagination(Math.ceil(data.length / pageSize));
      };

      // Render Pagination
      const renderPagination = (totalPages: number): void => {
        paginationDiv.innerHTML = "";
        if (totalPages <= 1) return;

        for (let i = 1; i <= totalPages; i++) {
          const btn = document.createElement("button");
          btn.textContent = i.toString();
          btn.className = i === currentPage ? "active" : "";
          btn.addEventListener("click", () => {
            currentPage = i;
            renderTable(procurementData);
          });
          paginationDiv.appendChild(btn);
        }
      };

      // Delete Data
      const deleteData = async (id: number): Promise<void> => {
        const result = await Swal.fire({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#0078d4",
          cancelButtonColor: "#d33",
          confirmButtonText: "Yes, delete it!",
        });

        if (result.isConfirmed) {
          try {
            const digest = await getRequestDigest();
            const response = await fetch(`${apiBase}(${id})`, {
              method: "DELETE",
              headers: {
                Accept: "application/json;odata=verbose",
                "X-RequestDigest": digest,
                "IF-MATCH": "*",
              },
            });

            if (response.ok) {
              toast("Deleted successfully", "success");
              await fetchData();
            } else {
              throw new Error(`Delete failed: ${response.status}`);
            }
          } catch (error) {
            console.error("Delete error:", error);
            toast("Delete failed", "error");
          }
        }
      };

      // View Data Function
      const viewData = (id: number): void => {
        const record = procurementData.find((d) => d.Id === id);
        if (!record) {
          toast("Record not found", "error");
          return;
        }

        editingId = id;
        formSection.style.display = "block";
        tableSection.style.display = "none";
        formTitle.textContent = "View Procurement";
        existingDataAlert.style.display = "none";

        // Add view-mode class to form section
        formSection.classList.add("view-mode");

        // Set project info (display only)
        const projectId =
          record[`${fieldMappings.Project}Id`] ||
          (record[fieldMappings.Project] && record[fieldMappings.Project].Id);

        if (projectId) {
          const project = projects.find((p) => p.Id === projectId);
          if (project) {
            projectSelect.value = projectId.toString();
            projectDetails.innerHTML = `
        <p><b>Profit Center:</b> ${project.PC || "-"}</p>
        <p><b>Customer:</b> ${project.CustomerName || "-"}</p>
        <p><b>Project Ref:</b> ${project.ProjectReference || "-"}</p>
        <p><b>Group Head:</b> ${project.GroupHead || "-"}</p>
        <p><b>Project Manager:</b> ${
          typeof project.ProjectManager === "object"
            ? project.ProjectManager?.Title
            : project.ProjectManager || "-"
        }</p>
      `;
          }
        }

        // Disable project selection in view mode
        projectSelect.disabled = true;

        // Clear and populate with view-only procurement items in table format
        procurementContainer.innerHTML = "";
        const procurementItems =
          parseProcurementForecast(record[fieldMappings.ProcurementForecast]) ||
          [];

        procurementItems.forEach((item) => {
          procurementContainer.appendChild(createViewProcurementRow(item));
        });

        // Hide form controls in view mode
        const addMoreBtn = document.querySelector(
          ".add-procurement-row"
        ) as HTMLButtonElement;
        if (addMoreBtn) addMoreBtn.style.display = "none";

        const submitBtn = form.querySelector(
          'button[type="submit"]'
        ) as HTMLButtonElement;
        if (submitBtn) {
          submitBtn.style.display = "none";
        }

        // Remove any existing export buttons to avoid duplicates
        const existingExportBtns = document.querySelectorAll(
          ".export-project-excel-btn, .export-top-btn"
        );
        existingExportBtns.forEach((btn) => btn.remove());

        // Create new export button
        const exportBtn = document.createElement("button");
        exportBtn.type = "button";
        exportBtn.className = "btn-primary export-project-excel-btn";
        exportBtn.textContent = "📊 Export BOM Excel";
        exportBtn.style.marginBottom = "15px";
        exportBtn.style.display = "block";

        // Add event listener with proper closure to capture current projectId and record
        exportBtn.addEventListener("click", () =>
          exportProjectToExcel(projectId, record)
        );

        // Insert the button at the top of the procurement container table
        const procurementContainerTable = document.getElementById(
          "procurementContainerTable"
        ) as HTMLElement;

        procurementContainerTable.parentNode?.insertBefore(
          exportBtn,
          procurementContainerTable
        );

        // Show procurement table
        procurementContainerTable.style.display = "block";
      };

      // Create view-only procurement row with description limited to 2 lines
      const createViewProcurementRow = (
        data: ProcurementForecastItem
      ): HTMLTableRowElement => {
        const row = document.createElement("tr");

        const getDisplayValue = (
          field: keyof ProcurementForecastItem
        ): string => {
          if (!data) return "";
          const value = data[field];

          if (value === null || value === undefined || value === "") return "";

          // Handle date fields
          if (
            field.includes("Plan") ||
            field.includes("Actual") ||
            field.includes("Forecast")
          ) {
            return formatDate(String(value));
          }

          // Handle numeric fields
          if (
            (field === "FCMQuantity" || field === "EnggQuantity") &&
            typeof value === "number"
          ) {
            return value.toString();
          }

          return String(value);
        };

        const statusValue = getDisplayValue("Status");
        const descriptionValue = escapeHtml(getDisplayValue("Description"));

        row.innerHTML = `
          <td>
            <div class="view-field description-view" title="${descriptionValue}">
              ${descriptionValue}
            </div>
          </td>
          <td><div class="view-field">${getDisplayValue(
            "FCMQuantity"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "EnggQuantity"
          )}</div></td>
          <td><div class="view-field status-badge" data-status="${escapeHtml(
            statusValue
          )}">${escapeHtml(statusValue)}</div></td>
          <td><div class="view-field">${escapeHtml(
            getDisplayValue("Make")
          )}</div></td>
          <td><div class="view-field">${escapeHtml(
            getDisplayValue("Model")
          )}</div></td>
          
          <!-- RFQ / Engg -->
          <td><div class="view-field">${getDisplayValue("RfqPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue("RfqActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "RfqForecast"
          )}</div></td>
          
          <!-- Vendor Offer / SCM -->
          <td><div class="view-field">${getDisplayValue("OfferPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "OfferActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "OfferForecast"
          )}</div></td>
          
          <!-- Technical Clearance / ENGG -->
          <td><div class="view-field">${getDisplayValue("TechPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "TechActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "TechForecast"
          )}</div></td>
          
          <!-- Order Finalization / SCM -->
          <td><div class="view-field">${getDisplayValue("OrderPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "OrderActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "OrderForecast"
          )}</div></td>
          
          <!-- PR / PM -->
          <td><div class="view-field">${getDisplayValue("PRPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue("PRActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "PRForecast"
          )}</div></td>
          
          <!-- Purchase Order / SCM -->
          <td><div class="view-field">${getDisplayValue("POPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue("POActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "POForecast"
          )}</div></td>
          
          <!-- Document Approval / ENGG -->
          <td><div class="view-field">${getDisplayValue("DocPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue("DocActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DocForecast"
          )}</div></td>
          
          <!-- Manufacturing Clearance / ENGG -->
          <td><div class="view-field">${getDisplayValue("MfgPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue("MfgActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "MfgForecast"
          )}</div></td>
          
          <!-- Inspection -->
          <td><div class="view-field">${getDisplayValue("InspPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "InspActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "InspForecast"
          )}</div></td>
          
          <!-- Material Dispatch -->
          <td><div class="view-field">${getDisplayValue("DispPlan")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DispActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DispForecast"
          )}</div></td>
          
          <!-- Delivery at Site -->
          <td><div class="view-field">${getDisplayValue(
            "DeliveryPlan"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DeliveryActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DeliveryForecast"
          )}</div></td>
          
          <td><div class="view-field remarks-view">${escapeHtml(
            getDisplayValue("Remarks")
          )}</div></td>
          <td></td>
        `;

        return row;
      };

      // Edit Data Function
      const editData = (id: number): void => {
        const record = procurementData.find((d) => d.Id === id);
        if (!record) {
          toast("Record not found", "error");
          return;
        }

        editingId = id;
        formSection.style.display = "block";
        tableSection.style.display = "none";
        formTitle.textContent = "Edit Procurement";
        existingDataAlert.style.display = "block";

        // Remove view-mode class for edit mode
        formSection.classList.remove("view-mode");

        // Enable project selection
        projectSelect.disabled = false;

        // Set project
        const projectId =
          record[`${fieldMappings.Project}Id`] ||
          (record[fieldMappings.Project] && record[fieldMappings.Project].Id);

        if (projectId) {
          projectSelect.value = projectId.toString();
          onProjectChange(projectId, true);
        }

        // Clear and populate form with editable procurement items
        procurementContainer.innerHTML = "";
        const procurementItems =
          parseProcurementForecast(record[fieldMappings.ProcurementForecast]) ||
          [];

        procurementItems.forEach((item) => {
          procurementContainer.appendChild(createProcurementRow(item));
        });

        // Show form controls in edit mode
        const addMoreBtn = document.querySelector(
          ".add-procurement-row"
        ) as HTMLButtonElement;
        if (addMoreBtn) addMoreBtn.style.display = "block";

        const submitBtn = form.querySelector(
          'button[type="submit"]'
        ) as HTMLButtonElement;
        if (submitBtn) {
          submitBtn.style.display = "inline-flex";
          submitBtn.textContent = "💾 Save Procurement";
        }

        // ADD IMPORT BUTTON IN EDIT MODE
        addImportButtonToEditMode(projectId, record);
      };

      // Add Import Button to Edit Mode
      const addImportButtonToEditMode = (
        projectId: number,
        record: any
      ): void => {
        // Remove any existing import buttons to avoid duplicates
        const existingImportBtns = document.querySelectorAll(
          ".import-excel-edit-btn"
        );
        existingImportBtns.forEach((btn) => btn.remove());

        // Create import button
        const importBtn = document.createElement("button");
        importBtn.type = "button";
        importBtn.className = "btn-primary import-excel-edit-btn";
        importBtn.textContent = "📥 Import Excel Data";
        importBtn.style.marginBottom = "15px";
        importBtn.style.marginRight = "10px";
        importBtn.style.display = "inline-block";

        // Add event listener
        importBtn.addEventListener("click", () =>
          importExcelForEdit(projectId, record)
        );

        // Insert the button at the top of the procurement container table
        const procurementContainerTable = document.getElementById(
          "procurementContainerTable"
        ) as HTMLElement;

        procurementContainerTable.parentNode?.insertBefore(
          importBtn,
          procurementContainerTable
        );
      };

      const importExcelForEdit = (projectId: number, record: any): void => {
        const modalHTML = `
    <div class="import-modal">
      <div class="import-modal-content">
        <div class="import-modal-header">
          <h3>Import Procurement Data from Excel</h3>
          <button class="close-modal">&times;</button>
        </div>

        <div class="import-section">
          <h4>Step 1: Download Template</h4>
          <p>Download the template file with the correct structure for import.</p>
          <button class="btn-primary" id="downloadEditTemplate">⬇️ Download Template</button>
        </div>

        <div class="import-section">
          <h4>Step 2: Upload Excel File</h4>
          <div class="file-upload-area" id="fileUploadArea">
            <div class="upload-icon">📁</div>
            <p><strong>Click to upload or drag & drop Excel file</strong></p>
            <p><small>Supported format: .xlsx, .xls (Max: 10MB)</small></p>
            <input type="file" id="excelFile" class="file-input" accept=".xlsx,.xls" style="display: none;">
            <div class="file-info" id="fileInfo"></div>
            <div class="upload-progress" id="uploadProgress" style="display: none;">
              <div class="progress-bar">
                <div class="progress-fill"></div>
              </div>
              <span>Processing file...</span>
            </div>
          </div>
        </div>

        <div class="import-section" id="previewSection" style="display:none;">
          <h4>Step 3: Preview & Import</h4>
          <div class="import-preview" id="importPreview"></div>
          <div class="import-actions">
            <button class="btn-secondary" id="cancelImport">Cancel</button>
            <button class="btn-primary" id="confirmImport">Import Data</button>
          </div>
          <div class="import-status" id="importStatus"></div>
        </div>
      </div>
    </div>
  `;

        document.body.insertAdjacentHTML("beforeend", modalHTML);
        const modal = document.querySelector(".import-modal") as HTMLElement;

        // Elements
        const fileUploadArea = document.getElementById(
          "fileUploadArea"
        ) as HTMLElement;
        const excelFileInput = document.getElementById(
          "excelFile"
        ) as HTMLInputElement;
        const fileInfo = document.getElementById("fileInfo") as HTMLElement;
        const previewSection = document.getElementById(
          "previewSection"
        ) as HTMLElement;
        const importPreview = document.getElementById(
          "importPreview"
        ) as HTMLElement;
        const confirmImport = document.getElementById(
          "confirmImport"
        ) as HTMLButtonElement;
        const cancelImport = document.getElementById(
          "cancelImport"
        ) as HTMLButtonElement;
        const closeModal = document.querySelector(
          ".close-modal"
        ) as HTMLButtonElement;
        const importStatus = document.getElementById(
          "importStatus"
        ) as HTMLElement;
        const downloadTemplateBtn = document.getElementById(
          "downloadEditTemplate"
        ) as HTMLButtonElement;
        const uploadProgress = document.getElementById(
          "uploadProgress"
        ) as HTMLElement;

        let importData: any[] = [];

        // File Upload Handling
        fileUploadArea.addEventListener("click", () => excelFileInput.click());

        fileUploadArea.addEventListener("dragover", (e) => {
          e.preventDefault();
          fileUploadArea.classList.add("dragover");
        });

        fileUploadArea.addEventListener("dragleave", () => {
          fileUploadArea.classList.remove("dragover");
        });

        fileUploadArea.addEventListener("drop", (e) => {
          e.preventDefault();
          fileUploadArea.classList.remove("dragover");
          const files = e.dataTransfer?.files;
          if (files && files[0]) {
            excelFileInput.files = files;
            handleFileSelection(files[0]);
          }
        });

        excelFileInput.addEventListener("change", (e) => {
          const files = (e.target as HTMLInputElement).files;
          if (files && files[0]) handleFileSelection(files[0]);
        });

        // Handle Excel File Selection
        const handleFileSelection = async (file: File) => { 

          if (!file.name.toLowerCase().match(/\.(xlsx|xls)$/)) { 
            toast("Please select an Excel file (.xlsx or .xls)", "error");
            return;
          }

          // Validate file size (10MB limit)
          if (file.size > 10 * 1024 * 1024) {
            toast("File size too large. Please use files under 10MB.", "error");
            return;
          }

          fileInfo.textContent = `Selected: ${file.name} (${(
            file.size / 1024
          ).toFixed(2)} KB)`;
          fileInfo.style.color = "#0078d4";

          // Show progress
          uploadProgress.style.display = "block";

          try { 
            const parsedData = await parseExcelFile(file);  
            if (parsedData.length === 0) { 
              toast("No valid data found in the Excel file", "warning");
              uploadProgress.style.display = "none";
              return;
            }

            const isValid = validateProcurementImportData(parsedData); 
            if (isValid) { 
              importData = parsedData;
              showImportPreview(parsedData);
              previewSection.style.display = "block";
            } else { 
              toast(
                "Invalid Excel format. Please check the required columns. The file should contain at least Description, Status, or Make columns.",
                "error"
              );
            }
          } catch (error) {
            console.error("❌ Excel parsing error:", error);
            toast(`Error reading Excel file: ${error}`, "error");
          } finally {
            uploadProgress.style.display = "none";
          } 
        };

        // Parse Excel File for Procurement Data
        const parseExcelFile = (file: File): Promise<any[]> => {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (e) => {
              try {
                if (!e.target?.result) {
                  reject(new Error("Failed to read file"));
                  return;
                }

                const data = new Uint8Array(e.target.result as ArrayBuffer);
                const workbook = XLSX.read(data, {
                  type: "array",
                  cellDates: true,
                  raw: false,
                });

                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];

                // Convert to JSON with headers
                const jsonData = XLSX.utils.sheet_to_json(worksheet, {
                  header: 1,
                  defval: "",
                });
 

                if (jsonData.length < 2) { 
                  return resolve([]);
                }

                // Handle both single-row and two-row headers
                let headers: string[];
                let dataStartRow = 1;

                if (
                  jsonData.length >= 2 &&
                  Array.isArray(jsonData[0]) &&
                  Array.isArray(jsonData[1])
                ) {
                  // Check if this is a two-row header structure
                  const firstRow = jsonData[0] as string[];
                  const secondRow = jsonData[1] as string[];

                  // If first row has section headers and second row has column names, use second row
                  if (
                    firstRow.some(
                      (cell) =>
                        cell && typeof cell === "string" && cell.includes("/")
                    ) &&
                    secondRow.some(
                      (cell) =>
                        cell &&
                        typeof cell === "string" &&
                        (cell.toLowerCase().includes("desc") ||
                          cell.toLowerCase().includes("status"))
                    )
                  ) {
                    headers = secondRow;
                    dataStartRow = 2; 
                  } else {
                    headers = firstRow;
                  }
                } else {
                  headers = jsonData[0] as string[];
                } 
                const rows: any[] = [];

                // Create header mapping for flexible column names
                const headerMap: { [key: string]: string } = {};
                headers.forEach((header, idx) => {
                  if (header && typeof header === "string") {
                    const cleanHeader = header.toString().trim().toLowerCase();
                     
                    // Map common variations to standard names
                    if (
                      cleanHeader.includes("desc") ||
                      cleanHeader.includes("item")
                    ) {
                      headerMap[cleanHeader] = "description";
                    } else if (
                      cleanHeader.includes("vendor") ||
                      cleanHeader.includes("supplier")
                    ) {
                      headerMap[cleanHeader] = "vendor";
                    } else if (
                      cleanHeader.includes("fcm") &&
                      (cleanHeader.includes("qty") ||
                        cleanHeader.includes("quantity"))
                    ) {
                      headerMap[cleanHeader] = "fcmquantity";
                    } else if (
                      cleanHeader.includes("engg") &&
                      (cleanHeader.includes("qty") ||
                        cleanHeader.includes("quantity"))
                    ) {
                      headerMap[cleanHeader] = "enggquantity";
                    } else if (cleanHeader.includes("status")) {
                      headerMap[cleanHeader] = "status";
                    } else if (
                      cleanHeader.includes("make") ||
                      cleanHeader.includes("manufacturer")
                    ) {
                      headerMap[cleanHeader] = "make";
                    } else if (
                      cleanHeader.includes("model") ||
                      cleanHeader.includes("part")
                    ) {
                      headerMap[cleanHeader] = "model";
                    } else if (cleanHeader.includes("remark")) {
                      headerMap[cleanHeader] = "remarks";
                    } else {
                      headerMap[cleanHeader] = cleanHeader;
                    }
                  }
                });
 
                for (let i = dataStartRow; i < jsonData.length; i++) {
                  const rowData = jsonData[i] as any[];
                  if (
                    !rowData ||
                    rowData.every(
                      (cell) =>
                        cell === "" || cell === null || cell === undefined
                    )
                  ) {
                    continue; // Skip completely empty rows
                  }

                  const row: any = {};

                  headers.forEach((header, idx) => {
                    if (
                      header &&
                      rowData[idx] !== undefined &&
                      rowData[idx] !== null &&
                      rowData[idx] !== ""
                    ) {
                      const cleanHeader = header
                        .toString()
                        .trim()
                        .toLowerCase();
                      const mappedHeader =
                        headerMap[cleanHeader] || cleanHeader;

                      // Handle different data types
                      let value = rowData[idx];
                      if (typeof value === "object" && value instanceof Date) {
                        value = value.toISOString().split("T")[0]; // Format dates as YYYY-MM-DD
                      } else if (typeof value === "number") {
                        value = value.toString();
                      } else if (typeof value === "string") {
                        value = value.trim();
                      }

                      row[mappedHeader] = value;
                    }
                  });
 
                  // Only add rows that have meaningful data
                  if (row.description || row.make || row.status || row.vendor) {
                    rows.push(row); 
                  } else { 
                  }
                }
 
                resolve(rows);
              } catch (err) { 
                reject(err);
              }
            };

            reader.onerror = (error) => {
              console.error("❌ FileReader error:", error);
              reject(new Error("Failed to read file"));
            };

            reader.onabort = () => {
              reject(new Error("File reading was aborted"));
            };

            try {
              reader.readAsArrayBuffer(file);
            } catch (error) {
              reject(new Error(`Cannot read file: ${error}`));
            }
          });
        };

        // Validate Procurement Import Data
        const validateProcurementImportData = (data: any[]): boolean => { 
          if (data.length === 0) { 
            return false;
          } 

          const first = data[0];
          const keys = Object.keys(first);
 
          // More flexible validation
          const hasRelevantColumns = keys.some((k) => {
            const key = k.toLowerCase();
            return (
              key.includes("desc") ||
              key.includes("item") ||
              key.includes("vendor") ||
              key.includes("supplier") ||
              key.includes("status") ||
              key.includes("qty") ||
              key.includes("quantity") ||
              key.includes("make") ||
              key.includes("model")
            );
          });
 
          return hasRelevantColumns && data.length > 0;
        };

        // Show Import Preview
        const showImportPreview = (data: any[]) => {
         
          const previewHTML = `
      <div style="padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <h4 style="color: #28a745; margin-bottom: 15px;">✅ File Ready for Import</h4>
        <p><strong>Found ${
          data.length
        } procurement records to import:</strong></p>
        <div class="preview-table-container" style="max-height: 300px; overflow-y: auto;">
          <table class="preview-table" style="width: 100%; border-collapse: collapse; font-size: 12px;">
            <thead style="background: #007bff; color: white; position: sticky; top: 0;">
              <tr>
                <th style="padding: 8px; border: 1px solid #ddd;">Description</th>
                <th style="padding: 8px; border: 1px solid #ddd;">Status</th>
                <th style="padding: 8px; border: 1px solid #ddd;">Make</th>
                <th style="padding: 8px; border: 1px solid #ddd;">Model</th>
                <th style="padding: 8px; border: 1px solid #ddd;">FCM Qty</th>
                <th style="padding: 8px; border: 1px solid #ddd;">Engg Qty</th>
                <th style="padding: 8px; border: 1px solid #ddd;">Remarks</th>
              </tr>
            </thead>
            <tbody>
              ${data
                .slice(0, 10)
                .map((row, index) => {
                  return `
                  <tr style="${
                    index % 2 === 0
                      ? "background: #f8f9fa;"
                      : "background: white;"
                  }">
                    <td style="padding: 6px; border: 1px solid #ddd;">${
                      row.description || "N/A"
                    }</td>
                    <td style="padding: 6px; border: 1px solid #ddd;">${
                      row.status || "N/A"
                    }</td>
                    <td style="padding: 6px; border: 1px solid #ddd;">${
                      row.make || row.manufacturer || "N/A"
                    }</td>
                    <td style="padding: 6px; border: 1px solid #ddd;">${
                      row.model || row.partnumber || "N/A"
                    }</td>
                    <td style="padding: 6px; border: 1px solid #ddd;">${
                      row.fcmquantity || row.fcmqty || "N/A"
                    }</td>
                    <td style="padding: 6px; border: 1px solid #ddd;">${
                      row.enggquantity || row.enggqty || "N/A"
                    }</td>
                    <td style="padding: 6px; border: 1px solid #ddd;">${
                      row.remarks || "N/A"
                    }</td>
                  </tr>
                `;
                })
                .join("")}
            </tbody>
          </table>
        </div>
        ${
          data.length > 10
            ? `<p style="margin-top: 10px; font-style: italic;">... and ${
                data.length - 10
              } more records</p>`
            : ""
        }
        <div style="margin-top: 15px; padding: 12px; background: #e7f3ff; border-radius: 5px;">
          <p style="margin: 0; color: #0056b3; font-size: 14px;">
            <strong>⚠️ Important:</strong> This will replace existing procurement data for this project.
          </p>
        </div>
      </div>`;

          importPreview.innerHTML = previewHTML; 
        };

        // Download Template without Project Information columns (A-E)
        downloadTemplateBtn.addEventListener("click", () => {
          // Get current project data
          const project = projects.find((p) => p.Id === projectId);

          // Get current procurement data for this project
          const currentProcurementItems =
            parseProcurementForecast(
              record[fieldMappings.ProcurementForecast]
            ) || [];

          // Create headers WITHOUT project information columns (A-E)
          const headers = [
            "Description",
            "Status",
            "Make",
            "Model",
            "FCMQuantity",
            "EnggQuantity",
            "Remarks",
            "RfqPlan",
            "RfqActual",
            "RfqForecast",
            "OfferPlan",
            "OfferActual",
            "OfferForecast",
            "TechPlan",
            "TechActual",
            "TechForecast",
            "OrderPlan",
            "OrderActual",
            "OrderForecast",
            "PRPlan",
            "PRActual",
            "PRForecast",
            "POPlan",
            "POActual",
            "POForecast",
            "DocPlan",
            "DocActual",
            "DocForecast",
            "MfgPlan",
            "MfgActual",
            "MfgForecast",
            "InspPlan",
            "InspActual",
            "InspForecast",
            "DispPlan",
            "DispActual",
            "DispForecast",
            "DeliveryPlan",
            "DeliveryActual",
            "DeliveryForecast",
          ];

          // Create worksheet data with headers only (no two-row structure for template)
          const wsData: string[][] = [headers];

          // Add existing procurement data rows
          if (currentProcurementItems.length > 0) {
            currentProcurementItems.forEach((item) => {
              const row = [
                // Item Information only (no project info)
                item.Description || "",
                item.Status || "RFQ Pending",
                item.Make || "",
                item.Model || "",
                item.FCMQuantity?.toString() || "",
                item.EnggQuantity?.toString() || "",
                item.Remarks || "",

                // RFQ dates
                formatDateForExcel(item.RfqPlan) || "",
                formatDateForExcel(item.RfqActual) || "",
                formatDateForExcel(item.RfqForecast) || "",

                // Offer dates
                formatDateForExcel(item.OfferPlan) || "",
                formatDateForExcel(item.OfferActual) || "",
                formatDateForExcel(item.OfferForecast) || "",

                // Tech dates
                formatDateForExcel(item.TechPlan) || "",
                formatDateForExcel(item.TechActual) || "",
                formatDateForExcel(item.TechForecast) || "",

                // Order dates
                formatDateForExcel(item.OrderPlan) || "",
                formatDateForExcel(item.OrderActual) || "",
                formatDateForExcel(item.OrderForecast) || "",

                // PR dates
                formatDateForExcel(item.PRPlan) || "",
                formatDateForExcel(item.PRActual) || "",
                formatDateForExcel(item.PRForecast) || "",

                // PO dates
                formatDateForExcel(item.POPlan) || "",
                formatDateForExcel(item.POActual) || "",
                formatDateForExcel(item.POForecast) || "",

                // Doc dates
                formatDateForExcel(item.DocPlan) || "",
                formatDateForExcel(item.DocActual) || "",
                formatDateForExcel(item.DocForecast) || "",

                // Mfg dates
                formatDateForExcel(item.MfgPlan) || "",
                formatDateForExcel(item.MfgActual) || "",
                formatDateForExcel(item.MfgForecast) || "",

                // Insp dates
                formatDateForExcel(item.InspPlan) || "",
                formatDateForExcel(item.InspActual) || "",
                formatDateForExcel(item.InspForecast) || "",

                // Disp dates
                formatDateForExcel(item.DispPlan) || "",
                formatDateForExcel(item.DispActual) || "",
                formatDateForExcel(item.DispForecast) || "",

                // Delivery dates
                formatDateForExcel(item.DeliveryPlan) || "",
                formatDateForExcel(item.DeliveryActual) || "",
                formatDateForExcel(item.DeliveryForecast) || "",
              ];
              wsData.push(row);
            });
          } else {
            // If no existing data, create one empty row with default status
            const emptyRow = Array(headers.length).fill("");
            emptyRow[1] = "RFQ Pending"; // Default status
            wsData.push(emptyRow);
          }

          // Create worksheet
          const ws = XLSX.utils.aoa_to_sheet(wsData);

          // Style the header row
          const headerStyle = {
            font: { bold: true, color: { rgb: "FFFFFF" }, sz: 11 },
            fill: { patternType: "solid", fgColor: { rgb: "2F5597" } },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          // Apply styles to header row
          for (let col = 0; col < headers.length; col++) {
            const address = XLSX.utils.encode_cell({ r: 0, c: col });
            ws[address].s = headerStyle;
          }

          // Set column widths
          ws["!cols"] = [
            { wch: 30 }, // Description
            { wch: 15 }, // Status
            { wch: 15 }, // Make
            { wch: 15 }, // Model
            { wch: 12 }, // FCMQuantity
            { wch: 12 }, // EnggQuantity
            { wch: 20 }, // Remarks
            // Process stages (3 columns each)
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // RFQ
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Offer
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Tech
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Order
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // PR
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // PO
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Doc
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Mfg
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Insp
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Disp
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Delivery
          ];

          // Create workbook with single sheet
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "Procurement Data");

          // Generate file name with timestamp
          const timestamp = new Date().toISOString().split("T")[0];
          const fileName = `Procurement_Template_${
            project?.Title?.replace(/[^a-zA-Z0-9]/g, "_") || "Project"
          }_${timestamp}.xlsx`;

          XLSX.writeFile(wb, fileName);

          toast(
            `Template downloaded with ${currentProcurementItems.length} existing items`,
            "success"
          );
        });

        // Perform Import and Auto-Submit
        const performImport = async () => {
          confirmImport.disabled = true;
          confirmImport.textContent = "Importing...";
          importStatus.style.display = "block";
          importStatus.textContent = "Processing procurement data...";
          importStatus.style.color = "#0078d4";

          try {
            // Convert imported data to procurement format
            const procurementItems: ProcurementForecastItem[] = importData.map(
              (row) => {
                return {
                  Description: row.description || "",
                  FCMQuantity: row.fcmquantity
                    ? parseFloat(row.fcmquantity)
                    : null,
                  EnggQuantity: row.enggquantity
                    ? parseFloat(row.enggquantity)
                    : null,
                  Status: row.status || "RFQ Pending",
                  Make: row.make || row.manufacturer || "",
                  Model: row.model || row.partnumber || "",
                  Remarks: row.remarks || "",

                  // Map date fields - initialize all to empty strings
                  RfqPlan: row.rfqplan || "",
                  RfqActual: row.rfqactual || "",
                  RfqForecast: row.rfqforecast || "",
                  OfferPlan: row.offerplan || "",
                  OfferActual: row.offeractual || "",
                  OfferForecast: row.offerforecast || "",
                  TechPlan: row.techplan || "",
                  TechActual: row.techactual || "",
                  TechForecast: row.techforecast || "",
                  OrderPlan: row.orderplan || "",
                  OrderActual: row.orderactual || "",
                  OrderForecast: row.orderforecast || "",
                  PRPlan: row.prplan || "",
                  PRActual: row.practual || "",
                  PRForecast: row.prforecast || "",
                  POPlan: row.poplan || "",
                  POActual: row.poactual || "",
                  POForecast: row.poforecast || "",
                  DocPlan: row.docplan || "",
                  DocActual: row.docactual || "",
                  DocForecast: row.docforecast || "",
                  MfgPlan: row.mfgplan || "",
                  MfgActual: row.mfgactual || "",
                  MfgForecast: row.mfgforecast || "",
                  InspPlan: row.inspplan || "",
                  InspActual: row.inspactual || "",
                  InspForecast: row.inspforecast || "",
                  DispPlan: row.dispplan || "",
                  DispActual: row.dispactual || "",
                  DispForecast: row.dispforecast || "",
                  DeliveryPlan: row.deliveryplan || "",
                  DeliveryActual: row.deliveryactual || "",
                  DeliveryForecast: row.deliveryforecast || "",
                };
              }
            );
 
            // Auto-submit the imported data to database
            await submitImportedData(procurementItems);

            // Close modal
            modal.remove();

            // Show success message and redirect
            toast(
              `Successfully imported ${procurementItems.length} procurement items and saved to database!`,
              "success"
            );

            // Redirect to main view after a short delay
            setTimeout(async () => {
              resetForm();
              await fetchData();
            }, 1500);
          } catch (error) {
            console.error("Import error:", error);
            importStatus.className = "import-status error";
            importStatus.innerHTML = `<strong style="color: #dc3545;">❌ Import Failed:</strong> ${error}`;
            toast("Failed to import and save data", "error");

            confirmImport.disabled = false;
            confirmImport.textContent = "Import Data";
          }
        };

        // Submit Imported Data to Database
        const submitImportedData = async (
          procurementItems: ProcurementForecastItem[]
        ): Promise<void> => {
          try {
            const digest = await getRequestDigest();

            if (!projectId) {
              throw new Error("No project selected");
            }

            // Check if project already exists
            const existingRecord = procurementData.find(
              (item) =>
                item[`${fieldMappings.Project}Id`] === projectId ||
                (item[fieldMappings.Project] &&
                  item[fieldMappings.Project].Id === projectId)
            );

            const itemData: any = {
              __metadata: { type: listEntityTypeName },
              [`${fieldMappings.Project}Id`]: projectId,
              [fieldMappings.ProcurementForecast]:
                JSON.stringify(procurementItems),
            };

            const headers: HeadersInit = {
              Accept: "application/json;odata=verbose",
              "Content-Type": "application/json;odata=verbose",
              "X-RequestDigest": digest,
            };

            let url = apiBase;

            // If editing existing record or project already exists, update it
            if (editingId || existingRecord) {
              const recordId = editingId || existingRecord.Id;
              url = `${apiBase}(${recordId})`;
              headers["IF-MATCH"] = "*";
              headers["X-HTTP-Method"] = "MERGE";
            }
 
            const response = await fetch(url, {
              method: "POST",
              headers: headers,
              body: JSON.stringify(itemData),
            });

            if (!response.ok) {
              const errorText = await response.text();
              throw new Error(
                `HTTP error! status: ${response.status}, details: ${errorText}`
              );
            }
 
          } catch (error) {
            console.error("Error submitting imported data:", error);
            throw error;
          }
        };

        // Modal Controls
        const closeModalHandler = () => modal.remove();
        closeModal.addEventListener("click", closeModalHandler);
        cancelImport.addEventListener("click", closeModalHandler);
        modal.addEventListener("click", (e) => {
          if (e.target === modal) closeModalHandler();
        });

        confirmImport.addEventListener("click", performImport);
      };
      // Project Change Handler
      const onProjectChange = (
        selectedId: number,
        isEditing: boolean = false
      ): void => {
        const project = projects.find((p) => p.Id === selectedId);
        if (!project) return;

        projectDetails.innerHTML = `
        <p><b>Profit Center:</b> ${project.PC || "-"}</p>
        <p><b>Customer:</b> ${project.CustomerName || "-"}</p>
        <p><b>Project Ref:</b> ${project.ProjectReference || "-"}</p>
        <p><b>Group Head:</b> ${project.GroupHead || "-"}</p>
        <p><b>Project Manager:</b> ${
          typeof project.ProjectManager === "object"
            ? project.ProjectManager?.Title
            : project.ProjectManager || "-"
        }</p>
      `;

        procurementContainerTable.style.display = "block";

        // Check if project already has data (only when not in edit mode)
        if (!isEditing) {
          const existingRecord = procurementData.find(
            (item) =>
              item[`${fieldMappings.Project}Id`] === selectedId ||
              (item[fieldMappings.Project] &&
                item[fieldMappings.Project].Id === selectedId)
          );

          if (existingRecord) {
            // Show existing data alert
            existingDataAlert.style.display = "block";
            formTitle.textContent = "Edit Procurement";
            editingId = existingRecord.Id;

            // Load existing procurement items
            const procurementItems =
              parseProcurementForecast(
                existingRecord[fieldMappings.ProcurementForecast]
              ) || [];
            procurementContainer.innerHTML = "";

            procurementItems.forEach((item) => {
              procurementContainer.appendChild(createProcurementRow(item));
            });
          } else {
            // New project, clear form
            existingDataAlert.style.display = "none";
            formTitle.textContent = "Add Procurement";
            editingId = null;

            procurementContainer.innerHTML = "";
            procurementContainer.appendChild(createProcurementRow());
          }
        }
      };

      // Create Procurement Row
      const createProcurementRow = (
        data?: ProcurementForecastItem
      ): HTMLTableRowElement => {
        const row = document.createElement("tr");

        const getFieldValue = (
          field: keyof ProcurementForecastItem
        ): string => {
          if (!data) return "";
          const value = data[field];
          if (value === null || value === undefined) return "";

          if (
            field.includes("Plan") ||
            field.includes("Actual") ||
            field.includes("Forecast")
          ) {
            return formatDateForInput(String(value));
          }

          if (
            (field === "FCMQuantity" || field === "EnggQuantity") &&
            typeof value === "number"
          ) {
            return value.toString();
          }

          return String(value);
        };

        row.innerHTML = `
        <td><input type="text" name="description" class="form-control" placeholder="Description" value="${escapeHtml(
          getFieldValue("Description")
        )}" required></td>
        <td><input type="number" name="fcm_qty" class="form-control number-input" placeholder="FCM Qty" value="${getFieldValue(
          "FCMQuantity"
        )}" step="0.01" min="0"></td>
        <td><input type="number" name="engg_qty" class="form-control number-input" placeholder="Engg Qty" value="${getFieldValue(
          "EnggQuantity"
        )}" step="0.01" min="0"></td>
        <td>
          <select name="status" class="form-control" required>
            ${statusOptions
              .map(
                (status) =>
                  `<option value="${status}" ${
                    getFieldValue("Status") === status ? "selected" : ""
                  }>${status}</option>`
              )
              .join("")}
          </select>
        </td>
        <td><input type="text" name="make" class="form-control" placeholder="Make" value="${escapeHtml(
          getFieldValue("Make")
        )}"></td>
        <td><input type="text" name="model" class="form-control" placeholder="Model" value="${escapeHtml(
          getFieldValue("Model")
        )}"></td>
        <!-- RFQ / Engg -->
        <td><input type="date" name="rfq_plan" class="form-control" value="${getFieldValue(
          "RfqPlan"
        )}"></td>
        <td><input type="date" name="rfq_actual" class="form-control" value="${getFieldValue(
          "RfqActual"
        )}"></td>
        <td><input type="date" name="rfq_forecast" class="form-control" value="${getFieldValue(
          "RfqForecast"
        )}"></td>
        
        <!-- Vendor Offer / SCM -->
        <td><input type="date" name="offer_plan" class="form-control" value="${getFieldValue(
          "OfferPlan"
        )}"></td>
        <td><input type="date" name="offer_actual" class="form-control" value="${getFieldValue(
          "OfferActual"
        )}"></td>
        <td><input type="date" name="offer_forecast" class="form-control" value="${getFieldValue(
          "OfferForecast"
        )}"></td>
        
        <!-- Technical Clearance / ENGG -->
        <td><input type="date" name="tech_plan" class="form-control" value="${getFieldValue(
          "TechPlan"
        )}"></td>
        <td><input type="date" name="tech_actual" class="form-control" value="${getFieldValue(
          "TechActual"
        )}"></td>
        <td><input type="date" name="tech_forecast" class="form-control" value="${getFieldValue(
          "TechForecast"
        )}"></td>
        
        <!-- Order Finalization / SCM -->
        <td><input type="date" name="order_plan" class="form-control" value="${getFieldValue(
          "OrderPlan"
        )}"></td>
        <td><input type="date" name="order_actual" class="form-control" value="${getFieldValue(
          "OrderActual"
        )}"></td>
        <td><input type="date" name="order_forecast" class="form-control" value="${getFieldValue(
          "OrderForecast"
        )}"></td>
        
        <!-- PR / PM -->
        <td><input type="date" name="pr_plan" class="form-control" value="${getFieldValue(
          "PRPlan"
        )}"></td>
        <td><input type="date" name="pr_actual" class="form-control" value="${getFieldValue(
          "PRActual"
        )}"></td>
        <td><input type="date" name="pr_forecast" class="form-control" value="${getFieldValue(
          "PRForecast"
        )}"></td>
        
        <!-- Purchase Order / SCM -->
        <td><input type="date" name="po_plan" class="form-control" value="${getFieldValue(
          "POPlan"
        )}"></td>
        <td><input type="date" name="po_actual" class="form-control" value="${getFieldValue(
          "POActual"
        )}"></td>
        <td><input type="date" name="po_forecast" class="form-control" value="${getFieldValue(
          "POForecast"
        )}"></td>
        
        <!-- Document Approval / ENGG -->
        <td><input type="date" name="doc_plan" class="form-control" value="${getFieldValue(
          "DocPlan"
        )}"></td>
        <td><input type="date" name="doc_actual" class="form-control" value="${getFieldValue(
          "DocActual"
        )}"></td>
        <td><input type="date" name="doc_forecast" class="form-control" value="${getFieldValue(
          "DocForecast"
        )}"></td>
        
        <!-- Manufacturing Clearance / ENGG -->
        <td><input type="date" name="mfg_plan" class="form-control" value="${getFieldValue(
          "MfgPlan"
        )}"></td>
        <td><input type="date" name="mfg_actual" class="form-control" value="${getFieldValue(
          "MfgActual"
        )}"></td>
        <td><input type="date" name="mfg_forecast" class="form-control" value="${getFieldValue(
          "MfgForecast"
        )}"></td>
        
        <!-- Inspection -->
        <td><input type="date" name="insp_plan" class="form-control" value="${getFieldValue(
          "InspPlan"
        )}"></td>
        <td><input type="date" name="insp_actual" class="form-control" value="${getFieldValue(
          "InspActual"
        )}"></td>
        <td><input type="date" name="insp_forecast" class="form-control" value="${getFieldValue(
          "InspForecast"
        )}"></td>
          
          <!-- Material Dispatch -->
          <td><input type="date" name="disp_plan" class="form-control" value="${getFieldValue(
            "DispPlan"
          )}"></td>
          <td><input type="date" name="disp_actual" class="form-control" value="${getFieldValue(
            "DispActual"
          )}"></td>
          <td><input type="date" name="disp_forecast" class="form-control" value="${getFieldValue(
            "DispForecast"
          )}"></td>
          
          <!-- Delivery at Site -->
          <td><input type="date" name="delivery_plan" class="form-control" value="${getFieldValue(
            "DeliveryPlan"
          )}"></td>
          <td><input type="date" name="delivery_actual" class="form-control" value="${getFieldValue(
            "DeliveryActual"
          )}"></td>
          <td><input type="date" name="delivery_forecast" class="form-control" value="${getFieldValue(
            "DeliveryForecast"
          )}"></td>

          <td><input type="text" name="remarks" class="form-control" placeholder="Remarks" value="${escapeHtml(
            getFieldValue("Remarks")
          )}"></td>
          <td><button type="button" class="remove-row btn-danger">🗑️</button></td>
        `;

        return row;
      };

      // Form Submission
      form.addEventListener("submit", async (e) => {
        e.preventDefault();

        if (!projectSelect.value) {
          toast("Please select a project", "error");
          return;
        }

        const rows = Array.from(procurementContainer.querySelectorAll("tr"));
        if (rows.length === 0) {
          toast("Please add at least one procurement item", "error");
          return;
        }

        try {
          const digest = await getRequestDigest();
          const projectId = parseInt(projectSelect.value);

          // Build array of procurement items from all rows
          const procurementItems: ProcurementForecastItem[] = rows.map(
            (row) => {
              const inputs = row.querySelectorAll("input, select");
              const item: ProcurementForecastItem = {
                Description: "",
                FCMQuantity: null,
                EnggQuantity: null,
                Status: "",
                Make: "",
                Model: "",
                Remarks: "",
                RfqPlan: "",
                RfqActual: "",
                RfqForecast: "",
                OfferPlan: "",
                OfferActual: "",
                OfferForecast: "",
                TechPlan: "",
                TechActual: "",
                TechForecast: "",
                OrderPlan: "",
                OrderActual: "",
                OrderForecast: "",
                PRPlan: "",
                PRActual: "",
                PRForecast: "",
                POPlan: "",
                POActual: "",
                POForecast: "",
                DocPlan: "",
                DocActual: "",
                DocForecast: "",
                MfgPlan: "",
                MfgActual: "",
                MfgForecast: "",
                InspPlan: "",
                InspActual: "",
                InspForecast: "",
                DispPlan: "",
                DispActual: "",
                DispForecast: "",
                DeliveryPlan: "",
                DeliveryActual: "",
                DeliveryForecast: "",
              };

              inputs.forEach((input) => {
                const element = input as HTMLInputElement | HTMLSelectElement;
                const name = element.name;
                const value = element.value;

                if (!name) return;

                switch (name) {
                  case "description":
                    item.Description = value;
                    break;
                  case "fcm_qty":
                    item.FCMQuantity = value ? parseFloat(value) : null;
                    break;
                  case "engg_qty":
                    item.EnggQuantity = value ? parseFloat(value) : null;
                    break;
                  case "status":
                    item.Status = value;
                    break;
                  case "make":
                    item.Make = value;
                    break;
                  case "model":
                    item.Model = value;
                    break;
                  case "remarks":
                    item.Remarks = value;
                    break;
                  case "rfq_plan":
                    item.RfqPlan = value;
                    break;
                  case "rfq_actual":
                    item.RfqActual = value;
                    break;
                  case "rfq_forecast":
                    item.RfqForecast = value;
                    break;
                  case "offer_plan":
                    item.OfferPlan = value;
                    break;
                  case "offer_actual":
                    item.OfferActual = value;
                    break;
                  case "offer_forecast":
                    item.OfferForecast = value;
                    break;
                  case "tech_plan":
                    item.TechPlan = value;
                    break;
                  case "tech_actual":
                    item.TechActual = value;
                    break;
                  case "tech_forecast":
                    item.TechForecast = value;
                    break;
                  case "order_plan":
                    item.OrderPlan = value;
                    break;
                  case "order_actual":
                    item.OrderActual = value;
                    break;
                  case "order_forecast":
                    item.OrderForecast = value;
                    break;
                  case "pr_plan":
                    item.PRPlan = value;
                    break;
                  case "pr_actual":
                    item.PRActual = value;
                    break;
                  case "pr_forecast":
                    item.PRForecast = value;
                    break;
                  case "po_plan":
                    item.POPlan = value;
                    break;
                  case "po_actual":
                    item.POActual = value;
                    break;
                  case "po_forecast":
                    item.POForecast = value;
                    break;
                  case "doc_plan":
                    item.DocPlan = value;
                    break;
                  case "doc_actual":
                    item.DocActual = value;
                    break;
                  case "doc_forecast":
                    item.DocForecast = value;
                    break;
                  case "mfg_plan":
                    item.MfgPlan = value;
                    break;
                  case "mfg_actual":
                    item.MfgActual = value;
                    break;
                  case "mfg_forecast":
                    item.MfgForecast = value;
                    break;
                  case "insp_plan":
                    item.InspPlan = value;
                    break;
                  case "insp_actual":
                    item.InspActual = value;
                    break;
                  case "insp_forecast":
                    item.InspForecast = value;
                    break;
                  case "disp_plan":
                    item.DispPlan = value;
                    break;
                  case "disp_actual":
                    item.DispActual = value;
                    break;
                  case "disp_forecast":
                    item.DispForecast = value;
                    break;
                  case "delivery_plan":
                    item.DeliveryPlan = value;
                    break;
                  case "delivery_actual":
                    item.DeliveryActual = value;
                    break;
                  case "delivery_forecast":
                    item.DeliveryForecast = value;
                    break;
                }
              });

              return item;
            }
          );

          // Check if project already exists
          const existingRecord = procurementData.find(
            (item) =>
              item[`${fieldMappings.Project}Id`] === projectId ||
              (item[fieldMappings.Project] &&
                item[fieldMappings.Project].Id === projectId)
          );

          const itemData: any = {
            __metadata: { type: listEntityTypeName },
            [`${fieldMappings.Project}Id`]: projectId,
            [fieldMappings.ProcurementForecast]:
              JSON.stringify(procurementItems),
          };

          const headers: HeadersInit = {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest,
          };

          let url = apiBase;

          // If editing existing record or project already exists, update it
          if (editingId || existingRecord) {
            const recordId = editingId || existingRecord.Id;
            url = `${apiBase}(${recordId})`;
            headers["IF-MATCH"] = "*";
            headers["X-HTTP-Method"] = "MERGE";
          }

         
          const response = await fetch(url, {
            method: "POST",
            headers: headers,
            body: JSON.stringify(itemData),
          });

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(
              `HTTP error! status: ${response.status}, details: ${errorText}`
            );
          }

          if (editingId || existingRecord) {
            toast(
              `Procurement data updated successfully! ${procurementItems.length} item(s) saved`,
              "success"
            );
          } else {
            toast(
              `Procurement data added successfully! ${procurementItems.length} item(s) saved`,
              "success"
            );
          }

          resetForm();
          await fetchData();
        } catch (error) {
          console.error("Error saving procurement:", error);
          toast("Failed to save procurement data", "error");
        }
      });

      // Reset Form
      const resetForm = (): void => {
        editingId = null;
        form.reset();
        formSection.style.display = "none";
        tableSection.style.display = "block";
        procurementContainer.innerHTML = "";
        procurementContainerTable.style.display = "none";
        projectDetails.innerHTML = "";
        existingDataAlert.style.display = "none";
        formTitle.textContent = "Add Procurement";
        projectSelect.disabled = false;
 
        // Remove view-mode class
        formSection.classList.remove("view-mode");

        // Remove any export/import buttons
        const actionBtns = document.querySelectorAll(
          ".export-project-excel-btn, .export-top-btn, .import-excel-edit-btn"
        );
        actionBtns.forEach((btn) => btn.remove());

        // Show form controls
        const addMoreBtn = document.querySelector(
          ".add-procurement-row"
        ) as HTMLButtonElement;
        if (addMoreBtn) addMoreBtn.style.display = "block";

        const submitBtn = form.querySelector(
          'button[type="submit"]'
        ) as HTMLButtonElement;
        if (submitBtn) {
          submitBtn.style.display = "inline-flex";
        }
      };

      // Export Project to Excel with Two Sheets
      const exportProjectToExcel = async (
        projectId: number,
        record: any
      ): Promise<void> => {
        showExportProgress("Preparing project data for export...");

        try {
          // Re-fetch the current record to ensure we have the latest data
          const currentRecord = procurementData.find((d) => d.Id === record.Id);
          if (!currentRecord) {
            hideExportProgress();
            toast("Record not found", "error");
            return;
          }

          const project = projects.find((p) => p.Id === projectId);
          if (!project) {
            hideExportProgress();
            toast("Project not found", "error");
            return;
          }

          const procurementItems =
            parseProcurementForecast(
              currentRecord[fieldMappings.ProcurementForecast]
            ) || [];

          if (procurementItems.length === 0) {
            hideExportProgress();
            toast("No procurement data to export for this project", "warning");
            return;
          }

          showExportProgress("Processing project details...");

          // SHEET 1: Project Summary
          const projectSummaryData = [
            ["PROJECT SUMMARY", ""],
            ["", ""],
            ["Project Information", ""],
            ["Project Name", project.Title || ""],
            ["Customer", project.CustomerName || ""],
            [
              "Project Manager",
              typeof project.ProjectManager === "object"
                ? project.ProjectManager?.Title || ""
                : project.ProjectManager || "",
            ],
            ["Group Head", project.GroupHead || ""],
            ["Project Reference", project.ProjectReference || ""],
            ["Profit Centre", project.PC || ""],
            ["", ""],
            ["Procurement Summary", ""],
            ["Total Procurement Items", procurementItems.length],
            ["", ""],
            ["Status-wise Breakdown", ""],
          ];

          // Add status counts
          const statusCounts = calculateProjectStatusCounts(procurementItems);
          statusOptions.forEach((status) => {
            projectSummaryData.push([status, statusCounts[status] || 0]);
          });

          // Add empty row and total
          projectSummaryData.push(["", ""]);
          projectSummaryData.push(["TOTAL ITEMS", procurementItems.length]);

          // Create Project Summary worksheet
          const projectSummaryWs = XLSX.utils.aoa_to_sheet(projectSummaryData);

          // Style Project Summary sheet
          const titleStyle = {
            font: { bold: true, color: { rgb: "FFFFFF" }, sz: 14 },
            fill: { patternType: "solid", fgColor: { rgb: "2F5597" } },
            alignment: { horizontal: "center", vertical: "center" },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          const sectionHeaderStyle = {
            font: { bold: true, color: { rgb: "FFFFFF" }, sz: 12 },
            fill: { patternType: "solid", fgColor: { rgb: "4472C4" } },
            alignment: { horizontal: "left", vertical: "center" },
            border: {
              top: { style: "thin", color: { rgb: "000000" } },
              bottom: { style: "thin", color: { rgb: "000000" } },
              left: { style: "thin", color: { rgb: "000000" } },
              right: { style: "thin", color: { rgb: "000000" } },
            },
          };

          const dataStyle = {
            font: { sz: 11 },
            alignment: { horizontal: "left", vertical: "center" },
            border: {
              top: { style: "thin", color: { rgb: "D0D0D0" } },
              bottom: { style: "thin", color: { rgb: "D0D0D0" } },
              left: { style: "thin", color: { rgb: "D0D0D0" } },
              right: { style: "thin", color: { rgb: "D0D0D0" } },
            },
          };

          const totalStyle = {
            font: { bold: true, sz: 11 },
            fill: { patternType: "solid", fgColor: { rgb: "E6F3FF" } },
            alignment: { horizontal: "left", vertical: "center" },
            border: {
              top: { style: "thin", color: { rgb: "000000" } },
              bottom: { style: "thin", color: { rgb: "000000" } },
              left: { style: "thin", color: { rgb: "000000" } },
              right: { style: "thin", color: { rgb: "000000" } },
            },
          };

          // Apply styles to Project Summary sheet
          projectSummaryWs["A1"].s = titleStyle;
          projectSummaryWs["A3"].s = sectionHeaderStyle;
          projectSummaryWs["A11"].s = sectionHeaderStyle;
          projectSummaryWs["A14"].s = sectionHeaderStyle;

          // Apply styles to data rows
          for (let i = 4; i <= 8; i++) {
            const addressA = `A${i}`;
            const addressB = `B${i}`;
            if (projectSummaryWs[addressA])
              projectSummaryWs[addressA].s = dataStyle;
            if (projectSummaryWs[addressB])
              projectSummaryWs[addressB].s = dataStyle;
          }

          // Apply styles to summary data
          for (let i = 12; i <= 12; i++) {
            const addressA = `A${i}`;
            const addressB = `B${i}`;
            if (projectSummaryWs[addressA])
              projectSummaryWs[addressA].s = dataStyle;
            if (projectSummaryWs[addressB])
              projectSummaryWs[addressB].s = dataStyle;
          }

          // Apply styles to status breakdown
          const statusStartRow = 15;
          const statusEndRow = statusStartRow + statusOptions.length - 1;
          for (let i = statusStartRow; i <= statusEndRow; i++) {
            const addressA = `A${i}`;
            const addressB = `B${i}`;
            if (projectSummaryWs[addressA])
              projectSummaryWs[addressA].s = dataStyle;
            if (projectSummaryWs[addressB])
              projectSummaryWs[addressB].s = dataStyle;
          }

          // Apply total style
          const totalRow = statusEndRow + 2;
          const totalAddressA = `A${totalRow}`;
          const totalAddressB = `B${totalRow}`;
          if (projectSummaryWs[totalAddressA])
            projectSummaryWs[totalAddressA].s = totalStyle;
          if (projectSummaryWs[totalAddressB])
            projectSummaryWs[totalAddressB].s = totalStyle;

          // Merge cells for titles
          projectSummaryWs["!merges"] = [
            { s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }, // PROJECT SUMMARY title
            { s: { r: 2, c: 0 }, e: { r: 2, c: 1 } }, // Project Information section
            { s: { r: 10, c: 0 }, e: { r: 10, c: 1 } }, // Procurement Summary section
            { s: { r: 13, c: 0 }, e: { r: 13, c: 1 } }, // Status-wise Breakdown section
          ];

          // Set column widths for Project Summary
          projectSummaryWs["!cols"] = [
            { wch: 30 }, // Column A
            { wch: 35 }, // Column B
          ];

          // SHEET 2: Procurement Details with Two-Line Headers
          showExportProgress("Processing procurement items...");

          // Create two-line header structure
          const headerRow1 = [
            "Sr No",
            "Description Of Item",
            "Quantity",
            "Unit",
            "Make",
            "Model",
            "RFQ / Engg",
            "",
            "",
            "Offer / SCM",
            "",
            "",
            "Technical Clearance / ENGG",
            "",
            "",
            "PR / PM",
            "",
            "",
            "Purchase Order / SCM",
            "",
            "",
            "Manufacturing Clearance / ENGG",
            "",
            "",
            "Status",
            "Remarks",
            "WEIGHTAGE",
          ];

          const headerRow2 = [
            "Sr No",
            "Description Of Item",
            "Quantity",
            "Unit",
            "Make",
            "Model",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Status",
            "Remarks",
            "WEIGHTAGE",
          ];

          // Create worksheet with headers
          const procurementWs = XLSX.utils.aoa_to_sheet([
            headerRow1,
            headerRow2,
          ]);

          // Define styles for Procurement sheet
          const mainHeaderStyle = {
            font: {
              bold: true,
              color: { rgb: "FFFFFF" },
              sz: 11,
            },
            fill: {
              patternType: "solid",
              fgColor: { rgb: "2F5597" }, // Dark blue
            },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          const stageHeaderStyle = {
            font: {
              bold: true,
              color: { rgb: "FFFFFF" },
              sz: 10,
            },
            fill: {
              patternType: "solid",
              fgColor: { rgb: "4472C4" }, // Medium blue
            },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          const subHeaderStyle = {
            font: {
              bold: true,
              color: { rgb: "FFFFFF" },
              sz: 9,
            },
            fill: {
              patternType: "solid",
              fgColor: { rgb: "5B9BD5" }, // Light blue
            },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          const dataCellStyle = {
            font: { sz: 9 },
            border: {
              top: { style: "thin", color: { rgb: "D0D0D0" } },
              bottom: { style: "thin", color: { rgb: "D0D0D0" } },
              left: { style: "thin", color: { rgb: "D0D0D0" } },
              right: { style: "thin", color: { rgb: "D0D0D0" } },
            },
            alignment: {
              horizontal: "left",
              vertical: "center",
            },
          };

          const centeredDataStyle = {
            ...dataCellStyle,
            alignment: {
              horizontal: "center",
              vertical: "center",
            },
          };

          // Apply styles to first header row
          for (let col = 0; col < headerRow1.length; col++) {
            const address = XLSX.utils.encode_cell({ r: 0, c: col });

            if (col >= 6 && col <= 8) {
              // RFQ / Engg stage
              procurementWs[address].s = stageHeaderStyle;
            } else if (col >= 9 && col <= 11) {
              // Offer / SCM stage
              procurementWs[address].s = stageHeaderStyle;
            } else if (col >= 12 && col <= 14) {
              // Technical Clearance / ENGG stage
              procurementWs[address].s = stageHeaderStyle;
            } else if (col >= 15 && col <= 17) {
              // PR / PM stage
              procurementWs[address].s = stageHeaderStyle;
            } else if (col >= 18 && col <= 20) {
              // Purchase Order / SCM stage
              procurementWs[address].s = stageHeaderStyle;
            } else if (col >= 21 && col <= 23) {
              // Manufacturing Clearance / ENGG stage
              procurementWs[address].s = stageHeaderStyle;
            } else {
              // Main columns
              procurementWs[address].s = mainHeaderStyle;
            }
          }

          // Apply styles to second header row
          for (let col = 0; col < headerRow2.length; col++) {
            const address = XLSX.utils.encode_cell({ r: 1, c: col });

            if (col >= 6 && col <= 23) {
              // All stage sub-headers (Plan, Actual, Forecast)
              procurementWs[address].s = subHeaderStyle;
            } else {
              // Main columns
              procurementWs[address].s = mainHeaderStyle;
            }
          }

          // Add data rows starting from row 2
          const dataRows: any[][] = [];

          procurementItems.forEach((procItem, index) => {
            const row = [
              index + 1,
              procItem.Description || "",
              procItem.FCMQuantity || procItem.EnggQuantity || "",
              "", // Unit - you may need to add this field to your data structure
              procItem.Make || "",
              procItem.Model || "",
              // RFQ dates
              formatDateForExcel(procItem.RfqPlan) || "",
              formatDateForExcel(procItem.RfqActual) || "",
              formatDateForExcel(procItem.RfqForecast) || "",
              // Offer dates
              formatDateForExcel(procItem.OfferPlan) || "",
              formatDateForExcel(procItem.OfferActual) || "",
              formatDateForExcel(procItem.OfferForecast) || "",
              // Tech dates
              formatDateForExcel(procItem.TechPlan) || "",
              formatDateForExcel(procItem.TechActual) || "",
              formatDateForExcel(procItem.TechForecast) || "",
              // PR dates
              formatDateForExcel(procItem.PRPlan) || "",
              formatDateForExcel(procItem.PRActual) || "",
              formatDateForExcel(procItem.PRForecast) || "",
              // PO dates
              formatDateForExcel(procItem.POPlan) || "",
              formatDateForExcel(procItem.POActual) || "",
              formatDateForExcel(procItem.POForecast) || "",
              // Mfg dates
              formatDateForExcel(procItem.MfgPlan) || "",
              formatDateForExcel(procItem.MfgActual) || "",
              formatDateForExcel(procItem.MfgForecast) || "",
              procItem.Status || "",
              procItem.Remarks || "",
              "", // WEIGHTAGE - you may need to add this field to your data structure
            ];
            dataRows.push(row);
          });

          // Add data to worksheet
          XLSX.utils.sheet_add_aoa(procurementWs, dataRows, { origin: "A3" });

          // Apply basic styling to data rows
          const dataRange = XLSX.utils.decode_range(
            procurementWs["!ref"] || "A1"
          );
          for (let R = 2; R <= dataRange.e.r; ++R) {
            for (let C = dataRange.s.c; C <= dataRange.e.c; ++C) {
              const address = XLSX.utils.encode_cell({ r: R, c: C });
              if (!procurementWs[address]) continue;

              // Add basic styling to data cells
              if (!procurementWs[address].s) {
                // Center align numeric and date columns
                if (C === 0 || C === 2 || (C >= 6 && C <= 23)) {
                  procurementWs[address].s = centeredDataStyle;
                } else {
                  procurementWs[address].s = dataCellStyle;
                }
              }
            }
          }

          // Set column widths for Procurement sheet
          procurementWs["!cols"] = [
            { wch: 6 }, // Sr No
            { wch: 30 }, // Description Of Item
            { wch: 10 }, // Quantity
            { wch: 8 }, // Unit
            { wch: 15 }, // Make
            { wch: 15 }, // Model
            // RFQ
            { wch: 8 },
            { wch: 8 },
            { wch: 8 },
            // Offer
            { wch: 8 },
            { wch: 8 },
            { wch: 8 },
            // Tech
            { wch: 8 },
            { wch: 8 },
            { wch: 8 },
            // PR
            { wch: 8 },
            { wch: 8 },
            { wch: 8 },
            // PO
            { wch: 8 },
            { wch: 8 },
            { wch: 8 },
            // Mfg
            { wch: 8 },
            { wch: 8 },
            { wch: 8 },
            { wch: 15 }, // Status
            { wch: 20 }, // Remarks
            { wch: 10 }, // WEIGHTAGE
          ];

          // Set row heights for Procurement sheet
          procurementWs["!rows"] = [
            { hpt: 25 }, // First header row
            { hpt: 20 }, // Second header row
            ...Array(dataRange.e.r - 1).fill({ hpt: 18 }), // Data rows
          ];

          // Merge cells for stage headers in first row
          procurementWs["!merges"] = [
            // Merge main headers (rowspan=2)
            { s: { r: 0, c: 0 }, e: { r: 1, c: 0 } }, // Sr No
            { s: { r: 0, c: 1 }, e: { r: 1, c: 1 } }, // Description Of Item
            { s: { r: 0, c: 2 }, e: { r: 1, c: 2 } }, // Quantity
            { s: { r: 0, c: 3 }, e: { r: 1, c: 3 } }, // Unit
            { s: { r: 0, c: 4 }, e: { r: 1, c: 4 } }, // Make
            { s: { r: 0, c: 5 }, e: { r: 1, c: 5 } }, // Model
            { s: { r: 0, c: 24 }, e: { r: 1, c: 24 } }, // Status
            { s: { r: 0, c: 25 }, e: { r: 1, c: 25 } }, // Remarks
            { s: { r: 0, c: 26 }, e: { r: 1, c: 26 } }, // WEIGHTAGE

            // Merge stage headers (colspan=3)
            { s: { r: 0, c: 6 }, e: { r: 0, c: 8 } }, // RFQ / Engg
            { s: { r: 0, c: 9 }, e: { r: 0, c: 11 } }, // Offer / SCM
            { s: { r: 0, c: 12 }, e: { r: 0, c: 14 } }, // Technical Clearance / ENGG
            { s: { r: 0, c: 15 }, e: { r: 0, c: 17 } }, // PR / PM
            { s: { r: 0, c: 18 }, e: { r: 0, c: 20 } }, // Purchase Order / SCM
            { s: { r: 0, c: 21 }, e: { r: 0, c: 23 } }, // Manufacturing Clearance / ENGG
          ];

          // Create workbook with both sheets
          showExportProgress("Creating Excel file with two sheets...");

          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, projectSummaryWs, "Cover Sheet");
          XLSX.utils.book_append_sheet(
            wb,
            procurementWs,
            "BOM Standard Format"
          );

          // Generate and save the Excel file
          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const data = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });

          const timestamp = new Date().toISOString().split("T")[0];
          const fileName = `Procurement_${project.Title.replace(
            /[^a-zA-Z0-9]/g,
            "_"
          )}_${timestamp}.xlsx`;

          saveAs(data, fileName);

          hideExportProgress();
          toast(
            `Excel file exported successfully! 2 sheets with ${procurementItems.length} procurement items`,
            "success"
          );
        } catch (error) {
          hideExportProgress();
          console.error("Project export error:", error);
          toast("Failed to export project Excel file", "error");
        }
      };

      // Enhanced Export to Excel Function with Project-wise Merged Cells
      const exportToExcel = async (): Promise<void> => {
        showExportProgress("Preparing data for export...");

        try {
          // Get filtered data based on current filters
          const project = filterProject.value;
          const customer = filterCustomer.value;
          const projectManager = filterProjectManager.value;
          const groupHead = filterGroupHead.value;
          const projectReference = filterProjectReference.value;
          const status = filterStatus.value;
          const make = filterMake.value;

          const filteredData = procurementData.filter((item) => {
            const projectTitle = item[fieldMappings.Project]?.Title || "";
            const projectData = projects.find((p) => p.Title === projectTitle);
            const procurementItems =
              parseProcurementForecast(
                item[fieldMappings.ProcurementForecast]
              ) || [];

            if (project && projectTitle !== project) return false;
            if (customer && projectData?.CustomerName !== customer)
              return false;
            if (projectManager) {
              const managerName =
                typeof projectData?.ProjectManager === "object"
                  ? projectData.ProjectManager?.Title
                  : projectData?.ProjectManager;
              if (managerName !== projectManager) return false;
            }
            if (groupHead && projectData?.GroupHead !== groupHead) return false;
            if (
              projectReference &&
              projectData?.ProjectReference !== projectReference
            )
              return false;

            if (
              status &&
              !procurementItems.some((item) => item.Status === status)
            )
              return false;

            if (make && !procurementItems.some((item) => item.Make === make))
              return false;

            return true;
          });

          if (filteredData.length === 0) {
            hideExportProgress();
            toast("No data to export", "warning");
            return;
          }

          showExportProgress("Processing procurement details...");

          // Create two-line header structure with project details
          const headerRow1 = [
            "Project Information",
            "",
            "",
            "",
            "",
            "Procurement Item Details",
            "",
            "",
            "",
            "",
            "RFQ /Engg",
            "",
            "",
            "Vendor Offer/SCM",
            "",
            "",
            "Technical Clearence/ENGG",
            "",
            "",
            "Order Finalization/SCM",
            "",
            "",
            "PR/PM",
            "",
            "",
            "Purchase Order/SCM",
            "",
            "",
            "Document Approval /ENGG",
            "",
            "",
            "Manufacturing clearence/Engg",
            "",
            "",
            "Inspection",
            "",
            "",
            "Material Dispatch",
            "",
            "",
            "Delivery at site",
            "",
            "",
            "Remarks",
          ];

          const headerRow2 = [
            "Project Name",
            "Customer",
            "Project Manager",
            "Group Head",
            "Project Reference",
            "Description",
            "FCM Quantity",
            "Engg Quantity",
            "Vendor name",
            "Status",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Plan",
            "Actual",
            "Forecast",
            "Remarks",
          ];

          const ws = XLSX.utils.aoa_to_sheet([headerRow1, headerRow2]);

          // Prepare data with project grouping information
          const dataRows: any[][] = [];
          let itemIndex = 1;
          const projectMerges: any[] = [];
          let currentRow = 2; // Start from row 3 (0-indexed row 2)

          // Group data by project
          const projectGroups = new Map();

          filteredData.forEach((item) => {
            const projectTitle = item[fieldMappings.Project]?.Title || "";
            const projectData = projects.find((p) => p.Title === projectTitle);
            const procurementItems =
              parseProcurementForecast(
                item[fieldMappings.ProcurementForecast]
              ) || [];

            if (!projectGroups.has(projectTitle)) {
              projectGroups.set(projectTitle, {
                projectData: projectData,
                items: [],
              });
            }

            procurementItems.forEach((procItem) => {
              projectGroups.get(projectTitle).items.push({
                ...procItem,
                itemIndex: itemIndex++,
              });
            });
          });

          // Build data rows with project grouping
          projectGroups.forEach((projectGroup, projectTitle) => {
            const { projectData, items } = projectGroup;
            const startRow = currentRow;

            items.forEach(
              (
                procItem: ProcurementForecastItem & { itemIndex: number },
                itemIndexInGroup: number
              ) => {
                const row = [
                  // Project Information (will be merged, so only fill first row)
                  itemIndexInGroup === 0 ? projectData?.Title || "" : "",
                  itemIndexInGroup === 0 ? projectData?.CustomerName || "" : "",
                  itemIndexInGroup === 0
                    ? typeof projectData?.ProjectManager === "object"
                      ? projectData?.ProjectManager?.Title || ""
                      : projectData?.ProjectManager || ""
                    : "",
                  itemIndexInGroup === 0 ? projectData?.GroupHead || "" : "",
                  itemIndexInGroup === 0
                    ? projectData?.ProjectReference || ""
                    : "",
                  // Item Information
                  // procItem.itemIndex,
                  procItem.Description || "",
                  procItem.FCMQuantity || "",
                  procItem.EnggQuantity || "",
                  procItem.Make || "",
                  procItem.Status || "",
                  // RFQ / Engg
                  formatDateForExcel(procItem.RfqPlan) || "",
                  formatDateForExcel(procItem.RfqActual) || "",
                  formatDateForExcel(procItem.RfqForecast) || "",
                  // Vendor Offer/SCM
                  formatDateForExcel(procItem.OfferPlan) || "",
                  formatDateForExcel(procItem.OfferActual) || "",
                  formatDateForExcel(procItem.OfferForecast) || "",
                  // Technical Clearence/ENGG
                  formatDateForExcel(procItem.TechPlan) || "",
                  formatDateForExcel(procItem.TechActual) || "",
                  formatDateForExcel(procItem.TechForecast) || "",
                  // Order Finalization/SCM
                  formatDateForExcel(procItem.OrderPlan) || "",
                  formatDateForExcel(procItem.OrderActual) || "",
                  formatDateForExcel(procItem.OrderForecast) || "",
                  // PR/PM
                  formatDateForExcel(procItem.PRPlan) || "",
                  formatDateForExcel(procItem.PRActual) || "",
                  formatDateForExcel(procItem.PRForecast) || "",
                  // Purchase Order/SCM
                  formatDateForExcel(procItem.POPlan) || "",
                  formatDateForExcel(procItem.POActual) || "",
                  formatDateForExcel(procItem.POForecast) || "",
                  // Document Approval /ENGG
                  formatDateForExcel(procItem.DocPlan) || "",
                  formatDateForExcel(procItem.DocActual) || "",
                  formatDateForExcel(procItem.DocForecast) || "",
                  // Manufacturing clearence/Engg
                  formatDateForExcel(procItem.MfgPlan) || "",
                  formatDateForExcel(procItem.MfgActual) || "",
                  formatDateForExcel(procItem.MfgForecast) || "",
                  // Inspection
                  formatDateForExcel(procItem.InspPlan) || "",
                  formatDateForExcel(procItem.InspActual) || "",
                  formatDateForExcel(procItem.InspForecast) || "",
                  // Material Dispatch
                  formatDateForExcel(procItem.DispPlan) || "",
                  formatDateForExcel(procItem.DispActual) || "",
                  formatDateForExcel(procItem.DispForecast) || "",
                  // Delivery at site
                  formatDateForExcel(procItem.DeliveryPlan) || "",
                  formatDateForExcel(procItem.DeliveryActual) || "",
                  formatDateForExcel(procItem.DeliveryForecast) || "",
                  procItem.Remarks || "",
                ];
                dataRows.push(row);
                currentRow++;
              }
            );

            // Add merge ranges for this project (columns A to E)
            if (items.length > 1) {
              for (let col = 0; col < 5; col++) {
                projectMerges.push({
                  s: { r: startRow, c: col },
                  e: { r: currentRow - 1, c: col },
                });
              }
            }
          });

          // Add data to worksheet starting from row 3
          XLSX.utils.sheet_add_aoa(ws, dataRows, { origin: "A3" });

          // Define styles
          const mainHeaderStyle = {
            font: { bold: true, color: { rgb: "FFFFFF" }, sz: 11 },
            fill: { patternType: "solid", fgColor: { rgb: "2F5597" } },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          const sectionHeaderStyle = {
            font: { bold: true, color: { rgb: "FFFFFF" }, sz: 12 },
            fill: { patternType: "solid", fgColor: { rgb: "4472C4" } },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          const subHeaderStyle = {
            font: { bold: true, color: { rgb: "FFFFFF" }, sz: 9 },
            fill: { patternType: "solid", fgColor: { rgb: "5B9BD5" } },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          const mergedCellStyle = {
            font: { sz: 9 },
            fill: { patternType: "solid", fgColor: { rgb: "F2F2F2" } },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "thin", color: { rgb: "D0D0D0" } },
              bottom: { style: "thin", color: { rgb: "D0D0D0" } },
              left: { style: "thin", color: { rgb: "D0D0D0" } },
              right: { style: "thin", color: { rgb: "D0D0D0" } },
            },
          };

          const dataCellStyle = {
            font: { sz: 9 },
            border: {
              top: { style: "thin", color: { rgb: "D0D0D0" } },
              bottom: { style: "thin", color: { rgb: "D0D0D0" } },
              left: { style: "thin", color: { rgb: "D0D0D0" } },
              right: { style: "thin", color: { rgb: "D0D0D0" } },
            },
            alignment: {
              horizontal: "left",
              vertical: "center",
            },
          };

          const centeredDataStyle = {
            ...dataCellStyle,
            alignment: {
              horizontal: "center",
              vertical: "center",
            },
          };

          // Apply styles to first header row
          for (let col = 0; col < headerRow1.length; col++) {
            const address = XLSX.utils.encode_cell({ r: 0, c: col });

            if (col < 5) {
              // Project Information section
              ws[address].s = sectionHeaderStyle;
            } else if (col === 5) {
              // Procurement Item Details section
              ws[address].s = sectionHeaderStyle;
            } else if (col >= 11 && col <= 43) {
              // Process stage columns
              ws[address].s = sectionHeaderStyle;
            } else if (col === 44) {
              // Remarks section
              ws[address].s = sectionHeaderStyle;
            }
          }

          // Apply styles to second header row
          for (let col = 0; col < headerRow2.length; col++) {
            const address = XLSX.utils.encode_cell({ r: 1, c: col });

            if (col < 5) {
              // Project information columns
              ws[address].s = mainHeaderStyle;
            } else if (col >= 5 && col <= 10) {
              // Item information columns
              ws[address].s = mainHeaderStyle;
            } else if (col >= 11 && col <= 43) {
              // Process stage sub-headers
              ws[address].s = subHeaderStyle;
            } else if (col === 44) {
              // Remarks column
              ws[address].s = mainHeaderStyle;
            }
          }

          // Apply styling to data rows and handle merged cells
          const dataRange = XLSX.utils.decode_range(ws["!ref"] || "A1");

          // First, apply basic styling to all data cells
          for (let R = 2; R <= dataRange.e.r; ++R) {
            for (let C = dataRange.s.c; C <= dataRange.e.c; ++C) {
              const address = XLSX.utils.encode_cell({ r: R, c: C });
              if (!ws[address]) continue;

              if (!ws[address].s) {
                // Default to data cell style
                ws[address].s = { ...dataCellStyle };
              }

              // Center align numeric, date, and index columns by merging centeredDataStyle
              if (C === 5 || C === 7 || C === 8 || (C >= 11 && C <= 43)) {
                ws[address].s = { ...ws[address].s, ...centeredDataStyle };
              }
            }
          }

          // Now apply merged cell styling to project information columns (A-E)
          // We need to find which cells are the first in their merge groups
          const mergedFirstCells = new Set();
          projectMerges.forEach((merge) => {
            const startAddress = XLSX.utils.encode_cell(merge.s);
            mergedFirstCells.add(startAddress);

            // Apply merged cell style to the first cell
            if (ws[startAddress]) {
              ws[startAddress].s = { ...mergedCellStyle };
            }
          });

          // Set column widths
          ws["!cols"] = [
            // Project Information
            { wch: 25 }, // Project Name
            { wch: 20 }, // Customer
            { wch: 20 }, // Project Manager
            { wch: 15 }, // Group Head
            { wch: 15 }, // Project Reference
            // Item Information
            { wch: 30 }, // Description
            { wch: 12 }, // FCM Quantity
            { wch: 12 }, // Engg Quantity
            { wch: 15 }, // Vendor name
            { wch: 15 }, // Status
            // Process stages (3 columns each)
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // RFQ
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Offer
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Tech
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Order
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // PR
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // PO
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Doc
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Mfg
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Insp
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Dispatch
            { wch: 10 },
            { wch: 10 },
            { wch: 10 }, // Delivery
            { wch: 20 }, // Remarks
          ];

          // Set row heights
          ws["!rows"] = [
            { hpt: 25 }, // First header row
            { hpt: 20 }, // Second header row
            ...Array(dataRange.e.r - 1).fill({ hpt: 18 }), // Data rows
          ];

          // Merge cells for section headers in first row
          const headerMerges = [
            // Project Information section (colspan=5)
            { s: { r: 0, c: 0 }, e: { r: 0, c: 4 } },
            // Procurement Item Details section (colspan=6)
            { s: { r: 0, c: 5 }, e: { r: 0, c: 10 } },
            // RFQ /Engg (colspan=3)
            { s: { r: 0, c: 11 }, e: { r: 0, c: 13 } },
            // Vendor Offer/SCM (colspan=3)
            { s: { r: 0, c: 14 }, e: { r: 0, c: 16 } },
            // Technical Clearence/ENGG (colspan=3)
            { s: { r: 0, c: 17 }, e: { r: 0, c: 19 } },
            // Order Finalization/SCM (colspan=3)
            { s: { r: 0, c: 20 }, e: { r: 0, c: 22 } },
            // PR/PM (colspan=3)
            { s: { r: 0, c: 23 }, e: { r: 0, c: 25 } },
            // Purchase Order/SCM (colspan=3)
            { s: { r: 0, c: 26 }, e: { r: 0, c: 28 } },
            // Document Approval /ENGG (colspan=3)
            { s: { r: 0, c: 29 }, e: { r: 0, c: 31 } },
            // Manufacturing clearence/Engg (colspan=3)
            { s: { r: 0, c: 32 }, e: { r: 0, c: 34 } },
            // Inspection (colspan=3)
            { s: { r: 0, c: 35 }, e: { r: 0, c: 37 } },
            // Material Dispatch (colspan=3)
            { s: { r: 0, c: 38 }, e: { r: 0, c: 40 } },
            // Delivery at site (colspan=3)
            { s: { r: 0, c: 41 }, e: { r: 0, c: 43 } },
            // Remarks section
            { s: { r: 0, c: 44 }, e: { r: 0, c: 44 } },

            // Merge main headers (rowspan=2) for second row
            { s: { r: 0, c: 0 }, e: { r: 1, c: 0 } }, // Project Name
            { s: { r: 0, c: 1 }, e: { r: 1, c: 1 } }, // Customer
            { s: { r: 0, c: 2 }, e: { r: 1, c: 2 } }, // Project Manager
            { s: { r: 0, c: 3 }, e: { r: 1, c: 3 } }, // Group Head
            { s: { r: 0, c: 4 }, e: { r: 1, c: 4 } }, // Project Reference
            { s: { r: 0, c: 6 }, e: { r: 1, c: 6 } }, // Description
            { s: { r: 0, c: 7 }, e: { r: 1, c: 7 } }, // FCM Quantity
            { s: { r: 0, c: 8 }, e: { r: 1, c: 8 } }, // Engg Quantity
            { s: { r: 0, c: 9 }, e: { r: 1, c: 9 } }, // Vendor name
            { s: { r: 0, c: 10 }, e: { r: 1, c: 10 } }, // Status
            { s: { r: 0, c: 44 }, e: { r: 1, c: 44 } }, // Remarks
          ];

          // Combine header merges with project-wise merges
          ws["!merges"] = [...headerMerges, ...projectMerges];

          // Create workbook with single sheet
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "Procurement Details");

          // Generate and save the Excel file
          showExportProgress("Generating Excel file...");

          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const data = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });

          const timestamp = new Date().toISOString().split("T")[0];
          const filterInfo = [
            project ? `Project-${project}` : "",
            customer ? `Customer-${customer}` : "",
            status ? `Status-${status}` : "",
            make ? `Make-${make}` : "",
          ]
            .filter(Boolean)
            .join("_");

          const fileName = filterInfo
            ? `Procurement_Report_${filterInfo}_${timestamp}.xlsx`
            : `Procurement_Report_${timestamp}.xlsx`;

          saveAs(data, fileName);

          hideExportProgress();

          // Calculate summary for toast message
          let totalProcurementItems = 0;
          projectGroups.forEach((projectGroup) => {
            totalProcurementItems += projectGroup.items.length;
          });

          toast(
            `Excel report exported successfully! ${projectGroups.size} projects, ${totalProcurementItems} items`,
            "success"
          );
        } catch (error) {
          hideExportProgress();
          console.error("Export error:", error);
          toast("Failed to export Excel report", "error");
        }
      };

      // Event Listeners
      showFormBtn.addEventListener("click", () => {
        resetForm();
        formSection.style.display = "block";
        tableSection.style.display = "none";
      });

      backBtn.addEventListener("click", resetForm);

      projectSelect.addEventListener("change", (e) => {
        const selectedId = parseInt((e.target as HTMLSelectElement).value);
        if (selectedId) {
          onProjectChange(selectedId);
        } else {
          procurementContainerTable.style.display = "none";
          projectDetails.innerHTML = "";
          existingDataAlert.style.display = "none";
          formTitle.textContent = "Add Procurement";
        }
      });

      // Add row button
      document
        .querySelector(".add-procurement-row")
        ?.addEventListener("click", () => {
          procurementContainer.appendChild(createProcurementRow());
        });

      // Remove row event delegation
      procurementContainer.addEventListener("click", (e) => {
        const target = e.target as HTMLElement;
        if (target.classList.contains("remove-row")) {
          const row = target.closest("tr");
          if (row && procurementContainer.children.length > 1) {
            row.remove();
          } else {
            toast("At least one row is required", "warning");
          }
        }
      });

      // Filter events
      filterProject.addEventListener("change", filterData);
      filterCustomer.addEventListener("change", filterData);
      filterProjectManager.addEventListener("change", filterData);
      filterGroupHead.addEventListener("change", filterData);
      filterProjectReference.addEventListener("change", filterData);
      filterStatus.addEventListener("change", filterData);
      filterMake.addEventListener("change", filterData);
      clearFiltersBtn.addEventListener("click", clearFilters);

      // Export button
      exportExcelBtn.addEventListener("click", exportToExcel);

      // Initialize app
      await initApp();
    }, 100);
  },
};
