import Swal from 'sweetalert2';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import "../styles/common.css";

declare const _spPageContextInfo: any;

const projectContent = `
<div class="project-page fade-in">
  <section class="table-section card">
  <div class="page-header">
    <h1> Project Management</h1>
    <div>
      <button class="btn-primary show-form-btn">+ Add New Project</button>
      <button class="btn-primary export-btn">Export Excel</button>
      <button class="btn-primary import-btn">Import Excel</button>
      <input type="file" class="excel-input" accept=".xlsx,.xls" style="display:none;" />
    </div>
  </div>
    <div class="table-actions">
  <input type="text" class="search-input" placeholder="Search Projects" />
  <button class="btn-secondary reset-search-btn">Reset Filter</button>
</div>
    <div style="overflow-x:auto;">
      <table class="modern-table">
        <thead>
          <tr>
          <th>Project Name</th>
            <th>PC</th>
            <th>Project Reference</th>
            <th>Customer Name</th>            
            <th>Group Head</th>
            <th>Project Manager</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="project-table-body"></tbody>
      </table>
    </div>
    <div class="pagination"></div>
  </section>

  <section class="form-section card" style="display:none;">
    <div class="form-header"><h2>➕ Add New Project</h2></div>
    <form id="projectForm">
      <div class="form-row">
      <div class="form-group"><label>Project Name</label><input type="text" id="name" required /></div>
        <div class="form-group"><label>PC</label><input type="text" id="pc" required /></div>
        
      </div>
      <div class="form-row">
      <div class="form-group"><label>Project Reference</label><input type="text" id="reference" required /></div>
        <div class="form-group"><label>Customer Name</label><input type="text" id="customer" required /></div>
        
      </div>
      <div class="form-row">
        <div class="form-group"><label>Group Head</label><input type="text" id="head" required /></div>
        <div class="form-group">
          <label>Project Manager</label>
          <div class="manager-lookup-container">
            <div class="manager-lookup">
              <input type="text" id="managerSearch" placeholder="Search for manager..." />
              <button type="button" class="search-manager-btn">Search</button>
            </div>
            <div id="managerSuggestions" class="manager-suggestions" style="display:none;"></div>
            <div id="selectedManagerDisplay" class="selected-manager" style="display:none;">
              <span id="selectedManagerName"></span>
              <button type="button" class="remove-manager" id="removeManager">×</button>
            </div>
            <input type="hidden" id="managerId" />
          </div>
        </div>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn-primary">Save Project</button>
        <button type="button" class="btn-secondary back-to-table">Back to List</button>
      </div>
    </form>
  </section>
</div>
`;

export default {
  content: projectContent,
  style: `
.project-page { font-family:'Segoe UI', Arial,sans-serif; color:#333; animation:fadeIn 0.4s ease-in; }

.card { background:#fff; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.08); padding:10px; margin-bottom:20px; transition:all 0.3s ease; }
.modern-table { width:100%; border-collapse:collapse; font-size:14px; }
.modern-table th { background:#f3f2f1; text-align:left; padding:12px; font-weight:600; border-bottom:2px solid #e1e1e1; }
.modern-table td { padding:10px; border-bottom:1px solid #eee; }
.modern-table tr:hover { background:#fafafa; }
.form-row { display:flex; flex-wrap:wrap; gap:20px; margin-bottom:20px; }
.form-group { flex:1 1 calc(50% - 10px); display:flex; flex-direction:column; }
.form-group label { font-weight:500; color:#444; margin-bottom:6px; }
.form-group input, .form-group select { width:100%; padding:10px 12px; border-radius:6px; border:1px solid #ccc; font-size:14px; line-height:1.4; box-sizing:border-box; transition:all 0.2s ease; }
.form-group input:focus, .form-group select:focus { border-color:#0078d4; box-shadow:0 0 3px rgba(0,120,212,0.4); outline:none; }
.form-actions { text-align:center; margin-top:25px; }
 
.btn-primary:hover { background:#005a9e; }
.btn-secondary { background:#e1e1e1; color:#333; margin-left:10px; }
.btn-secondary:hover { background:#ccc; }
.form-header h2 { color:#0078d4; margin-bottom:20px; font-size:18px; font-weight:600; }
.table-actions { display:flex; justify-content:space-between; margin-bottom:10px; flex-wrap:wrap; gap:10px; }
.search-input { padding:8px 12px; border:1px solid #ccc; border-radius:6px; flex:1; min-width:180px; }
.pagination { margin-top:15px; display:flex; gap:5px; flex-wrap:wrap; justify-content:end; }
.pagination button { padding:6px 12px; border:none; background:#e1e1e1; border-radius:4px; cursor:pointer; }
.pagination button.active { background:#0078d4; color:#fff; }
.toast { position: fixed; bottom: 20px; right: 20px; padding: 12px 20px; color: #fff; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.2); opacity: 0; transition: opacity 0.3s; z-index: 10000; }
.toast.success { background: #28a745; }
.toast.error { background: #dc3545; }
.actions-cell { display: flex; gap: 5px; }
.edit-btn, .delete-btn { width: 28px; height: 28px; border: none; border-radius: 4px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; padding: 0; transition: all 0.2s ease; }
.edit-btn { background-color: #ff9800; color: #fff; }
.delete-btn { background-color: #dc3545; color: #fff; }
.edit-btn:hover { background-color: #e68900; }
.delete-btn:hover { background-color: #c82333; }

/* Manager lookup styles */
.manager-lookup { display: flex; gap: 10px; margin-bottom: 5px; }
.manager-lookup input { flex: 1; padding: 10px 12px; border: 1px solid #ccc; border-radius: 6px; font-size: 14px; }
.manager-lookup input:focus { border-color: #0078d4; outline: none; box-shadow: 0 0 3px rgba(0,120,212,0.4); }
.manager-lookup button { background: #0078d4; color: white; border: none; border-radius: 4px; padding: 10px 15px; cursor: pointer; font-size: 14px; font-weight: 500; white-space: nowrap; }
.manager-lookup button:hover { background: #005a9e; }
.manager-suggestions { position: absolute; background: white; border: 1px solid #ddd; border-radius: 4px; max-height: 200px; overflow-y: auto; z-index: 1000; width: 100%; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-top: 2px; }
.manager-suggestion-item { padding: 10px; cursor: pointer; border-bottom: 1px solid #eee; }
.manager-suggestion-item:hover { background: #f3f2f1; }
.manager-suggestion-item.selected { background: #e1f5fe; }
.selected-manager { display: flex; align-items: center; justify-content: space-between; background: #f3f2f1; padding: 8px 12px; border-radius: 4px; margin-top: 5px; border: 1px solid #e1e1e1; }
.selected-manager span { font-weight: 500; }
.remove-manager { background: none; border: none; color: #d13438; cursor: pointer; font-size: 18px; padding: 0 5px; line-height: 1; }
.remove-manager:hover { color: #a4262c; }

@media (max-width:768px){
  .form-group { flex:1 1 100%; }
  .btn-primary,.btn-secondary { width:100%; justify-content:center; margin-top:10px; }
  .manager-lookup { flex-direction: column; }
  .manager-lookup button { width: 100%; }
}
`,
script: () => {
  setTimeout(() => {
    const listName = "Project List";

    const tableBody = document.querySelector('.project-table-body') as HTMLElement;
    const showFormBtn = document.querySelector('.show-form-btn') as HTMLElement;
    const formSection = document.querySelector('.form-section') as HTMLElement;
    const tableSection = document.querySelector('.table-section') as HTMLElement;
    const form = document.querySelector('#projectForm') as HTMLFormElement;
    const backBtn = document.querySelector('.back-to-table') as HTMLElement;
    const submitBtn = form.querySelector('button[type="submit"]') as HTMLButtonElement;
    const exportBtn = document.querySelector('.export-btn') as HTMLElement;
    const importBtn = document.querySelector('.import-btn') as HTMLElement;
    const excelInput = document.querySelector('.excel-input') as HTMLInputElement;
    const searchInput = document.querySelector('.search-input') as HTMLInputElement;
    const formHeader = document.querySelector('.form-header h2') as HTMLElement;
    const paginationDiv = document.querySelector('.pagination') as HTMLElement;

    // Manager lookup elements
    const managerSearchInput = document.querySelector('#managerSearch') as HTMLInputElement;
    const searchManagerBtn = document.querySelector('.search-manager-btn') as HTMLButtonElement;
    const managerSuggestionsDiv = document.querySelector('#managerSuggestions') as HTMLElement;
    const selectedManagerDisplayDiv = document.querySelector('#selectedManagerDisplay') as HTMLElement;
    const selectedManagerNameSpan = document.querySelector('#selectedManagerName') as HTMLSpanElement;
    const removeManagerBtn = document.querySelector('#removeManager') as HTMLButtonElement;
    const managerIdInput = document.querySelector('#managerId') as HTMLInputElement;

    let currentPage = 1;
    const pageSize = 10;

    const siteUrl = typeof _spPageContextInfo !== "undefined"
      ? _spPageContextInfo.webAbsoluteUrl
      : window.location.origin + "/sites/Kriya";

    const apiBase = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;
    let projectData: any[] = [];
    let editingId: number | null = null;

    const toast = (msg: string, type: 'success' | 'error' = 'success') => {
      const toastEl = document.createElement("div");
      toastEl.className = `toast ${type}`;
      toastEl.textContent = msg;
      document.body.appendChild(toastEl);
      requestAnimationFrame(() => toastEl.style.opacity = "1");
      setTimeout(() => { toastEl.style.opacity = "0"; setTimeout(() => toastEl.remove(), 500); }, 2500);
    };

    const resetSearchBtn = document.querySelector('.reset-search-btn') as HTMLButtonElement;

resetSearchBtn.addEventListener('click', () => {
  searchInput.value = '';
  currentPage = 1;
  renderTable(projectData);
});

    const getDigest = async () => {
      if (typeof _spPageContextInfo !== "undefined") return _spPageContextInfo.formDigestValue;
      const res = await fetch(`${siteUrl}/_api/contextinfo`, { 
        method: "POST", 
        headers: { 
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose"
        } 
      });
      const data = await res.json();
      return data.d.GetContextWebInformation.FormDigestValue;
    };

    // Search managers in SharePoint - FIXED: Use correct filter syntax
    const searchManagers = async (searchTerm: string = '') => {
      try {
        let url = `${siteUrl}/_api/web/siteusers?$filter=PrincipalType eq 1`;
        
        if (searchTerm) {
          // Correct SharePoint filter syntax
          url += ` and (substringof('${searchTerm}', Title) eq true or substringof('${searchTerm}', Email) eq true)`;
        }
        
        url += `&$top=20&$orderby=Title`;
        
        const res = await fetch(url, {
          headers: { 
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/json;odata=verbose'
          }
        });
        
        if (!res.ok) {
          const errorText = await res.text();
          console.error("Search managers error:", errorText);
          throw new Error(`HTTP error! status: ${res.status}`);
        }
        
        const data = await res.json();
        const users = data.d.results || [];
        
        return users
          .filter((user: any) => {
            const title = user.Title || '';
            return !title.includes('System Account') && 
                   !title.includes('App@sharepoint') &&
                   !title.includes('SharingLinks') &&
                   !title.includes('NT AUTHORITY') &&
                   !title.includes('Membership');
          })
          .map((user: any) => ({
            id: user.Id,
            title: user.Title || '',
            email: user.Email || ''
          }))
          .sort((a: any, b: any) => a.title.localeCompare(b.title));
      } catch (error) {
        console.error("Error searching managers:", error);
        toast("Failed to search managers. Please try again.", "error");
        return [];
      }
    };

    // Display manager suggestions
    const displayManagerSuggestions = (managers: any[]) => {
      managerSuggestionsDiv.innerHTML = '';
      if (managers.length === 0) {
        const noResults = document.createElement('div');
        noResults.className = 'manager-suggestion-item';
        noResults.textContent = 'No managers found';
        managerSuggestionsDiv.appendChild(noResults);
      } else {
        managers.forEach(manager => {
          const suggestion = document.createElement('div');
          suggestion.className = 'manager-suggestion-item';
          suggestion.innerHTML = `
            <strong>${manager.title}</strong>
            ${manager.email ? `<br><small>${manager.email}</small>` : ''}
          `;
          suggestion.dataset.id = manager.id.toString();
          suggestion.addEventListener('click', () => {
            selectManager(manager);
          });
          managerSuggestionsDiv.appendChild(suggestion);
        });
      }
      managerSuggestionsDiv.style.display = 'block';
    };

    // Select a manager
    const selectManager = (manager: any) => {
      selectedManagerNameSpan.textContent = `${manager.title}${manager.email ? ` (${manager.email})` : ''}`;
      selectedManagerDisplayDiv.style.display = 'flex';
      managerIdInput.value = manager.id.toString();
      managerSuggestionsDiv.style.display = 'none';
      managerSearchInput.value = '';
    };

    // Clear selected manager
    const clearSelectedManager = () => {
      selectedManagerDisplayDiv.style.display = 'none';
      managerIdInput.value = '';
      managerSearchInput.value = '';
    };

const getManagerDisplayName = (project: any) => {
  // Try expanded field first
  if (project.ProjectManager && project.ProjectManager.Title) {
    return project.ProjectManager.Title + (project.ProjectManager.Email ? ` (${project.ProjectManager.Email})` : '');
  }
  // Check for manager ID
  if (project.ProjectManagerId) {
    return `User ID: ${project.ProjectManagerId}`;
  }
  return "";
};

    // Fetch projects - IMPROVED: Better error handling and logging
 // Fetch projects - UPDATED: Remove email from expand since it might not be supported
const fetchProjects = async () => {
  try {
    // Try with minimal expand first, then get email separately if needed
    const res = await fetch(`${apiBase}?$select=Id,Title,PC,ProjectReference,CustomerName,GroupHead,ProjectManagerId,ProjectManager/Id,ProjectManager/Title&$expand=ProjectManager&$orderby=Id desc`, {
      headers: { 
        'Accept': 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose'
      }
    });
    
    if (!res.ok) {
      const errorText = await res.text();
      console.error("Fetch projects error response:", errorText);
      
      // Try without expand first if the first query fails
      const res2 = await fetch(`${apiBase}?$select=Id,Title,PC,ProjectReference,CustomerName,GroupHead,ProjectManagerId&$orderby=Id desc`, {
        headers: { 
          'Accept': 'application/json;odata=verbose',
          'Content-Type': 'application/json;odata=verbose'
        }
      });
      
      if (!res2.ok) {
        const errorText2 = await res2.text();
        console.error("Second fetch attempt error:", errorText2);
        throw new Error(`HTTP error! status: ${res2.status}`);
      }
      
      const data2 = await res2.json();
      projectData = data2.d.results || []; 
    } else {
      const data = await res.json();
      projectData = data.d.results || []; 
    }
    
    // If we have ProjectManagerId but no expanded data, fetch manager details separately
    for (const project of projectData) {
      if (project.ProjectManagerId && !project.ProjectManager) {
        try {
          const managerRes = await fetch(`${siteUrl}/_api/web/siteusers(${project.ProjectManagerId})?$select=Id,Title,Email`, {
            headers: { 
              'Accept': 'application/json;odata=verbose',
              'Content-Type': 'application/json;odata=verbose'
            }
          });
          if (managerRes.ok) {
            const managerData = await managerRes.json();
            project.ProjectManager = {
              Id: managerData.d.Id,
              Title: managerData.d.Title,
              Email: managerData.d.Email
            };
          }
        } catch (error) {
          console.warn(`Could not fetch manager details for ID ${project.ProjectManagerId}:`, error);
        }
      }
    }
    
    renderTable(projectData);
  } catch (err) {
    console.error("Error fetching projects:", err);
    toast("Error fetching projects. Please check console for details.", "error");
  }
};
    // Save project - FIXED: Correct payload format for SharePoint
    const saveProject = async (payload: any, isUpdate = false) => {
      // Check for duplicate Project Name
      const duplicate = projectData.find(p => 
        p.Title?.toLowerCase() === payload.Title.toLowerCase() &&
        (!isUpdate || p.Id !== editingId)
      );
      if (duplicate) {
        toast("Project with this name already exists", "error");
        return;
      }

      try {
        const digest = await getDigest();
        const url = isUpdate ? `${apiBase}(${editingId})` : apiBase;
        const headers: any = {
          "Accept": "application/json;odata=verbose",
          "Content-Type": "application/json;odata=verbose",
          "X-RequestDigest": digest
        };
        
        if (isUpdate) {
          if (editingId === null) { 
            toast("No project selected", "error"); 
            return; 
          }
          headers["X-HTTP-Method"] = "MERGE";
          headers["IF-MATCH"] = "*";
        }

        // For SharePoint REST API, people field should be set using the ID
        // Ensure we're using the correct field name (check SharePoint internal name)
        const finalPayload = {
          __metadata: { type: "SP.Data.Project_x0020_ListListItem" },
          Title: payload.Title,
          PC: payload.PC,
          ProjectReference: payload.ProjectReference,
          CustomerName: payload.CustomerName,          
          GroupHead: payload.GroupHead
        };

        // Set Project Manager field - use correct internal field name
        if (payload.ProjectManagerId && payload.ProjectManagerId !== '') {
          // SharePoint expects the user ID for people fields
          (finalPayload as any)["ProjectManagerId"] = parseInt(payload.ProjectManagerId);
        } else {
          // To clear the field in SharePoint, you might need to set it to null
          (finalPayload as any)["ProjectManagerId"] = null;
        }

        console.log("Saving payload:", finalPayload);

        const res = await fetch(url, { 
          method: "POST", 
          headers, 
          body: JSON.stringify(finalPayload) 
        });
        
        if (!res.ok) {
          const errorText = await res.text();
          console.error("Save error response:", errorText);
          
          // Try to parse the error for better message
          try {
            const errorJson = JSON.parse(errorText);
            console.error("Save error details:", errorJson);
            if (errorJson.error && errorJson.error.message && errorJson.error.message.value) {
              toast(`Save failed: ${errorJson.error.message.value}`, "error");
            } else {
              toast(isUpdate ? "Update failed. Check console." : "Add failed. Check console.", "error");
            }
          } catch (e) {
            toast(isUpdate ? "Update failed. Check console." : "Add failed. Check console.", "error");
          }
        } else {
          toast(isUpdate ? "Project updated successfully" : "Project added successfully", "success");
          editingId = null;
          // Refresh the project list
          setTimeout(() => fetchProjects(), 1000);
        }
      } catch (err) {
        console.error("Save error:", err);
        toast(isUpdate ? "Update failed" : "Add failed", "error");
      }
    };

    const deleteProject = async (id: number) => {
      Swal.fire({
        title: 'Are you sure?', 
        text: "You won't be able to revert this!", 
        icon: 'warning',
        showCancelButton: true, 
        confirmButtonColor: '#0078d4', 
        cancelButtonColor: '#d33', 
        confirmButtonText: 'Yes, delete it!'
      }).then(async result => {
        if (result.isConfirmed) {
          try {
            const digest = await getDigest();
            const res = await fetch(`${apiBase}(${id})`, {
              method: "POST",
              headers: {
                "Accept": "application/json;odata=verbose",
                "Content-Type": "application/json;odata=verbose",
                "X-RequestDigest": digest,
                "X-HTTP-Method": "DELETE",
                "IF-MATCH": "*"
              }
            });
            if (res.ok) { 
              toast("Project deleted successfully", "success"); 
              fetchProjects(); 
            } else {
              const errorText = await res.text();
              console.error("Delete error:", errorText);
              toast("Failed to delete project", "error");
            }
          } catch (err) { 
            console.error("Delete error:", err);
            toast("Delete request failed", "error"); 
          }
        }
      });
    };

    const renderTable = (data: any[]) => {
      const startIndex = (currentPage - 1) * pageSize;
      const paginatedData = data.slice(startIndex, startIndex + pageSize);

      tableBody.innerHTML = paginatedData.map(p => {
        const managerName = getManagerDisplayName(p);
        
        return `
<tr>
  <td>${p.Title || ""}</td>
  <td>${p.PC || ""}</td>
  <td>${p.ProjectReference || ""}</td>
  <td>${p.CustomerName || ""}</td> 
  <td>${p.GroupHead || ""}</td>
  <td>${managerName || ""}</td>
  <td class="actions-cell">
    <button class="edit-btn" data-id="${p.Id}" title="Edit">✏️</button>
    <button class="delete-btn" data-id="${p.Id}" title="Delete">🗑️</button>
  </td>
</tr>`;
      }).join("");

      attachTableHandlers();
      const totalPages = Math.ceil(data.length / pageSize);
      renderPagination(totalPages);
    };

    const attachTableHandlers = () => {
      document.querySelectorAll('.edit-btn').forEach(btn =>
        btn.addEventListener('click', async () => {
          const id = Number((btn as HTMLElement).dataset.id!);
          const proj = projectData.find(x => x.Id === id);
          if (!proj) return;
          
          (document.querySelector('#name') as HTMLInputElement).value = proj.Title || '';
          (document.querySelector('#pc') as HTMLInputElement).value = proj.PC || '';
          (document.querySelector('#reference') as HTMLInputElement).value = proj.ProjectReference || '';
          (document.querySelector('#customer') as HTMLInputElement).value = proj.CustomerName || '';            
          (document.querySelector('#head') as HTMLInputElement).value = proj.GroupHead || '';
          
          // Clear and populate manager lookup
          clearSelectedManager();
          
          // Check if we have manager data
          if (proj.ProjectManagerId) {
            console.log("Editing project manager ID:", proj.ProjectManagerId);
            console.log("Project Manager expanded data:", proj.ProjectManager);
            
            // If we have expanded manager data, use it directly
            if (proj.ProjectManager && proj.ProjectManager.Id) {
              selectManager({
                id: proj.ProjectManager.Id,
                title: proj.ProjectManager.Title,
                email: proj.ProjectManager.Email
              });
            } else if (proj.ProjectManagerId) {
              // Try to fetch the user details
              try {
                const res = await fetch(`${siteUrl}/_api/web/siteusers(${proj.ProjectManagerId})`, {
                  headers: { 
                    'Accept': 'application/json;odata=verbose',
                    'Content-Type': 'application/json;odata=verbose'
                  }
                });
                if (res.ok) {
                  const managerData = await res.json();
                  selectManager({
                    id: managerData.d.Id,
                    title: managerData.d.Title,
                    email: managerData.d.Email
                  });
                }
              } catch (error) {
                console.error("Error fetching manager details:", error);
                // Still show the ID
                selectManager({
                  id: proj.ProjectManagerId,
                  title: `User ${proj.ProjectManagerId}`,
                  email: ''
                });
              }
            }
          }

          editingId = proj.Id;
          formHeader.textContent = "✏️ Update Project";
          submitBtn.textContent = "Update Project";
          formSection.style.display = "block";
          tableSection.style.display = "none";
          showFormBtn.style.display = "none";
        })
      );

      document.querySelectorAll('.delete-btn').forEach(btn =>
        btn.addEventListener('click', () => {
          const id = Number((btn as HTMLElement).dataset.id!);
          deleteProject(id);
        })
      );
    };

    const renderPagination = (totalPages: number) => {
      paginationDiv.innerHTML = '';
      for (let i = 1; i <= totalPages; i++) {
        const btn = document.createElement('button');
        btn.textContent = i.toString();
        btn.className = i === currentPage ? 'active' : '';
        btn.addEventListener('click', () => {
          currentPage = i;
          const query = searchInput.value.toLowerCase();
          const filteredData = projectData.filter(p => {
            const managerName = getManagerDisplayName(p);
            return (
              (p.Title || '').toLowerCase().includes(query) ||
              (p.PC || '').toLowerCase().includes(query) ||
              (p.ProjectReference || '').toLowerCase().includes(query) ||
              (p.CustomerName || '').toLowerCase().includes(query) ||            
              (p.GroupHead || '').toLowerCase().includes(query) ||
              (managerName || '').toLowerCase().includes(query)
            );
          });
          renderTable(filteredData);
        });
        paginationDiv.appendChild(btn);
      }
    };

    searchInput.addEventListener('input', () => {
      currentPage = 1;
      const query = searchInput.value.toLowerCase();
      const filteredData = projectData.filter(p => {
        const managerName = getManagerDisplayName(p);
        return (
          (p.Title || '').toLowerCase().includes(query) ||
          (p.PC || '').toLowerCase().includes(query) ||
          (p.ProjectReference || '').toLowerCase().includes(query) ||
          (p.CustomerName || '').toLowerCase().includes(query) ||          
          (p.GroupHead || '').toLowerCase().includes(query) ||
          (managerName || '').toLowerCase().includes(query)
        );
      });
      renderTable(filteredData);
    });

    form.addEventListener('submit', async e => {
      e.preventDefault();

      const payload: any = {
        Title: (document.querySelector('#name') as HTMLInputElement).value,
        PC: (document.querySelector('#pc') as HTMLInputElement).value,
        ProjectReference: (document.querySelector('#reference') as HTMLInputElement).value,
        CustomerName: (document.querySelector('#customer') as HTMLInputElement).value,          
        GroupHead: (document.querySelector('#head') as HTMLInputElement).value
      };

      // Get the manager ID from the hidden input
      const managerId = managerIdInput.value;
      if (managerId && managerId.trim() !== '') {
        payload.ProjectManagerId = managerId;
      } else {
        payload.ProjectManagerId = null;
      }

      await saveProject(payload, editingId !== null);

      // Reset form
      form.reset();
      clearSelectedManager();
      formSection.style.display = "none";
      tableSection.style.display = "block";
      showFormBtn.style.display = "inline-block";
      submitBtn.textContent = "Save Project";
      editingId = null;
    });

    showFormBtn.addEventListener('click', () => {
      form.reset();
      clearSelectedManager();
      editingId = null;
      formSection.style.display = "block";
      tableSection.style.display = "none";
      showFormBtn.style.display = "none";
      submitBtn.textContent = "Add Project";
      formHeader.textContent = "➕ Add New Project";
    });

    backBtn.addEventListener('click', () => {
      formSection.style.display = "none";
      tableSection.style.display = "block";
      showFormBtn.style.display = "inline-block";
      editingId = null;
      form.reset();
      clearSelectedManager();
      submitBtn.textContent = "Save Project";
    });

    // Excel Export
    exportBtn.addEventListener('click', () => {
      if (!projectData.length) { 
        toast("No data to export", "error"); 
        return; 
      }
      
      const wsData = projectData.map(p => {
        const managerName = getManagerDisplayName(p);
        return {
          'Project Name': p.Title || '',
          PC: p.PC || '',
          'Project Reference': p.ProjectReference || '',
          'Customer Name': p.CustomerName || '',          
          'Group Head': p.GroupHead || '',
          'Project Manager': managerName || ''
        };
      });
      
      const ws = XLSX.utils.json_to_sheet(wsData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Projects");
      const buf = XLSX.write(wb, { bookType: "xlsx", type: "array" });
      saveAs(new Blob([buf], { type: "application/octet-stream" }), `projects_${new Date().toISOString().slice(0,10)}.xlsx`);
      toast("Excel exported successfully", "success");
    });

    // Excel Import
    importBtn.addEventListener('click', () => excelInput.click());
    excelInput.addEventListener('change', async (e: Event) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      Swal.fire({
        title: 'Importing...',
        text: 'Please wait while importing data',
        allowOutsideClick: false,
        showConfirmButton: false,
        willOpen: () => {
          Swal.showLoading();
        }
      });

      try {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data);
        const sheetName = workbook.SheetNames[0];
        const jsonData: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

        let successCount = 0;
        let errorCount = 0;

        for (const row of jsonData) {
          try {
            const payload: any = {
              Title: row["Project Name"] || '',
              PC: row.PC || '',
              ProjectReference: row["Project Reference"] || '',
              CustomerName: row["Customer Name"] || '',            
              GroupHead: row["Group Head"] || ''
            };
            
            // Find manager by name/email from Excel
            const managerName = row["Project Manager"];
            if (managerName && managerName.trim() !== "") {
              // Try to parse email from the manager field
              const emailMatch = managerName.match(/\(([^)]+)\)/);
              const searchTerm = emailMatch ? emailMatch[1] : managerName;
              
              // Search for the manager
              const managers = await searchManagers(searchTerm);
              if (managers.length > 0) {
                payload.ProjectManagerId = managers[0].id;
              }
            }

            await saveProject(payload, false);
            successCount++;
          } catch (error) {
            errorCount++;
            console.error("Import error for row:", row, error);
          }
        }

        Swal.fire({
          title: 'Import Complete',
          text: `Successfully imported ${successCount} projects. ${errorCount} failed.`,
          icon: 'success',
          confirmButtonColor: '#0078d4'
        });

        fetchProjects();
      } catch (error) {
        console.error("Import error:", error);
        Swal.fire({
          title: 'Import Failed',
          text: 'Error reading Excel file',
          icon: 'error',
          confirmButtonColor: '#0078d4'
        });
      }

      excelInput.value = "";
    });

    // Manager lookup event listeners
    searchManagerBtn.addEventListener('click', async () => {
      const searchTerm = managerSearchInput.value.trim();
      if (searchTerm.length < 2) {
        toast("Please enter at least 2 characters to search", "error");
        return;
      }
      
      const managers = await searchManagers(searchTerm);
      displayManagerSuggestions(managers);
    });

    managerSearchInput.addEventListener('keydown', async (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        searchManagerBtn.click();
      }
    });

    managerSearchInput.addEventListener('input', async () => {
      const searchTerm = managerSearchInput.value.trim();
      if (searchTerm.length >= 2) {
        const managers = await searchManagers(searchTerm);
        displayManagerSuggestions(managers);
      } else {
        managerSuggestionsDiv.style.display = 'none';
      }
    });

    managerSearchInput.addEventListener('focus', () => {
      if (managerSearchInput.value.trim().length >= 2) {
        managerSuggestionsDiv.style.display = 'block';
      }
    });

    // Hide suggestions when clicking outside
    document.addEventListener('click', (e) => {
      if (!managerSearchInput.contains(e.target as Node) && 
          !managerSuggestionsDiv.contains(e.target as Node) &&
          !searchManagerBtn.contains(e.target as Node)) {
        managerSuggestionsDiv.style.display = 'none';
      }
    });

    removeManagerBtn.addEventListener('click', clearSelectedManager);

    // Initialize - fetch projects on load
    fetchProjects();

  }, 300);
}
};