declare const _spPageContextInfo: any;
import Swal from "sweetalert2";
import * as XLSX from 'xlsx-js-style';
import "../styles/common.css";
import "../styles/revenue.css";

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead?: string;
} 

interface SortConfig {
  column: string;
  direction: 'asc' | 'desc';
  subColumn?: string;
  monthIndex?: number;
}

let currentSortConfig: SortConfig = {
  column: '',
  direction: 'asc'
};


interface RevenueForecastItem {
  Id: number;
  Title: string;
  Project?: { 
    Id: number;
    Title: string;
  };
  ProfitCentre?: string;
  OBL?: number;
  ForecastData?: string;
  RevenueActual?: string;
  Remarks?: string | null;
  CreatedDate?: string;
  UpdatedDate?: string;
  [key: string]: any;
}

interface SharePointResponse<T> {
  d: {
    results: T[];
  };
}

 
// Update the ForecastItem interface to include date
interface ForecastItem {
    name: string;
    plan: number;
    actual: number;
    forecast?: number;
    date?: string;
    // Add previous field if needed (plan is typically the previous value)
    previous?: number; // If you need a separate previous field
}

 

// Fixed ForecastMonthData interface  
interface ForecastMonthData {
    plan: number;
    actual: number;
    forecast?: number;
    date?: string;
    items?: {
        [itemNumber: string]: ForecastItem;
    };
}

// Fixed YearlyForecastData interface
interface YearlyForecastData {
    [year: string]: {
        plan: number;
        actual: number;
        forecast?: number; // Optional for yearly data
    };
}

// Fixed ForecastData interface with proper index signature
interface ForecastData {
    [monthKey: string]: ForecastMonthData | YearlyForecastData | undefined;
    yearly?: YearlyForecastData;
}

interface UserContext {
  loginName: string;
  displayName: string;
  groups: string[];
  isSuperAdmin: boolean;
  isGroupHead: boolean;
  isProjectManager: boolean;
  userGroups?: string[];
  managedProjects?: string[];
  managedGroups?: string[];
}

// Add these variables after the other declarations

export default {
  content: `
<div class="revenue-page fade-in">
  <section class="table-section card">
    <div class="page-header">
      <h1>Revenue Forecast Management</h1>
      <button class="btn-primary show-form-btn">+ Add Forecast</button>
    </div>
    
    <div class="table-actions">
          <div class="table-actions-row">
        <div class="tableColp4">
          <label for="filterProject">Project</label>
          <select id="filterProject"><option value="">All Projects</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterCustomer">Customer</label>
          <select id="filterCustomer"><option value="">All Customers</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterProjectManager">Project Manager</label>
          <select id="filterProjectManager"><option value="">All Managers</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterGroupHead">Group Head</label>
          <select id="filterGroupHead"><option value="">All Group Heads</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterProjectReference">Project Reference</label>
          <select id="filterProjectReference"><option value="">All References</option></select>
        </div>
        <div class="tableColp4"> 
          <label>&nbsp;</label>
          <button class="btn-secondary clear-filters-btn" title="Clear All Filters">Reset Filter</button> 
        </div>
      </div>
      
      <!-- Second Row: Year, Month, Import Actual, Export Excel -->
      <div class="table-actions-row">
        <div class="tableColp4">
          <label for="filterYear">Year</label>
          <select id="filterYear"><option value="">All Years</option></select>
        </div>
        <div class="tableColp4">
          <label for="filterMonth">Month</label>
          <select id="filterMonth"><option value="">All Months</option></select>
        </div>
        <div class="tableColp4"> 
          <label>&nbsp;</label>
          <button class="btn-secondary import-actual-btn">📥 Import Actual</button>
        </div>
        <div class="tableColp4"> 
          <label>&nbsp;</label>
          <button class="btn-secondary export-btn">📊 Export Excel</button>
        </div>
        <div class="tableColp4"> 
    <label>&nbsp;</label>
    <button class="btn-secondary export-details-btn">📋 Details Export Excel</button>
  </div>
      </div>
    </div>
       
    <div class="table-container-rev">
      <div style="overflow-x:auto;">
        <table class="month-columns-table-rev"> 
           <thead id="totalsHeader"></thead> 
           <thead id="monthColumnsHeader"></thead> 
        <tbody class="revenue-table-body-rev"></tbody>
      </table>
         
      </div>
      
      <!-- Pagination -->
      <!-- Pagination -->
<div class="pagination-container">
  <div class="pagination-left">
    <button class="pagination-btn" id="firstPage" disabled>First</button>
    <button class="pagination-btn" id="prevPage" disabled>Previous</button>
    
    <div class="pagination-info">
      Page <span id="currentPage">1</span> of <span id="totalPages">1</span>
    </div>
    
    <div class="pagination-pages" id="pageNumbers"></div>
    
    <button class="pagination-btn" id="nextPage" disabled>Next</button>
    <button class="pagination-btn" id="lastPage" disabled>Last</button>
  </div>
  
  <div class="pagination-right">
    <div class="page-size-selector">
      <label for="pageSizeSelect">Show:</label>
      <select id="pageSizeSelect" class="page-size-select">
        <option value="10">10</option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100">100</option>
      </select>
      <span>per page</span>
    </div>
    
    <div class="pagination-info">
      Showing <span id="startItem">0</span>-<span id="endItem">0</span> of <span id="totalItems">0</span> records
    </div>
  </div>
</div>
    </div>
  </section>

  <section class="form-section card" style="display:none;">
    <div class="page-header">
      <h1 id="formTitle">Add / Edit Forecast</h1>
    </div>
    <form id="revenueForm">
      <div class="form-row">
        <div class="form-group from-group-box project-select-container">
          <label>Project</label>
          <select id="projectSelect" required></select>
        </div>
        <div id="projectDetails"></div>
      </div>
      
      <!-- OBL Section with Enhanced Validation --> 
      <div class="obl-section-container hidden-section">
        <div class="obl-main-section">
          <div class="form-group">
            <label>Last Month OBL 
              <span class="info-tooltip" title="For new projects, enter the initial OBL value. For existing projects, this will be auto-populated from last month's data.">ℹ️</span>
            </label>
            <input type="text" id="oblLastMonth" class="obl-input number-input" placeholder="Enter OBL" readonly />
            <div class="field-note">For new projects: Enter initial OBL value</div>
          </div>
          <div class="validation-summary">
            <div class="validation-item">
              <span class="validation-label">Total Current Value:</span>
              <span class="validation-value" id="totalCurrentValue">0</span>
            </div>
            <div class="validation-item">
              <span class="validation-label">Remaining Balance:</span>
              <span class="validation-value" id="remainingValue">0</span>
            </div>
            <div class="validation-line">
              <div class="line-fill" id="oblLineFill"></div>
            </div>
          </div>
        </div>
        <div class="validation-message" id="oblValidationMessage">
          ✅ All values are within OBL limit
        </div>
      </div>
      
      <!-- Historical Months (Last 3 Months - Readonly) -->
       <div class="forecast-section hidden-section" id="historicalForecastSection">
        <h3>Historical Data (Last 3 Months - Readonly)</h3>
        <div id="historicalContainer" class="historical-container"></div>
      </div>
      
      <!-- Current + Next 2 Months - Hidden by default -->
      <div class="forecast-section hidden-section" id="detailedForecastSection">
      <h3>Detailed Forecast (Current + Next 2 Months)</h3>
      <div id="firstRowContainer" class="first-row-container">
         
      </div>
    </div>
      
      <!-- Next 15 Months - Hidden by default -->
      <div class="forecast-section hidden-section" id="longtermForecastSection">
        <h3>Long-term Forecast (Next 15 Months)</h3>
        <div id="remainingContainer" class="remaining-container"></div>
      </div>

      <!-- 5-Year Forecast Section - Hidden by default -->
      <div class="forecast-section hidden-section" id="yearlyForecastSection">
        <h3>5-Year Forecast</h3>
        <div id="yearlyContainer" class="yearly-container-rev"></div>
      </div>
      
      <div class="form-actions">
        <button type="submit" class="btn-primary">💾 Save Forecast</button>
        <button type="button" class="btn-secondary back-to-table">⬅ Back</button>
      </div>
    </form>
  </section>
</div>
  `,

 style:`
 /* Additional styles for pagination */
.page-number.dots {
  background-color: transparent;
  border: none;
  cursor: default;
  color: #6c757d;
}

.pagination-btn:focus,
.page-number:focus,
.page-size-select:focus {
  outline: 2px solid #007bff;
  outline-offset: 2px;
}

/* Loading state for table */
.table-loading {
  opacity: 0.7;
  pointer-events: none;
}

/* Animation for page transitions */
@keyframes fadeIn {
  from { opacity: 0.5; }
  to { opacity: 1; }
}

.revenue-table-body-rev tr {
  animation: fadeIn 0.3s ease-in;
}

/* Responsive table container */
.table-container-rev {
  overflow-x: auto;
  max-height: calc(100vh - 300px);
  position: relative;
}

.table-container-rev::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-container-rev::-webkit-scrollbar-track {
  background: #f1f1f1;
}

.table-container-rev::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 4px;
}

.table-container-rev::-webkit-scrollbar-thumb:hover {
  background: #555;
}

.pagination-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  padding: 15px;
  background-color: #f8f9fa;
  border-radius: 8px;
  border: 1px solid #dee2e6;
  flex-wrap: wrap;
  gap: 15px;
}

.pagination-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.pagination-right {
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
}

.page-size-selector {
  display: flex;
  align-items: center;
  gap: 8px;
}

.page-size-select {
  padding: 5px 10px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  background-color: white;
  font-size: 14px;
  cursor: pointer;
}

.page-size-select:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25);
}

.pagination-btn {
  padding: 6px 12px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.2s;
}

.pagination-btn:hover:not(:disabled) {
  background-color: #0056b3;
}

.pagination-btn:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
  opacity: 0.6;
}

.pagination-info {
  font-size: 14px;
  color: #495057;
  white-space: nowrap;
}

.pagination-pages {
  display: flex;
  gap: 5px;
}

.page-number {
  padding: 6px 12px;
  background-color: white;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s;
}

.page-number:hover:not(.active) {
  background-color: #f8f9fa;
  border-color: #007bff;
}

.page-number.active {
  background-color: #007bff;
  color: white;
  border-color: #007bff;
}

/* Responsive styles */
@media (max-width: 768px) {
  .pagination-container {
    flex-direction: column;
    align-items: stretch;
    gap: 15px;
  }
  
  .pagination-left, .pagination-right {
    justify-content: center;
    width: 100%;
  }
} 

/* Totals Header Styles */
.totals-header-table {
  margin-bottom: 10px;
  background-color: #f8f9fa;
  border-collapse: separate;
  border-spacing: 0;
}

.totals-header-table th {
  padding: 8px 5px;
  font-size: 12px;
  font-weight: bold;
  text-align: center;
  vertical-align: middle;
  border: 1px solid #dee2e6;
  border-bottom: 2px solid #007bff;
  background-color: #e9ecef;
}

.totals-header-table .totals-label {
  font-weight: 600;
  color: #495057;
  background-color: #f1f3f4 !important;
}

.totals-header-table .all-projects-total {
  background-color: #d1ecf1 !important;
  color: #0c5460;
}

.totals-header-table .filtered-total {
  background-color: #d4edda !important;
  color: #155724;
}

.totals-header-table .total-value {
  font-weight: bold;
  font-size: 13px;
}

/* Adjust main table margin */
.table-container-rev > div > table:last-child {
  margin-top: 0;
}

/* Ensure proper column alignment */
.totals-header-table th,
.month-columns-table-rev th {
  min-width: 100px;
  box-sizing: border-box;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .totals-header-table th {
    font-size: 10px;
    padding: 5px 3px;
  }
  
  .totals-header-table .total-value {
    font-size: 11px;
  }
}

tr.filtered-total {
    background-color: #00ffff;
}
tr.all-projects-total {
    background-color: #fff8dc;
}
    .role-indicator {
    display: none;
}
 `,

  script: () => {
    setTimeout(async () => {
      const siteUrl = typeof _spPageContextInfo !== "undefined" ? _spPageContextInfo.webAbsoluteUrl : window.location.origin + "/sites/Kriya";
      const listName = "Revenue Forecast List";
      const projectListName = "Project List";

      // DOM Elements
      const tableBody = document.querySelector(".revenue-table-body-rev") as HTMLElement;
      const monthColumnsHeader = document.querySelector("#monthColumnsHeader") as HTMLElement;
      const formSection = document.querySelector(".form-section") as HTMLElement;
      const tableSection = document.querySelector(".table-section") as HTMLElement;
      const showFormBtn = document.querySelector(".show-form-btn") as HTMLButtonElement;
      const projectSelect = document.querySelector("#projectSelect") as HTMLSelectElement;
      const historicalContainer = document.querySelector("#historicalContainer") as HTMLElement;
      const firstRowContainer = document.querySelector("#firstRowContainer") as HTMLElement;
      const remainingContainer = document.querySelector("#remainingContainer") as HTMLElement;
      const yearlyContainer = document.querySelector("#yearlyContainer") as HTMLElement;
      const projectDetails = document.querySelector("#projectDetails") as HTMLElement;
      const backBtn = document.querySelector(".back-to-table") as HTMLButtonElement;
      const form = document.querySelector("#revenueForm") as HTMLFormElement;
      const exportBtn = document.querySelector(".export-btn") as HTMLButtonElement;
      const oblLastMonthInput = document.querySelector("#oblLastMonth") as HTMLInputElement;
      const totalCurrentValueSpan = document.querySelector("#totalCurrentValue") as HTMLSpanElement;
      const remainingValueSpan = document.querySelector("#remainingValue") as HTMLSpanElement;
      const oblLineFill = document.querySelector("#oblLineFill") as HTMLDivElement;
      const oblValidationMessage = document.querySelector("#oblValidationMessage") as HTMLDivElement;
      const formTitle = document.querySelector("#formTitle") as HTMLElement;

      // Filter Elements
      const filterYear = document.querySelector("#filterYear") as HTMLSelectElement;
      const filterMonth = document.querySelector("#filterMonth") as HTMLSelectElement;
      const filterProject = document.querySelector("#filterProject") as HTMLSelectElement;
      const filterCustomer = document.querySelector("#filterCustomer") as HTMLSelectElement;
      const filterProjectManager = document.querySelector("#filterProjectManager") as HTMLSelectElement;
      const filterGroupHead = document.querySelector("#filterGroupHead") as HTMLSelectElement;
      const filterProjectReference = document.querySelector("#filterProjectReference") as HTMLSelectElement;

      // Action Buttons
      const importActualBtns = document.querySelector(".import-actual-btn") as HTMLButtonElement;
      const clearFiltersBtn = document.querySelector(".clear-filters-btn") as HTMLButtonElement;
      
      const exportDetailsBtn = document.querySelector(".export-details-btn") as HTMLButtonElement;

      // Pagination Elements
      const firstPageBtn = document.querySelector("#firstPage") as HTMLButtonElement;
      const prevPageBtn = document.querySelector("#prevPage") as HTMLButtonElement;
      const nextPageBtn = document.querySelector("#nextPage") as HTMLButtonElement;
      const lastPageBtn = document.querySelector("#lastPage") as HTMLButtonElement;
      const currentPageSpan = document.querySelector("#currentPage") as HTMLSpanElement;
      const totalPagesSpan = document.querySelector("#totalPages") as HTMLSpanElement;
      const pageNumbersDiv = document.querySelector("#pageNumbers") as HTMLDivElement;
      const startItemSpan = document.querySelector("#startItem") as HTMLSpanElement;
      const endItemSpan = document.querySelector("#endItem") as HTMLSpanElement;
      const totalItemsSpan = document.querySelector("#totalItems") as HTMLSpanElement;

      let projects: ProjectItem[] = [];
      let forecasts: RevenueForecastItem[] = [];
      let editingId: number | null = null;
      let allMonths: string[] = [];

      let currentUser: UserContext;
      let userGroups: string[] = [];
      let managedProjects: string[] = [];
      let managedGroups: string[] = [];
      
      // Pagination variables
let currentPage = 1;
let pageSize = 10; // Default page size
let totalPages = 1;
let filteredData: RevenueForecastItem[] = [];

      const roleStyles = `
.role-indicator {
  padding: 8px 15px;
  margin-bottom: 15px;
  border-radius: 5px;
  color: white;
  font-weight: bold;
  display: inline-block;
}

.role-badge {
  display: flex;
  align-items: center;
  gap: 8px;
}

.table-actions {
  margin-top: 15px;
}

.hidden-by-role {
  display: none !important;
}
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = roleStyles;
document.head.appendChild(styleSheet);

      // ========== UTILITY FUNCTIONS ==========
const pageSizeSelect = document.querySelector("#pageSizeSelect") as HTMLSelectElement;
const getUserContext = async (): Promise<UserContext> => {
  try {
    // Get current user information
    const userRes = await fetch(`${siteUrl}/_api/web/currentuser`, {
      headers: { Accept: "application/json;odata=verbose" }
    });
    const userData = await userRes.json();
    const loginName = userData.d.LoginName;
    const displayName = userData.d.Title;

    // Get user's groups
    const groupsRes = await fetch(`${siteUrl}/_api/web/currentuser/groups`, {
      headers: { Accept: "application/json;odata=verbose" }
    });
    const groupsData = await groupsRes.json();
    userGroups = groupsData.d.results.map((g: any) => g.Title);
     
    // Check roles based on group membership
    const isSuperAdmin = userGroups.some(g => 
      g.toLowerCase().includes("super admin") || 
      g.toLowerCase() === "site owners" ||
      g === "Super Admin"
    );
    
    const isGroupHead = userGroups.some(g => 
      g.toLowerCase().includes("group head") || 
      g === "Group Head"
    );
    
    const isProjectManager = userGroups.some(g => 
      g.toLowerCase().includes("project manager") || 
      g === "Project Manager"
    );

    // If user is Group Head, get their managed groups
    if (isGroupHead) {
      const groupHeadName = displayName;
      managedGroups = [groupHeadName]; 
    }

    // If user is Project Manager, get their managed projects
    if (isProjectManager) {
      // Load projects where this user is the project manager
      const pmProjectsRes = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$filter=ProjectManager/Title eq '${displayName}'&$select=Id,Title`,
        { headers: { Accept: "application/json;odata=verbose" } }
      );
      const pmProjectsData = await pmProjectsRes.json();
      managedProjects = pmProjectsData.d.results.map((p: any) => p.Title); 
    }
 
    return {
      loginName,
      displayName,
      groups: userGroups,
      isSuperAdmin,
      isGroupHead,
      isProjectManager,
      userGroups,
      managedProjects,
      managedGroups
    };
  } catch (error) {
    console.error("Error getting user context:", error);
    // Default to most restrictive access if error
    return {
      loginName: "",
      displayName: "",
      groups: [],
      isSuperAdmin: false,
      isGroupHead: false,
      isProjectManager: false,
      managedProjects: [],
      managedGroups: []
    };
  }
};

const getSafeString = (value: any, defaultValue: string = "-"): string => {
  if (value === null || value === undefined) {
    return defaultValue;
  }
  
  if (typeof value === 'string') {
    return value.trim() || defaultValue;
  }
  
  if (typeof value === 'object' && 'Title' in value) {
    return value.Title?.trim() || defaultValue;
  }
  
  return String(value) || defaultValue;
};

// ========== ROLE-BASED FILTERING FUNCTIONS ==========

const filterDataByRole = (data: RevenueForecastItem[]): RevenueForecastItem[] => { 
  if (currentUser.isSuperAdmin) { 
    return data;
  }

  const filteredData = data.filter(forecast => {
    const projectTitle = forecast.Project?.Title;
    
    if (!projectTitle) { 
      return false;
    }

    const project = projects.find(p => p.Title === projectTitle);
    
    if (!project) { 
      return false;
    }

    if (currentUser.isGroupHead) {
      // Group Head can see projects in their managed groups
      const canAccess = currentUser.managedGroups?.some(group => 
        project.GroupHead === group
      ) || false;
       return canAccess;
    }

    if (currentUser.isProjectManager) {
      // Project Manager can see only their assigned projects
      const canAccess = currentUser.managedProjects?.includes(projectTitle) || false;
       return canAccess;
    }
      return false;
  });
  // Log the filtered project titles for debugging
  filteredData.forEach((f, i) => { 
  });
  
  return filteredData;
};

const updateUIForRole = (): void => {
  const pageHeader = document.querySelector(".page-header") as HTMLElement;
  const roleIndicator = document.createElement("div");
  roleIndicator.className = "role-indicator";
  
  let roleText = "";
  if (currentUser.isSuperAdmin) {
    roleText = "Super Admin - Full Access";
    roleIndicator.style.backgroundColor = "#28a745"; // Green
  } else if (currentUser.isGroupHead) {
    roleText = `Group Head - ${currentUser.displayName}`;
    roleIndicator.style.backgroundColor = "#17a2b8"; // Blue
  } else if (currentUser.isProjectManager) {
    roleText = `Project Manager - ${currentUser.displayName}`;
    roleIndicator.style.backgroundColor = "#ffc107"; // Yellow
  } else {
    roleText = "Limited Access";
    roleIndicator.style.backgroundColor = "#6c757d"; // Gray
  }
  
  roleIndicator.innerHTML = `
    <span class="role-badge">👤 ${roleText}</span>
  `;
  
  // Insert role indicator after the header
  pageHeader.parentNode?.insertBefore(roleIndicator, pageHeader.nextSibling);

  // Disable "Add Forecast" button for non-Super Admins if needed
  if (!currentUser.isSuperAdmin) {
    showFormBtn.disabled = false; // Allow all to add, but filter projects
  }

  // Apply CSS classes for role-based UI elements
  setTimeout(() => {
    applyRoleBasedUIClasses();
  }, 100);
};

const applyRoleBasedUIClasses = (): void => {
  if (currentUser.isSuperAdmin) {
    // Super Admin should see ALL columns
    document.querySelectorAll('.hidden-by-role').forEach(element => {
      element.classList.remove('hidden-by-role');
    });
    return;
  }
  
  // Apply classes to table header cells
  const tableHeaders = document.querySelectorAll('.month-columns-table-rev th');
  
  tableHeaders.forEach(header => {
    const headerText = header.textContent?.toLowerCase() || '';
    
    // Project Manager column - hide for Project Manager login (they only see themselves)
    if (headerText.includes('project manager') || headerText.includes('manager')) {
      if (currentUser.isProjectManager) {
        header.classList.add('hidden-by-role');
      } else {
        header.classList.remove('hidden-by-role');
      }
    }
    
    // Group Head column - hide for Group Head login (they only see themselves)
    if (headerText.includes('group head') || headerText.includes('head')) {
      if (currentUser.isGroupHead) {
        header.classList.add('hidden-by-role');
      } else {
        header.classList.remove('hidden-by-role');
      }
    }
  });

  // Apply classes to filter elements
  const projectManagerFilter = document.querySelector('#filterProjectManager')?.closest('.tableColp4');
  const groupHeadFilter = document.querySelector('#filterGroupHead')?.closest('.tableColp4');
  
  if (projectManagerFilter) {
    if (currentUser.isProjectManager) {
      projectManagerFilter.classList.add('hidden-by-role');
    } else {
      projectManagerFilter.classList.remove('hidden-by-role');
    }
  }
  
  if (groupHeadFilter) {
    if (currentUser.isGroupHead) {
      groupHeadFilter.classList.add('hidden-by-role');
    } else {
      groupHeadFilter.classList.remove('hidden-by-role');
    }
  }
};

const filterProjectSelectByRole = (): void => {
  if (currentUser.isSuperAdmin) {
    return; // Super Admin sees all projects
  }

  const options = projectSelect.querySelectorAll("option");
  options.forEach((option, index) => {
    if (index === 0) return; // Skip "Select Project" option
    
    const projectId = parseInt(option.value);
    const project = projects.find(p => p.Id === projectId);
    
    if (!project) {
      option.style.display = "none";
      return;
    }

    let showOption = false;
    
    if (currentUser.isGroupHead) {
      showOption = currentUser.managedGroups?.some(group => 
        project.GroupHead === group
      ) || false;
    } else if (currentUser.isProjectManager) {
      showOption = currentUser.managedProjects?.includes(project.Title) || false;
    }
    
    option.style.display = showOption ? "" : "none";
  });

  // Reset selection if current selection is hidden
  if (projectSelect.value) {
    const selectedOption = projectSelect.selectedOptions[0];
    if (selectedOption.style.display === "none") {
      projectSelect.value = "";
      toast("warning", "Your current project selection is not accessible with your role");
    }
  }
};

      const toast = (icon: any, title: string) => Swal.fire({ toast: true, icon, title, position: "top-end", timer: 2000, showConfirmButton: false });


      
      const getDigest = async (): Promise<string> => {
        const res = await fetch(`${siteUrl}/_api/contextinfo`, { 
          method: "POST", 
          headers: { Accept: "application/json;odata=verbose" } 
        });
        const data = await res.json();
        return data.d.GetContextWebInformation.FormDigestValue;
      };

      // Safe JSON parsing function
      const safeJsonParse = (jsonString: string | undefined, fallback: any = {}): any => {
        try {
          if (!jsonString || jsonString.trim() === '') {
            return fallback;
          }
          
          const cleanedString = jsonString.trim();
          
          // Handle common JSON issues
          if (cleanedString === '""' || cleanedString === "null") {
            return fallback;
          }
          
          return JSON.parse(cleanedString);
        } catch (error) {
          console.error("JSON parse error:", error, "Input:", jsonString);
          return fallback;
        }
      };

      const formatMonthKey = (date: Date): string => {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      };

      const formatMonthLabel = (date: Date): string => {
        return date.toLocaleString("default", { month: "short", year: "2-digit" });
      };

      const generateForecastTitle = (project: ProjectItem, forecastData: ForecastData): string => {
        const currentYear = new Date().getFullYear();
        let totalValue = 0;
        
        // Calculate total from monthly data only (exclude yearly)
        Object.keys(forecastData).forEach(key => {
          if (key.match(/^\d{4}-\d{2}$/)) {
            const monthData = forecastData[key] as ForecastMonthData;
            if (monthData) {
              totalValue += monthData.actual;
            }
          }
        });
        
        return `${project.Title} - ${currentYear} Forecast - ${totalValue.toLocaleString()}`;
      };

      // Get current and next 2 months for display
      const getDisplayMonths = (): string[] => {
        const now = new Date();
        const months: string[] = [];
        
        // Current month + next 2 months
        for (let i = 0; i < 3; i++) {
          const month = new Date(now.getFullYear(), now.getMonth() + i, 1);
          months.push(formatMonthKey(month));
        }
        
        return months;
      };

      const getAllMonthsForStorage = (): string[] => {
        return generateIdealMonthStructure();
      };

      // Utility function to allow only numbers 0-9 in text inputs
      const allowOnlyNumbers = (input: HTMLInputElement): void => {
        input.addEventListener('input', function() {
          let value = this.value.replace(/[^\d]/g, '');
          
          if (value.length > 1 && value.startsWith('0')) {
            value = value.replace(/^0+/, '');
            if (value === '') value = '0';
          }
          
          this.value = value;
          
          if (value === '' || value === '0') {
            this.className = this.className.replace('input-with-value', 'input-empty');
          } else {
            this.className = this.className.replace('input-empty', 'input-with-value');
          }
        });
        
        input.addEventListener('keydown', function(e) {
          if ([8, 9, 13, 27, 46].includes(e.keyCode) || 
              (e.keyCode === 65 && e.ctrlKey === true) || 
              (e.keyCode === 67 && e.ctrlKey === true) ||
              (e.keyCode === 86 && e.ctrlKey === true) ||
              (e.keyCode === 88 && e.ctrlKey === true) ||
              (e.keyCode >= 35 && e.keyCode <= 39)) {
            return;
          }
          
          if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
          }
        });
        
        input.addEventListener('paste', function(e) {
          const clipboardData = e.clipboardData || (window as any).clipboardData;
          const pastedData = clipboardData?.getData('Text') || '';
          
          if (/[^\d]/.test(pastedData)) {
            e.preventDefault();
          }
        });
      };

      // Function to get numeric value from text input - 0 is placeholder
      const getNumericValue = (input: HTMLInputElement): number => {
        const value = input.value.trim();
        if (value === '' || value === '0') return 0;
        return parseInt(value) || 0;
      };

      // Function to set numeric value to text input - 0 shows as empty
      const setNumericValue = (input: HTMLInputElement, value: number): void => {
        if (value === 0) {
          input.value = '';
          input.className = input.className.replace('input-with-value', 'input-empty');
        } else {
          input.value = value.toString();
          input.className = input.className.replace('input-empty', 'input-with-value');
        }
      };

      // Enhanced OBL validation with toast notifications
      const showOBLErrorToast = (message: string, isWarning: boolean = false): void => {
        const existingToast = document.querySelector('.obl-error-toast');
        if (existingToast) existingToast.remove();
        
        const toast = document.createElement('div');
        toast.className = `obl-error-toast ${isWarning ? 'warning' : ''}`;
        toast.innerHTML = `
          ${message}
          <button class="toast-close">&times;</button>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
          if (toast.parentNode) {
            toast.remove();
          }
        }, 5000);
        
        toast.querySelector('.toast-close')?.addEventListener('click', () => {
          toast.remove();
        });
      };

      // ========== MONTH STRUCTURE FUNCTIONS ==========
      const createEmptyItems = (): { [key: string]: ForecastItem } => {
          const items: { [key: string]: ForecastItem } = {};
          for (let i = 1; i <= 10; i++) {
              items[i.toString()] = { 
                  name: '', 
                  plan: 0, 
                  actual: 0, 
                  forecast: 0, 
                  date: '' 
              };
          }
          return items;
      };

      const generateIdealMonthStructure = (): string[] => {
        const months: string[] = [];
        const currentDate = new Date(); 
        // Historical: 3 months before current (readonly)
        for (let i = -3; i < 0; i++) {
          const historicalDate = new Date(currentDate);
          historicalDate.setMonth(historicalDate.getMonth() + i);
          months.push(formatMonthKey(historicalDate));
        }
        
        // Detailed: Current + Next 2 months (editable with items)
        for (let i = 0; i < 3; i++) {
          const detailedDate = new Date(currentDate);
          detailedDate.setMonth(detailedDate.getMonth() + i);
          months.push(formatMonthKey(detailedDate));
        }
        
        // Future: Next 15 months (simple inputs)
        for (let i = 3; i < 18; i++) {
          const futureDate = new Date(currentDate);
          futureDate.setMonth(futureDate.getMonth() + i);
          months.push(formatMonthKey(futureDate));
        }
         
        return months;
      };

      // ========== YEARLY FORECAST FUNCTIONS ==========

      const getLastMonthKey = (existingData: ForecastData): string | undefined => {
        const monthKeys = Object.keys(existingData).filter(key => key.match(/^\d{4}-\d{2}$/));
        
        if (monthKeys.length === 0) {
          return undefined;
        }
        
        // Sort months and get the last one
        const sortedMonths = monthKeys.sort();
        const lastMonth = sortedMonths[sortedMonths.length - 1];
         
        return lastMonth;
      };

      const createFreshYearlyStructure = (lastMonthKey?: string): YearlyForecastData => {
        const yearlyData: YearlyForecastData = {};
        
        // Determine start year dynamically
        let startYear: number;
        
        if (lastMonthKey) {
          // Extract year from last month key (format: "YYYY-MM")
          startYear = parseInt(lastMonthKey.split('-')[0]); 
        } else {
          // If no last month key, calculate from current date + 15 months
          const futureDate = new Date();
          futureDate.setMonth(futureDate.getMonth() + 15);
          startYear = futureDate.getFullYear(); 
        }
        
        const endYear = startYear + 4; // 5 years total including start year 
        
        for (let year = startYear; year <= endYear; year++) {
          yearlyData[year.toString()] = {
            plan: 0,
            actual: 0
          };
        }
        
        return yearlyData;
      };


      const createFreshForecastStructure = (): ForecastData => {
          const idealMonths = generateIdealMonthStructure();
          const freshData: ForecastData = {};
          
          const currentMonthKey = formatMonthKey(new Date());
          
          idealMonths.forEach((monthKey, index) => {
              const isCurrentMonth = monthKey === currentMonthKey;
              freshData[monthKey] = {
                  plan: 0,
                  actual: 0,
                  forecast: 0, // Now optional but provided for consistency
                  date: isCurrentMonth ? '' : undefined,
                  items: (index >= 3 && index <= 5) ? createEmptyItems() : {}
              };
          });
          
          // Initialize yearly data dynamically
          const lastMonthKey = idealMonths[idealMonths.length - 1];
          freshData.yearly = createFreshYearlyStructure(lastMonthKey);
          
          return freshData;
      };

      

      // Type guard to check if data is ForecastMonthData - updated for optional forecast
      const isForecastMonthData = (data: any): data is ForecastMonthData => {
          return data && 
                typeof data.plan === 'number' && 
                typeof data.actual === 'number';
                // Removed forecast check since it's optional
      };

      const handleMonthProgression = (forecastData: ForecastData): ForecastData => {
        const now = new Date();
        const currentMonthKey = formatMonthKey(now);
         
        const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
        const idealMonths = generateIdealMonthStructure();
        
        // Check if progression is needed
        if (originalMonths[0] === idealMonths[0]) { 
          return forecastData;
        } 
        const updatedData: ForecastData = {}; 
        idealMonths.forEach((monthKey, index) => { 
          const existingData = forecastData[monthKey];
          if (existingData && isForecastMonthData(existingData)) {
            // Month exists - copy as-is
            updatedData[monthKey] = JSON.parse(JSON.stringify(existingData));
          } else {
            // New month - create empty
            updatedData[monthKey] = {
              plan: 0,
              actual: 0,
              items: (index >= 3 && index <= 5) ? createEmptyItems() : {}
            };
          }
        }); 
        console.log("=== APPLYING VALUE PROPAGATION ==="); 
        const currentMonthIndex = idealMonths.indexOf(currentMonthKey);
        
        idealMonths.forEach((monthKey, index) => {
          const monthData = updatedData[monthKey];
          
          if (monthData && isForecastMonthData(monthData)) { 
            const isCurrentOrFuture = index >= currentMonthIndex;
            
            if (isCurrentOrFuture) { 
              const oldActual = monthData.actual; 
              monthData.plan = oldActual;  // Carry forward actual as plan
              monthData.actual = 0;        // Reset actual to 0 
              // Apply same logic to items for detailed months
              if (monthData.items && Object.keys(monthData.items).length > 0) {
                Object.keys(monthData.items).forEach(itemKey => {
                  const item = monthData.items![itemKey];
                  const oldItemActual = item.actual;
                  
                  item.plan = oldItemActual;  // Carry forward item actual as plan
                  item.actual = 0;          
                });
              }
            } else { 
            }
          }
        });

        // Preserve yearly data if it exists
        if (forecastData.yearly) {
          updatedData.yearly = JSON.parse(JSON.stringify(forecastData.yearly));
        } else {
          // Create fresh yearly data based on new last month
          const lastMonthKey = idealMonths[idealMonths.length - 1];
          updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
        } 
        return updatedData;
      };

      const propagateMonthValues = (forecastData: ForecastData): ForecastData => {
        if (Object.keys(forecastData).length === 0) {
          return forecastData;
        }
        
        return handleMonthProgression(forecastData);
      };

      // ========== DATA LOADING FUNCTIONS ==========

const loadProjects = async (): Promise<void> => {
  try {
    const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$select=Id,Title,CustomerName,GroupHead,PC,ProjectReference,ProjectManager/Title&$expand=ProjectManager`, {
      headers: { Accept: "application/json;odata=verbose" }
    });
    const data: SharePointResponse<ProjectItem> = await res.json();
    const rawProjects: ProjectItem[] = data.d?.results || [];
    
    // Clean up the projects data - ensure all required fields have at least empty string
    const cleanedProjects = rawProjects.map((p: ProjectItem) => ({
      ...p,
      CustomerName: p.CustomerName || "",
      GroupHead: p.GroupHead || "",
      PC: p.PC || "",
      ProjectReference: p.ProjectReference || "",
      ProjectManager: p.ProjectManager || ""
    }));
    
    // Remove duplicates by Title using a Map
    const projectMap = new Map<string, ProjectItem>();
    cleanedProjects.forEach(p => {
      projectMap.set(p.Title, p);
    });
    
    projects = Array.from(projectMap.values());
    
    projectSelect.innerHTML = `<option value="">Select Project</option>` + 
      projects.map(p => `<option value="${p.Id}">${p.Title}</option>`).join("");
  } catch (error) {
    console.error("Error loading projects:", error);
    toast("error", "Failed to load projects");
  }        
};

      const loadForecasts = async (): Promise<void> => {
        try {
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Id,Title,Project/Id,Project/Title,ProfitCentre,OBL,ForecastData,RevenueActual,Remarks,CreatedDate,UpdatedDate&$expand=Project&$top=5000`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const data: SharePointResponse<RevenueForecastItem> = await res.json();
          
          forecasts = (data.d?.results || []).map(forecast => ({
            ...forecast,
            ForecastData: typeof forecast.ForecastData === 'string' ? 
              forecast.ForecastData : 
              JSON.stringify(forecast.ForecastData || {}),
            RevenueActual: typeof forecast.RevenueActual === 'string' ? 
              forecast.RevenueActual : 
              JSON.stringify(forecast.RevenueActual || {})
          })); 
        } catch (error) { 
          toast("error", "Failed to load forecasts");
        }
      };
 
      
      // ========== EXPORT FUNCTIONS ==========
 
      // Add this utility function at the top with other utility functions
      const getMonthName = (monthNumber: string): string => {
        const months = [
          "Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        return months[parseInt(monthNumber) - 1] || "Month";
      };

      const exportToExcelWithFullStyle = (): void => { 
        // Get selected year and month from filters
        const selectedYear = filterYear.value;
        const selectedMonth = filterMonth.value;
        
        if (!selectedYear || !selectedMonth) {
          toast("error", "Please select year and month to export");
          return;
        }

        // Use filtered data from pagination (current view)
        const exportData = filteredData.length > 0 ? filteredData : forecasts;
        
        if (exportData.length === 0) {
          toast("error", "No data available to export");
          return;
        }

        try {
          // Generate headers according to your specified structure
          const { headers, allMonths, lastFiveYears } = generateHeadersStructure(selectedYear, selectedMonth, exportData);
           
          const excelData = exportData.map(forecast => {
            const projectTitle = forecast.Project?.Title || "-";
            const proj = projects.find(p => p.Title === projectTitle);
            
            // Parse data from both sources
            const revenueActualData = safeJsonParse(forecast.RevenueActual, {});
            const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
            
            // Get OBL value from database
            const oblValue = forecast.OBL || 0;
            
            // Selected month key
            const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
            const monthName = getMonthName(selectedMonth);
            
            // Get data for selected month
            const selectedMonthForecastData = forecastData[selectedMonthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            const selectedMonthPlan = selectedMonthForecastData.plan || 0;
            const selectedMonthCurrent = selectedMonthForecastData.actual || 0;
            const selectedMonthActual = revenueActualData[selectedMonthKey] || 0;
            const selectedMonthForecast = selectedMonthForecastData.forecast || 0;

            // Create base row data - MUST MATCH HEADER NAMES EXACTLY
            const rowData: any = {
              "Profit Centre": forecast.ProfitCentre || "-",
              "SO/Project Ref": proj?.ProjectReference || "-",
              "Customer Name": proj?.CustomerName || "-",
              "Project Name": projectTitle,
              "Group Head": proj?.GroupHead || "-",
              "Project Manager": typeof proj?.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-",
              "OBL": oblValue,
              // Updated column names with year and simplified labels
              [`${monthName} ${selectedYear} (P)`]: selectedMonthPlan,
              [`${monthName} ${selectedYear} (C)`]: selectedMonthCurrent,
              [`${monthName} ${selectedYear} (R)`]: selectedMonthActual,
              [`${monthName} ${selectedYear} (F)`]: selectedMonthForecast,
            };
            
            // Add next 17 months data (previous + current)
            allMonths.forEach(monthKey => {
              const [year, month] = monthKey.split('-');
              const monthLabel = getMonthName(month);
              const displayLabel = `${monthLabel} ${year}`;
              
              // Get forecast data for plan and current
              const forecastMonthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
              const planValue = forecastMonthData.plan || 0;
              const currentValue = forecastMonthData.actual || 0;
              
              // Add both previous (plan) and current columns for each month
              rowData[`${displayLabel} (P)`] = planValue;
              rowData[`${displayLabel} (C)`] = currentValue;
            });
            
            // Add 5-year data (previous + current)
            lastFiveYears.forEach(year => {
              const yearData = forecastData.yearly?.[year] || { plan: 0, actual: 0 };
              rowData[`${year} (P)`] = yearData.plan;
              rowData[`${year} (C)`] = yearData.actual;
            });     
            
            // Calculate balance: OBL - (Total current of month + Total Current of Year)
            const totalMonthlyCurrent = Object.keys(forecastData)
              .filter(key => key.match(/^\d{4}-\d{2}$/))
              .reduce((sum, monthKey) => {
                const monthData = forecastData[monthKey] as ForecastMonthData;
                return sum + (monthData?.actual || 0);
              }, 0);

            const totalYearlyCurrent = forecastData.yearly ? 
              Object.values(forecastData.yearly).reduce((sum, yearData) => {
                return sum + (yearData.actual || 0);
              }, 0) : 0;

            rowData["Balance"] = oblValue - (totalMonthlyCurrent + totalYearlyCurrent);
            
            return rowData;
          });
 
          const wb = XLSX.utils.book_new();
          
          // Convert data to worksheet with headers
          const ws = XLSX.utils.json_to_sheet(excelData, { header: headers });

          // Define styles
          const headerStyle = {
            fill: {
              fgColor: { rgb: "FF0078D4" }
            },
            font: {
              name: "Arial",
              sz: 10,
              bold: true,
              color: { rgb: "FFFFFFFF" }
            },
            alignment: {
              horizontal: "center",
              vertical: "center"
            },
            border: {
              top: { style: "thin", color: { rgb: "FF000000" } },
              left: { style: "thin", color: { rgb: "FF000000" } },
              bottom: { style: "thin", color: { rgb: "FF000000" } },
              right: { style: "thin", color: { rgb: "FF000000" } }
            }
          };

          const dataStyle = {
            font: {
              name: "Arial",
              sz: 10
            },
            alignment: {
              horizontal: "center",
              vertical: "center"
            },
            border: {
              top: { style: "thin", color: { rgb: "FFD0D0D0" } },
              left: { style: "thin", color: { rgb: "FFD0D0D0" } },
              bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
              right: { style: "thin", color: { rgb: "FFD0D0D0" } }
            }
          };

          const numberStyle = {
            ...dataStyle,
            alignment: {
              horizontal: "right",
              vertical: "center"
            }
          };

          // Apply styles to all cells
          const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
          
          // Style header row (row 0)
          for (let col = range.s.c; col <= range.e.c; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            if (!ws[cellAddress]) continue;
            
            if (!ws[cellAddress].s) {
              ws[cellAddress].s = {};
            }
            ws[cellAddress].s = headerStyle;
          }
          
          // Style data rows
          for (let row = range.s.r + 1; row <= range.e.r; row++) {
            for (let col = range.s.c; col <= range.e.c; col++) {
              const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
              if (!ws[cellAddress]) continue;
              
              // Determine if this is a number column
              const isNumberColumn = col >= 6; // Starting from OBL column
              const styleToApply = isNumberColumn ? numberStyle : dataStyle;
              
              if (!ws[cellAddress].s) {
                ws[cellAddress].s = {};
              }
              ws[cellAddress].s = styleToApply;
            }
          }

          // Set column widths
          const colWidths = headers.map((header: string) => {
            if (header.includes('Project Name')) return { wch: 25 };
            if (header.includes('Customer Name')) return { wch: 20 };
            if (header.includes('Profit Centre') || header.includes('SO/Project Ref')) return { wch: 12 };
            if (header.includes('Group Head') || header.includes('Project Manager')) return { wch: 15 };
            if (header.includes('OBL') || header.includes('Balance')) return { wch: 12 };
            if (header.includes('(P)') || header.includes('(C)') || header.includes('(F)')) return { wch: 10 };
            return { wch: 12 };
          });
          ws['!cols'] = colWidths;

          // Freeze header row
          ws['!freeze'] = { x: 0, y: 1 };

          // Add worksheet to workbook
          XLSX.utils.book_append_sheet(wb, ws, "Revenue Forecast");

          // Generate filename and export
          const monthName = getMonthName(selectedMonth);
          const fileName = `Revenue_Forecast_${monthName}_${selectedYear}_Filtered.xlsx`;
          
          XLSX.writeFile(wb, fileName);
           
          toast("success", `Exported ${exportData.length} filtered records for ${monthName} ${selectedYear}`);
          
        } catch (error) { 
          toast("error", "Failed to export data to Excel");
        }
      };

      // Updated helper function to generate headers according to your structure
      const generateHeadersStructure = (selectedYear: string, selectedMonth: string, exportData: RevenueForecastItem[]) => {
        const baseHeaders = [
          "Profit Centre", 
          "SO/Project Ref", 
          "Customer Name", 
          "Project Name", 
          "Group Head", 
          "Project Manager", 
          "OBL",
        ];

        // Add selected month columns - UPDATED with year and simplified labels
        const selectedMonthName = getMonthName(selectedMonth);
        const selectedMonthHeaders = [
          `${selectedMonthName} ${selectedYear} (P)`,
          `${selectedMonthName} ${selectedYear} (C)`,
          `${selectedMonthName} ${selectedYear} (R)`,
          `${selectedMonthName} ${selectedYear} (F)`
        ];

        // Get all unique months from the data
        const allMonthKeys = new Set<string>();
        
        exportData.forEach(forecast => {
          const forecastData = safeJsonParse(forecast.ForecastData, {});
          Object.keys(forecastData).forEach(key => {
            if (key && key.match(/^\d{4}-\d{2}$/)) {
              allMonthKeys.add(key);
            }
          });
        });

        // Sort months and take NEXT 17 months (excluding current month)
        const sortedMonthKeys = Array.from(allMonthKeys).sort();
        const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
        const selectedIndex = sortedMonthKeys.indexOf(selectedMonthKey);
        
        // Start from the month AFTER the selected month
        const startIndex = selectedIndex >= 0 ? selectedIndex + 1 : 0;
        const next17Months = sortedMonthKeys.slice(startIndex, startIndex + 17);
 
        // Add monthly columns (previous + current for each of the next 17 months)
        const monthlyHeaders: string[] = [];
        next17Months.forEach(monthKey => {
          const [year, month] = monthKey.split('-');
          const monthLabel = getMonthName(month);
          const displayLabel = `${monthLabel} ${year}`;
          monthlyHeaders.push(`${displayLabel} (P)`, `${displayLabel} (C)`);
        });

        // Get last 5 years from yearly forecast data
        const lastFiveYears = getLastFiveYears(exportData);
        const yearlyHeaders: string[] = [];
        lastFiveYears.forEach(year => {
          yearlyHeaders.push(`${year} (P)`, `${year} (C)`);
        });

        // Add balance column
        const finalHeaders = [
          ...baseHeaders,
          ...selectedMonthHeaders,
          ...monthlyHeaders,
          ...yearlyHeaders,
          "Balance"
        ];
        
        return { 
          headers: finalHeaders, 
          allMonths: next17Months,
          lastFiveYears
        };
      };

      // Helper function to get last 5 years from data
      const getLastFiveYears = (data: RevenueForecastItem[]): string[] => {
        const years = new Set<string>();
        
        data.forEach(forecast => {
          const forecastData = safeJsonParse(forecast.ForecastData, {});
          if (forecastData.yearly) {
            Object.keys(forecastData.yearly).forEach(year => {
              years.add(year);
            });
          }
        });
        
        // Sort years and get last 5
        const sortedYears = Array.from(years).sort();
        return sortedYears.slice(-5);
      };



      const exportDetailedItemsToExcel = (): void => { 
        const selectedYear = filterYear.value;
        const selectedMonth = filterMonth.value;
        
        if (!selectedYear || !selectedMonth) {
          toast("error", "Please select year and month to export");
          return;
        }

        // Use filtered data from pagination (current view)
        const exportData = filteredData.length > 0 ? filteredData : forecasts;
        
        if (exportData.length === 0) {
          toast("error", "No data available to export");
          return;
        }

        try {
          // Get current and next 2 months for detailed items
          const currentDate = new Date();
          const detailedMonths: string[] = [];
          for (let i = 0; i < 3; i++) {
            const monthDate = new Date(currentDate);
            monthDate.setMonth(monthDate.getMonth() + i);
            const monthKey = formatMonthKey(monthDate);
            if (monthKey) {
              detailedMonths.push(monthKey);
            }
          }

          // Get next 15 months for monthly totals
          const nextFifteenMonths: string[] = [];
          for (let i = 3; i < 18; i++) {
            const monthDate = new Date(currentDate);
            monthDate.setMonth(monthDate.getMonth() + i);
            const monthKey = formatMonthKey(monthDate);
            if (monthKey) {
              nextFifteenMonths.push(monthKey);
            }
          }

          // Get last 5 years from actual forecast data
          const lastFiveYears = getLastFiveYearsFromForecastData(exportData);
 
          // Get month names for headers with safety checks
          const selectedMonthName = getMonthName(selectedMonth) || selectedMonth;
          const currentMonthName = getMonthName(detailedMonths[0]?.split('-')[1] || '') || detailedMonths[0]?.split('-')[1] || '';
          const nextMonth1Name = getMonthName(detailedMonths[1]?.split('-')[1] || '') || detailedMonths[1]?.split('-')[1] || '';
          const nextMonth2Name = getMonthName(detailedMonths[2]?.split('-')[1] || '') || detailedMonths[2]?.split('-')[1] || '';
          const currentMonthYear = detailedMonths[0]?.split('-')[0] || '';
          const nextMonth1Year = detailedMonths[1]?.split('-')[0] || '';
          const nextMonth2Year = detailedMonths[2]?.split('-')[0] || '';

          // Prepare data for Excel with two-row header structure
          const excelData: any[][] = [];

          // First row headers - REMOVED CURRENT MONTH TOTALS (L-M)
          const firstRowHeaders = [
            "SO/Project Ref", 
            "Project Name", 
            "Customer Name",
            "Profit Centre", 
            "Group Head", 
            "Project Manager", 
            "OBL",
            
            // Selected month totals (4 columns) - H-K
            `${selectedMonthName} ${selectedYear} (P)`,
            `${selectedMonthName} ${selectedYear} (C)`,
            `${selectedMonthName} ${selectedYear} (R)`,
            `${selectedMonthName} ${selectedYear} (F)`,
            
            // Current month items section header - will be merged across 5 columns - L-P
            `${currentMonthName} ${currentMonthYear}`.toUpperCase(),
            "", "", "", "", // Placeholders for merged columns M-P
            
            // Next month 1 totals (2 columns) - Q-R
            `${nextMonth1Name} ${nextMonth1Year} (P)`,
            `${nextMonth1Name} ${nextMonth1Year} (C)`,
            
            // Next month 1 items section header - will be merged across 3 columns - S-U
            `${nextMonth1Name} ${nextMonth1Year}`.toUpperCase(),
            "", "", // Placeholders for merged columns T-U
            
            // Next month 2 totals (2 columns) - V-W
            `${nextMonth2Name} ${nextMonth2Year} (P)`,
            `${nextMonth2Name} ${nextMonth2Year} (C)`,
            
            // Next month 2 items section header - will be merged across 3 columns - X-Z
            `${nextMonth2Name} ${nextMonth2Year}`.toUpperCase(),
            "", "", // Placeholders for merged columns Y-Z
          ];

          // Add next 15 months headers (P and C for each month) - starting from column AA
          nextFifteenMonths.forEach(monthKey => {
            const [year, month] = monthKey.split('-');
            const monthLabel = getMonthName(month) || month;
            firstRowHeaders.push(`${monthLabel} ${year} (P)`, `${monthLabel} ${year} (C)`);
          });

          // Add 5-year headers (P and C for each year)
          lastFiveYears.forEach(year => {
            firstRowHeaders.push(`${year} (P)`, `${year} (C)`);
          });

          // Add Balance header
          firstRowHeaders.push("Balance");

          // Second row headers - UPDATED COLUMN POSITIONS
          const secondRowHeaders = [
            "", "", "", "", "", "", "", // Empty for first 7 columns (A-G)
            
            // Selected month totals (4 columns) - H-K
            "", "", "", "",
            
            // Current month items headers (5 columns) - L-P
            "Item Description", "Previous", "Current", "Forecast", "Date",
            
            // Next month 1 totals (2 columns) - Q-R
            "", "",
            
            // Next month 1 items headers (3 columns) - S-U
            "Item Description", "Previous", "Current",
            
            // Next month 2 totals (2 columns) - V-W
            "", "",
            
            // Next month 2 items headers (3 columns) - X-Z
            "Item Description", "Previous", "Current",
          ];

          // Add empty headers for next 15 months and 5 years
          const remainingColumns = firstRowHeaders.length - secondRowHeaders.length;
          for (let i = 0; i < remainingColumns; i++) {
            secondRowHeaders.push("");
          }

          excelData.push(firstRowHeaders);
          excelData.push(secondRowHeaders);

          // Prepare detailed data with merged project information
          exportData.forEach(forecast => {
            const projectTitle = forecast.Project?.Title || "-";
            const proj = projects.find(p => p.Title === projectTitle);
            
            // Parse data from both sources
            const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
            const revenueActualData = safeJsonParse(forecast.RevenueActual, {});
            
            // Get OBL value from database
            const oblValue = forecast.OBL || 0;

            // Get data for detailed months with safety checks
            const detailedMonthsData: any[] = [];
            for (let i = 0; i < 3; i++) {
              const monthKey = detailedMonths[i];
              if (monthKey) {
                const monthForecastData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0, items: createEmptyItems() };
                const monthActualData = revenueActualData[monthKey] || 0;
                detailedMonthsData.push({
                  plan: monthForecastData.plan || 0,
                  current: monthForecastData.actual || 0,
                  actual: monthActualData,
                  forecast: monthForecastData.forecast || 0,
                  items: monthForecastData.items || createEmptyItems()
                });
              } else {
                detailedMonthsData.push({
                  plan: 0,
                  current: 0,
                  actual: 0,
                  forecast: 0,
                  items: createEmptyItems()
                });
              }
            }

            // Calculate total current value for balance
            const totalMonthlyCurrent = Object.keys(forecastData)
              .filter(key => key.match(/^\d{4}-\d{2}$/))
              .reduce((sum, monthKey) => {
                const monthData = forecastData[monthKey] as ForecastMonthData;
                return sum + (monthData?.actual || 0);
              }, 0);

            const totalYearlyCurrent = forecastData.yearly ? 
              Object.values(forecastData.yearly).reduce((sum: number, yearData: any) => {
                return sum + (yearData.actual || 0);
              }, 0) : 0;

            const balance = oblValue - (totalMonthlyCurrent + totalYearlyCurrent);

            // Create one row for each item (1-10)
            for (let itemNum = 1; itemNum <= 10; itemNum++) {
              const itemKey = itemNum.toString();
              
              const rowData: any[] = [
                // Base information (7 columns) - A-G
                proj?.ProjectReference || "-",
                projectTitle,
                proj?.CustomerName || "-",
                forecast.ProfitCentre || "-",
                proj?.GroupHead || "-",
                typeof proj?.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-",
                oblValue,
                
                // Selected month totals (4 columns) - H-K
                detailedMonthsData[0]?.plan || 0,
                detailedMonthsData[0]?.current || 0,
                detailedMonthsData[0]?.actual || 0,
                detailedMonthsData[0]?.forecast || 0,
              ];

              // Current month items (5 columns) - L-P (previously N-R)
              const currentMonthItems = detailedMonthsData[0]?.items || createEmptyItems();
              const currentMonthItem = currentMonthItems[itemKey] || { name: '', plan: 0, actual: 0, forecast: 0, date: '' };
              rowData.push(
                currentMonthItem.name || `Item ${itemNum}`,
                currentMonthItem.plan,
                currentMonthItem.actual,
                currentMonthItem.forecast || 0,
                currentMonthItem.date || ""
              );

              // Next month 1 totals (2 columns) - Q-R (previously S-T)
              rowData.push(
                detailedMonthsData[1]?.plan || 0,
                detailedMonthsData[1]?.current || 0
              );

              // Next month 1 items (3 columns) - S-U (previously U-W)
              const nextMonth1Items = detailedMonthsData[1]?.items || createEmptyItems();
              const nextMonth1Item = nextMonth1Items[itemKey] || { name: '', plan: 0, actual: 0 };
              rowData.push(
                nextMonth1Item.name || `Item ${itemNum}`,
                nextMonth1Item.plan,
                nextMonth1Item.actual
              );

              // Next month 2 totals (2 columns) - V-W (previously X-Y)
              rowData.push(
                detailedMonthsData[2]?.plan || 0,
                detailedMonthsData[2]?.current || 0
              );

              // Next month 2 items (3 columns) - X-Z (previously Z-AB)
              const nextMonth2Items = detailedMonthsData[2]?.items || createEmptyItems();
              const nextMonth2Item = nextMonth2Items[itemKey] || { name: '', plan: 0, actual: 0 };
              rowData.push(
                nextMonth2Item.name || `Item ${itemNum}`,
                nextMonth2Item.plan,
                nextMonth2Item.actual
              );

              // Add next 15 months data (P and C for each month) - starting from column AA
              nextFifteenMonths.forEach(monthKey => {
                const monthForecastData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
                rowData.push(
                  monthForecastData.plan || 0,
                  monthForecastData.actual || 0
                );
              });

              // Add 5-year data (P and C for each year)
              lastFiveYears.forEach(year => {
                const yearData = forecastData.yearly?.[year] || { plan: 0, actual: 0 };
                rowData.push(
                  yearData.plan,
                  yearData.actual
                );
              });

              // Add Balance - only for first item of each project, empty for others
              if (itemNum === 1) {
                rowData.push(balance);
              } else {
                rowData.push("");
              }

              excelData.push(rowData);
            }
          });

          if (excelData.length <= 2) {
            toast("info", "No detailed items data found for export");
            return;
          } 
          // Create workbook
          const wb = XLSX.utils.book_new();
          const ws = XLSX.utils.aoa_to_sheet(excelData);

          // Define styles
          const mainHeaderStyle = {
            fill: { fgColor: { rgb: "FF0078D4" } },
            font: { name: "Arial", sz: 10, bold: true, color: { rgb: "FFFFFFFF" } },
            alignment: { horizontal: "center", vertical: "center" },
            border: {
              top: { style: "thin", color: { rgb: "FF000000" } },
              left: { style: "thin", color: { rgb: "FF000000" } },
              bottom: { style: "thin", color: { rgb: "FF000000" } },
              right: { style: "thin", color: { rgb: "FF000000" } }
            }
          };

          const subHeaderStyle = {
            fill: { fgColor: { rgb: "FF0056B3" } },
            font: { name: "Arial", sz: 10, bold: true, color: { rgb: "FFFFFFFF" } },
            alignment: { horizontal: "center", vertical: "center" },
            border: {
              top: { style: "thin", color: { rgb: "FF000000" } },
              left: { style: "thin", color: { rgb: "FF000000" } },
              bottom: { style: "thin", color: { rgb: "FF000000" } },
              right: { style: "thin", color: { rgb: "FF000000" } }
            }
          };

          const dataStyle = {
            font: { name: "Arial", sz: 10 },
            alignment: { horizontal: "center", vertical: "center" },
            border: {
              top: { style: "thin", color: { rgb: "FFD0D0D0" } },
              left: { style: "thin", color: { rgb: "FFD0D0D0" } },
              bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
              right: { style: "thin", color: { rgb: "FFD0D0D0" } }
            }
          };

          const numberStyle = {
            ...dataStyle,
            alignment: { horizontal: "right", vertical: "center" }
          };

          const textStyle = {
            ...dataStyle,
            alignment: { horizontal: "left", vertical: "center" }
          };

          // Apply styles to all cells
          const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
          
          // Style first header row (row 0)
          for (let col = range.s.c; col <= range.e.c; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            if (!ws[cellAddress]) continue;
            if (!ws[cellAddress].s) ws[cellAddress].s = {};
            ws[cellAddress].s = mainHeaderStyle;
          }
          
          // Style second header row (row 1)
          for (let col = range.s.c; col <= range.e.c; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 1, c: col });
            if (!ws[cellAddress]) continue;
            if (!ws[cellAddress].s) ws[cellAddress].s = {};
            ws[cellAddress].s = subHeaderStyle;
          }
          
          // Style data rows (starting from row 2)
          for (let row = range.s.r + 2; row <= range.e.r; row++) {
            for (let col = range.s.c; col <= range.e.c; col++) {
              const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
              if (!ws[cellAddress]) continue;
              
              // Determine column type for styling
              let styleToApply = dataStyle;
              
              // Text columns: Item Description columns and text fields
              if (col === 0 || col === 1 || col === 2 || // SO/Project Ref, Project Name, Customer Name
                  col === 11 || col === 17 || col === 23) { // Item Description columns (updated positions)
                styleToApply = textStyle;
              } 
              // Number columns: Previous, Current, Forecast, OBL, Month totals
              else if (col === 6 || // OBL
                      (col >= 7 && col <= 10) || // Selected month totals (H-K)
                      col === 12 || col === 13 || col === 14 || // Current month Previous, Current, Forecast (updated positions)
                      col === 18 || col === 19 || // Next month 1 Previous, Current (updated positions)
                      col === 24 || col === 25 || // Next month 2 Previous, Current (updated positions)
                      (col >= 26) // All remaining columns (next 15 months, 5 years, balance)
              ) {
                styleToApply = numberStyle;
              }
              
              if (!ws[cellAddress].s) {
                ws[cellAddress].s = {};
              }
              ws[cellAddress].s = styleToApply;
            }
          }

          // Set column widths - UPDATED FOR NEW STRUCTURE
          const colWidths = [
            { wch: 12 }, // A: SO/Project Ref
            { wch: 25 }, // B: Project Name
            { wch: 20 }, // C: Customer Name
            { wch: 12 }, // D: Profit Centre
            { wch: 15 }, // E: Group Head
            { wch: 15 }, // F: Project Manager
            { wch: 10 }, // G: OBL
            { wch: 12 }, // H: Selected Month (P)
            { wch: 12 }, // I: Selected Month (C)
            { wch: 12 }, // J: Selected Month (R)
            { wch: 12 }, // K: Selected Month (F)
            { wch: 20 }, // L: Current Month Item Description
            { wch: 10 }, // M: Current Month Previous
            { wch: 10 }, // N: Current Month Current
            { wch: 10 }, // O: Current Month Forecast
            { wch: 12 }, // P: Current Month Date
            { wch: 12 }, // Q: Next Month 1 (P)
            { wch: 12 }, // R: Next Month 1 (C)
            { wch: 20 }, // S: Next Month 1 Item Description
            { wch: 10 }, // T: Next Month 1 Previous
            { wch: 10 }, // U: Next Month 1 Current
            { wch: 12 }, // V: Next Month 2 (P)
            { wch: 12 }, // W: Next Month 2 (C)
            { wch: 20 }, // X: Next Month 2 Item Description
            { wch: 10 }, // Y: Next Month 2 Previous
            { wch: 10 }, // Z: Next Month 2 Current
          ];

          // Add widths for next 15 months (each month has 2 columns)
          for (let i = 0; i < nextFifteenMonths.length * 2; i++) {
            colWidths.push({ wch: 12 });
          }

          // Add widths for 5 years (each year has 2 columns)
          for (let i = 0; i < lastFiveYears.length * 2; i++) {
            colWidths.push({ wch: 12 });
          }

          // Add width for Balance
          colWidths.push({ wch: 12 });

          ws['!cols'] = colWidths;

          // Ensure merges array exists
          if (!ws['!merges']) {
            ws['!merges'] = [];
          }

          // UPDATED MERGE RANGES - REMOVED CURRENT MONTH TOTALS
          // Merge header cells for month sections ONLY
          ws['!merges'].push({ s: { r: 0, c: 11 }, e: { r: 0, c: 15 } }); // Current month header - spans 5 columns (L-P)
          ws['!merges'].push({ s: { r: 0, c: 17 }, e: { r: 0, c: 19 } }); // Next month 1 header - spans 3 columns (S-U)
          ws['!merges'].push({ s: { r: 0, c: 23 }, e: { r: 0, c: 25 } }); // Next month 2 header - spans 3 columns (X-Z)

          // Merge project information and totals (excluding item details)
          let currentRow = 2; // Start from first data row
          while (currentRow < excelData.length) {
            const endRow = Math.min(currentRow + 9, excelData.length - 1); // 10 rows per project
            
            // Merge project information (columns A-G)
            for (let col = 0; col < 7; col++) {
              if (currentRow < endRow && ws['!merges']) {
                ws['!merges'].push({ s: { r: currentRow, c: col }, e: { r: endRow, c: col } });
              }
            }
            
            // Merge ALL totals columns (selected month totals, detailed month totals, next 15 months, 5 years, balance)
            // Columns to merge: H-K (selected month totals), Q-R, V-W, and everything from column AA onwards
            const totalColumnsToMerge = [
              7, 8, 9, 10, // H-K: Selected month totals
              16, 17, // Q-R: Next month 1 totals
              21, 22, // V-W: Next month 2 totals
            ];
            
            // Add next 15 months and yearly columns (starting from column AA)
            const monthlyStartCol = 26; // Column AA (26 = 0-based index for AA)
            for (let col = monthlyStartCol; col < firstRowHeaders.length; col++) {
              totalColumnsToMerge.push(col);
            }
            
            // Apply all merges - WITH NULL CHECK
            totalColumnsToMerge.forEach(col => {
              if (currentRow < endRow && ws['!merges']) {
                ws['!merges'].push({ s: { r: currentRow, c: col }, e: { r: endRow, c: col } });
              }
            });
            
            currentRow = endRow + 1; // Move to next project group
          }

          // Clear the placeholder cells in first row after merging
          for (let col = 12; col <= 15; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            delete ws[cellAddress];
          }
          for (let col = 18; col <= 19; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            delete ws[cellAddress];
          }
          for (let col = 24; col <= 25; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            delete ws[cellAddress];
          }

          // Freeze header rows and first few columns
          ws['!freeze'] = { x: 7, y: 2 };

          // Add worksheet to workbook
          XLSX.utils.book_append_sheet(wb, ws, "Detailed Items");

          // Generate filename and export
          const monthName = getMonthName(selectedMonth) || selectedMonth;
          const fileName = `Revenue_Forecast_Detailed_Items_${monthName}_${selectedYear}.xlsx`;
          
          XLSX.writeFile(wb, fileName); 
          toast("success", `Exported ${excelData.length - 2} detailed item records`);
          
        } catch (error) { 
          toast("error", "Failed to export detailed items data to Excel");
        }
      };
          
      // Helper function to get last 5 years from
      const getLastFiveYearsFromForecastData = (data: RevenueForecastItem[]): string[] => {
        const years = new Set<string>();
        
        data.forEach(forecast => {
          const forecastData = safeJsonParse(forecast.ForecastData, {});
          if (forecastData.yearly) {
            Object.keys(forecastData.yearly).forEach(year => {
              years.add(year);
            });
          }
        });
        
        // Sort years and get last 5
        const sortedYears = Array.from(years).sort();
        return sortedYears.slice(-5);
      };    

      // ======  PAGINATION FUNCTIONS ======

const initializePagination = (data: RevenueForecastItem[]): void => { 
  // Apply role filtering ONCE
  const roleFilteredData = filterDataByRole(data);
  filteredData = roleFilteredData; 
  calculateTotalPages();
  currentPage = 1;
  updatePaginationControls();
  renderCurrentPage();
  
  // Refresh totals header
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
};

const calculateTotalPages = (): void => {
  totalPages = Math.ceil(filteredData.length / pageSize);
};
const updatePaginationControls = (): void => {
  currentPageSpan.textContent = currentPage.toString();
  totalPagesSpan.textContent = totalPages.toString();
  
  const startItem = (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, filteredData.length);
  startItemSpan.textContent = startItem.toString();
  endItemSpan.textContent = endItem.toString();
  totalItemsSpan.textContent = filteredData.length.toString();
  
  // Update page size selector
  pageSizeSelect.value = pageSize.toString();
  
  // Enable/disable navigation buttons
  firstPageBtn.disabled = currentPage === 1;
  prevPageBtn.disabled = currentPage === 1;
  nextPageBtn.disabled = currentPage === totalPages;
  lastPageBtn.disabled = currentPage === totalPages;
  
  updatePageNumbers();
};

const updatePageNumbers = (): void => {
  pageNumbersDiv.innerHTML = '';
  
  const maxVisiblePages = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
  let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
  
  if (endPage - startPage + 1 < maxVisiblePages) {
    startPage = Math.max(1, endPage - maxVisiblePages + 1);
  }
  
  // Add "..." before first page if needed
  if (startPage > 1) {
    const dotsBtn = document.createElement('button');
    dotsBtn.className = 'page-number dots';
    dotsBtn.textContent = '...';
    dotsBtn.disabled = true;
    pageNumbersDiv.appendChild(dotsBtn);
  }
  
  for (let i = startPage; i <= endPage; i++) {
    const pageBtn = document.createElement('button');
    pageBtn.className = `page-number ${i === currentPage ? 'active' : ''}`;
    pageBtn.textContent = i.toString();
    pageBtn.addEventListener('click', () => goToPage(i));
    pageNumbersDiv.appendChild(pageBtn);
  }
  
  // Add "..." after last page if needed
  if (endPage < totalPages) {
    const dotsBtn = document.createElement('button');
    dotsBtn.className = 'page-number dots';
    dotsBtn.textContent = '...';
    dotsBtn.disabled = true;
    pageNumbersDiv.appendChild(dotsBtn);
  }
};

const goToPage = (page: number): void => {
  if (page < 1 || page > totalPages || page === currentPage) return;
  
  currentPage = page;
  updatePaginationControls();
  renderCurrentPage();
  
  // Scroll to top of table
  const tableContainer = document.querySelector('.table-container-rev') as HTMLElement;
  if (tableContainer) {
    tableContainer.scrollTop = 0;
  }
};
 
const changePageSize = (newSize: number): void => {
  if (newSize === pageSize) return;
  
  pageSize = newSize;
  
  // Calculate new page number to keep the same first item visible
  const oldStartItem = (currentPage - 1) * pageSize;
  currentPage = Math.floor(oldStartItem / pageSize) + 1;
  
  calculateTotalPages();
  
  // Adjust current page if it exceeds new total pages
  if (currentPage > totalPages) {
    currentPage = totalPages || 1;
  }
  
  updatePaginationControls();
  renderCurrentPage();
  
  toast("info", `Showing ${pageSize} records per page`);
};

const renderCurrentPage = (): void => {
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, filteredData.length);
  const pageData = filteredData.slice(startIndex, endIndex); 
  renderTableWithMonthColumns(pageData);
};
const setupPaginationEventListeners = (): void => {
  // Navigation buttons
  firstPageBtn.addEventListener("click", () => goToPage(1));
  prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
  nextPageBtn.addEventListener("click", () => goToPage(currentPage + 1));
  lastPageBtn.addEventListener("click", () => goToPage(totalPages));
  
  // Page size selector
  pageSizeSelect.addEventListener("change", (e) => {
    const newSize = parseInt((e.target as HTMLSelectElement).value);
    changePageSize(newSize);
  });
};

// ========== TABLE RENDERING FUNCTIONS ==========
// Define checkEditPermission function BEFORE renderTableWithMonthColumns
const checkEditPermission = (forecast: RevenueForecastItem): boolean => {
  if (currentUser.isSuperAdmin) { 
    return true;
  }

  const projectTitle = forecast.Project?.Title;
  if (!projectTitle) return false;

  const project = projects.find(p => p.Title === projectTitle);
  if (!project) return false;

  if (currentUser.isGroupHead) { 
    // Group Head can edit projects in their managed groups
    return currentUser.managedGroups?.some(group => 
      project.GroupHead === group
    ) || false;
  }

  if (currentUser.isProjectManager) { 
    // Project Manager can edit only their assigned projects
    return currentUser.managedProjects?.includes(projectTitle) || false;
  }

  return false;
};

// Helper function to calculate totals
const calculateTotals = (
  data: RevenueForecastItem[],
  displayMonths: string[],
  currentMonthKey: string
): any => {

  let dataToCalculate = currentUser.isSuperAdmin
    ? data
    : filterDataByRole(data);

  const totals = {
    obl: 0,
    actualRevenue: 0,
    monthly: {} as {
      [key: string]: { plan: number; current: number; forecast: number; total: number }
    }
  };

  // Init months
  displayMonths.forEach(monthKey => {
    totals.monthly[monthKey] = { plan: 0, current: 0, forecast: 0, total: 0 };
  });

  dataToCalculate.forEach(forecast => {

    // ✅ ROUND OBL
    totals.obl += Math.round(Number(forecast.OBL) || 0);

    const forecastData = safeJsonParse(forecast.ForecastData, {});

    displayMonths.forEach(monthKey => {
      const m = forecastData[monthKey] || {};
      const isCurrent = monthKey === currentMonthKey;

      const plan = Math.round(Number(m.plan) || 0);
      const current = Math.round(Number(m.actual) || 0);
      const forecastVal = Math.round(Number(m.forecast) || 0);

      totals.monthly[monthKey].plan += plan;
      totals.monthly[monthKey].current += current;

      if (isCurrent) {
        totals.monthly[monthKey].forecast += forecastVal;
        totals.monthly[monthKey].total += plan + current + forecastVal;
      } else {
        totals.monthly[monthKey].total += plan + current;
      }
    });
  });

  return totals;
};
 
const renderTotalsHeader = (displayMonths: string[], currentMonthKey: string): void => {
  const totalsHeader = document.querySelector("#totalsHeader") as HTMLElement;
  if (!totalsHeader) return;

  totalsHeader.innerHTML = '';

  // Get all data and apply role filtering
  const allData = forecasts;
  const roleFiltered = filterDataByRole(allData);
  const filtered = filteredData.length ? filteredData : roleFiltered;

  const allTotals = calculateTotals(allData, displayMonths, currentMonthKey);
  const filteredTotals = calculateTotals(filtered, displayMonths, currentMonthKey);

  const showPM = currentUser.isSuperAdmin || !currentUser.isProjectManager;
  const showGH = currentUser.isSuperAdmin || !currentUser.isGroupHead;

  const buildTotalsRow = (label: string, totals: any, css: string) => `
    <tr class="${css}">
      <!-- Project -->
      <td class="totals-label">${label}</td>

      <!-- Customer -->
      <td></td>

      ${showPM ? `<td></td>` : ''}
      ${showGH ? `<td></td>` : ''}

      <!-- Project Reference -->
      <td></td>

      <!-- OBL -->
      <td class="total-value">${totals.obl.toLocaleString('en-IN')}</td>

      <!-- Actual Revenue -->
      <td class="total-value">${totals.actualRevenue.toLocaleString('en-IN')}</td>

      <!-- Months -->
      ${displayMonths.map(m => {
        const isCurrent = m === currentMonthKey;
        const t = totals.monthly[m] || { plan: 0, current: 0, forecast: 0, total: 0 };

        return isCurrent
          ? `
            <td>${t.plan}</td>
            <td>${t.current}</td>
            <td>${t.forecast}</td>
            <td class="total-value">${t.total}</td>
          `
          : `
            <td>${t.plan}</td>
            <td>${t.current}</td>
            <td class="total-value">${t.total}</td>
          `;
      }).join('')}

      <!-- Actions -->
      <td></td>
    </tr>
  `;

  totalsHeader.innerHTML = `
    <table class="totals-header-table" style="width: 100%;">
      ${buildTotalsRow(`All`, allTotals, 'all-projects-total')}
      ${buildTotalsRow(`Filtered (${filtered.length})`, filteredTotals, 'filtered-total')}
    </table>
  `;
};

const renderTableWithMonthColumns = (data: RevenueForecastItem[]): void => {
  const roleFilteredForecasts = filterDataByRole(data); 
  if (!roleFilteredForecasts.length) {
    tableBody.innerHTML = `<tr><td colspan="20" style="text-align:center;padding:20px;">
      ${currentUser.isSuperAdmin ? 'No records found' : 
        currentUser.isGroupHead ? 'No records found in your groups' : 
        currentUser.isProjectManager ? 'No assigned projects found' : 
        'No access to view any records'}
    </td></tr>`; 
    const totalsHeader = document.querySelector("#totalsHeader") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = ''; 
    return;
  } 
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  
  // First, render the totals rows above the main header
  renderTotalsHeader(displayMonths, currentMonthKey);
  
  // Determine which columns to show based on role - MUST MATCH TOTALS HEADER
  const showProjectManagerColumn = currentUser.isSuperAdmin ? true : !currentUser.isProjectManager;
  const showGroupHeadColumn = currentUser.isSuperAdmin ? true : !currentUser.isGroupHead;
  
  // IMPORTANT: Count total columns to verify alignment
  let totalColumnCount = 0;
  
  // Count base columns
  totalColumnCount += 1; // Project
  totalColumnCount += 1; // Customer
  if (showProjectManagerColumn) totalColumnCount += 1;
  if (showGroupHeadColumn) totalColumnCount += 1;
  totalColumnCount += 1; // Project Reference
  totalColumnCount += 1; // OBL
  totalColumnCount += 1; // Actual Revenue
  
  // Count month columns
  displayMonths.forEach(monthKey => {
    const isCurrentMonth = monthKey === currentMonthKey;
    totalColumnCount += isCurrentMonth ? 4 : 3;
  });
  
  totalColumnCount += 1; // Actions 
  // Build main table header (rows 3 & 4 - after the 2 totals rows)
  const mainHeaderHTML = `
    <!-- ROW 3: Main Header Row 1 -->
    <tr>
      <!-- Project Column with Sort -->
      <th rowspan="2" class="project-info-cell">Project Reference</th>
      <th rowspan="2" class="project-info-cell">
        <div class="sort-header-container">
          <span class="header-label">Project</span>
          <div class="sort-buttons-container">
            <button class="sort-btn ${currentSortConfig.column === 'project' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                    data-sort="project" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn ${currentSortConfig.column === 'project' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                    data-sort="project" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Customer Column with Sort -->
      <th rowspan="2" class="project-info-cell">
        <div class="sort-header-container">
          <span class="header-label">Customer</span>
          <div class="sort-buttons-container">
            <button class="sort-btn ${currentSortConfig.column === 'customer' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                    data-sort="customer" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn ${currentSortConfig.column === 'customer' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                    data-sort="customer" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      ${showProjectManagerColumn ? `
        <th rowspan="2" class="project-info-cell">Project Manager</th>
      ` : ''}
      
      ${showGroupHeadColumn ? `
        <th rowspan="2" class="project-info-cell">Group Head</th>
      ` : ''}
      
      
      
      <!-- OBL Column with Sort -->
      <th rowspan="2" class="month-column-header">
        <div class="sort-header-container">
          <span class="header-label">OBL</span>
          <div class="sort-buttons-container">
            <button class="sort-btn ${currentSortConfig.column === 'obl' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                    data-sort="obl" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn ${currentSortConfig.column === 'obl' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                    data-sort="obl" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Actual Revenue Column with Sort -->
      <th rowspan="2" class="month-column-header">
        <div class="sort-header-container">
          <span class="header-label">Actual Revenue</span>
          <div class="sort-buttons-container">
            <button class="sort-btn ${currentSortConfig.column === 'actualRevenue' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                    data-sort="actualRevenue" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn ${currentSortConfig.column === 'actualRevenue' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                    data-sort="actualRevenue" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      ${displayMonths.map((month, monthIndex) => {
        const isCurrentMonth = month === currentMonthKey;
        const colspan = isCurrentMonth ? 4 : 3; // Current month has 4 columns, others have 3
        return `
          <th colspan="${colspan}" class="month-column-header ${isCurrentMonth ? 'current-month-header' : ''}">
            <div class="sort-header-container">
              <span class="header-label">${formatMonthLabel(new Date(month + "-01"))}</span>
              <div class="sort-buttons-container">
                <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                        data-sort="month" data-direction="asc" data-month-index="${monthIndex}" title="Sort by Month Total Ascending">▲</button>
                <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                        data-sort="month" data-direction="desc" data-month-index="${monthIndex}" title="Sort by Month Total Descending">▼</button>
              </div>
            </div>
            ${isCurrentMonth ? ' <span style="font-size:10px;color:#ffeb3b;">(Current Month)</span>' : ''}
          </th>
        `;
      }).join('')}
      <th rowspan="2">Actions</th>
    </tr>
    
    <!-- ROW 4: Main Header Row 2 (Sub-headers) -->
    <tr>
      ${displayMonths.map((month, monthIndex) => {
        const isCurrentMonth = month === currentMonthKey;
        if (isCurrentMonth) {
          return `
            <th class="month-subheader current-month-header-table">
              <div class="sort-header-container">
                <span>Previous</span>
                <div class="sort-buttons-container">
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Ascending">▲</button>
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader current-month-header-table">
              <div class="sort-header-container">
                <span>Current</span>
                <div class="sort-buttons-container">
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Ascending">▲</button>
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader current-month-header-table">
              <div class="sort-header-container">
                <span>Forecast</span>
                <div class="sort-buttons-container">
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'forecast' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="forecast" data-month-index="${monthIndex}" title="Sort Forecast Ascending">▲</button>
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'forecast' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="forecast" data-month-index="${monthIndex}" title="Sort Forecast Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader current-month-header-table">
              <div class="sort-header-container">
                <span>Total</span>
                <div class="sort-buttons-container">
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Ascending">▲</button>
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Descending">▼</button>
                </div>
              </div>
            </th>
          `;
        } else {
          return `
            <th class="month-subheader">
              <div class="sort-header-container">
                <span>Previous</span>
                <div class="sort-buttons-container">
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Ascending">▲</button>
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader">
              <div class="sort-header-container">
                <span>Current</span>
                <div class="sort-buttons-container">
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Ascending">▲</button>
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader">
              <div class="sort-header-container">
                <span>Total</span>
                <div class="sort-buttons-container">
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'asc' ? 'sort-asc active' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Ascending">▲</button>
                  <button class="sort-btn ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'desc' ? 'sort-desc active' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Descending">▼</button>
                </div>
              </div>
            </th>
          `;
        }
      }).join('')}
    </tr>
  `;

  // Set main header HTML
  monthColumnsHeader.innerHTML = mainHeaderHTML;

  // Verify column count
  const totalsRow1 = document.querySelector('.totals-row-above-header') as HTMLTableRowElement;
  const mainHeaderRow1 = document.querySelector('.month-columns-table-rev thead:nth-child(2) tr:nth-child(1)') as HTMLTableRowElement;
  
  if (totalsRow1 && mainHeaderRow1) {
    const totalsColumns = totalsRow1.querySelectorAll('td').length;
    const mainHeaderColumns = mainHeaderRow1.querySelectorAll('th').length;
     
    
    if (totalsColumns !== mainHeaderColumns) { 
    }
  }

  // Build table body with actual data
  let tableBodyHTML = '';

  roleFilteredForecasts.forEach((forecast, index) => {
    // ... (keep the existing table body rendering code exactly as you have it)
    
    const projectTitle = forecast.Project?.Title || "-";
    const proj = projects.find(p => p.Title === projectTitle);
    
    // Parse forecast data
    const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
    const revenueActualData = safeJsonParse(forecast.RevenueActual, {});
    
    // Get selected year and month for actual revenue
    const selectedYear = filterYear.value;
    const selectedMonth = filterMonth.value;
    const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
    const actualRevenue = selectedMonthKey ? revenueActualData[selectedMonthKey] || 0 : 0;
    const formattedOBL = Math.round(forecast.OBL || 0).toLocaleString('en-IN');
    const formattedActualRevenue = Math.round(actualRevenue || 0).toLocaleString('en-IN');
    
    // Start building the row
    let rowHTML = `
      <tr>
        <td class="project-info-cell">${getSafeString(proj?.ProjectReference)}</td>
        <td class="project-info-cell">${projectTitle}</td>
        <td class="project-info-cell">${getSafeString(proj?.CustomerName)}</td>
    `;

    // Add Project Manager column if visible
    if (showProjectManagerColumn) {
      rowHTML += `<td class="project-info-cell">${proj ? getSafeString(proj.ProjectManager) : "-"}</td>`;
    }

    // Add Group Head column if visible
    if (showGroupHeadColumn) {
      rowHTML += `<td class="project-info-cell">${proj ? getSafeString(proj.GroupHead) : "-"}</td>`;
    }

    rowHTML += `
        
        <td class="month-column-cell">${formattedOBL}</td>
        <td class="month-column-cell">${formattedActualRevenue}</td>
    `;

    // Add month columns data with totals
    displayMonths.forEach((monthKey, monthIndex) => {
      const monthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
      const isCurrentMonth = monthKey === currentMonthKey;
      
      // Calculate totals
      const planValue = monthData.plan || 0;
      const currentValue = monthData.actual || 0;
      const forecastValue = monthData.forecast || 0;
      
      if (isCurrentMonth) {
        // Current month: show plan, current, forecast, and total (plan + current + forecast)
        const totalValue = planValue + currentValue + forecastValue;
        rowHTML += `
          <td class="month-column-cell">${planValue}</td>
          <td class="month-column-cell">${currentValue}</td>
          <td class="month-column-cell">${forecastValue}</td>
          <td class="month-column-cell total-cell" style="font-weight: bold; background-color: #f0f8ff;">${totalValue}</td>
        `;
      } else {
        // Other months: show plan, current, and total (plan + current)
        const totalValue = planValue + currentValue;
        rowHTML += `
          <td class="month-column-cell">${planValue}</td>
          <td class="month-column-cell">${currentValue}</td>
          <td class="month-column-cell total-cell" style="font-weight: bold; background-color: #f5f5f5;">${totalValue}</td>
        `;
      }
    });

    // Add actions column - only show edit button if user has permission
    const canEdit = checkEditPermission(forecast);
    rowHTML += `
        <td class="actions-cell">
          ${canEdit ? `<button class="edit-btn edit-action-btn" data-id="${forecast.Id}">✏️ Edit</button>` : 
            '<span class="no-edit-permission" title="You do not have permission to edit this record">🔒</span>'}
        </td>
      </tr>
    `;

    tableBodyHTML += rowHTML;
  });

  tableBody.innerHTML = tableBodyHTML;
  
  // Attach event listeners
  attachSortButtonListeners();
  attachTableEventListeners();
};

 
const attachSortButtonListeners = (): void => {
  document.querySelectorAll('.sort-btn[data-sort]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const button = e.currentTarget as HTMLButtonElement;
      const sortColumn = button.dataset.sort;
      const direction = button.dataset.direction as 'asc' | 'desc';
      const subColumn = button.dataset.subcolumn;
      const monthIndex = button.dataset.monthIndex ? parseInt(button.dataset.monthIndex) : undefined;
      
      if (sortColumn && direction) {
        handleRevenueSort(sortColumn, direction, subColumn, monthIndex);
      }
    });
  });
};

const attachTableEventListeners = (): void => {
  tableBody.querySelectorAll(".edit-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const id = parseInt((btn as HTMLButtonElement).dataset.id!);
      editForecast(id);
    });
  });
};

const handleRevenueSort = (column: string, direction: 'asc' | 'desc', subColumn?: string, monthIndex?: number): void => {
  // Update current sort state
  currentSortConfig = {
    column,
    direction,
    subColumn,
    monthIndex
  };

  const dataToSort = filteredData.length > 0 ? filteredData : forecasts;
  
  if (dataToSort.length === 0) return;

  const sortedData = [...dataToSort].sort((a, b) => {
    let valueA: any = 0;
    let valueB: any = 0;

    switch (column) {
      case 'obl':
        valueA = a.OBL || 0;
        valueB = b.OBL || 0;
        break;
      
      case 'actualRevenue':
        const selectedYear = filterYear.value;
        const selectedMonth = filterMonth.value;
        const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
        
        if (selectedMonthKey) {
          const revenueA = safeJsonParse(a.RevenueActual, {});
          const revenueB = safeJsonParse(b.RevenueActual, {});
          valueA = revenueA[selectedMonthKey] || 0;
          valueB = revenueB[selectedMonthKey] || 0;
        } else {
          valueA = 0;
          valueB = 0;
        }
        break;
      
      case 'month':
        const displayMonths = getDisplayMonths();
        
        // Use the specific month index if provided, otherwise default to first month
        const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
        const monthKeyToUse = displayMonths[monthIndexToUse];
        
        const dataA = safeJsonParse(a.ForecastData, {});
        const dataB = safeJsonParse(b.ForecastData, {});
        const monthDataA = dataA[monthKeyToUse] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
        const monthDataB = dataB[monthKeyToUse] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
        
        if (subColumn) {
          switch (subColumn) {
            case 'plan':
              valueA = monthDataA.plan || 0;
              valueB = monthDataB.plan || 0;
              break;
            case 'current':
              valueA = monthDataA.actual || 0;
              valueB = monthDataB.actual || 0;
              break;
            case 'forecast':
              valueA = monthDataA.forecast || 0;
              valueB = monthDataB.forecast || 0;
              break;
            default:
              valueA = monthDataA.actual || 0;
              valueB = monthDataB.actual || 0;
          }
        } else {
          valueA = monthDataA.actual || 0;
          valueB = monthDataB.actual || 0;
        }
        break;
      
      case 'project':
        valueA = a.Project?.Title || "";
        valueB = b.Project?.Title || "";
        break;
      
      case 'customer':
        const projA = projects.find(p => p.Title === a.Project?.Title);
        const projB = projects.find(p => p.Title === b.Project?.Title);
        valueA = projA?.CustomerName || "";
        valueB = projB?.CustomerName || "";
        break;
      
      default:
        return 0;
    }

    if (typeof valueA === 'number' && typeof valueB === 'number') {
      return direction === 'asc' ? valueA - valueB : valueB - valueA;
    } else {
      // String comparison
      const strA = String(valueA).toLowerCase();
      const strB = String(valueB).toLowerCase();
      return direction === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
    }
  });

  if (filteredData.length > 0) {
    filteredData = sortedData;
  } else {
    forecasts = sortedData;
  }

  currentPage = 1;
  updatePaginationControls();
  renderCurrentPage();
  
  const sortDirectionText = direction === 'asc' ? 'Ascending' : 'Descending';
  let columnName = '';
  
  if (subColumn) {
    columnName = subColumn.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
  } else if (column === 'obl') {
    columnName = 'OBL';
  } else if (column === 'actualRevenue') {
    columnName = 'Actual Revenue';
  } else if (column === 'project') {
    columnName = 'Project';
  } else if (column === 'customer') {
    columnName = 'Customer';
  } else {
    const displayMonths = getDisplayMonths();
    const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
    const monthKey = displayMonths[monthIndexToUse];
    const monthDate = new Date(monthKey + "-01");
    columnName = formatMonthLabel(monthDate);
  }
  
  toast("info", `Sorted by ${columnName} (${sortDirectionText})`);
};
 
   
const clearFilters = (): void => {
  filterYear.value = "";
  filterMonth.value = "";
  filterProject.value = "";
  filterCustomer.value = "";
  filterProjectManager.value = "";
  filterGroupHead.value = "";
  filterProjectReference.value = "";
  
  // Reset sorting
  currentSortConfig = {
    column: '',
    direction: 'asc'
  };
  
  initializePagination(forecasts);
  
  // Refresh totals header
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
  
  toast("info", "All filters and sorting cleared");
};

      // ========== FORM MANAGEMENT FUNCTIONS ==========

      const showForm = (isEditMode: boolean = false): void => {
        formSection.style.display = "block";
        tableSection.style.display = "none";
        showFormBtn.style.display = "none";
        
        if (isEditMode) {
          formSection.classList.add('edit-mode');
          projectSelect.disabled = true;
          formTitle.textContent = "Edit Forecast";
        } else {
          formSection.classList.remove('edit-mode');
          projectSelect.disabled = false;
          formTitle.textContent = "Add Forecast";
        }
      };

      const hideForm = (): void => {
        formSection.style.display = "none";
        tableSection.style.display = "block";
        showFormBtn.style.display = "inline-block";
        formSection.classList.remove('edit-mode');
        projectSelect.disabled = false;
      };

      const resetForm = (): void => {
        editingId = null;
        form.reset();
        projectSelect.value = "";
        projectDetails.innerHTML = "";
        historicalContainer.innerHTML = "";
        firstRowContainer.innerHTML = "";
        remainingContainer.innerHTML = "";
        yearlyContainer.innerHTML = "";
        
        // Hide all forecast sections
        toggleForecastSections(false);
        
        const oblContainer = document.querySelector('.obl-section-container') as HTMLElement;
        oblContainer.className = 'obl-section-container hidden-section';
        oblLastMonthInput.removeAttribute('readonly');
        oblLastMonthInput.placeholder = "Enter OBL";
        setNumericValue(oblLastMonthInput, 0);
        
        const fieldNote = oblContainer.querySelector('.field-note') as HTMLElement;
        if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
        
        oblValidationMessage.textContent = "✅ All values are within OBL limit";
        oblValidationMessage.className = 'validation-message';
        
        updateOBLValidationDisplay();
      };
    
      // ========== VALIDATION FUNCTIONS ==========

      const calculateTotalCurrentValue = (): number => {
        let total = 0;
        
        // Include monthly actual values
        const editableMonths = allMonths.slice(3);
        
        editableMonths.forEach(monthKey => {
          const currentInputs = document.querySelectorAll<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]:not([readonly])`);
          currentInputs.forEach(input => {
            total += getNumericValue(input);
          });
        });
        
        // Include yearly actual values
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.yearly-current-input-rev:not([readonly])`);
        yearlyCurrentInputs.forEach(input => {
          total += getNumericValue(input);
        });
        
        return total;
      };

      const validateOBLLimit = (changedInput?: HTMLInputElement): boolean => {
        const oblValue = getNumericValue(oblLastMonthInput);
        const totalCurrent = calculateTotalCurrentValue();
        
        totalCurrentValueSpan.textContent = totalCurrent.toLocaleString();
        
        const remaining = oblValue - totalCurrent;
        remainingValueSpan.textContent = remaining.toLocaleString();
        
        if (oblValue === 0) {
          oblLineFill.style.width = `0%`;
          oblLineFill.className = 'line-fill';
          
          if (totalCurrent > 0) {
            showOBLErrorToast('⚠️ OBL is zero but current values exist. Please set OBL value.', true);
            blockAllCurrentInputs();
            return false;
          } else {
            const existingToast = document.querySelector('.obl-error-toast');
            if (existingToast) existingToast.remove();
            unblockAllCurrentInputs();
            return true;
          }
        }
        
        const percentage = Math.min((totalCurrent / oblValue) * 100, 100);
        oblLineFill.style.width = `${percentage}%`;
        
        oblLineFill.className = 'line-fill';
        if (percentage > 90) {
          oblLineFill.classList.add('danger');
        } else if (percentage > 75) {
          oblLineFill.classList.add('warning');
        }
        
        oblValidationMessage.className = 'validation-message';
        
        if (totalCurrent > oblValue) {
          const exceedAmount = totalCurrent - oblValue;
          showOBLErrorToast(`❌ Total current value exceeds OBL by ${exceedAmount.toLocaleString()}! Reduce values to continue.`);
          oblValidationMessage.classList.add('danger');
          blockIncreasingCurrentInputs(changedInput);
          return false;
        } else if (percentage > 90) {
          showOBLErrorToast('⚠️ OBL limit nearly reached! Consider reducing values.', true);
          oblValidationMessage.classList.add('warning');
          unblockAllCurrentInputs();
          return true;
        } else {
          const existingToast = document.querySelector('.obl-error-toast');
          if (existingToast) existingToast.remove();
          
          oblValidationMessage.textContent = '✅ All values are within OBL limit';
          unblockAllCurrentInputs();
          return true;
        }
      };

      const blockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-rev:not([readonly])');
        
        currentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
      };

      const blockIncreasingCurrentInputs = (allowedInput?: HTMLInputElement): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-rev:not([readonly])');
        
        currentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
        
        yearlyCurrentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
      };

      const unblockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([data-month="0"])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-rev');
        
        currentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
      };

      const allowInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
        const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
        const isIncreasing = newValue > oldValue;
        
        if (!isIncreasing) {
          return true;
        }
        
        const oblValue = getNumericValue(oblLastMonthInput);
        const currentTotal = calculateTotalCurrentValue();
        const increaseAmount = newValue - oldValue;
        
        return (currentTotal + increaseAmount) <= oblValue;
      };

   const allowItemInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
    const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
    const isIncreasing = newValue > oldValue;
    
    if (!isIncreasing) {
        return true;
    }
    
    const monthKey = input.dataset.month!;
    const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
    
    if (!mainCurrentInput) return true;
    
    const mainCurrentValue = getNumericValue(mainCurrentInput);
    const itemCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.item-current-input[data-month="${monthKey}"]`);
    
    let currentItemsTotal = 0;
    itemCurrentInputs.forEach(itemInput => {
        if (itemInput === input) {
            currentItemsTotal += newValue;
        } else {
            currentItemsTotal += getNumericValue(itemInput);
        }
    });
    
    return currentItemsTotal <= mainCurrentValue;
};

      const validateMonthItemTotals = (changedInput?: HTMLInputElement): boolean => {
        let allValid = true;
        
        for (let i = 3; i <= 5; i++) {
          if (i < allMonths.length) {
            const monthKey = allMonths[i];
            const monthValid = validateSingleMonthItems(monthKey, changedInput);
            if (!monthValid) {
              allValid = false;
            }
          }
        }
        
        return allValid;
      };

    const validateSingleMonthItems = (monthKey: string, changedInput?: HTMLInputElement): boolean => {
    const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
    const itemCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.item-current-input[data-month="${monthKey}"]`);
    
    if (!mainCurrentInput) return true;
    
    const mainCurrentValue = getNumericValue(mainCurrentInput);
    let itemsTotal = 0;
    
    itemCurrentInputs.forEach(input => {
        itemsTotal += getNumericValue(input);
    });
    
    let validationDisplay = document.querySelector(`.month-total-validation[data-month="${monthKey}"]`) as HTMLDivElement;
    if (!validationDisplay) {
        validationDisplay = document.createElement('div');
        validationDisplay.className = 'month-total-validation';
        validationDisplay.setAttribute('data-month', monthKey);
        
        const monthBlock = mainCurrentInput.closest('.month-block');
        if (monthBlock) {
            const existingValidation = monthBlock.querySelector('.month-total-validation');
            if (existingValidation) {
                existingValidation.remove();
            }
            monthBlock.appendChild(validationDisplay);
        }
    }
    
    if (itemsTotal > mainCurrentValue) {
        validationDisplay.textContent = `❌ Items total (${itemsTotal}) exceeds Month current (${mainCurrentValue})! Reduce item values to continue.`;
        validationDisplay.className = 'month-total-validation month-total-invalid';
        
        blockIncreasingMonthItemInputs(monthKey, changedInput);
        return false;
    } else if (itemsTotal === mainCurrentValue && itemsTotal > 0) {
        validationDisplay.textContent = `✅ Items total matches Month current: ${itemsTotal}`;
        validationDisplay.className = 'month-total-validation month-total-valid';
        unblockAllMonthItemInputs(monthKey);
        return true;
    } else {
        validationDisplay.textContent = `📊 Items total: ${itemsTotal} / ${mainCurrentValue}`;
        validationDisplay.className = 'month-total-validation month-total-valid';
        unblockAllMonthItemInputs(monthKey);
        return true;
    }
};
const blockIncreasingMonthItemInputs = (monthKey: string, allowedInput?: HTMLInputElement): void => {
    const itemInputs = document.querySelectorAll<HTMLInputElement>(`input.item-current-input[data-month="${monthKey}"]`);
    
    itemInputs.forEach(input => {
        if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
        } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
        }
    });
};

      const unblockAllMonthItemInputs = (monthKey: string): void => {
    const itemInputs = document.querySelectorAll<HTMLInputElement>(`input.item-current-input[data-month="${monthKey}"]`);
    
    itemInputs.forEach(input => {
        input.style.backgroundColor = '';
        input.style.cursor = '';
        input.removeAttribute('data-block-increase');
        input.removeAttribute('readonly');
    });
};

      const updateOBLValidationDisplay = (changedInput?: HTMLInputElement): void => {
        validateOBLLimit(changedInput);
        validateMonthItemTotals(changedInput);
      };

      // ========== FORECAST FORM FUNCTIONS ==========

       const onProjectChange = (projectId: number, existingForecast?: RevenueForecastItem): void => {
        const project = projects.find(p => p.Id === projectId);
        if (!project) return;

        // Show all forecast sections when project is selected
        toggleForecastSections(true);

        renderProjectDetails(project);
        
        let forecastData: ForecastData = {};
        if (existingForecast) {
          forecastData = safeJsonParse(existingForecast.ForecastData, {});
        }

        const isNewProject = !existingForecast;
        
        const oblContainer = document.querySelector('.obl-section-container') as HTMLElement;
        const fieldNote = oblContainer.querySelector('.field-note') as HTMLElement;
        
        if (isNewProject) {
          oblContainer.className = 'obl-section-container visible-section new-project';
          oblLastMonthInput.removeAttribute('readonly');
          oblLastMonthInput.placeholder = "Enter initial OBL for new project";
          if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
          oblValidationMessage.textContent = "Enter initial OBL value for new project";
          oblValidationMessage.className = 'validation-message';
          
          const defaultOBL = project.PC ? 100000 : 0;
          setNumericValue(oblLastMonthInput, defaultOBL);
        } else {
          oblContainer.className = 'obl-section-container visible-section existing-project';
          oblLastMonthInput.setAttribute('readonly', 'true');
          
          const oblValue = existingForecast?.OBL || 0;
          setNumericValue(oblLastMonthInput, oblValue);
          
          oblLastMonthInput.placeholder = "OBL from database";
          if (fieldNote) fieldNote.textContent = "OBL value from database record";
          
          if (oblValue > 0) {
            oblLastMonthInput.value = oblValue.toString();
            oblLastMonthInput.className = oblLastMonthInput.className.replace('input-empty', 'input-with-value');
          }
        }

        renderForecastInterface(forecastData, getNumericValue(oblLastMonthInput), existingForecast);
      };

      // Add this function to show/hide forecast sections
      const toggleForecastSections = (show: boolean): void => {
        const sections = [
          '.obl-section-container',
          '#historicalForecastSection',
          '#detailedForecastSection', 
          '#longtermForecastSection',
          '#yearlyForecastSection'
        ];
        
        sections.forEach(selector => {
          const element = document.querySelector(selector) as HTMLElement;
          if (element) {
            if (show) {
              element.classList.remove('hidden-section');
              element.classList.add('visible-section');
            } else {
              element.classList.remove('visible-section');
              element.classList.add('hidden-section');
            }
          }
        });
      };
      const renderProjectDetails = (project: ProjectItem): void => { 
        projectDetails.innerHTML =
          `<p><b>Profit Center:</b> ${project.PC || "-"}</p>
           <p><b>Customer:</b> ${project.CustomerName || "-"}</p>
           <p><b>Project Ref:</b> ${project.ProjectReference || "-"}</p>
           <p><b>Group Head:</b> ${project.GroupHead || "-"}</p>
           <p><b>Project Manager:</b> ${typeof project.ProjectManager === "object" ? project.ProjectManager?.Title : project.ProjectManager || "-"}</p>`;
      };

      const getForecastMonths = (): string[] => {
        return generateIdealMonthStructure();
      };

      const renderForecastInterface = (existingData: ForecastData, displayOBL: number, existingForecast?: RevenueForecastItem): void => {
        allMonths = getForecastMonths();
        
        setNumericValue(oblLastMonthInput, displayOBL);

        renderHistoricalMonths(allMonths.slice(0, 3), existingData);
        renderFirstRow(allMonths.slice(3, 6), existingData);
        renderRemainingMonths(allMonths.slice(6), existingData);
        renderYearlyForecast(existingData.yearly || createFreshYearlyStructure(getLastMonthKey(existingData)));

        // Protect historical elements from any interactions
        protectHistoricalElements();
        
        updateOBLValidationDisplay();
        attachForecastEventListeners();
      };

      const protectHistoricalElements = (): void => {
        // Remove any existing event listeners from historical elements by cloning and replacing
        document.querySelectorAll('.historical-month input, .historical-month select, .historical-month button').forEach(element => {
          const newElement = element.cloneNode(true) as HTMLElement;
          element.parentNode?.replaceChild(newElement, element);
        });
        
        // Add global event prevention for historical sections
        document.querySelectorAll('.historical-month').forEach(section => {
          section.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toast("warning", "Historical data cannot be modified");
            return false;
          });
          
          section.addEventListener('keydown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            return false;
          });
          
          section.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            return false;
          });
        });
      };

      const renderHistoricalMonths = (months: string[], existingData: ForecastData): void => {
        let html = '';

        months.forEach((monthKey, index) => {
          const monthDate = new Date(monthKey + "-01");
          const monthLabel = formatMonthLabel(monthDate);
          const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, items: {} };
          
          html += renderHistoricalMonthBox(monthKey, monthLabel, data, index);
        });

        historicalContainer.innerHTML = html;
      };

// Update renderHistoricalMonthBox to handle all 10 items
const renderHistoricalMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, index: number): string => {
    const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
    const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
    const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
    const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
    
    const items = data.items || createEmptyItems();
    
    return `
      <div class="month-box-rev historical-month">
        <div class="month-header-rev">${monthLabel} (Historical - Readonly)</div>
        
        <div class="month-block">
          <div class="main-inputs-container-rev">
            <div class="main-input-group-rev">
              <label>Previous</label>
              <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                    readonly class="main-plan-input ${planInputClass} number-input" />
            </div>
            <div class="main-input-group-rev">
              <label>Current</label>
              <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                    readonly class="main-current-input ${actualInputClass} number-input" />
            </div>
          </div>
        </div>

        <div class="items-section historical-items-section">
          <div class="items-header historical-items-header">
            <div>Item Description</div>
            <div>Previous</div>
            <div>Current</div>
          </div>
          
          ${Array.from({length: 10}, (_, i) => {
            const itemNum = i + 1;
            const itemKey = itemNum.toString(); // Convert to string for object key access
            const item = items[itemKey] || { name: '', plan: 0, actual: 0 };
            const itemPlanValue = item.plan > 0 ? item.plan.toString() : '';
            const itemActualValue = item.actual > 0 ? item.actual.toString() : '';
            const itemPlanClass = item.plan > 0 ? 'input-with-value' : 'input-empty';
            const itemActualClass = item.actual > 0 ? 'input-with-value' : 'input-empty';
            const itemNameClass = item.name ? 'input-with-value' : 'input-empty';
            
            return `
              <div class="item-row historical-item-row">
                <input type="text" placeholder="Item ${itemNum}" value="${item.name}" data-item="${itemKey}" data-month="${monthKey}" readonly 
                      class="${itemNameClass}" />
                <input type="text" value="${itemPlanValue}" data-item-type="plan" data-item="${itemKey}" data-month="${monthKey}" 
                      readonly class="item-plan-input ${itemPlanClass} number-input" />
                <input type="text" value="${itemActualValue}" data-item-type="actual" data-item="${itemKey}" data-month="${monthKey}" 
                      readonly class="item-current-input ${itemActualClass} number-input" />
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
};

 // Updated function to render first row with 40%/60% split in one row
// Fixed function to render first row with 40%/60% split in one row
const renderFirstRow = (months: string[], existingData: ForecastData): void => {
  let html = '';

  // Create single row container for all three months
  html += `<div class="detailed-months-row">`;
  
  // Current Month - 40%
  const currentMonth = months[0];
  if (currentMonth) {
    const monthDate = new Date(currentMonth + "-01");
    const monthLabel = formatMonthLabel(monthDate);
    const data = existingData[currentMonth] as ForecastMonthData || { plan: 0, actual: 0, items: {} };
    
    html += `<div class="current-month-container">`;
    html += renderDetailedMonthBox(currentMonth, monthLabel, data, true); // true for current month
    html += `</div>`;
  }
  
  // Next 2 Months - 60% (split equally)
  html += `<div class="next-months-container">`;
  for (let i = 1; i <= 2; i++) {
    if (i < months.length) {
      const monthKey = months[i];
      const monthDate = new Date(monthKey + "-01");
      const monthLabel = formatMonthLabel(monthDate);
      const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, items: {} };
      
      html += `<div class="next-month-box">`;
      html += renderDetailedMonthBox(monthKey, monthLabel, data, false); // false for non-current months
      html += `</div>`;
    }
  }
  html += `</div>`;
  
  html += `</div>`;

  firstRowContainer.innerHTML = html;
};

      const renderRemainingMonths = (months: string[], existingData: ForecastData): void => {
        let html = '';

        for (let row = 0; row < 3; row++) {
          html += `<div class="remaining-row-rev">`;
          for (let col = 0; col < 5; col++) {
            const index = (row * 5) + col;
            if (index >= months.length) break;
            
            const monthKey = months[index];
            const monthDate = new Date(monthKey + "-01");
            const monthLabel = formatMonthLabel(monthDate);
            const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            
            html += renderSimpleMonthBox(monthKey, monthLabel, data);
          }
          html += `</div>`;
        }

        remainingContainer.innerHTML = html;
      };

      const renderYearlyForecast = (yearlyData: YearlyForecastData): void => {
        let html = '';

        const years = Object.keys(yearlyData).sort();
        
        years.forEach(year => {
          const data = yearlyData[year] || { plan: 0, actual: 0 };
          html += renderYearlyBox(year, data);
        });

        yearlyContainer.innerHTML = html;
      };

      const renderYearlyBox = (year: string, data: { plan: number; actual: number }): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
        const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
        
        return `
          <div class="yearly-box-rev">
            <div class="yearly-header-rev">${year}</div>
            
            <div class="yearly-inputs-container-rev">
              <div class="yearly-input-group-rev">
                <label>Previous</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-year="${year}"
                      readonly class="yearly-plan-input-rev ${planInputClass} number-input" />
              </div>
              <div class="yearly-input-group-rev">
                <label>Current</label>
                <input type="text" value="${displayActualValue}" data-type="actual" data-year="${year}"
                      class="yearly-current-input-rev ${actualInputClass} number-input" />
              </div>
            </div>
          </div>
        `;
      };

// Update the renderDetailedMonthBox function to display all 10 items
const renderDetailedMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, isCurrentMonth: boolean = false): string => {
    const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
    const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
    const displayForecastValue = data.forecast || 0;
    const displayDateValue = data.date || '';
    
    const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
    const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
    const forecastInputClass = displayForecastValue > 0 ? 'input-with-value' : 'input-empty';
    const dateInputClass = displayDateValue ? 'input-with-value' : 'input-empty';
    
    const items = data.items || createEmptyItems();
    
    return `
      <div class="detailed-month-box ${isCurrentMonth ? 'current-month-box' : 'next-month-box'}">
        <div class="month-header-rev">
          ${monthLabel}
          ${isCurrentMonth ? '<span class="current-month-indicator">Current</span>' : ''}
        </div>
        
        <div class="month-block">
          <div class="enhanced-inputs-container">
            <!-- Previous Column -->
            <div class="enhanced-input-group">
              <label>Previous</label>
              <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                    readonly class="main-plan-input ${planInputClass} number-input" />
            </div>
            
            <!-- Current Column -->
            <div class="enhanced-input-group">
              <label>Current</label>
              <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                    class="main-current-input ${actualInputClass} number-input" />
            </div>
            
            <!-- Forecast Column - Only for Current Month -->
            ${isCurrentMonth ? `
              <div class="enhanced-input-group">
                <label>Forecast</label>
                <input type="text" value="${displayForecastValue}" data-type="forecast" data-month="${monthKey}"
                      class="main-forecast-input ${forecastInputClass} number-input" />
              </div>
              
              <!-- Date Column - Only for Current Month -->
              <div class="enhanced-input-group">
                <label>Date</label>
                <input type="date" value="${displayDateValue}" data-type="date" data-month="${monthKey}"
                      class="forecast-date-input ${dateInputClass}" />
              </div>
            ` : ''}
          </div>
          <div id="validation-${monthKey}" class="month-total-validation"></div>
        </div>

        <div class="items-section">
          <div class="items-header">
            <div>Item Description</div>
            <div>Previous</div>
            <div>Current</div>
            ${isCurrentMonth ? `
              <div>Forecast</div>
              <div>Date</div>
            ` : ''}
          </div>
          
          ${Array.from({length: 10}, (_, i) => i + 1).map(itemNum => {
            const item = items[itemNum] || { name: '', plan: 0, actual: 0, forecast: 0, date: '' };
            const itemPlanValue = item.plan > 0 ? item.plan.toString() : '';
            const itemActualValue = item.actual > 0 ? item.actual.toString() : '';
            const itemForecastValue = (item.forecast || 0) > 0 ? (item.forecast || 0).toString() : '';
            const itemDateValue = item.date || '';
            
            const itemPlanClass = item.plan > 0 ? 'input-with-value' : 'input-empty';
            const itemActualClass = item.actual > 0 ? 'input-with-value' : 'input-empty';
            const itemForecastClass = (item.forecast || 0) > 0 ? 'input-with-value' : 'input-empty';
            const itemDateClass = itemDateValue ? 'input-with-value' : 'input-empty';
            const itemNameClass = item.name ? 'input-with-value' : 'input-empty';
            
            return `
              <div class="item-row">
                <!-- Item Description -->
                <input type="text" placeholder="Item ${itemNum}" value="${item.name}" 
                      data-item="${itemNum}" data-month="${monthKey}" 
                      class="${itemNameClass}" />
                
                <!-- Previous (Plan) -->
                <input type="text" value="${itemPlanValue}" 
                      data-item-type="plan" data-item="${itemNum}" data-month="${monthKey}" 
                      readonly class="item-plan-input ${itemPlanClass} number-input" />
                
                <!-- Current (Actual) -->
                <input type="text" value="${itemActualValue}" 
                      data-item-type="actual" data-item="${itemNum}" data-month="${monthKey}" 
                      class="item-current-input ${itemActualClass} number-input" />
                
                <!-- Forecast - Only for Current Month -->
                ${isCurrentMonth ? `
                  <input type="text" value="${itemForecastValue}" 
                        data-item-type="forecast" data-item="${itemNum}" data-month="${monthKey}" 
                        class="item-forecast-input ${itemForecastClass} number-input" />
                  
                  <!-- Date - Only for Current Month -->
                  <input type="date" value="${itemDateValue}" 
                        data-item-type="date" data-item="${itemNum}" data-month="${monthKey}" 
                        class="item-date-input ${itemDateClass}" />
                ` : ''}
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
};

 


      const renderSimpleMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value' : 'input-empty';
        const actualInputClass = data.actual > 0 ? 'input-with-value' : 'input-empty';
        
        return `
          <div class="month-box-rev simple-month-rev">
            <div class="month-header-rev">${monthLabel}</div>
            
            <div class="main-inputs-container-rev">
              <div class="main-input-group-rev">
                <label>Previous</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}" 
                      readonly class="main-plan-input ${planInputClass} number-input" />
              </div>
              <div class="main-input-group-rev">
                <label>Current</label>
                <input type="text" value="${displayActualValue}"  id="actualCurrent" data-type="actual" data-month="${monthKey}" 
                      class="main-current-input ${actualInputClass} number-input" />
              </div>
            </div>
          </div>
        `;
      };

const attachForecastEventListeners = (): void => {
    // Apply number validation to all number inputs
    document.querySelectorAll<HTMLInputElement>('.number-input').forEach(input => {
        allowOnlyNumbers(input);
    });

    // Set up focus handlers for all number inputs to store old values
    document.querySelectorAll<HTMLInputElement>('.number-input:not([readonly])').forEach(input => {
        input.addEventListener('focus', function() {
            this.setAttribute('data-old-value', getNumericValue(this).toString());
        });
    });

     



// ===== MAIN CURRENT INPUTS =====
    document.querySelectorAll<HTMLInputElement>('.main-current-input:not([readonly])').forEach(input => {
        input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
                const allowByOBL = allowInputIncrease(this, currentValue);
                
                if (!allowByOBL) {
                    setNumericValue(this, oldValue);
                    updateOBLValidationDisplay(this);
                    return;
                }
            }
            
            // Update visual state
            if (currentValue === 0) {
                this.className = this.className.replace('input-with-value', 'input-empty');
            } else {
                this.className = this.className.replace('input-empty', 'input-with-value');
            }

            updateOBLValidationDisplay(this);
        });
    });

    // ===== MAIN FORECAST INPUTS (Only in current month) =====
    document.querySelectorAll<HTMLInputElement>('.main-forecast-input:not([readonly])').forEach(input => {
        input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
                const allowByOBL = allowInputIncrease(this, currentValue);
                
                if (!allowByOBL) {
                    setNumericValue(this, oldValue);
                    updateOBLValidationDisplay(this);
                    return;
                }
            }
            
            // Update visual state
            if (currentValue === 0) {
                this.className = this.className.replace('input-with-value', 'input-empty');
            } else {
                this.className = this.className.replace('input-empty', 'input-with-value');
            }

            updateOBLValidationDisplay(this);
        });
    });

    // ===== ITEM CURRENT INPUTS =====
    document.querySelectorAll<HTMLInputElement>('.item-current-input:not([readonly])').forEach(input => {
        input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
                const allowByOBL = allowInputIncrease(this, currentValue);
                const allowByMonth = allowItemInputIncrease(this, currentValue);
                
                if (!allowByOBL || !allowByMonth) {
                    setNumericValue(this, oldValue);
                    updateOBLValidationDisplay(this);
                    return;
                }
            }
            
            // Update visual state
            if (currentValue === 0) {
                this.className = this.className.replace('input-with-value', 'input-empty');
            } else {
                this.className = this.className.replace('input-empty', 'input-with-value');
            }

            updateOBLValidationDisplay(this);
        });
    });

    // ===== ITEM FORECAST INPUTS (Only in current month) =====
    document.querySelectorAll<HTMLInputElement>('.item-forecast-input:not([readonly])').forEach(input => {
        input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
                const allowByOBL = allowInputIncrease(this, currentValue);
                const allowByMonth = allowItemInputIncrease(this, currentValue);
                
                if (!allowByOBL || !allowByMonth) {
                    setNumericValue(this, oldValue);
                    updateOBLValidationDisplay(this);
                    return;
                }
            }
            
            // Update visual state
            if (currentValue === 0) {
                this.className = this.className.replace('input-with-value', 'input-empty');
            } else {
                this.className = this.className.replace('input-empty', 'input-with-value');
            }

            updateOBLValidationDisplay(this);
        });
    });

    // ===== YEARLY CURRENT INPUTS =====
    document.querySelectorAll<HTMLInputElement>('.yearly-current-input-rev:not([readonly])').forEach(input => {
        input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
                const allowByOBL = allowInputIncrease(this, currentValue);
                
                if (!allowByOBL) {
                    setNumericValue(this, oldValue);
                    updateOBLValidationDisplay(this);
                    return;
                }
            }
            
            // Update visual state
            if (currentValue === 0) {
                this.className = this.className.replace('input-with-value', 'input-empty');
            } else {
                this.className = this.className.replace('input-empty', 'input-with-value');
            }

            updateOBLValidationDisplay(this);
        });
    });

    // ===== MAIN DATE INPUTS (Only in current month) =====
    document.querySelectorAll<HTMLInputElement>('.forecast-date-input:not([readonly])').forEach(input => {
        input.addEventListener('change', function() {
            if (this.value === '') {
                this.className = this.className.replace('input-with-value', 'input-empty');
            } else {
                this.className = this.className.replace('input-empty', 'input-with-value');
            }
        });
    });

    // ===== ITEM DATE INPUTS (Only in current month) =====
    document.querySelectorAll<HTMLInputElement>('.item-date-input:not([readonly])').forEach(input => {
        input.addEventListener('change', function() {
            if (this.value === '') {
                this.className = this.className.replace('input-with-value', 'input-empty');
            } else {
                this.className = this.className.replace('input-empty', 'input-with-value');
            }
        });
    });

    // ===== ITEM NAME INPUTS =====
    document.querySelectorAll<HTMLInputElement>('input[data-item]:not([readonly])').forEach(input => {
        if (!input.classList.contains('number-input')) {
            input.addEventListener('input', function() {
                if (this.value === '') {
                    this.className = this.className.replace('input-with-value', 'input-empty');
                } else {
                    this.className = this.className.replace('input-empty', 'input-with-value');
                }
            });
        }
    });







    // ===== VALIDATION FOR ITEM TOTALS =====
    document.querySelectorAll<HTMLInputElement>('.main-current-input:not([readonly])').forEach(input => {
        input.addEventListener('input', function() {
            const monthKey = this.dataset.month;
            if (monthKey) {
                validateSingleMonthItems(monthKey, this);
            }
        });
    });

    document.querySelectorAll<HTMLInputElement>('.item-current-input:not([readonly])').forEach(input => {
        input.addEventListener('input', function() {
            const monthKey = this.dataset.month;
            if (monthKey) {
                validateSingleMonthItems(monthKey, this);
            }
        });
    });

    // ===== REAL-TIME OBL VALIDATION =====
    const validationInputs = document.querySelectorAll<HTMLInputElement>(`
        .main-current-input:not([readonly]),
        .item-current-input:not([readonly]),
        .yearly-current-input-rev:not([readonly]),
        .main-forecast-input:not([readonly]),
        .item-forecast-input:not([readonly])
    `);

    validationInputs.forEach(input => {
        input.addEventListener('input', function() {
            setTimeout(() => {
                updateOBLValidationDisplay(this);
            }, 100);
        });
    });
};

 
const editForecast = async (id: number): Promise<void> => {
    editingId = id;
    const forecast = forecasts.find(f => f.Id === id);
    if (!forecast) {
        toast("error", "Forecast not found");
        return;
    }

    showForm(true);
    
    let forecastData: ForecastData = {};
    
    try {
        let forecastDataString = forecast.ForecastData || "{}";
        forecastDataString = forecastDataString.trim();
        
        if (!forecastDataString || forecastDataString === '""' || forecastDataString === "null") {
            forecastDataString = "{}";
        }
        
        forecastData = JSON.parse(forecastDataString); 
    } catch (e) { 
        forecastData = createFreshForecastStructure();
        
        toast("warning", "Corrupted forecast data detected. Loaded empty structure.");
    }
    
    forecastData = propagateMonthValues(forecastData);
    
    const displayOBL = forecast.OBL || 0;
    
    console.log("Editing Forecast:", { 
        displayOBL 
    });
    
    if (forecast.Project) {
        projectSelect.value = String(forecast.Project.Id);
        onProjectChange(forecast.Project.Id, forecast);
    }
    
    toast("info", `Editing forecast for ${forecast.Title}`);
};

      // ========== FORM SUBMISSION ==========

form.addEventListener("submit", async (e: Event) => {
    e.preventDefault();
    
    const projectId = parseInt(projectSelect.value);
    const project = projects.find(p => p.Id === projectId);
    
    if (!project) {
        toast("error", "Please select a project");
        return;
    }

    const isNewProject = !editingId && !forecasts.some(f => f.Project?.Id === projectId);
    
    if (!isNewProject && forecasts.some(f => f.Project?.Id === projectId && f.Id !== editingId)) {
        toast("error", "Forecast already exists for this project!");
        return;
    }

    const oblValue = getNumericValue(oblLastMonthInput);
    if (isNewProject && oblValue === 0) {
        const confirmZeroOBL = await Swal.fire({
            icon: "question",
            title: "Zero OBL Value",
            text: "You're setting OBL to zero for a new project. This means there's no budget limit. Continue?",
            showCancelButton: true,
            confirmButtonText: "Yes, Continue",
            cancelButtonText: "No, Set OBL"
        });
        
        if (!confirmZeroOBL.isConfirmed) {
            oblLastMonthInput.focus();
            return;
        }
    }

    const totalCurrent = calculateTotalCurrentValue();
    
    if (oblValue > 0 && totalCurrent > oblValue) {
        toast("error", "Total current value cannot exceed OBL!");
        return;
    }

    let hasMonthValidationError = false;
    for (let i = 3; i <= 5; i++) {
        if (i < allMonths.length) {
            const monthKey = allMonths[i];
            const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
            const itemCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.item-current-input[data-month="${monthKey}"]`);
            
            if (mainCurrentInput) {
                const mainCurrentValue = getNumericValue(mainCurrentInput);
                let itemsTotal = 0;
                
                itemCurrentInputs.forEach(input => {
                    itemsTotal += getNumericValue(input);
                });
                
                if (itemsTotal > mainCurrentValue) {
                    hasMonthValidationError = true;
                    toast("error", `Items total exceeds month current value for ${formatMonthLabel(new Date(monthKey + "-01"))}!`);
                    break;
                }
            }
        }
    }

    if (hasMonthValidationError) {
        return;
    }

    try {
        const forecastData: ForecastData = {};

        const allStorageMonths = getAllMonthsForStorage(); 
        
        // Process monthly data including current month items with dates
        allStorageMonths.forEach(monthKey => {
            const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input[data-month="${monthKey}"]`);
            const mainPlanInput = document.querySelector<HTMLInputElement>(`input.main-plan-input[data-month="${monthKey}"]`);
            const mainForecastInput = document.querySelector<HTMLInputElement>(`input.main-forecast-input[data-month="${monthKey}"]`);
            const mainDateInput = document.querySelector<HTMLInputElement>(`input.forecast-date-input[data-month="${monthKey}"]`);
            
            if (mainCurrentInput && mainPlanInput) {
                const monthData: ForecastMonthData = {
                    plan: getNumericValue(mainPlanInput),
                    actual: getNumericValue(mainCurrentInput),
                    items: {}
                };

                // Add forecast if available (only for current month)
                if (mainForecastInput) {
                    monthData.forecast = getNumericValue(mainForecastInput);
                }

                // Add date if available (only for current month)
                if (mainDateInput && mainDateInput.value) {
                    monthData.date = mainDateInput.value;
                }

                // Process items for detailed months (index 3-5 in allMonths array = current + next 2 months)
                 // Process items for detailed months (index 3-5 in allMonths array = current + next 2 months)
const monthIndex = allStorageMonths.indexOf(monthKey);
if (monthIndex >= 3 && monthIndex <= 5) {
    for (let itemNum = 1; itemNum <= 10; itemNum++) {
        const itemKey = itemNum.toString();
        const itemNameInput = document.querySelector<HTMLInputElement>(`input[data-item="${itemKey}"][data-month="${monthKey}"]:not([data-item-type])`);
        const itemPlanInput = document.querySelector<HTMLInputElement>(`input.item-plan-input[data-item="${itemKey}"][data-month="${monthKey}"]`);
        const itemCurrentInput = document.querySelector<HTMLInputElement>(`input.item-current-input[data-item="${itemKey}"][data-month="${monthKey}"]`);
        const itemForecastInput = document.querySelector<HTMLInputElement>(`input.item-forecast-input[data-item="${itemKey}"][data-month="${monthKey}"]`);
        const itemDateInput = document.querySelector<HTMLInputElement>(`input.item-date-input[data-item="${itemKey}"][data-month="${monthKey}"]`);
        
        if (itemNameInput && itemPlanInput && itemCurrentInput) {
            const itemData: ForecastItem = {
                name: itemNameInput.value || '',
                plan: getNumericValue(itemPlanInput),
                actual: getNumericValue(itemCurrentInput)
            };

            // Add item forecast if it exists (only for current month)
            if (itemForecastInput) {
                itemData.forecast = getNumericValue(itemForecastInput);
            }

            // Add item date if it exists (only for current month)
            if (itemDateInput && itemDateInput.value) {
                itemData.date = itemDateInput.value;
            }

            monthData.items![itemKey] = itemData;
        }
    }
}

                forecastData[monthKey] = monthData;
            }
        });

        // Process yearly data
        const yearlyData: YearlyForecastData = {};
        const yearlyPlanInputs = document.querySelectorAll<HTMLInputElement>('.yearly-plan-input-rev');
        // const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('.yearly-current-input');
        
        if (yearlyPlanInputs.length > 0) {
            const years = new Set<string>();
            yearlyPlanInputs.forEach(input => {
                const year = input.dataset.year;
                if (year) years.add(year);
            });
            
            Array.from(years).sort().forEach(year => {
                const planInput = document.querySelector<HTMLInputElement>(`input.yearly-plan-input-rev[data-year="${year}"]`);
                const currentInput = document.querySelector<HTMLInputElement>(`input.yearly-current-input-rev[data-year="${year}"]`);
                
                if (planInput && currentInput) {
                    yearlyData[year] = {
                        plan: getNumericValue(planInput),
                        actual: getNumericValue(currentInput)
                    };
                }
            });
            
            forecastData.yearly = yearlyData;
        }

 

// ========== UPDATE FORM SUBMISSION TO INCLUDE YEARLY PROPAGATION ==========

// In your form submission handler, replace the propagateMonthValues call with:
const propagatedData = propagateCollectionValues(forecastData);
        const digest = await getDigest();
        
        const payload: any = {
            __metadata: { type: "SP.Data.Revenue_x0020_Forecast_x0020_ListListItem" },
            Title: generateForecastTitle(project, propagatedData),
            ProjectId: project.Id,
            ProfitCentre: project.PC || "",
            ForecastData: JSON.stringify(propagatedData),
            Remarks: `Revenue forecast for ${project.Title}. Last updated: ${new Date().toLocaleDateString()}`,
            UpdatedDate: new Date().toISOString()
        };

        // Add OBL for new projects
        if (!editingId && isNewProject) {
            const oblValueToSave = getNumericValue(oblLastMonthInput);
            payload.OBL = oblValueToSave;
        }

        // Add CreatedDate for new items
        if (!editingId) {
            payload.CreatedDate = new Date().toISOString();
        } 
        
        // Log current month items data for verification
        const currentMonthKey = formatMonthKey(new Date());
        const currentMonthData = propagatedData[currentMonthKey] as ForecastMonthData;
        if (currentMonthData && currentMonthData.items) { 
        }

        const url = editingId 
            ? `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${editingId})`
            : `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;
        
        const headers: any = {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest
        };
        
        if (editingId) {
            headers["IF-MATCH"] = "*";
            headers["X-HTTP-Method"] = "MERGE";
        }

        const res = await fetch(url, { 
            method: "POST", 
            headers, 
            body: JSON.stringify(payload) 
        });
        
        if (res.ok) {
            toast("success", editingId ? "Forecast Updated!" : "Forecast Added!");
            await loadForecasts();
            initializePagination(forecasts);
            hideForm();
            resetForm();
        } else {
            const errorText = await res.text();
            console.error("SharePoint Error:", errorText);
            toast("error", `Error saving forecast: ${res.status}`);
        }
    } catch (error) {
        console.error("Error saving forecast:", error);
        toast("error", "Error saving forecast!");
    }
});

 
const initializeFilters = (): void => {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  
  // Year filter
  filterYear.innerHTML = '<option value="">All Years</option>';
  for (let year = currentYear - 1; year <= currentYear + 2; year++) {
    const selected = year === currentYear ? 'selected' : '';
    filterYear.innerHTML += `<option value="${year}" ${selected}>${year}</option>`;
  }
  
  // Month filter
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  filterMonth.innerHTML = '<option value="">All Months</option>';
  for (let month = 1; month <= 12; month++) {
    const selected = month === currentMonth ? 'selected' : '';
    filterMonth.innerHTML += `<option value="${month}" ${selected}>${monthNames[month - 1]}</option>`;
  }

 const roleFilteredForecasts = filterDataByRole(forecasts); // Make sure this line exists

const accessibleProjectTitles = roleFilteredForecasts
  .map((f: RevenueForecastItem) => f.Project?.Title) // Add type annotation
  .filter((title): title is string => !!title);
  
  filterProject.innerHTML = '<option value="">All Projects</option>' + 
    [...new Set(accessibleProjectTitles)]
      .sort()
      .map(project => `<option value="${project}">${project}</option>`)
      .join("");

  // Customer filter - only customers from accessible projects
  const accessibleProjects = projects.filter(p => accessibleProjectTitles.includes(p.Title));
  const accessibleCustomers = accessibleProjects
    .map(p => p.CustomerName)
    .filter((customer): customer is string => !!customer);
    
  filterCustomer.innerHTML = '<option value="">All Customers</option>' + 
    [...new Set(accessibleCustomers)]
      .sort()
      .map(customer => `<option value="${customer}">${customer}</option>`)
      .join("");

  // Project Manager filter - based on role
  let accessibleManagers: string[] = [];
  
  // Helper function to extract manager name
  const getManagerName = (project: ProjectItem): string | undefined => {
    if (!project.ProjectManager) return undefined;
    
    if (typeof project.ProjectManager === 'string') {
      return project.ProjectManager;
    }
    
    return project.ProjectManager.Title;
  };
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all managers
    accessibleManagers = projects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isGroupHead) {
    // Group Head sees managers in their groups
    const groupHeadProjects = projects.filter(p => 
      currentUser.managedGroups?.some(group => p.GroupHead === group)
    );
    accessibleManagers = groupHeadProjects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isProjectManager) {
    // Project Manager sees only themselves
    accessibleManagers = [currentUser.displayName];
  }
  
  // Remove duplicates and sort
  accessibleManagers = [...new Set(accessibleManagers)].sort();
  
  filterProjectManager.innerHTML = '<option value="">All Managers</option>' + 
    accessibleManagers.map(manager => `<option value="${manager}">${manager}</option>`).join("");

  // Group Head filter - based on role
  let accessibleGroupHeads: string[] = [];
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all group heads
    accessibleGroupHeads = projects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  } else if (currentUser.isGroupHead) {
    // Group Head sees only themselves
    accessibleGroupHeads = [currentUser.displayName];
  } else if (currentUser.isProjectManager) {
    // Project Manager sees group heads of their projects
    const pmProjects = projects.filter(p => 
      currentUser.managedProjects?.includes(p.Title)
    );
    accessibleGroupHeads = pmProjects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  }
  
  // Remove duplicates and sort
  accessibleGroupHeads = [...new Set(accessibleGroupHeads)].sort();
  
  filterGroupHead.innerHTML = '<option value="">All Group Heads</option>' + 
    accessibleGroupHeads.map(head => `<option value="${head}">${head}</option>`).join("");

  // Project Reference filter - only from accessible projects
  const accessibleReferences = accessibleProjects
    .map(p => p.ProjectReference)
    .filter((ref): ref is string => !!ref);
    
  filterProjectReference.innerHTML = '<option value="">All References</option>' + 
    [...new Set(accessibleReferences)]
      .sort()
      .map(ref => `<option value="${ref}">${ref}</option>`)
      .join("");
};

const filterTable = (): void => {
  const year = filterYear.value;
  const month = filterMonth.value;
  const project = filterProject.value;
  const customer = filterCustomer.value;
  const projectManager = filterProjectManager.value;
  const groupHead = filterGroupHead.value;
  const projectReference = filterProjectReference.value; 
  let filtered = [...forecasts]; // Create a copy

  // Apply additional filters first
  filtered = filtered.filter(forecast => { 
    if (year && month) {
      const monthKey = `${year}-${month.padStart(2, "0")}`;
      const data: ForecastData = safeJsonParse(forecast.ForecastData, {});
      if (!(monthKey in data)) return false;
    }
    
    if (project && forecast.Project?.Title !== project) return false;
    
    if (customer) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.CustomerName !== customer) return false;
    }
    
    if (projectManager) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      const managerName = typeof proj?.ProjectManager === 'object' ? proj.ProjectManager?.Title : proj?.ProjectManager;
      if (managerName !== projectManager) return false;
    }
    
    if (groupHead) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.GroupHead !== groupHead) return false;
    }
    
    if (projectReference) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.ProjectReference !== projectReference) return false;
    }
    
    return true;
  }); 
  // Apply role-based filtering LAST
  filtered = filterDataByRole(filtered); 
  if (filtered.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="20" style="text-align:center;padding:20px;">No records found for selected filters</td></tr>`;
    
    // Clear totals header
    const totalsHeader = document.querySelector("#totalsHeader") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = '';
    
    initializePagination([]);
  } else {
    initializePagination(filtered);
    
    // Refresh totals header after filtering
    const displayMonths = getDisplayMonths();
    const currentMonthKey = formatMonthKey(new Date());
    setTimeout(() => {
      renderTotalsHeader(displayMonths, currentMonthKey);
    }, 100);
  }
};


// ========== AUTO PROGRESSION FUNCTIONS ==========

const applyAutoProgression = async (): Promise<void> => { 
  
  if (forecasts.length === 0) { 
    return;
  }

  const digest = await getDigest();
  let progressedCount = 0;
  let errorCount = 0;
  
  for (const forecast of forecasts) {
    try {
      if (!forecast.ForecastData) { 
        continue;
      }
      
      const originalData = safeJsonParse(forecast.ForecastData, {});
       
      if (checkIfNeedsProgression(originalData)) {  
        const progressedData = propagateCollectionValues(originalData);
        
        const payload = {
          __metadata: { type: "SP.Data.Revenue_x0020_Forecast_x0020_ListListItem" },
          ForecastData: JSON.stringify(progressedData),
          UpdatedDate: new Date().toISOString()
        };
        
        const response = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`, {
          method: "POST",
          headers: {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest,
            "IF-MATCH": "*",
            "X-HTTP-Method": "MERGE"
          },
          body: JSON.stringify(payload)
        });
        
        if (response.ok) {
          progressedCount++; 
        } else {
          errorCount++; 
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      } else { 
      }
    } catch (error) {
      errorCount++; 
    }
  }
  
  if (progressedCount > 0) { 
    await loadForecasts();
    toast("success", `Monthly and yearly data progressed for ${progressedCount} revenue forecasts`);
  } else if (errorCount > 0) { 
    toast("warning", `Some errors occurred during monthly and yearly progression`);
  } else { 
  }
};

const checkIfNeedsProgression = (forecastData: ForecastData): boolean => {
  const months = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
  
  if (months.length === 0) return true;

  const idealMonths = generateIdealMonthStructure();
  const firstIdealMonth = idealMonths[0];
  const firstDataMonth = months[0];
  
  // Check if monthly progression is needed
  const monthlyProgressionNeeded = firstDataMonth !== firstIdealMonth;
  
  // ALWAYS check for yearly progression, even if monthly is not needed
  const currentYear = new Date().getFullYear();
  let yearlyProgressionNeeded = false;
  
  if (forecastData.yearly) {
    const years = Object.keys(forecastData.yearly).map(y => parseInt(y)).sort();
    yearlyProgressionNeeded = years.length > 0 && years[0] < currentYear;
  } else {
    yearlyProgressionNeeded = true; // Need progression if no yearly data
  } 
  
  return monthlyProgressionNeeded || yearlyProgressionNeeded;
};

// ========== ENHANCED YEARLY PROPAGATION FOR REVENUE ==========

const propagateCollectionValues = (forecastData: ForecastData): ForecastData => {
  const updatedData: ForecastData = { ...forecastData };
  
  // Ensure yearly data exists before progression
  if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) {
    const longTermMonths = generateIdealMonthStructure().slice(6);
    const lastMonthKey = longTermMonths[longTermMonths.length - 1];
    updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
  }

  // Detect if it's a new month by checking current month structure
  const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
  const idealMonths = generateIdealMonthStructure();
  const isNewMonth = originalMonths[0] !== idealMonths[0];
   
  // Apply monthly progression (long-term collection)
  const monthlyProgressed = propagateMonthValues(updatedData);
  
  // Apply yearly progression only when month changes
  const yearlyProgressed = propagateYearlyValues(monthlyProgressed, isNewMonth); 
  return yearlyProgressed;
};

// ========== FIXED YEARLY PROPAGATION FOR REVENUE ==========

const propagateYearlyValues = (forecastData: ForecastData, isNewMonth: boolean = false): ForecastData => {
  if (!isNewMonth) { 
    return forecastData;
  }

  const updatedData: ForecastData = { ...forecastData };
  
  if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) { 
    return updatedData;
  }

  const yearlyData = updatedData.yearly; 
  const updatedYearlyData: YearlyForecastData = {};

  // CORRECT LOGIC FOR REVENUE:
  // For each year, current ACTUAL values become the new PLAN values for the SAME YEAR
  // ACTUAL values reset to 0
  
  Object.keys(yearlyData).forEach(year => {
    const yearData = yearlyData[year];
    if (yearData) {
      updatedYearlyData[year] = {
        plan: yearData.actual, // Current actual becomes new plan for same year
        actual: 0, // Reset actual to 0 
      };
       
    }
  });

  updatedData.yearly = updatedYearlyData; 
  return updatedData;
};

const initialize = async (): Promise<void> => {
  try { 
    currentUser = await getUserContext(); 
    await loadProjects(); 
    await loadForecasts(); 
    if (forecasts.length > 0) { 
      await applyAutoProgression();
    } else { 
    }
    
    initializeFilters(); 
    setupPaginationEventListeners();
    
    // Get role-filtered data count for verification
    const roleFilteredCount = filterDataByRole(forecasts).length;
    console.log("Role-filtered forecasts:", roleFilteredCount, "out of", forecasts.length);
    
    initializePagination(forecasts); 
    importActualBtns.addEventListener("click", importActualDatas);
    
    updateUIForRole();
    filterProjectSelectByRole(); 
  } catch (error) { 
    toast("error", "Failed to initialize application");
  }
};

   
  const importActualDatas = (): void => { 
    const modalHTMLRev = `
      <div class="import-modal" style="display: none;">
        <div class="import-modal-content">
          <div class="import-modal-header">
            <h3>Import Monthly Actual Revenue Data</h3>
            <button class="close-modal">&times;</button>
          </div>

          <div class="import-section">
            <h4>Step 1: Download Template</h4>
            <button class="btn-primary" id="downloadTemplate">⬇️ Download Template</button>
          </div>

          <div class="import-section">
            <h4>Step 2: Upload Excel File</h4>
            <div class="file-upload-area" id="fileUploadArea">
              <div class="upload-icon">📁</div>
              <p>Click to upload or drag & drop Excel file</p>
              <p><small>Supported format: Excel with Project Reference, Month, and Actual Revenue columns</small></p>
              <input type="file" id="excelFile" class="file-input" accept=".xlsx,.xls">
              <div class="file-info" id="fileInfo"></div>
            </div>
          </div>

          <div class="import-section" id="previewSection" style="display:none;">
            <h4>Step 3: Preview & Import</h4>
            <div class="import-preview" id="importPreview"></div>
            <div class="import-actions">
              <button class="btn-secondary" id="cancelImport">Cancel</button>
              <button class="btn-primary" id="confirmImport">Import Data</button>
            </div>
            <div class="import-status" id="importStatus"></div>
          </div>
        </div>
      </div>
    `;

    // Remove any existing modal first
    const existingModal = document.querySelector('.import-modal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add the modal to the body
    document.body.insertAdjacentHTML("beforeend", modalHTMLRev);
    const modal = document.querySelector(".import-modal") as HTMLElement;
    
    // Show the modal with proper styling
    setTimeout(() => {
        modal.style.display = "flex";
        modal.style.position = "fixed";
        modal.style.top = "0";
        modal.style.left = "0";
        modal.style.width = "100%";
        modal.style.height = "100%";
        modal.style.backgroundColor = "rgba(0,0,0,0.5)";
        modal.style.zIndex = "9999";
        modal.style.justifyContent = "center";
        modal.style.alignItems = "center";
        
        // Also ensure modal content is styled
        const modalContent = modal.querySelector('.import-modal-content') as HTMLElement;
        if (modalContent) {
            modalContent.style.backgroundColor = "white";
            modalContent.style.padding = "20px";
            modalContent.style.borderRadius = "10px";
            modalContent.style.maxWidth = "90%";
            modalContent.style.maxHeight = "90%";
            modalContent.style.overflow = "auto";
            modalContent.style.boxShadow = "0 4px 20px rgba(0,0,0,0.2)";
        }
         
    }, 10);

    // Elements
    const fileUploadArea = document.querySelector("#fileUploadArea") as HTMLElement;
    const excelFileInput = document.querySelector("#excelFile") as HTMLInputElement;
    const fileInfo = document.querySelector("#fileInfo") as HTMLElement;
    const previewSection = document.querySelector("#previewSection") as HTMLElement;
    const importPreview = document.querySelector("#importPreview") as HTMLElement;
    const confirmImport = document.querySelector("#confirmImport") as HTMLButtonElement;
    const cancelImport = document.querySelector("#cancelImport") as HTMLButtonElement;
    const closeModal = document.querySelector(".close-modal") as HTMLButtonElement;
    const importStatus = document.querySelector("#importStatus") as HTMLElement;
    const downloadTemplateBtn = document.querySelector("#downloadTemplate") as HTMLButtonElement;

    let importData: any[] = [];
    let listEntityType: string = "";

    // Month name to number mapping
    const monthMap: { [key: string]: number } = {
        jan: 1, january: 1, "jan-": 1,
        feb: 2, february: 2, "feb-": 2,
        mar: 3, march: 3, "mar-": 3,
        apr: 4, april: 4, "apr-": 4,
        may: 5, "may-": 5,
        jun: 6, june: 6, "jun-": 6,
        jul: 7, july: 7, "jul-": 7,
        aug: 8, august: 8, "aug-": 8,
        sep: 9, september: 9, "sep-": 9,
        oct: 10, october: 10, "oct-": 10,
        nov: 11, november: 11, "nov-": 11,
        dec: 12, december: 12, "dec-": 12,
    };

    // Parse month string to YYYY-MM format
    const parseMonth = (monthStr: string): string => {
        if (!monthStr) return "";

        // If already in YYYY-MM format
        if (/^\d{4}-\d{2}$/.test(monthStr)) {
            return monthStr;
        }

        // Handle formats like "Nov-25", "November 2025", "Nov 2025"
        const match = monthStr.toLowerCase().match(/([a-z]+)[-\s]*'?(\d{2,4})?/);
        if (match) {
            const monthName = match[1];
            let year = match[2];

            const monthNum = monthMap[monthName];
            if (monthNum) {
                // Handle year
                if (!year) {
                    // If no year provided, use current year
                    year = new Date().getFullYear().toString();
                } else if (year.length === 2) {
                    // Convert 2-digit year to 4-digit
                    const currentYear = new Date().getFullYear();
                    const century = Math.floor(currentYear / 100) * 100;
                    const yearNum = parseInt(year);
                    year = (century + yearNum).toString();
                }

                return `${year}-${monthNum.toString().padStart(2, "0")}`;
            }
        }

        return "";
    };

    // Get correct List Entity Type
    const getListEntityType = async (): Promise<string> => {
        if (listEntityType) return listEntityType;
        const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`, {
            headers: { Accept: "application/json;odata=verbose" },
        });
        const data = await res.json();
        listEntityType = data.d.ListItemEntityTypeFullName; 
        return listEntityType;
    };

    // Handle empty database data and create proper 4-month structure
    const updateRevenueData = (existingData: string, month: string, actualRevenue: number): string => { 
        let finalData: { [key: string]: number } = {};

        if (existingData && existingData.trim() !== "" && existingData !== "{}" && existingData !== "null" && existingData !== "undefined") {
            try {
                const parsed = JSON.parse(existingData); 
                finalData = { ...parsed };
            } catch (parseError) { 
                finalData = {};
            }
        } else { 
            finalData = {};
        } 
        finalData[month] = actualRevenue; 
        const getFourMonthWindow = (): string[] => {
            const currentDate = new Date();
            const validMonths: string[] = [];

            // Start from current month and go backwards 3 months
            for (let i = 0; i < 4; i++) {
                const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
                const yearStr = date.getFullYear();
                const monthStr = (date.getMonth() + 1).toString().padStart(2, "0");
                validMonths.push(`${yearStr}-${monthStr}`);
            }

            return validMonths.sort().reverse(); // newest first
        };

        const fourMonthWindow = getFourMonthWindow(); 
        const resultData: { [key: string]: number } = {};

        fourMonthWindow.forEach((monthKey) => {
            // Use existing value if available, otherwise 0
            resultData[monthKey] = finalData[monthKey] !== undefined ? finalData[monthKey] : 0;
        });
 
        return JSON.stringify(resultData);
    };

    // File Upload Handling
    fileUploadArea.addEventListener("click", () => excelFileInput.click());
    fileUploadArea.addEventListener("dragover", (e) => {
        e.preventDefault();
        fileUploadArea.classList.add("dragover");
    });
    fileUploadArea.addEventListener("dragleave", () => fileUploadArea.classList.remove("dragover"));
    fileUploadArea.addEventListener("drop", (e) => {
        e.preventDefault();
        fileUploadArea.classList.remove("dragover");
        const files = e.dataTransfer?.files;
        if (files && files[0]) {
            excelFileInput.files = files;
            handleFileSelection(files[0]);
        }
    });
    excelFileInput.addEventListener("change", (e) => {
        const files = (e.target as HTMLInputElement).files;
        if (files && files[0]) handleFileSelection(files[0]);
    });

    // Handle Excel File Selection
    const handleFileSelection = async (file: File) => { 
        if (!file.name.toLowerCase().match(/\.(xlsx|xls)$/)) {
            toast("error", "Please select an Excel file (.xlsx or .xls)");
            return;
        }

        fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`;

        try {
            const parsedData = await parseExcelFile(file); 
            if (validateImportData(parsedData)) { 
                importData = parsedData;
                showImportPreview(parsedData);
                // Force show the preview section
                previewSection.style.display = "block";
                previewSection.style.opacity = "1"; 
            } else { 
                toast("error", "Invalid Excel format. Please check the required columns.");
            }
        } catch (error) { 
            toast("error", "Error reading Excel file");
        }
    };

    // Parse Excel File - SIMPLIFIED VERSION
    const parseExcelFile = (file: File): Promise<any[]> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target?.result as ArrayBuffer);
                    const workbook = XLSX.read(data, { type: "array" });
                    const sheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[sheetName];

                    // Use sheet_to_json with header: 1 to get array of arrays
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); 
                    if (jsonData.length < 2) { 
                        return resolve([]);
                    }

                    const headers = jsonData[0] as string[];  
                    const rows: any[] = [];

                    // Start from row 1 (skip header row)
                    for (let i = 1; i < jsonData.length; i++) {
                        const rowData = jsonData[i] as any[];
                        if (!rowData || rowData.length === 0) continue;

                        const row: any = {};

                        // Map headers to row values
                        headers.forEach((header, idx) => {
                            if (header && rowData[idx] !== undefined && rowData[idx] !== null) {
                                row[header.trim()] = rowData[idx];
                            }
                        });
 
                        // Parse month if available
                        if (row["Month"] || row["month"]) {
                            let monthValue = row["Month"] || row["month"];

                            // 🧠 Handle Excel numeric date (e.g., 45962)
                            if (typeof monthValue === "number") {
                                const excelDate = new Date(Math.round((monthValue - 25569) * 86400 * 1000));
                                const yyyy = excelDate.getFullYear();
                                const mm = String(excelDate.getMonth() + 1).padStart(2, "0");
                                monthValue = `${yyyy}-${mm}`; // convert to YYYY-MM format
                            }

                            const monthStr = monthValue.toString();
                            row.parsedMonth = parseMonth(monthStr); 
                        }

                        // Only add row if it has required data
                        const hasProjectRef = row["Project Reference"] || row["project_reference"];
                        const hasMonth = row.parsedMonth;

                        if (hasProjectRef && hasMonth) {
                            rows.push(row); 
                        } else { 
                        }
                    } 
                    resolve(rows);
                } catch (err) { 
                    reject(err);
                }
            };
            reader.onerror = (error) => {
                console.error("❌ FileReader error:", error);
                reject(new Error("Failed to read file"));
            };
            reader.readAsArrayBuffer(file);
        });
    };

    // Validate Columns - RELAXED VALIDATION
    const validateImportData = (data: any[]): boolean => { 
        if (data.length === 0) { 
            return false;
        } 
        // Check if first row has the required columns (case insensitive)
        const first = data[0];
        const keys = Object.keys(first).map((k) => k.toLowerCase()); 
        const hasProjectRef = keys.some((k) => k.includes("project") && k.includes("reference"));
        const hasMonth = keys.some((k) => k.includes("month"));
        const hasRevenue = keys.some((k) => k.includes("actual") && (k.includes("revenue") || k.includes("rev")));

        console.log("✅ Validation results:", { hasProjectRef, hasMonth, hasRevenue, dataLength: data.length });

        // Return true if we have at least project reference and month
        return hasProjectRef && hasMonth;
    };

    // Show Preview
    const showImportPreview = (data: any[]) => { 
        const monthSummary: { [key: string]: number } = {};

        data.forEach((row) => {
            const month = row.parsedMonth;
            if (month) {
                monthSummary[month] = (monthSummary[month] || 0) + 1;
            }
        });

        const monthSummaryText = Object.keys(monthSummary)
            .map((month) => {
                return `${month}: ${monthSummary[month]} records`;
            })
            .join(", ");

        const previewHTML = `
            <div style="padding: 20px; background: #f8f9fa; border-radius: 8px;">
                <h4 style="color: #28a745; margin-bottom: 15px;">✅ File Ready for Import</h4>
                <p><strong>Found ${data.length} records to import:</strong></p>
                <p><strong>Month Summary:</strong> ${monthSummaryText || "No months found"}</p>
                <div class="preview-table-container" style="max-height: 400px; overflow-y: auto;">
                    <table class="preview-table" style="width: 100%; border-collapse: collapse;">
                        <thead style="background: #007bff; color: white;">
                            <tr>
                                <th style="padding: 10px; border: 1px solid #ddd;">Project Reference</th>
                                <th style="padding: 10px; border: 1px solid #ddd;">Month</th>
                                <th style="padding: 10px; border: 1px solid #ddd;">Actual Revenue</th>
                                <th style="padding: 10px; border: 1px solid #ddd;">Project Match</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.slice(0, 10).map((row, index) => {
                                const projectRef = row["Project Reference"] || row["project_reference"] || "N/A";
                                const month = row["Month"] || row["month"] || "N/A";
                                const actualRevenue = row["Actual Revenue"] || row["actual_revenue"] || row["Actual"] || row["actual"] || "0";
                                const project = projects.find((p) => p.ProjectReference === projectRef);

                                return `
                                        <tr style="${index % 2 === 0 ? "background: #f8f9fa;" : "background: white;"}">
                                            <td style="padding: 8px; border: 1px solid #ddd;">${projectRef}</td>
                                            <td style="padding: 8px; border: 1px solid #ddd;">${month} (${row.parsedMonth || "Invalid"})</td>
                                            <td style="padding: 8px; border: 1px solid #ddd;">${actualRevenue}</td>
                                            <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${project ? "✅" : "❌"}</td>
                                        </tr>
                                    `;
                            }).join("")}
                        </tbody>
                    </table>
                </div>
                ${data.length > 10 ? `<p style="margin-top: 10px; font-style: italic;">... and ${data.length - 10} more records</p>` : ""}
                <div style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 5px;">
                    <p style="margin: 0; color: #0056b3;"><strong>Ready to import?</strong> Click the "Import Data" button below.</p>
                    <p style="margin: 5px 0 0 0; font-size: 12px;"><strong>Note:</strong> Only the imported month will be updated, all other data preserved</p>
                </div>
            </div>`;

        importPreview.innerHTML = previewHTML; 
    };

    // Perform Import - CORRECTED VERSION
    const performImport = async () => {
        confirmImport.disabled = true;
        confirmImport.textContent = "Importing...";
        importStatus.style.display = "block";
        importStatus.textContent = "Updating Revenue Data...";

        let success = 0,
            error = 0,
            notFound = 0,
            invalidMonth = 0,
            skipped = 0;
        const entityType = await getListEntityType(); 
        for (const row of importData) {
            const projectRef = row["Project Reference"] || row["project_reference"];
            const month = row.parsedMonth;
            const actualRevenue = parseFloat(row["Actual Revenue"] || row["actual_revenue"] || row["Actual"] || row["actual"] || "0");
            if (!month) { 
                invalidMonth++;
                continue;
            }

            const project = projects.find((p) => p.ProjectReference === projectRef);
            if (!project) { 
                notFound++;
                continue;
            }

            const forecast = forecasts.find((f) => f.Project?.Title === project.Title);
            if (!forecast?.Id) { 
                notFound++;
                continue;
            }

            try {
                const digest = await getDigest(); 
                const currentForecastResponse = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})?$select=Id,RevenueActual`, {
                    method: "GET",
                    headers: {
                        Accept: "application/json;odata=verbose",
                    },
                });

                if (!currentForecastResponse.ok) {
                    throw new Error(`Failed to fetch current data: ${currentForecastResponse.status}`);
                }

                const currentData = await currentForecastResponse.json();
                const currentRevenueData = currentData.d.RevenueActual || "{}"; 
                const updatedRevenueData = updateRevenueData(currentRevenueData, month, actualRevenue); 
                try {
                    const before = JSON.parse(currentRevenueData);
                    const after = JSON.parse(updatedRevenueData);
                    const changedMonths = Object.keys(after).filter((m) => before[m] !== after[m]);
                    console.log(`🔍 CHANGED MONTHS: ${changedMonths.join(", ")}`);
                } catch (e) { 
                }

                const payload = {
                    __metadata: { type: entityType },
                    RevenueActual: updatedRevenueData,
                    UpdatedDate: new Date().toISOString(),
                }; 
                const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`, {
                    method: "POST",
                    headers: {
                        Accept: "application/json;odata=verbose",
                        "Content-Type": "application/json;odata=verbose",
                        "X-RequestDigest": digest,
                        "IF-MATCH": "*",
                        "X-HTTP-Method": "MERGE",
                    },
                    body: JSON.stringify(payload),
                });

                if (res.ok) {
                    success++; 
                } else {
                    error++;
                    const text = await res.text();
                    console.warn(`⚠️ Failed for ${projectRef} (${month}):`, text);
                }

                await new Promise((r) => setTimeout(r, 100));
            } catch (err) {
                error++;
                console.error(`❌ Error updating ${projectRef} (${month}):`, err);
            }
        }

        // Calculate skipped records
        skipped = importData.length - (success + error + notFound + invalidMonth);
 
        importStatus.className = "import-status success";
        importStatus.innerHTML = `
        <strong>Import Complete!</strong><br>
        ✅ Success: ${success} records imported<br>
        ❌ Errors: ${error} records<br>
        🔍 Project Not Found: ${notFound} records<br>
        📅 Invalid Month: ${invalidMonth} records<br>
        ⏭️ Skipped: ${skipped} records<br>
        <small>Only the imported month was updated, all other data preserved</small>
    `;

        // Refresh data
        await loadForecasts();
        initializePagination(forecasts);

        confirmImport.disabled = false;
        confirmImport.textContent = "Import Data";
    };

    // Download Template with all project references
    downloadTemplateBtn.addEventListener("click", () => {
        if (!projects || projects.length === 0) {
            toast("error", "No projects available to create template");
            return;
        }

        const wsData = [["Project Reference", "Month", "Actual Revenue"]];

        // Add all project references with empty Month and Actual Revenue columns
        projects.forEach((p) => {
            wsData.push([p.ProjectReference || "", "", ""]);
        });

        const ws = XLSX.utils.aoa_to_sheet(wsData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Revenue Template");

        const fileName = `Revenue_Import_Template.xlsx`;

        XLSX.writeFile(wb, fileName);
    });

    // Modal Controls
    const closeModalHandler = () => modal.remove();
    closeModal.addEventListener("click", closeModalHandler);
    cancelImport.addEventListener("click", closeModalHandler);
    modal.addEventListener("click", (e) => {
        if (e.target === modal) closeModalHandler();
    });

    confirmImport.addEventListener("click", performImport);
};
      // ========== EVENT LISTENERS ==========

      showFormBtn.addEventListener("click", () => {
        resetForm();
        showForm(false);
      });    
          
      backBtn.addEventListener("click", hideForm);
      
projectSelect.addEventListener("change", (e) => {
  if (editingId) {
    toast("warning", "Cannot change project in edit mode");
    const forecast = forecasts.find(f => f.Id === editingId);
    if (forecast?.Project) {
      projectSelect.value = String(forecast.Project.Id);
    }
    return;
  }

  const projectId = parseInt((e.target as HTMLSelectElement).value);
  if (projectId) {
    const project = projects.find(p => p.Id === projectId);
    if (project) {
      // Check if user has access to this project
      if (!currentUser.isSuperAdmin) {
        let hasAccess = false;
        
        if (currentUser.isGroupHead) {
          hasAccess = currentUser.managedGroups?.some(group => 
            project.GroupHead === group
          ) || false;
        } else if (currentUser.isProjectManager) {
          hasAccess = currentUser.managedProjects?.includes(project.Title) || false;
        }
        
        if (!hasAccess) {
          toast("error", "You don't have access to this project");
          projectSelect.value = "";
          return;
        }
      }
      
      const existingForecast = forecasts.find(f => f.Project?.Id === projectId);
      if (existingForecast && !editingId) {
        Swal.fire({
          icon: "question",
          title: "Existing Forecast Found",
          text: `A forecast already exists for ${project.Title}. Would you like to edit it?`,
          showCancelButton: true,
          confirmButtonText: "Yes, Edit",
          cancelButtonText: "No, Create New"
        }).then((result) => {
          if (result.isConfirmed) {
            editingId = existingForecast.Id;
            showForm(true);
            onProjectChange(projectId, existingForecast);
          } else {
            onProjectChange(projectId);
          }
        });
      } else {
        onProjectChange(projectId, existingForecast);
      }
    }
  }
});

      // Pagination event listeners
      firstPageBtn.addEventListener("click", () => goToPage(1));
      prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
      nextPageBtn.addEventListener("click", () => goToPage(currentPage + 1));
      lastPageBtn.addEventListener("click", () => goToPage(totalPages));

      // Filter event listeners
      filterYear.addEventListener("change", filterTable);
      filterMonth.addEventListener("change", filterTable);
      filterProject.addEventListener("change", filterTable);
      filterCustomer.addEventListener("change", filterTable);
      filterProjectManager.addEventListener("change", filterTable);
      filterGroupHead.addEventListener("change", filterTable);
      filterProjectReference.addEventListener("change", filterTable);

      // Action button event listeners
      exportBtn.addEventListener("click", exportToExcelWithFullStyle);
      exportDetailsBtn.addEventListener("click", exportDetailedItemsToExcel);
      clearFiltersBtn.addEventListener("click", clearFilters);

      // Initialize the application
      initialize();
    }, 100);
  }
};


 