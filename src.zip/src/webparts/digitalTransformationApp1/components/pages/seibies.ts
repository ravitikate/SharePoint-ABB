declare const _spPageContextInfo: any;
import Swal from "sweetalert2";
import * as XLSX from 'xlsx-js-style';
import "../styles/common.css";
import "../styles/seibies.css";

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead?: string;
}

interface SortConfig {
  column: string;
  direction: 'asc' | 'desc';
  subColumn?: string;
  monthIndex?: number;
}

let currentSortConfig: SortConfig = {
  column: '',
  direction: 'asc'
};

interface SeibiesForecastItem {
  Id: number;
  Title: string;
  Project?: { 
    Id: number;
    Title: string;
  };
  ProfitCentre?: string;
  OBL?: number;
  ForecastData?: string;
  SeibiesActual?: string; 
  CreatedDate?: string;
  UpdatedDate?: string;
  [key: string]: any;
}

interface SharePointResponse<T> {
  d: {
    results: T[];
  };
}
 
interface ForecastMonthData {
    plan: number;
    actual: number;
    forecast?: number;
    date?: string;
}

interface YearlyForecastData {
    [year: string]: {
        plan: number;
        actual: number;
        forecast?: number;
    };
}

interface ForecastData {
    [monthKey: string]: ForecastMonthData | YearlyForecastData | undefined;
    yearly?: YearlyForecastData;
}

interface UserContext {
  loginName: string;
  displayName: string;
  groups: string[];
  isSuperAdmin: boolean;
  isGroupHead: boolean;
  isProjectManager: boolean;
  userGroups?: string[];
  managedProjects?: string[];
  managedGroups?: string[];
}

export default {
  content: `
<div class="seibies-page fade-in">
  <section class="table-section-seibies card">
    <div class="page-header-seibies">
      <h1>SEIBIES Forecast Management</h1>
      <button class="btn-primary-seibies show-form-btn-seibies">+ Add SEIBIES Forecast</button>
    </div>
    
    <div class="table-actions-seibies">
      <div class="table-actions-row-seibies">
        <div class="tableColp4-seibies">
          <label for="filterProjectSeibies">Project</label>
          <select id="filterProjectSeibies"><option value="">All Projects</option></select>
        </div>
        <div class="tableColp4-seibies">
          <label for="filterCustomerSeibies">Customer</label>
          <select id="filterCustomerSeibies"><option value="">All Customers</option></select>
        </div>
        <div class="tableColp4-seibies">
          <label for="filterProjectManagerSeibies">Project Manager</label>
          <select id="filterProjectManagerSeibies"><option value="">All Managers</option></select>
        </div>
        <div class="tableColp4-seibies">
          <label for="filterGroupHeadSeibies">Group Head</label>
          <select id="filterGroupHeadSeibies"><option value="">All Group Heads</option></select>
        </div>
        <div class="tableColp4-seibies">
          <label for="filterProjectReferenceSeibies">Project Reference</label>
          <select id="filterProjectReferenceSeibies"><option value="">All References</option></select>
        </div>
        <div class="tableColp4-seibies"> 
          <label>&nbsp;</label>
          <button class="btn-secondary-seibies clear-filters-btn-seibies" title="Clear All Filters">Reset Filter</button> 
        </div>
      </div>
      
      <div class="table-actions-row-seibies">
        <div class="tableColp4-seibies">
          <label for="filterYearSeibies">Year</label>
          <select id="filterYearSeibies"><option value="">All Years</option></select>
        </div>
        <div class="tableColp4-seibies">
          <label for="filterMonthSeibies">Month</label>
          <select id="filterMonthSeibies"><option value="">All Months</option></select>
        </div>
        <div class="tableColp4-seibies"> 
          <label>&nbsp;</label>
          <button class="btn-secondary-seibies import-actual-btn-seibies">📥 Import Actual</button>
        </div>
        <div class="tableColp4-seibies"> 
          <label>&nbsp;</label>
          <button class="btn-secondary-seibies export-btn-seibies">📊 Export Excel</button>
        </div> 
      </div>
    </div>
       
    <div class="table-container-seibies">
      <div style="overflow-x:auto;">
        <table class="month-columns-table-seibies">
          <thead id="monthColumnsHeaderSeibies"></thead>
          <tbody class="seibies-table-body"></tbody>
        </table>
      </div>
      
     <div class="pagination-container-seibies">
  <div class="pagination-left-seibies">
    <button class="pagination-btn-seibies" id="firstPageSeibies" disabled>First</button>
    <button class="pagination-btn-seibies" id="prevPageSeibies" disabled>Previous</button>
    
    <div class="pagination-info-seibies">
      Page <span id="currentPageSeibies">1</span> of <span id="totalPagesSeibies">1</span>
    </div>
    
    <div class="pagination-pages-seibies" id="pageNumbersSeibies"></div>
    
    <button class="pagination-btn-seibies" id="nextPageSeibies" disabled>Next</button>
    <button class="pagination-btn-seibies" id="lastPageSeibies" disabled>Last</button>
  </div>
  
  <div class="pagination-right-seibies">
    <div class="page-size-selector-seibies">
      <label for="pageSizeSelectSeibies">Show:</label>
      <select id="pageSizeSelectSeibies" class="page-size-select-seibies">
        <option value="10">10</option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100">100</option>
      </select>
      <span>per page</span>
    </div>
    
    <div class="pagination-info-seibies">
      Showing <span id="startItemSeibies">0</span>-<span id="endItemSeibies">0</span> of <span id="totalItemsSeibies">0</span> records
    </div>
  </div>
</div>
    </div>
  </section>

  <section class="form-section-seibies card" style="display:none;">
    <div class="page-header-seibies">
      <h1 id="formTitleSeibies">Add / Edit SEIBIES Forecast</h1>
    </div>
    <form id="seibiesForm">
      <div class="form-row-seibies">
        <div class="form-group-seibies project-select-container-seibies">
          <label>Project</label>
          <select id="projectSelectSeibies" required></select>
        </div>
        <div id="projectDetailsSeibies"></div>
      </div>
      
      <div class="obl-section-container-seibies hidden-section">
        <div class="obl-main-section-seibies">
          <div class="form-group-seibies">
            <label>SEI-BIES 
              <span class="info-tooltip-seibies" title="For new projects, enter the initial OBL value. For existing projects, this will be auto-populated from last month's data.">ℹ️</span>
            </label>
            <input type="text" id="oblLastMonthSeibies" class="obl-input-seibies number-input-seibies" placeholder="Enter OBL" readonly />
            <div class="field-note-seibies">For new projects: Enter initial OBL value</div>
          </div>
          <div class="validation-summary-seibies">
            <div class="validation-item-seibies">
              <span class="validation-label-seibies">Total Current Value:</span>
              <span class="validation-value-seibies" id="totalCurrentValueSeibies">0</span>
            </div>
            <div class="validation-item-seibies">
              <span class="validation-label-seibies">Remaining Balance:</span>
              <span class="validation-value-seibies" id="remainingValueSeibies">0</span>
            </div>
            <div class="validation-line-seibies">
              <div class="line-fill-seibies" id="oblLineFillSeibies"></div>
            </div>
          </div>
        </div>
        <div class="validation-message-seibies" id="oblValidationMessageSeibies">
          ✅ All values are within OBL limit
        </div>
      </div>
      
      <div class="forecast-section-seibies hidden-section" id="historicalForecastSectionSeibies">
        <h3>Historical Data (Last 3 Months - Readonly)</h3>
        <div id="historicalContainerSeibies" class="historical-container-seibies"></div>
      </div>
      
      <div class="forecast-section-seibies hidden-section" id="detailedForecastSectionSeibies">
        <h3>Detailed Forecast (Current + Next 2 Months)</h3>
        <div id="firstRowContainerSeibies" class="first-row-container-seibies"></div>
      </div>
      
      <div class="forecast-section-seibies hidden-section" id="longtermForecastSectionSeibies">
        <h3>Long-term Forecast (Next 15 Months)</h3>
        <div id="remainingContainerSeibies" class="remaining-container-seibies"></div>
      </div>

      <div class="forecast-section-seibies hidden-section" id="yearlyForecastSectionSeibies">
        <h3>5-Year Forecast</h3>
        <div id="yearlyContainerSeibies" class="yearly-container-seibies"></div>
      </div>
      
      <div class="form-actions-seibies">
        <button type="submit" class="btn-primary-seibies">💾 Save SEIBIES Forecast</button>
        <button type="button" class="btn-secondary-seibies back-to-table-seibies">⬅ Back</button>
      </div>
    </form>
  </section>
</div>
  `,

  style: `
  .role-indicator-seibies {
  padding: 8px 15px;
  margin-bottom: 15px;
  border-radius: 5px;
  color: white;
  font-weight: bold;
  display: inline-block;
}

.role-badge-seibies {
  display: flex;
  align-items: center;
  gap: 8px;
}

.hidden-by-role-seibies {
  display: none !important;
}

.no-edit-permission-seibies {
  color: #6c757d;
  font-size: 14px;
  cursor: not-allowed;
}

/* Totals Header Styles */
.totals-header-table-seibies {
  margin-bottom: 10px;
  background-color: #f8f9fa;
  border-collapse: separate;
  border-spacing: 0;
}

.totals-header-table-seibies th {
  padding: 8px 5px;
  font-size: 12px;
  font-weight: bold;
  text-align: center;
  vertical-align: middle;
  border: 1px solid #dee2e6;
  border-bottom: 2px solid #007bff;
  background-color: #e9ecef;
}

.totals-header-table-seibies .totals-label-seibies {
  font-weight: 600;
  color: #495057;
  background-color: #f1f3f4 !important;
}

.totals-header-table-seibies .all-projects-total-seibies {
  background-color: #d1ecf1 !important;
  color: #0c5460;
}

.totals-header-table-seibies .filtered-total-seibies {
  background-color: #d4edda !important;
  color: #155724;
}

.totals-header-table-seibies .total-value-seibies {
  font-weight: bold;
  font-size: 13px;
}

/* Update the table margin */
.table-container-seibies > div > table:last-child {
  margin-top: 0;
}
.page-size-selector-seibies {
  display: flex;
  align-items: center;
  gap: 8px;
}

.page-size-select-seibies {
  padding: 5px 10px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  background-color: white;
  font-size: 14px;
  cursor: pointer;
}

.pagination-left-seibies {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.pagination-right-seibies {
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
}

.pagination-container-seibies {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  padding: 15px;
  background-color: #f8f9fa;
  border-radius: 8px;
  border: 1px solid #dee2e6;
  flex-wrap: wrap;
  gap: 15px;
}  

tr.filtered-total-seibies {
    background-color: #00ffff;
}
tr.all-projects-total-seibies {
    background-color: #fff8dc;
}
    .role-indicator-seibies {
    display: none;
}
`,

  script: () => {
    setTimeout(async () => {
      const siteUrl = typeof _spPageContextInfo !== "undefined" ? _spPageContextInfo.webAbsoluteUrl : window.location.origin + "/sites/Kriya";
      const listName = "SEIBIES";
      const projectListName = "Project List";

      // DOM Elements - Updated with Seibies-specific IDs
      const tableBody = document.querySelector(".seibies-table-body") as HTMLElement;
      const monthColumnsHeader = document.querySelector("#monthColumnsHeaderSeibies") as HTMLElement;
      const formSection = document.querySelector(".form-section-seibies") as HTMLElement;
      const tableSection = document.querySelector(".table-section-seibies") as HTMLElement;
      const showFormBtn = document.querySelector(".show-form-btn-seibies") as HTMLButtonElement;
      const projectSelect = document.querySelector("#projectSelectSeibies") as HTMLSelectElement;
      const historicalContainer = document.querySelector("#historicalContainerSeibies") as HTMLElement;
      const firstRowContainer = document.querySelector("#firstRowContainerSeibies") as HTMLElement;
      const remainingContainer = document.querySelector("#remainingContainerSeibies") as HTMLElement;
      const yearlyContainer = document.querySelector("#yearlyContainerSeibies") as HTMLElement;
      const projectDetails = document.querySelector("#projectDetailsSeibies") as HTMLElement;
      const backBtn = document.querySelector(".back-to-table-seibies") as HTMLButtonElement;
      const form = document.querySelector("#seibiesForm") as HTMLFormElement;
      const exportBtn = document.querySelector(".export-btn-seibies") as HTMLButtonElement;
      const oblLastMonthInput = document.querySelector("#oblLastMonthSeibies") as HTMLInputElement;
      const totalCurrentValueSpan = document.querySelector("#totalCurrentValueSeibies") as HTMLSpanElement;
      const remainingValueSpan = document.querySelector("#remainingValueSeibies") as HTMLSpanElement;
      const oblLineFill = document.querySelector("#oblLineFillSeibies") as HTMLDivElement;
      const oblValidationMessage = document.querySelector("#oblValidationMessageSeibies") as HTMLDivElement;
      const formTitle = document.querySelector("#formTitleSeibies") as HTMLElement;

      // Filter Elements - Updated with Seibies-specific IDs
      const filterYear = document.querySelector("#filterYearSeibies") as HTMLSelectElement;
      const filterMonth = document.querySelector("#filterMonthSeibies") as HTMLSelectElement;
      const filterProject = document.querySelector("#filterProjectSeibies") as HTMLSelectElement;
      const filterCustomer = document.querySelector("#filterCustomerSeibies") as HTMLSelectElement;
      const filterProjectManager = document.querySelector("#filterProjectManagerSeibies") as HTMLSelectElement;
      const filterGroupHead = document.querySelector("#filterGroupHeadSeibies") as HTMLSelectElement;
      const filterProjectReference = document.querySelector("#filterProjectReferenceSeibies") as HTMLSelectElement;

      // Action Buttons - Updated with Seibies-specific IDs
      const importActualBtn = document.querySelector(".import-actual-btn-seibies") as HTMLButtonElement;
      const clearFiltersBtn = document.querySelector(".clear-filters-btn-seibies") as HTMLButtonElement; 

      // Pagination Elements - Updated with Seibies-specific IDs
      const firstPageBtn = document.querySelector("#firstPageSeibies") as HTMLButtonElement;
      const prevPageBtn = document.querySelector("#prevPageSeibies") as HTMLButtonElement;
      const nextPageBtn = document.querySelector("#nextPageSeibies") as HTMLButtonElement;
      const lastPageBtn = document.querySelector("#lastPageSeibies") as HTMLButtonElement;
      const currentPageSpan = document.querySelector("#currentPageSeibies") as HTMLSpanElement;
      const totalPagesSpan = document.querySelector("#totalPagesSeibies") as HTMLSpanElement;
      const pageNumbersDiv = document.querySelector("#pageNumbersSeibies") as HTMLDivElement;
      const startItemSpan = document.querySelector("#startItemSeibies") as HTMLSpanElement;
      const endItemSpan = document.querySelector("#endItemSeibies") as HTMLSpanElement;
      const totalItemsSpan = document.querySelector("#totalItemsSeibies") as HTMLSpanElement;

      let projects: ProjectItem[] = [];
      let forecasts: SeibiesForecastItem[] = [];
      let editingId: number | null = null;
      let allMonths: string[] = [];

      let currentUser: UserContext;
      let userGroups: string[] = [];
      let managedProjects: string[] = [];
      let managedGroups: string[] = [];
      
      // Pagination variables
// Add this with other DOM element declarations
const pageSizeSelect = document.querySelector("#pageSizeSelectSeibies") as HTMLSelectElement;

// Update the pagination variable declarations
let pageSize = 10; // Make this variable instead of const
let currentPage = 1;
let totalPages = 1;
let filteredData: SeibiesForecastItem[] = [];

      // ========== UTILITY FUNCTIONS ==========

      const toast = (icon: any, title: string) => Swal.fire({ toast: true, icon, title, position: "top-end", timer: 2000, showConfirmButton: false });

      const getDigest = async (): Promise<string> => {
        const res = await fetch(`${siteUrl}/_api/contextinfo`, { 
          method: "POST", 
          headers: { Accept: "application/json;odata=verbose" } 
        });
        const data = await res.json();
        return data.d.GetContextWebInformation.FormDigestValue;
      };

      // Add this with other utility functions
      const getUserContext = async (): Promise<UserContext> => {
        try {
          const userRes = await fetch(`${siteUrl}/_api/web/currentuser`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const userData = await userRes.json();
          const loginName = userData.d.LoginName;
          const displayName = userData.d.Title;

          const groupsRes = await fetch(`${siteUrl}/_api/web/currentuser/groups`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const groupsData = await groupsRes.json();
          userGroups = groupsData.d.results.map((g: any) => g.Title);
          
          const isSuperAdmin = userGroups.some(g => 
            g.toLowerCase().includes("super admin") || 
            g.toLowerCase() === "site owners" ||
            g === "Super Admin"
          );
          
          const isGroupHead = userGroups.some(g => 
            g.toLowerCase().includes("group head") || 
            g === "Group Head"
          );
          
          const isProjectManager = userGroups.some(g => 
            g.toLowerCase().includes("project manager") || 
            g === "Project Manager"
          );

          if (isGroupHead) {
            const groupHeadName = displayName;
            managedGroups = [groupHeadName]; 
          }

          if (isProjectManager) {
            const pmProjectsRes = await fetch(
              `${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$filter=ProjectManager/Title eq '${displayName}'&$select=Id,Title`,
              { headers: { Accept: "application/json;odata=verbose" } }
            );
            const pmProjectsData = await pmProjectsRes.json();
            managedProjects = pmProjectsData.d.results.map((p: any) => p.Title); 
          }
      
          return {
            loginName,
            displayName,
            groups: userGroups,
            isSuperAdmin,
            isGroupHead,
            isProjectManager,
            userGroups,
            managedProjects,
            managedGroups
          };
        } catch (error) {
          console.error("Error getting user context:", error);
          return {
            loginName: "",
            displayName: "",
            groups: [],
            isSuperAdmin: false,
            isGroupHead: false,
            isProjectManager: false,
            managedProjects: [],
            managedGroups: []
          };
        }
      };

      const filterDataByRole = (data: SeibiesForecastItem[]): SeibiesForecastItem[] => { 
        if (currentUser.isSuperAdmin) { 
          return data;
        }

        const filteredData = data.filter(forecast => {
          const projectTitle = forecast.Project?.Title;
          
          if (!projectTitle) { 
            return false;
          }

          const project = projects.find(p => p.Title === projectTitle);
          
          if (!project) { 
            return false;
          }

          if (currentUser.isGroupHead) {
            const canAccess = currentUser.managedGroups?.some(group => 
              project.GroupHead === group
            ) || false;
            return canAccess;
          }

          if (currentUser.isProjectManager) {
            const canAccess = currentUser.managedProjects?.includes(projectTitle) || false;
            return canAccess;
          }
          
          return false;
        });
        
        return filteredData;
      };

      const checkEditPermission = (forecast: SeibiesForecastItem): boolean => {
        if (currentUser.isSuperAdmin) { 
          return true;
        }

        const projectTitle = forecast.Project?.Title;
        if (!projectTitle) return false;

        const project = projects.find(p => p.Title === projectTitle);
        if (!project) return false;

        if (currentUser.isGroupHead) { 
          return currentUser.managedGroups?.some(group => 
            project.GroupHead === group
          ) || false;
        }

        if (currentUser.isProjectManager) { 
          return currentUser.managedProjects?.includes(projectTitle) || false;
        }

        return false;
      };

      const updateUIForRole = (): void => {
        const pageHeader = document.querySelector(".page-header-seibies") as HTMLElement;
        const roleIndicator = document.createElement("div");
        roleIndicator.className = "role-indicator-seibies";
        
        let roleText = "";
        if (currentUser.isSuperAdmin) {
          roleText = "Super Admin - Full Access";
          roleIndicator.style.backgroundColor = "#28a745";
        } else if (currentUser.isGroupHead) {
          roleText = `Group Head - ${currentUser.displayName}`;
          roleIndicator.style.backgroundColor = "#17a2b8";
        } else if (currentUser.isProjectManager) {
          roleText = `Project Manager - ${currentUser.displayName}`;
          roleIndicator.style.backgroundColor = "#ffc107";
        } else {
          roleText = "Limited Access";
          roleIndicator.style.backgroundColor = "#6c757d";
        }
        
        roleIndicator.innerHTML = `
          <span class="role-badge-seibies">👤 ${roleText}</span>
        `;
        
        pageHeader.parentNode?.insertBefore(roleIndicator, pageHeader.nextSibling);

        if (!currentUser.isSuperAdmin) {
          showFormBtn.disabled = false;
        }

        setTimeout(() => {
          applyRoleBasedUIClasses();
        }, 100);
      };

      const applyRoleBasedUIClasses = (): void => {
        if (currentUser.isSuperAdmin) {
          document.querySelectorAll('.hidden-by-role-seibies').forEach(element => {
            element.classList.remove('hidden-by-role-seibies');
          });
          return;
        }
        
        const tableHeaders = document.querySelectorAll('.month-columns-table-seibies th');
        
        tableHeaders.forEach(header => {
          const headerText = header.textContent?.toLowerCase() || '';
          
          if (headerText.includes('project manager') || headerText.includes('manager')) {
            if (currentUser.isProjectManager) {
              header.classList.add('hidden-by-role-seibies');
            } else {
              header.classList.remove('hidden-by-role-seibies');
            }
          }
          
          if (headerText.includes('group head') || headerText.includes('head')) {
            if (currentUser.isGroupHead) {
              header.classList.add('hidden-by-role-seibies');
            } else {
              header.classList.remove('hidden-by-role-seibies');
            }
          }
        });

        const projectManagerFilter = document.querySelector('#filterProjectManagerSeibies')?.closest('.tableColp4-seibies');
        const groupHeadFilter = document.querySelector('#filterGroupHeadSeibies')?.closest('.tableColp4-seibies');
        
        if (projectManagerFilter) {
          if (currentUser.isProjectManager) {
            projectManagerFilter.classList.add('hidden-by-role-seibies');
          } else {
            projectManagerFilter.classList.remove('hidden-by-role-seibies');
          }
        }
        
        if (groupHeadFilter) {
          if (currentUser.isGroupHead) {
            groupHeadFilter.classList.add('hidden-by-role-seibies');
          } else {
            groupHeadFilter.classList.remove('hidden-by-role-seibies');
          }
        }
      };

      const filterProjectSelectByRole = (): void => {
        if (currentUser.isSuperAdmin) {
          return;
        }

        const options = projectSelect.querySelectorAll("option");
        options.forEach((option, index) => {
          if (index === 0) return;
          
          const projectId = parseInt(option.value);
          const project = projects.find(p => p.Id === projectId);
          
          if (!project) {
            option.style.display = "none";
            return;
          }

          let showOption = false;
          
          if (currentUser.isGroupHead) {
            showOption = currentUser.managedGroups?.some(group => 
              project.GroupHead === group
            ) || false;
          } else if (currentUser.isProjectManager) {
            showOption = currentUser.managedProjects?.includes(project.Title) || false;
          }
          
          option.style.display = showOption ? "" : "none";
        });

        if (projectSelect.value) {
          const selectedOption = projectSelect.selectedOptions[0];
          if (selectedOption.style.display === "none") {
            projectSelect.value = "";
            toast("warning", "Your current project selection is not accessible with your role");
          }
        }
      };

      // Safe JSON parsing function
      const safeJsonParse = (jsonString: string | undefined, fallback: any = {}): any => {
        try {
          if (!jsonString || jsonString.trim() === '') {
            return fallback;
          }
          
          const cleanedString = jsonString.trim();
          
          if (cleanedString === '""' || cleanedString === "null") {
            return fallback;
          }
          
          return JSON.parse(cleanedString);
        } catch (error) {
          console.error("JSON parse error:", error, "Input:", jsonString);
          return fallback;
        }
      };

      const formatMonthKey = (date: Date): string => {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      };

      const formatMonthLabel = (date: Date): string => {
        return date.toLocaleString("default", { month: "short", year: "2-digit" });
      };

      const generateForecastTitle = (project: ProjectItem, forecastData: ForecastData): string => {
        const currentYear = new Date().getFullYear();
        let totalValue = 0;
        
        Object.keys(forecastData).forEach(key => {
          if (key.match(/^\d{4}-\d{2}$/)) {
            const monthData = forecastData[key] as ForecastMonthData;
            if (monthData) {
              totalValue += monthData.actual;
            }
          }
        });
        
        return `${project.Title} - ${currentYear} SEIBIES Forecast - ${totalValue.toLocaleString()}`;
      };

      // Get current and next 2 months for display
      const getDisplayMonths = (): string[] => {
        const now = new Date();
        const months: string[] = [];
        
        for (let i = 0; i < 3; i++) {
          const month = new Date(now.getFullYear(), now.getMonth() + i, 1);
          months.push(formatMonthKey(month));
        }
        
        return months;
      };

      const getAllMonthsForStorage = (): string[] => {
        return generateIdealMonthStructure();
      };

      // Utility function to allow only numbers 0-9 in text inputs
      const allowOnlyNumbers = (input: HTMLInputElement): void => {
        input.addEventListener('input', function() {
          let value = this.value.replace(/[^\d]/g, '');
          
          if (value.length > 1 && value.startsWith('0')) {
            value = value.replace(/^0+/, '');
            if (value === '') value = '0';
          }
          
          this.value = value;
          
          if (value === '' || value === '0') {
            this.className = this.className.replace('input-with-value-seibies', 'input-empty-seibies');
          } else {
            this.className = this.className.replace('input-empty-seibies', 'input-with-value-seibies');
          }
        });
        
        input.addEventListener('keydown', function(e) {
          if ([8, 9, 13, 27, 46].includes(e.keyCode) || 
              (e.keyCode === 65 && e.ctrlKey === true) || 
              (e.keyCode === 67 && e.ctrlKey === true) ||
              (e.keyCode === 86 && e.ctrlKey === true) ||
              (e.keyCode === 88 && e.ctrlKey === true) ||
              (e.keyCode >= 35 && e.keyCode <= 39)) {
            return;
          }
          
          if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
          }
        });
        
        input.addEventListener('paste', function(e) {
          const clipboardData = e.clipboardData || (window as any).clipboardData;
          const pastedData = clipboardData?.getData('Text') || '';
          
          if (/[^\d]/.test(pastedData)) {
            e.preventDefault();
          }
        });
      };

      // Function to get numeric value from text input - 0 is placeholder
      const getNumericValue = (input: HTMLInputElement): number => {
        const value = input.value.trim();
        if (value === '' || value === '0') return 0;
        return parseInt(value) || 0;
      };

      // Function to set numeric value to text input - 0 shows as empty
      const setNumericValue = (input: HTMLInputElement, value: number): void => {
        if (value === 0) {
          input.value = '';
          input.className = input.className.replace('input-with-value-seibies', 'input-empty-seibies');
        } else {
          input.value = value.toString();
          input.className = input.className.replace('input-empty-seibies', 'input-with-value-seibies');
        }
      };

      // Enhanced OBL validation with toast notifications
      const showOBLErrorToast = (message: string, isWarning: boolean = false): void => {
        const existingToast = document.querySelector('.obl-error-toast-seibies');
        if (existingToast) existingToast.remove();
        
        const toast = document.createElement('div');
        toast.className = `obl-error-toast-seibies ${isWarning ? 'warning-seibies' : ''}`;
        toast.innerHTML = `
          ${message}
          <button class="toast-close-seibies">&times;</button>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
          if (toast.parentNode) {
            toast.remove();
          }
        }, 5000);
        
        toast.querySelector('.toast-close-seibies')?.addEventListener('click', () => {
          toast.remove();
        });
      };

      // ========== MONTH STRUCTURE FUNCTIONS ==========

      const generateIdealMonthStructure = (): string[] => {
        const months: string[] = [];
        const currentDate = new Date(); 
        // Historical: 3 months before current (readonly)
        for (let i = -3; i < 0; i++) {
          const historicalDate = new Date(currentDate);
          historicalDate.setMonth(historicalDate.getMonth() + i);
          months.push(formatMonthKey(historicalDate));
        }
        
        // Detailed: Current + Next 2 months (editable with items)
        for (let i = 0; i < 3; i++) {
          const detailedDate = new Date(currentDate);
          detailedDate.setMonth(detailedDate.getMonth() + i);
          months.push(formatMonthKey(detailedDate));
        }
        
        // Future: Next 15 months (simple inputs)
        for (let i = 3; i < 18; i++) {
          const futureDate = new Date(currentDate);
          futureDate.setMonth(futureDate.getMonth() + i);
          months.push(formatMonthKey(futureDate));
        } 
        return months;
      };

      // ========== YEARLY FORECAST FUNCTIONS ==========

      const getLastMonthKey = (existingData: ForecastData): string | undefined => {
        const monthKeys = Object.keys(existingData).filter(key => key.match(/^\d{4}-\d{2}$/));
        
        if (monthKeys.length === 0) {
          return undefined;
        }
        
        const sortedMonths = monthKeys.sort();
        const lastMonth = sortedMonths[sortedMonths.length - 1]; 
        return lastMonth;
      };

      const createFreshYearlyStructure = (lastMonthKey?: string): YearlyForecastData => {
        const yearlyData: YearlyForecastData = {};
        
        let startYear: number;
        
        if (lastMonthKey) {
          startYear = parseInt(lastMonthKey.split('-')[0]); 
        } else {
          const futureDate = new Date();
          futureDate.setMonth(futureDate.getMonth() + 15);
          startYear = futureDate.getFullYear(); 
        }
        
        const endYear = startYear + 4; 
        for (let year = startYear; year <= endYear; year++) {
          yearlyData[year.toString()] = {
            plan: 0,
            actual: 0
          };
        }
        
        return yearlyData;
      };

      const createFreshForecastStructure = (): ForecastData => {
        const idealMonths = generateIdealMonthStructure();
        const freshData: ForecastData = {};
        
        const currentMonthKey = formatMonthKey(new Date());
        
        idealMonths.forEach((monthKey, index) => {
          const isCurrentMonth = monthKey === currentMonthKey;
          freshData[monthKey] = {
            plan: 0,
            actual: 0,
            forecast: 0,
            date: isCurrentMonth ? '' : undefined
          };
        });
        
        const lastMonthKey = idealMonths[idealMonths.length - 1];
        freshData.yearly = createFreshYearlyStructure(lastMonthKey);
        
        return freshData;
      };

      // Type guard to check if data is ForecastMonthData
      const isForecastMonthData = (data: any): data is ForecastMonthData => {
        return data && 
               typeof data.plan === 'number' && 
               typeof data.actual === 'number';
      };

      const handleMonthProgression = (forecastData: ForecastData): ForecastData => {
        const now = new Date();
        const currentMonthKey = formatMonthKey(now); 
        const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
        const idealMonths = generateIdealMonthStructure();
        
        if (originalMonths[0] === idealMonths[0]) { 
          return forecastData;
        }
 
        const updatedData: ForecastData = {};

        idealMonths.forEach((monthKey, index) => {
          const existingData = forecastData[monthKey];
          if (existingData && isForecastMonthData(existingData)) {
            updatedData[monthKey] = JSON.parse(JSON.stringify(existingData));
          } else {
            updatedData[monthKey] = {
              plan: 0,
              actual: 0
            };
          }
        }); 
        const currentMonthIndex = idealMonths.indexOf(currentMonthKey);
        
        idealMonths.forEach((monthKey, index) => {
          const monthData = updatedData[monthKey];
          
          if (monthData && isForecastMonthData(monthData)) {
            const isCurrentOrFuture = index >= currentMonthIndex;
            
            if (isCurrentOrFuture) {
              const oldActual = monthData.actual;
              
              monthData.plan = oldActual;
              monthData.actual = 0;
              
             } else {
            }
          }
        });

        if (forecastData.yearly) {
          updatedData.yearly = JSON.parse(JSON.stringify(forecastData.yearly));
        } else {
          const lastMonthKey = idealMonths[idealMonths.length - 1];
          updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
        }
 
        return updatedData;
      };

      const propagateMonthValues = (forecastData: ForecastData): ForecastData => {
        if (Object.keys(forecastData).length === 0) {
          return forecastData;
        }
        
        return handleMonthProgression(forecastData);
      };

      // ========== DATA LOADING FUNCTIONS ==========

      const loadProjects = async (): Promise<void> => {
        try {
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$select=Id,Title,CustomerName,GroupHead,PC,ProjectReference,ProjectManager/Title&$expand=ProjectManager`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const data: SharePointResponse<ProjectItem> = await res.json();
          const rawProjects: ProjectItem[] = data.d?.results || [];
          
          projects = Array.from(new Map(rawProjects.map((p: ProjectItem) => [p.Title, p])).values());
          
          projectSelect.innerHTML = `<option value="">Select Project</option>` + 
            projects.map(p => `<option value="${p.Id}">${p.Title}</option>`).join("");
        } catch (error) {
          console.error("Error loading projects:", error);
          toast("error", "Failed to load projects");
        }        
      };

      const loadForecasts = async (): Promise<void> => {
        try {
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Id,Title,Project/Id,Project/Title,ProfitCentre,OBL,ForecastData,SeibiesActual,CreatedDate,UpdatedDate&$expand=Project&$top=5000`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const data: SharePointResponse<SeibiesForecastItem> = await res.json();
          
          forecasts = (data.d?.results || []).map(forecast => ({
            ...forecast,
            ForecastData: typeof forecast.ForecastData === 'string' ? 
              forecast.ForecastData : 
              JSON.stringify(forecast.ForecastData || {}),
            SeibiesActual: typeof forecast.SeibiesActual === 'string' ? 
              forecast.SeibiesActual : 
              JSON.stringify(forecast.SeibiesActual || {})
          }));
           
          
        } catch (error) { 
          toast("error", "Failed to load SEIBIES forecasts");
        }
      };

      // ========== EXPORT FUNCTIONS ==========

      const getMonthName = (monthNumber: string): string => {
        const months = [
          "Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        return months[parseInt(monthNumber) - 1] || "Month";
      };

      const exportToExcelWithFullStyle = (): void => { 
        const selectedYear = filterYear.value;
        const selectedMonth = filterMonth.value;
        
        if (!selectedYear || !selectedMonth) {
          toast("error", "Please select year and month to export");
          return;
        }

        const exportData = filteredData.length > 0 ? filteredData : forecasts;
        
        if (exportData.length === 0) {
          toast("error", "No SEIBIES data available to export");
          return;
        }

        try {
          const { headers, allMonths, lastFiveYears } = generateHeadersStructure(selectedYear, selectedMonth, exportData);
        
          const excelData = exportData.map(forecast => {
            const projectTitle = forecast.Project?.Title || "-";
            const proj = projects.find(p => p.Title === projectTitle);
            
            const seibiesActualData = safeJsonParse(forecast.SeibiesActual, {});
            const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
            
            const oblValue = forecast.OBL || 0;
            
            const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
            const monthName = getMonthName(selectedMonth);
            
            const selectedMonthForecastData = forecastData[selectedMonthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            const selectedMonthPlan = selectedMonthForecastData.plan || 0;
            const selectedMonthCurrent = selectedMonthForecastData.actual || 0;
            const selectedMonthActual = seibiesActualData[selectedMonthKey] || 0;
            const selectedMonthForecast = selectedMonthForecastData.forecast || 0;

            const rowData: any = {
              "Profit Centre": forecast.ProfitCentre || "-",
              "SO/Project Ref": proj?.ProjectReference || "-",
              "Customer Name": proj?.CustomerName || "-",
              "Project Name": projectTitle,
              "Group Head": proj?.GroupHead || "-",
              "Project Manager": typeof proj?.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-",
              "SEI-BIES": oblValue,
              [`${monthName} ${selectedYear} (P)`]: selectedMonthPlan,
              [`${monthName} ${selectedYear} (C)`]: selectedMonthCurrent,
              [`${monthName} ${selectedYear} (R)`]: selectedMonthActual,
              [`${monthName} ${selectedYear} (F)`]: selectedMonthForecast,
            };
            
            allMonths.forEach(monthKey => {
              const [year, month] = monthKey.split('-');
              const monthLabel = getMonthName(month);
              const displayLabel = `${monthLabel} ${year}`;
              
              const forecastMonthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
              const planValue = forecastMonthData.plan || 0;
              const currentValue = forecastMonthData.actual || 0;
              
              rowData[`${displayLabel} (P)`] = planValue;
              rowData[`${displayLabel} (C)`] = currentValue;
            });
            
            lastFiveYears.forEach(year => {
              const yearData = forecastData.yearly?.[year] || { plan: 0, actual: 0 };
              rowData[`${year} (P)`] = yearData.plan;
              rowData[`${year} (C)`] = yearData.actual;
            });     
            
            const totalMonthlyCurrent = Object.keys(forecastData)
              .filter(key => key.match(/^\d{4}-\d{2}$/))
              .reduce((sum, monthKey) => {
                const monthData = forecastData[monthKey] as ForecastMonthData;
                return sum + (monthData?.actual || 0);
              }, 0);

            const totalYearlyCurrent = forecastData.yearly ? 
              Object.values(forecastData.yearly).reduce((sum, yearData) => {
                return sum + (yearData.actual || 0);
              }, 0) : 0;

            rowData["Balance"] = oblValue - (totalMonthlyCurrent + totalYearlyCurrent);
            
            return rowData;
          });
 
          const wb = XLSX.utils.book_new();
          
          const ws = XLSX.utils.json_to_sheet(excelData, { header: headers });

          const headerStyle = {
            fill: {
              fgColor: { rgb: "FF0078D4" }
            },
            font: {
              name: "Arial",
              sz: 10,
              bold: true,
              color: { rgb: "FFFFFFFF" }
            },
            alignment: {
              horizontal: "center",
              vertical: "center"
            },
            border: {
              top: { style: "thin", color: { rgb: "FF000000" } },
              left: { style: "thin", color: { rgb: "FF000000" } },
              bottom: { style: "thin", color: { rgb: "FF000000" } },
              right: { style: "thin", color: { rgb: "FF000000" } }
            }
          };

          const dataStyle = {
            font: {
              name: "Arial",
              sz: 10
            },
            alignment: {
              horizontal: "center",
              vertical: "center"
            },
            border: {
              top: { style: "thin", color: { rgb: "FFD0D0D0" } },
              left: { style: "thin", color: { rgb: "FFD0D0D0" } },
              bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
              right: { style: "thin", color: { rgb: "FFD0D0D0" } }
            }
          };

          const numberStyle = {
            ...dataStyle,
            alignment: {
              horizontal: "right",
              vertical: "center"
            }
          };

          const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
          
          for (let col = range.s.c; col <= range.e.c; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            if (!ws[cellAddress]) continue;
            
            if (!ws[cellAddress].s) {
              ws[cellAddress].s = {};
            }
            ws[cellAddress].s = headerStyle;
          }
          
          for (let row = range.s.r + 1; row <= range.e.r; row++) {
            for (let col = range.s.c; col <= range.e.c; col++) {
              const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
              if (!ws[cellAddress]) continue;
              
              const isNumberColumn = col >= 6;
              const styleToApply = isNumberColumn ? numberStyle : dataStyle;
              
              if (!ws[cellAddress].s) {
                ws[cellAddress].s = {};
              }
              ws[cellAddress].s = styleToApply;
            }
          }

          const colWidths = headers.map((header: string) => {
            if (header.includes('Project Name')) return { wch: 25 };
            if (header.includes('Customer Name')) return { wch: 20 };
            if (header.includes('Profit Centre') || header.includes('SO/Project Ref')) return { wch: 12 };
            if (header.includes('Group Head') || header.includes('Project Manager')) return { wch: 15 };
            if (header.includes('OBL') || header.includes('Balance')) return { wch: 12 };
            if (header.includes('(P)') || header.includes('(C)') || header.includes('(F)')) return { wch: 10 };
            return { wch: 12 };
          });
          ws['!cols'] = colWidths;

          ws['!freeze'] = { x: 0, y: 1 };

          XLSX.utils.book_append_sheet(wb, ws, "SEIBIES Forecast");

          const monthName = getMonthName(selectedMonth);
          const fileName = `SEIBIES_Forecast_${monthName}_${selectedYear}_Filtered.xlsx`;
          
          XLSX.writeFile(wb, fileName);
           
          toast("success", `Exported ${exportData.length} filtered SEIBIES records for ${monthName} ${selectedYear}`);
          
        } catch (error) { 
          toast("error", "Failed to export SEIBIES data to Excel");
        }
      };

      const generateHeadersStructure = (selectedYear: string, selectedMonth: string, exportData: SeibiesForecastItem[]) => {
        const baseHeaders = [
          "Profit Centre", 
          "SO/Project Ref", 
          "Customer Name", 
          "Project Name", 
          "Group Head", 
          "Project Manager", 
          "SEI-BIES",
        ];

        const selectedMonthName = getMonthName(selectedMonth);
        const selectedMonthHeaders = [
          `${selectedMonthName} ${selectedYear} (P)`,
          `${selectedMonthName} ${selectedYear} (C)`,
          `${selectedMonthName} ${selectedYear} (R)`,
          `${selectedMonthName} ${selectedYear} (F)`
        ];

        const allMonthKeys = new Set<string>();
        
        exportData.forEach(forecast => {
          const forecastData = safeJsonParse(forecast.ForecastData, {});
          Object.keys(forecastData).forEach(key => {
            if (key && key.match(/^\d{4}-\d{2}$/)) {
              allMonthKeys.add(key);
            }
          });
        });

        const sortedMonthKeys = Array.from(allMonthKeys).sort();
        const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
        const selectedIndex = sortedMonthKeys.indexOf(selectedMonthKey);
        
        const startIndex = selectedIndex >= 0 ? selectedIndex + 1 : 0;
        const next17Months = sortedMonthKeys.slice(startIndex, startIndex + 17);
 
        const monthlyHeaders: string[] = [];
        next17Months.forEach(monthKey => {
          const [year, month] = monthKey.split('-');
          const monthLabel = getMonthName(month);
          const displayLabel = `${monthLabel} ${year}`;
          monthlyHeaders.push(`${displayLabel} (P)`, `${displayLabel} (C)`);
        });

        const lastFiveYears = getLastFiveYears(exportData);
        const yearlyHeaders: string[] = [];
        lastFiveYears.forEach(year => {
          yearlyHeaders.push(`${year} (P)`, `${year} (C)`);
        });

        const finalHeaders = [
          ...baseHeaders,
          ...selectedMonthHeaders,
          ...monthlyHeaders,
          ...yearlyHeaders,
          "Balance"
        ];
        
        return { 
          headers: finalHeaders, 
          allMonths: next17Months,
          lastFiveYears
        };
      };

      const getLastFiveYears = (data: SeibiesForecastItem[]): string[] => {
        const years = new Set<string>();
        
        data.forEach(forecast => {
          const forecastData = safeJsonParse(forecast.ForecastData, {});
          if (forecastData.yearly) {
            Object.keys(forecastData.yearly).forEach(year => {
              years.add(year);
            });
          }
        });
        
        const sortedYears = Array.from(years).sort();
        return sortedYears.slice(-5);
      };

        
      // ======  PAGINATION FUNCTIONS ======

const initializePagination = (data: SeibiesForecastItem[]): void => { 
  // Apply role filtering ONCE
  const roleFilteredData = filterDataByRole(data);
  filteredData = roleFilteredData; 
  calculateTotalPages();
  currentPage = 1;
  updatePaginationControls();
  renderCurrentPage();
  
  // Refresh totals header
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
};

const calculateTotalPages = (): void => {
  totalPages = Math.ceil(filteredData.length / pageSize);
};

const changePageSize = (newSize: number): void => {
  if (newSize === pageSize) return;
  
  pageSize = newSize;
  
  // Calculate new page number to keep the same first item visible
  const oldStartItem = (currentPage - 1) * pageSize;
  currentPage = Math.floor(oldStartItem / pageSize) + 1;
  
  calculateTotalPages();
  
  // Adjust current page if it exceeds new total pages
  if (currentPage > totalPages) {
    currentPage = totalPages || 1;
  }
  
  updatePaginationControls();
  renderCurrentPage();
  
  toast("info", `Showing ${pageSize} SEIBIES records per page`);
};

const updatePaginationControls = (): void => {
  currentPageSpan.textContent = currentPage.toString();
  totalPagesSpan.textContent = totalPages.toString();
  
  const startItem = (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, filteredData.length);
  startItemSpan.textContent = startItem.toString();
  endItemSpan.textContent = endItem.toString();
  totalItemsSpan.textContent = filteredData.length.toString();
  
  // Update page size selector
  if (pageSizeSelect) {
    pageSizeSelect.value = pageSize.toString();
  }
  
  // Enable/disable navigation buttons
  firstPageBtn.disabled = currentPage === 1;
  prevPageBtn.disabled = currentPage === 1;
  nextPageBtn.disabled = currentPage === totalPages;
  lastPageBtn.disabled = currentPage === totalPages;
  
  updatePageNumbers();
};

const updatePageNumbers = (): void => {
  pageNumbersDiv.innerHTML = '';
  
  const maxVisiblePages = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
  let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
  
  if (endPage - startPage + 1 < maxVisiblePages) {
    startPage = Math.max(1, endPage - maxVisiblePages + 1);
  }
  
  // Add "..." before first page if needed
  if (startPage > 1) {
    const dotsBtn = document.createElement('button');
    dotsBtn.className = 'page-number-seibies dots-seibies';
    dotsBtn.textContent = '...';
    dotsBtn.disabled = true;
    pageNumbersDiv.appendChild(dotsBtn);
  }
  
  for (let i = startPage; i <= endPage; i++) {
    const pageBtn = document.createElement('button');
    pageBtn.className = `page-number-seibies ${i === currentPage ? 'active-seibies' : ''}`;
    pageBtn.textContent = i.toString();
    pageBtn.addEventListener('click', () => goToPage(i));
    pageNumbersDiv.appendChild(pageBtn);
  }
  
  // Add "..." after last page if needed
  if (endPage < totalPages) {
    const dotsBtn = document.createElement('button');
    dotsBtn.className = 'page-number-seibies dots-seibies';
    dotsBtn.textContent = '...';
    dotsBtn.disabled = true;
    pageNumbersDiv.appendChild(dotsBtn);
  }
};

      const goToPage = (page: number): void => {
        if (page < 1 || page > totalPages || page === currentPage) return;
        
        currentPage = page;
        updatePaginationControls();
        renderCurrentPage();
      };
 
     

      // ========== TABLE RENDERING FUNCTIONS ==========

// Add this function with your other utility functions
const calculateTotals = (
  data: SeibiesForecastItem[],
  displayMonths: string[],
  currentMonthKey: string
): any => {
  let dataToCalculate = currentUser.isSuperAdmin
    ? data
    : filterDataByRole(data);

  const totals = {
    obl: 0,
    actualSeibies: 0,
    monthly: {} as {
      [key: string]: { plan: number; current: number; forecast: number; total: number }
    }
  };

  // Init months
  displayMonths.forEach(monthKey => {
    totals.monthly[monthKey] = { plan: 0, current: 0, forecast: 0, total: 0 };
  });

  dataToCalculate.forEach(forecast => {
    // ROUND OBL
    totals.obl += Math.round(Number(forecast.OBL) || 0);

    const forecastData = safeJsonParse(forecast.ForecastData, {});

    displayMonths.forEach(monthKey => {
      const m = forecastData[monthKey] || {};
      const isCurrent = monthKey === currentMonthKey;

      const plan = Math.round(Number(m.plan) || 0);
      const current = Math.round(Number(m.actual) || 0);
      const forecastVal = Math.round(Number(m.forecast) || 0);

      totals.monthly[monthKey].plan += plan;
      totals.monthly[monthKey].current += current;

      if (isCurrent) {
        totals.monthly[monthKey].forecast += forecastVal;
        totals.monthly[monthKey].total += plan + current + forecastVal;
      } else {
        totals.monthly[monthKey].total += plan + current;
      }
    });
  });

  return totals;
};

// Add this function after calculateTotals
const renderTotalsHeader = (displayMonths: string[], currentMonthKey: string): void => {
  const totalsHeader = document.createElement('thead');
  totalsHeader.id = 'totalsHeaderSeibies';
  
  const table = document.querySelector('.month-columns-table-seibies') as HTMLTableElement;
  if (!table) return;
  
  // Remove existing totals header if present
  const existingTotals = document.querySelector('#totalsHeaderSeibies');
  if (existingTotals) existingTotals.remove();
  
  // Insert at the beginning of the table
  table.insertBefore(totalsHeader, table.firstChild);

  // Get all data and apply role filtering
  const allData = forecasts;
  const roleFiltered = filterDataByRole(allData);
  const filtered = filteredData.length ? filteredData : roleFiltered;

  const allTotals = calculateTotals(allData, displayMonths, currentMonthKey);
  const filteredTotals = calculateTotals(filtered, displayMonths, currentMonthKey);

  const showPM = currentUser.isSuperAdmin || !currentUser.isProjectManager;
  const showGH = currentUser.isSuperAdmin || !currentUser.isGroupHead;

  const buildTotalsRow = (label: string, totals: any, css: string) => `
    <tr class="${css}">
      <!-- Project -->
      <td class="totals-label-seibies">${label}</td>

      <!-- Customer -->
      <td></td>

      ${showPM ? `<td></td>` : ''}
      ${showGH ? `<td></td>` : ''}

      <!-- Project Reference -->
      <td></td>

      <!-- OBL -->
      <td class="total-value-seibies">${totals.obl.toLocaleString('en-IN')}</td>

      <!-- Actual SEIBIES -->
      <td class="total-value-seibies">${totals.actualSeibies.toLocaleString('en-IN')}</td>

      <!-- Months -->
      ${displayMonths.map(m => {
        const isCurrent = m === currentMonthKey;
        const t = totals.monthly[m] || { plan: 0, current: 0, forecast: 0, total: 0 };

        return isCurrent
          ? `
            <td>${t.plan}</td>
            <td>${t.current}</td>
            <td>${t.forecast}</td>
            <td class="total-value-seibies">${t.total}</td>
          `
          : `
            <td>${t.plan}</td>
            <td>${t.current}</td>
            <td class="total-value-seibies">${t.total}</td>
          `;
      }).join('')}

      <!-- Actions -->
      <td></td>
    </tr>
  `;

  totalsHeader.innerHTML = `
    <table class="totals-header-table-seibies" style="width: 100%;">
      ${buildTotalsRow(`All`, allTotals, 'all-projects-total-seibies')}
      ${buildTotalsRow(`Filtered (${filtered.length})`, filteredTotals, 'filtered-total-seibies')}
    </table>
  `;
};

// Update renderCurrentPage to call renderTotalsHeader
const renderCurrentPage = (): void => {
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, filteredData.length);
  const pageData = filteredData.slice(startIndex, endIndex);
  
  renderTableWithMonthColumns(pageData);
  
  // Add totals header
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
};
const renderTableWithMonthColumns = (data: SeibiesForecastItem[]): void => {
  // Apply role-based filtering to the data
  const roleFilteredForecasts = filterDataByRole(data);
  
  if (!roleFilteredForecasts.length) {
    tableBody.innerHTML = `<tr><td colspan="25" style="text-align:center;padding:20px;">
      ${currentUser.isSuperAdmin ? 'No SEIBIES records found' : 
        currentUser.isGroupHead ? 'No SEIBIES records found in your groups' : 
        currentUser.isProjectManager ? 'No assigned SEIBIES projects found' : 
        'No access to view any SEIBIES records'}
    </td></tr>`;
    
    // Clear totals header if no data
    const totalsHeader = document.querySelector("#totalsHeaderSeibies") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = '';
    return;
  }

  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  
  // First, render the totals rows above the main header
  renderTotalsHeader(displayMonths, currentMonthKey);
  
  // Determine which columns to show based on role - MUST MATCH TOTALS HEADER
  const showProjectManagerColumn = currentUser.isSuperAdmin ? true : !currentUser.isProjectManager;
  const showGroupHeadColumn = currentUser.isSuperAdmin ? true : !currentUser.isGroupHead;
  
  // Count total columns to verify alignment
  let totalColumnCount = 0;
  
  // Count base columns
  totalColumnCount += 1; // Project
  totalColumnCount += 1; // Customer
  if (showProjectManagerColumn) totalColumnCount += 1;
  if (showGroupHeadColumn) totalColumnCount += 1;
  totalColumnCount += 1; // Project Reference
  totalColumnCount += 1; // SEI-BIES
  totalColumnCount += 1; // Actual SEIBIES
  
  // Count month columns
  displayMonths.forEach(monthKey => {
    const isCurrentMonth = monthKey === currentMonthKey;
    totalColumnCount += isCurrentMonth ? 4 : 3; // Current month has 4 columns, others have 3
  });
  
  totalColumnCount += 1; // Actions
  
  // Build main table header
  const mainHeaderHTML = `
    <!-- ROW 1: Main Header Row 1 -->
    <tr>
      <!-- Project Column with Sort -->
      <th rowspan="2" class="project-info-cell-seibies">
        <div class="sort-header-container-seibies">
          <span class="header-label-seibies">Project</span>
          <div class="sort-buttons-container-seibies">
            <button class="sort-btn-seibies ${currentSortConfig.column === 'project' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                    data-sort="project" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-seibies ${currentSortConfig.column === 'project' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                    data-sort="project" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Customer Column with Sort -->
      <th rowspan="2" class="project-info-cell-seibies">
        <div class="sort-header-container-seibies">
          <span class="header-label-seibies">Customer</span>
          <div class="sort-buttons-container-seibies">
            <button class="sort-btn-seibies ${currentSortConfig.column === 'customer' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                    data-sort="customer" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-seibies ${currentSortConfig.column === 'customer' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                    data-sort="customer" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      ${showProjectManagerColumn ? `
        <th rowspan="2" class="project-info-cell-seibies">
          <div class="sort-header-container-seibies">
            <span class="header-label-seibies">Project Manager</span>
            <div class="sort-buttons-container-seibies">
              <button class="sort-btn-seibies ${currentSortConfig.column === 'projectManager' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                      data-sort="projectManager" data-direction="asc" title="Sort Ascending">▲</button>
              <button class="sort-btn-seibies ${currentSortConfig.column === 'projectManager' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                      data-sort="projectManager" data-direction="desc" title="Sort Descending">▼</button>
            </div>
          </div>
        </th>
      ` : ''}
      
      ${showGroupHeadColumn ? `
        <th rowspan="2" class="project-info-cell-seibies">
          <div class="sort-header-container-seibies">
            <span class="header-label-seibies">Group Head</span>
            <div class="sort-buttons-container-seibies">
              <button class="sort-btn-seibies ${currentSortConfig.column === 'groupHead' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                      data-sort="groupHead" data-direction="asc" title="Sort Ascending">▲</button>
              <button class="sort-btn-seibies ${currentSortConfig.column === 'groupHead' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                      data-sort="groupHead" data-direction="desc" title="Sort Descending">▼</button>
            </div>
          </div>
        </th>
      ` : ''}
      
      <!-- Project Reference Column -->
      <th rowspan="2" class="project-info-cell-seibies">Project Reference</th>
      
      <!-- SEI-BIES Column with Sort -->
      <th rowspan="2" class="month-column-header-seibies">
        <div class="sort-header-container-seibies">
          <span class="header-label-seibies">SEI-BIES</span>
          <div class="sort-buttons-container-seibies">
            <button class="sort-btn-seibies ${currentSortConfig.column === 'obl' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                    data-sort="obl" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-seibies ${currentSortConfig.column === 'obl' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                    data-sort="obl" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Actual SEIBIES Column with Sort -->
      <th rowspan="2" class="month-column-header-seibies">
        <div class="sort-header-container-seibies">
          <span class="header-label-seibies">Actual SEIBIES</span>
          <div class="sort-buttons-container-seibies">
            <button class="sort-btn-seibies ${currentSortConfig.column === 'actualSeibies' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                    data-sort="actualSeibies" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-seibies ${currentSortConfig.column === 'actualSeibies' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                    data-sort="actualSeibies" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      ${displayMonths.map((month, monthIndex) => {
        const isCurrentMonth = month === currentMonthKey;
        const colspan = isCurrentMonth ? 4 : 3; // Current month has 4 columns, others have 3
        return `
          <th colspan="${colspan}" class="month-column-header-seibies ${isCurrentMonth ? 'current-month-header-seibies' : ''}">
            <div class="sort-header-container-seibies">
              <span class="header-label-seibies">${formatMonthLabel(new Date(month + "-01"))}</span>
              <div class="sort-buttons-container-seibies">
                <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                        data-sort="month" data-direction="asc" data-month-index="${monthIndex}" title="Sort by Month Total Ascending">▲</button>
                <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                        data-sort="month" data-direction="desc" data-month-index="${monthIndex}" title="Sort by Month Total Descending">▼</button>
              </div>
            </div>
            ${isCurrentMonth ? ' <span style="font-size:10px;color:#ffeb3b;">(Current Month)</span>' : ''}
          </th>
        `;
      }).join('')}
      <th rowspan="2">Actions</th>
    </tr>
    
    <!-- ROW 2: Main Header Row 2 (Sub-headers) -->
    <tr>
      ${displayMonths.map((month, monthIndex) => {
        const isCurrentMonth = month === currentMonthKey;
        if (isCurrentMonth) {
          return `
            <th class="month-subheader-seibies current-month-header-table-seibies">
              <div class="sort-header-container-seibies">
                <span>Plan</span>
                <div class="sort-buttons-container-seibies">
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Ascending">▲</button>
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-seibies current-month-header-table-seibies">
              <div class="sort-header-container-seibies">
                <span>Current</span>
                <div class="sort-buttons-container-seibies">
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Ascending">▲</button>
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-seibies current-month-header-table-seibies">
              <div class="sort-header-container-seibies">
                <span>Forecast</span>
                <div class="sort-buttons-container-seibies">
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'forecast' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="forecast" data-month-index="${monthIndex}" title="Sort Forecast Ascending">▲</button>
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'forecast' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="forecast" data-month-index="${monthIndex}" title="Sort Forecast Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-seibies current-month-header-table-seibies">
              <div class="sort-header-container-seibies">
                <span>Total</span>
                <div class="sort-buttons-container-seibies">
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Ascending">▲</button>
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Descending">▼</button>
                </div>
              </div>
            </th>
          `;
        } else {
          return `
            <th class="month-subheader-seibies">
              <div class="sort-header-container-seibies">
                <span>Plan</span>
                <div class="sort-buttons-container-seibies">
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Ascending">▲</button>
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-seibies">
              <div class="sort-header-container-seibies">
                <span>Current</span>
                <div class="sort-buttons-container-seibies">
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Ascending">▲</button>
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-seibies">
              <div class="sort-header-container-seibies">
                <span>Total</span>
                <div class="sort-buttons-container-seibies">
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'asc' ? 'sort-asc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Ascending">▲</button>
                  <button class="sort-btn-seibies ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'desc' ? 'sort-desc-seibies active-seibies' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Descending">▼</button>
                </div>
              </div>
            </th>
          `;
        }
      }).join('')}
    </tr>
  `;

  // Set main header HTML
  monthColumnsHeader.innerHTML = mainHeaderHTML;

  // Build table body with actual data
  let tableBodyHTML = '';

  roleFilteredForecasts.forEach((forecast, index) => {
    const projectTitle = forecast.Project?.Title || "-";
    const proj = projects.find(p => p.Title === projectTitle);
    
    // Parse forecast data
    const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
    const seibiesActualData = safeJsonParse(forecast.SeibiesActual, {});
    
    // Get selected year and month for actual SEIBIES
    const selectedYear = filterYear.value;
    const selectedMonth = filterMonth.value;
    const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
    const actualSeibies = selectedMonthKey ? seibiesActualData[selectedMonthKey] || 0 : 0;
    const formattedOBL = Math.round(forecast.OBL || 0).toLocaleString('en-IN');
    const formattedActualSeibies = Math.round(actualSeibies || 0).toLocaleString('en-IN');
    
    // Start building the row
    let rowHTML = `
      <tr>
        <td class="project-info-cell-seibies">${projectTitle}</td>
        <td class="project-info-cell-seibies">${proj?.CustomerName || "-"}</td>
    `;

    // Add Project Manager column if visible
    if (showProjectManagerColumn) {
      const managerName = typeof proj?.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-";
      rowHTML += `<td class="project-info-cell-seibies">${managerName}</td>`;
    }

    // Add Group Head column if visible
    if (showGroupHeadColumn) {
      rowHTML += `<td class="project-info-cell-seibies">${proj?.GroupHead || "-"}</td>`;
    }

    rowHTML += `
        <td class="project-info-cell-seibies">${proj?.ProjectReference || "-"}</td>
        <td class="month-column-cell-seibies">${formattedOBL}</td>
        <td class="month-column-cell-seibies">${formattedActualSeibies}</td>
    `;

    // Add month columns data with totals
    displayMonths.forEach((monthKey, monthIndex) => {
      const monthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
      const isCurrentMonth = monthKey === currentMonthKey;
      
      // Calculate totals
      const planValue = monthData.plan || 0;
      const currentValue = monthData.actual || 0;
      const forecastValue = monthData.forecast || 0;
      
      if (isCurrentMonth) {
        // Current month: show plan, current, forecast, and total (plan + current + forecast)
        const totalValue = planValue + currentValue + forecastValue;
        rowHTML += `
          <td class="month-column-cell-seibies">${planValue}</td>
          <td class="month-column-cell-seibies">${currentValue}</td>
          <td class="month-column-cell-seibies">${forecastValue}</td>
          <td class="month-column-cell-seibies total-cell-seibies" style="font-weight: bold; background-color: #f0f8ff;">${totalValue}</td>
        `;
      } else {
        // Other months: show plan, current, and total (plan + current)
        const totalValue = planValue + currentValue;
        rowHTML += `
          <td class="month-column-cell-seibies">${planValue}</td>
          <td class="month-column-cell-seibies">${currentValue}</td>
          <td class="month-column-cell-seibies total-cell-seibies" style="font-weight: bold; background-color: #f5f5f5;">${totalValue}</td>
        `;
      }
    });

    // Add actions column - only show edit button if user has permission
    const canEdit = checkEditPermission(forecast);
    rowHTML += `
        <td class="actions-cell-seibies">
          ${canEdit ? `<button class="edit-btn-seibies edit-action-btn-seibies" data-id="${forecast.Id}">✏️ Edit</button>` : 
            '<span class="no-edit-permission-seibies" title="You do not have permission to edit this SEIBIES record">🔒</span>'}
        </td>
      </tr>
    `;

    tableBodyHTML += rowHTML;
  });

  tableBody.innerHTML = tableBodyHTML;
  
  // Attach event listeners
  attachSortButtonListeners();
  attachTableEventListeners();
};

      const attachSortButtonListeners = (): void => {
        document.querySelectorAll('.sort-btn-seibies[data-sort]').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const button = e.currentTarget as HTMLButtonElement;
            const sortColumn = button.dataset.sort;
            const direction = button.dataset.direction as 'asc' | 'desc';
            const subColumn = button.dataset.subcolumn;
            const monthIndex = button.dataset.monthIndex ? parseInt(button.dataset.monthIndex) : undefined;
            
            if (sortColumn && direction) {
              handleSeibiesSort(sortColumn, direction, subColumn, monthIndex);
            }
          });
        });
      };

      const attachTableEventListeners = (): void => {
        tableBody.querySelectorAll(".edit-btn-seibies").forEach(btn => {
          btn.addEventListener("click", () => {
            const id = parseInt((btn as HTMLButtonElement).dataset.id!);
            editForecast(id);
          });
        });
      };

      const handleSeibiesSort = (column: string, direction: 'asc' | 'desc', subColumn?: string, monthIndex?: number): void => {
        currentSortConfig = {
          column,
          direction,
          subColumn,
          monthIndex
        };

        const dataToSort = filteredData.length > 0 ? filteredData : forecasts;
        
        if (dataToSort.length === 0) return;

        const sortedData = [...dataToSort].sort((a, b) => {
          let valueA: any = 0;
          let valueB: any = 0;

          switch (column) {
            case 'obl':
              valueA = a.OBL || 0;
              valueB = b.OBL || 0;
              break;
            
            case 'actualSeibies':
              const selectedYear = filterYear.value;
              const selectedMonth = filterMonth.value;
              const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
              
              if (selectedMonthKey) {
                const seibiesA = safeJsonParse(a.SeibiesActual, {});
                const seibiesB = safeJsonParse(b.SeibiesActual, {});
                valueA = seibiesA[selectedMonthKey] || 0;
                valueB = seibiesB[selectedMonthKey] || 0;
              } else {
                valueA = 0;
                valueB = 0;
              }
              break;
            
            case 'month':
              const displayMonths = getDisplayMonths();
              
              const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
              const monthKeyToUse = displayMonths[monthIndexToUse];
              
              const dataA = safeJsonParse(a.ForecastData, {});
              const dataB = safeJsonParse(b.ForecastData, {});
              const monthDataA = dataA[monthKeyToUse] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
              const monthDataB = dataB[monthKeyToUse] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
              
              if (subColumn) {
                switch (subColumn) {
                  case 'plan':
                    valueA = monthDataA.plan || 0;
                    valueB = monthDataB.plan || 0;
                    break;
                  case 'current':
                    valueA = monthDataA.actual || 0;
                    valueB = monthDataB.actual || 0;
                    break;
                  case 'forecast':
                    valueA = monthDataA.forecast || 0;
                    valueB = monthDataB.forecast || 0;
                    break;
                  default:
                    valueA = monthDataA.actual || 0;
                    valueB = monthDataB.actual || 0;
                }
              } else {
                valueA = monthDataA.actual || 0;
                valueB = monthDataB.actual || 0;
              }
              break;
            
            case 'project':
              valueA = a.Project?.Title || "";
              valueB = b.Project?.Title || "";
              break;
            
            case 'customer':
              const projA = projects.find(p => p.Title === a.Project?.Title);
              const projB = projects.find(p => p.Title === b.Project?.Title);
              valueA = projA?.CustomerName || "";
              valueB = projB?.CustomerName || "";
              break;
            
            default:
              return 0;
          }

          if (typeof valueA === 'number' && typeof valueB === 'number') {
            return direction === 'asc' ? valueA - valueB : valueB - valueA;
          } else {
            const strA = String(valueA).toLowerCase();
            const strB = String(valueB).toLowerCase();
            return direction === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
          }
        });

        if (filteredData.length > 0) {
          filteredData = sortedData;
        } else {
          forecasts = sortedData;
        }

        currentPage = 1;
        updatePaginationControls();
        renderCurrentPage();
        
        const sortDirectionText = direction === 'asc' ? 'Ascending' : 'Descending';
        let columnName = '';
        
        if (subColumn) {
          columnName = subColumn.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
        } else if (column === 'obl') {
          columnName = 'OBL';
        } else if (column === 'actualSeibies') {
          columnName = 'Actual SEIBIES';
        } else if (column === 'project') {
          columnName = 'Project';
        } else if (column === 'customer') {
          columnName = 'Customer';
        } else {
          const displayMonths = getDisplayMonths();
          const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
          const monthKey = displayMonths[monthIndexToUse];
          const monthDate = new Date(monthKey + "-01");
          columnName = formatMonthLabel(monthDate);
        }
        
        toast("info", `Sorted by ${columnName} (${sortDirectionText})`);
      };

const clearFilters = (): void => {
  filterYear.value = "";
  filterMonth.value = "";
  filterProject.value = "";
  filterCustomer.value = "";
  filterProjectManager.value = "";
  filterGroupHead.value = "";
  filterProjectReference.value = "";
  
  // Reset sorting
  currentSortConfig = {
    column: '',
    direction: 'asc'
  };
  
  initializePagination(forecasts);
  
  // Refresh totals header
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
  
  toast("info", "All SEIBIES filters and sorting cleared");
};
// In the initialize function or separate setup function:
const setupPaginationEventListeners = (): void => {
  // Page size selector
  if (pageSizeSelect) {
    pageSizeSelect.addEventListener("change", (e) => {
      const newSize = parseInt((e.target as HTMLSelectElement).value);
      changePageSize(newSize);
    });
  }
};

// Call this in your initialize function
setupPaginationEventListeners();

      // ========== FORM MANAGEMENT FUNCTIONS ==========

      const showForm = (isEditMode: boolean = false): void => {
        formSection.style.display = "block";
        tableSection.style.display = "none";
        showFormBtn.style.display = "none";
        
        if (isEditMode) {
          formSection.classList.add('edit-mode-seibies');
          projectSelect.disabled = true;
          formTitle.textContent = "Edit SEIBIES Forecast";
        } else {
          formSection.classList.remove('edit-mode-seibies');
          projectSelect.disabled = false;
          formTitle.textContent = "Add SEIBIES Forecast";
        }
      };

      const hideForm = (): void => {
        formSection.style.display = "none";
        tableSection.style.display = "block";
        showFormBtn.style.display = "inline-block";
        formSection.classList.remove('edit-mode-seibies');
        projectSelect.disabled = false;
      };

      const resetForm = (): void => {
        editingId = null;
        form.reset();
        projectSelect.value = "";
        projectDetails.innerHTML = "";
        historicalContainer.innerHTML = "";
        firstRowContainer.innerHTML = "";
        remainingContainer.innerHTML = "";
        yearlyContainer.innerHTML = "";
        
        toggleForecastSections(false);
        
        const oblContainer = document.querySelector('.obl-section-container-seibies') as HTMLElement;
        oblContainer.className = 'obl-section-container-seibies hidden-section';
        oblLastMonthInput.removeAttribute('readonly');
        oblLastMonthInput.placeholder = "Enter OBL";
        setNumericValue(oblLastMonthInput, 0);
        
        const fieldNote = oblContainer.querySelector('.field-note-seibies') as HTMLElement;
        if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
        
        oblValidationMessage.textContent = "✅ All values are within OBL limit";
        oblValidationMessage.className = 'validation-message-seibies';
        
        updateOBLValidationDisplay();
      };
    
      // ========== VALIDATION FUNCTIONS ==========

      const calculateTotalCurrentValue = (): number => {
        let total = 0;
        
        const editableMonths = allMonths.slice(3);
        
        editableMonths.forEach(monthKey => {
          const currentInputs = document.querySelectorAll<HTMLInputElement>(`input.main-current-input-seibies[data-month="${monthKey}"]:not([readonly])`);
          currentInputs.forEach(input => {
            total += getNumericValue(input);
          });
        });
        
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.yearly-current-input-seibies:not([readonly])`);
        yearlyCurrentInputs.forEach(input => {
          total += getNumericValue(input);
        });
        
        return total;
      };

      const validateOBLLimit = (changedInput?: HTMLInputElement): boolean => {
        const oblValue = getNumericValue(oblLastMonthInput);
        const totalCurrent = calculateTotalCurrentValue();
        
        totalCurrentValueSpan.textContent = totalCurrent.toLocaleString();
        
        const remaining = oblValue - totalCurrent;
        remainingValueSpan.textContent = remaining.toLocaleString();
        
        if (oblValue === 0) {
          oblLineFill.style.width = `0%`;
          oblLineFill.className = 'line-fill-seibies';
          
          if (totalCurrent > 0) {
            showOBLErrorToast('⚠️ OBL is zero but current values exist. Please set OBL value.', true);
            blockAllCurrentInputs();
            return false;
          } else {
            const existingToast = document.querySelector('.obl-error-toast-seibies');
            if (existingToast) existingToast.remove();
            unblockAllCurrentInputs();
            return true;
          }
        }
        
        const percentage = Math.min((totalCurrent / oblValue) * 100, 100);
        oblLineFill.style.width = `${percentage}%`;
        
        oblLineFill.className = 'line-fill-seibies';
        if (percentage > 90) {
          oblLineFill.classList.add('danger-seibies');
        } else if (percentage > 75) {
          oblLineFill.classList.add('warning-seibies');
        }
        
        oblValidationMessage.className = 'validation-message-seibies';
        
        if (totalCurrent > oblValue) {
          const exceedAmount = totalCurrent - oblValue;
          showOBLErrorToast(`❌ Total current value exceeds OBL by ${exceedAmount.toLocaleString()}! Reduce values to continue.`);
          oblValidationMessage.classList.add('danger-seibies');
          blockIncreasingCurrentInputs(changedInput);
          return false;
        } else if (percentage > 90) {
          showOBLErrorToast('⚠️ OBL limit nearly reached! Consider reducing values.', true);
          oblValidationMessage.classList.add('warning-seibies');
          unblockAllCurrentInputs();
          return true;
        } else {
          const existingToast = document.querySelector('.obl-error-toast-seibies');
          if (existingToast) existingToast.remove();
          
          oblValidationMessage.textContent = '✅ All values are within OBL limit';
          unblockAllCurrentInputs();
          return true;
        }
      };

      const blockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-seibies:not([readonly])');
        
        currentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
      };

      const blockIncreasingCurrentInputs = (allowedInput?: HTMLInputElement): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-seibies:not([readonly])');
        
        currentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
        
        yearlyCurrentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
      };

      const unblockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([data-month="0"])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-seibies');
        
        currentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
      };

      const allowInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
        const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
        const isIncreasing = newValue > oldValue;
        
        if (!isIncreasing) {
          return true;
        }
        
        const oblValue = getNumericValue(oblLastMonthInput);
        const currentTotal = calculateTotalCurrentValue();
        const increaseAmount = newValue - oldValue;
        
        return (currentTotal + increaseAmount) <= oblValue;
      };

      const updateOBLValidationDisplay = (changedInput?: HTMLInputElement): void => {
        validateOBLLimit(changedInput);
      };

      // ========== FORECAST FORM FUNCTIONS ==========

      const onProjectChange = (projectId: number, existingForecast?: SeibiesForecastItem): void => {
        const project = projects.find(p => p.Id === projectId);
        if (!project) return;

        toggleForecastSections(true);

        renderProjectDetails(project);
        
        let forecastData: ForecastData = {};
        if (existingForecast) {
          forecastData = safeJsonParse(existingForecast.ForecastData, {});
        }

        const isNewProject = !existingForecast;
        
        const oblContainer = document.querySelector('.obl-section-container-seibies') as HTMLElement;
        const fieldNote = oblContainer.querySelector('.field-note-seibies') as HTMLElement;
        
        if (isNewProject) {
          oblContainer.className = 'obl-section-container-seibies visible-section-seibies new-project-seibies';
          oblLastMonthInput.removeAttribute('readonly');
          oblLastMonthInput.placeholder = "Enter initial OBL for new project";
          if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
          oblValidationMessage.textContent = "Enter initial OBL value for new project";
          oblValidationMessage.className = 'validation-message-seibies';
          
          const defaultOBL = project.PC ? 100000 : 0;
          setNumericValue(oblLastMonthInput, defaultOBL);
        } else {
          oblContainer.className = 'obl-section-container-seibies visible-section-seibies existing-project-seibies';
          oblLastMonthInput.setAttribute('readonly', 'true');
          
          const oblValue = existingForecast?.OBL || 0;
          setNumericValue(oblLastMonthInput, oblValue);
          
          oblLastMonthInput.placeholder = "OBL from database";
          if (fieldNote) fieldNote.textContent = "OBL value from database record";
          
          if (oblValue > 0) {
            oblLastMonthInput.value = oblValue.toString();
            oblLastMonthInput.className = oblLastMonthInput.className.replace('input-empty-seibies', 'input-with-value-seibies');
          }
        }

        renderForecastInterface(forecastData, getNumericValue(oblLastMonthInput), existingForecast);
      };

      const toggleForecastSections = (show: boolean): void => {
        const sections = [
          '.obl-section-container-seibies',
          '#historicalForecastSectionSeibies',
          '#detailedForecastSectionSeibies', 
          '#longtermForecastSectionSeibies',
          '#yearlyForecastSectionSeibies'
        ];
        
        sections.forEach(selector => {
          const element = document.querySelector(selector) as HTMLElement;
          if (element) {
            if (show) {
              element.classList.remove('hidden-section');
              element.classList.add('visible-section-seibies');
            } else {
              element.classList.remove('visible-section-seibies');
              element.classList.add('hidden-section');
            }
          }
        });
      };

      const renderProjectDetails = (project: ProjectItem): void => { 
        projectDetails.innerHTML =
          `<p><b>Profit Center:</b> ${project.PC || "-"}</p>
           <p><b>Customer:</b> ${project.CustomerName || "-"}</p>
           <p><b>Project Ref:</b> ${project.ProjectReference || "-"}</p>
           <p><b>Group Head:</b> ${project.GroupHead || "-"}</p>
           <p><b>Project Manager:</b> ${typeof project.ProjectManager === "object" ? project.ProjectManager?.Title : project.ProjectManager || "-"}</p>`;
      };

      const getForecastMonths = (): string[] => {
        return generateIdealMonthStructure();
      };

      const renderForecastInterface = (existingData: ForecastData, displayOBL: number, existingForecast?: SeibiesForecastItem): void => {
        allMonths = getForecastMonths();
        
        setNumericValue(oblLastMonthInput, displayOBL);

        renderHistoricalMonths(allMonths.slice(0, 3), existingData);
        renderFirstRow(allMonths.slice(3, 6), existingData);
        renderRemainingMonths(allMonths.slice(6), existingData);
        renderYearlyForecast(existingData.yearly || createFreshYearlyStructure(getLastMonthKey(existingData)));

        protectHistoricalElements();
        
        updateOBLValidationDisplay();
        attachForecastEventListeners();
      };

      const protectHistoricalElements = (): void => {
        document.querySelectorAll('.historical-month-seibies input, .historical-month-seibies select, .historical-month-seibies button').forEach(element => {
          const newElement = element.cloneNode(true) as HTMLElement;
          element.parentNode?.replaceChild(newElement, element);
        });
        
        document.querySelectorAll('.historical-month-seibies').forEach(section => {
          section.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toast("warning", "Historical SEIBIES data cannot be modified");
            return false;
          });
          
          section.addEventListener('keydown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            return false;
          });
          
          section.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            return false;
          });
        });
      };

      const renderHistoricalMonths = (months: string[], existingData: ForecastData): void => {
        let html = '';

        months.forEach((monthKey, index) => {
          const monthDate = new Date(monthKey + "-01");
          const monthLabel = formatMonthLabel(monthDate);
          const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
          
          html += renderHistoricalMonthBox(monthKey, monthLabel, data, index);
        });

        historicalContainer.innerHTML = html;
      };

      const renderHistoricalMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, index: number): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        const actualInputClass = data.actual > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        
        return `
          <div class="month-box-seibies historical-month-seibies">
            <div class="month-header-seibies">${monthLabel} (Historical - Readonly)</div>
            
            <div class="month-block-seibies">
              <div class="main-inputs-container-seibies">
                <div class="main-input-group-seibies">
                  <label>Previous</label>
                  <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                        readonly class="main-plan-input-seibies ${planInputClass} number-input-seibies" />
                </div>
                <div class="main-input-group-seibies">
                  <label>Current</label>
                  <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                        readonly class="main-current-input-seibies ${actualInputClass} number-input-seibies" />
                </div>
              </div>
            </div>
          </div>
        `;
      };

      const renderFirstRow = (months: string[], existingData: ForecastData): void => {
        let html = '';

        html += `<div class="detailed-months-row-seibies">`;
        
        const currentMonth = months[0];
        if (currentMonth) {
          const monthDate = new Date(currentMonth + "-01");
          const monthLabel = formatMonthLabel(monthDate);
          const data = existingData[currentMonth] as ForecastMonthData || { plan: 0, actual: 0 };
          
          html += `<div class="current-month-container-seibies">`;
          html += renderDetailedMonthBox(currentMonth, monthLabel, data, true);
          html += `</div>`;
        }
        
        html += `<div class="next-months-container-seibies">`;
        for (let i = 1; i <= 2; i++) {
          if (i < months.length) {
            const monthKey = months[i];
            const monthDate = new Date(monthKey + "-01");
            const monthLabel = formatMonthLabel(monthDate);
            const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            
            html += `<div class="next-month-box-seibies">`;
            html += renderDetailedMonthBox(monthKey, monthLabel, data, false);
            html += `</div>`;
          }
        }
        html += `</div>`;
        
        html += `</div>`;

        firstRowContainer.innerHTML = html;
      };

      const renderRemainingMonths = (months: string[], existingData: ForecastData): void => {
        let html = '';

        for (let row = 0; row < 3; row++) {
          html += `<div class="remaining-row-seibies">`;
          for (let col = 0; col < 5; col++) {
            const index = (row * 5) + col;
            if (index >= months.length) break;
            
            const monthKey = months[index];
            const monthDate = new Date(monthKey + "-01");
            const monthLabel = formatMonthLabel(monthDate);
            const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            
            html += renderSimpleMonthBox(monthKey, monthLabel, data);
          }
          html += `</div>`;
        }

        remainingContainer.innerHTML = html;
      };

      const renderYearlyForecast = (yearlyData: YearlyForecastData): void => {
        let html = '';

        const years = Object.keys(yearlyData).sort();
        
        years.forEach(year => {
          const data = yearlyData[year] || { plan: 0, actual: 0 };
          html += renderYearlyBox(year, data);
        });

        yearlyContainer.innerHTML = html;
      };

      const renderYearlyBox = (year: string, data: { plan: number; actual: number }): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        const actualInputClass = data.actual > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        
        return `
          <div class="yearly-box-seibies">
            <div class="yearly-header-seibies">${year}</div>
            
            <div class="yearly-inputs-container-seibies">
              <div class="yearly-input-group-seibies">
                <label>Previous</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-year="${year}"
                      readonly class="yearly-plan-input-seibies ${planInputClass} number-input-seibies" />
              </div>
              <div class="yearly-input-group-seibies">
                <label>Current</label>
                <input type="text" value="${displayActualValue}" data-type="actual" data-year="${year}"
                      class="yearly-current-input-seibies ${actualInputClass} number-input-seibies" />
              </div>
            </div>
          </div>
        `;
      };

      const renderDetailedMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, isCurrentMonth: boolean = false): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const displayForecastValue = data.forecast || 0;
        const displayDateValue = data.date || '';
        
        const planInputClass = data.plan > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        const actualInputClass = data.actual > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        const forecastInputClass = displayForecastValue > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        const dateInputClass = displayDateValue ? 'input-with-value-seibies' : 'input-empty-seibies';
        
        return `
          <div class="detailed-month-box-seibies ${isCurrentMonth ? 'current-month-box-seibies' : 'next-month-box-seibies'}">
            <div class="month-header-seibies">
              ${monthLabel}
              ${isCurrentMonth ? '<span class="current-month-indicator-seibies">Current</span>' : ''}
            </div>
            
            <div class="month-block-seibies">
              <div class="enhanced-inputs-container-seibies">
                <div class="enhanced-input-group-seibies">
                  <label>Previous</label>
                  <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                        readonly class="main-plan-input-seibies ${planInputClass} number-input-seibies" />
                </div>
                
                <div class="enhanced-input-group-seibies">
                  <label>Current</label>
                  <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                        class="main-current-input-seibies ${actualInputClass} number-input-seibies" />
                </div>
                
                ${isCurrentMonth ? `
                  <div class="enhanced-input-group-seibies">
                    <label>Forecast</label>
                    <input type="text" value="${displayForecastValue}" data-type="forecast" data-month="${monthKey}"
                          class="main-forecast-input-seibies ${forecastInputClass} number-input-seibies" />
                  </div>
                  
                  <div class="enhanced-input-group-seibies">
                    <label>Date</label>
                    <input type="date" value="${displayDateValue}" data-type="date" data-month="${monthKey}"
                          class="forecast-date-input-seibies ${dateInputClass}" />
                  </div>
                ` : ''}
              </div>
            </div>
          </div>
        `;
      };

      const renderSimpleMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        const actualInputClass = data.actual > 0 ? 'input-with-value-seibies' : 'input-empty-seibies';
        
        return `
          <div class="month-box-seibies simple-month-seibies">
            <div class="month-header-seibies">${monthLabel}</div>
            
            <div class="main-inputs-container-seibies">
              <div class="main-input-group-seibies">
                <label>Previous</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}" 
                      readonly class="main-plan-input-seibies ${planInputClass} number-input-seibies" />
              </div>
              <div class="main-input-group-seibies">
                <label>Current</label>
                <input type="text" value="${displayActualValue}"  id="actualCurrent" data-type="actual" data-month="${monthKey}" 
                      class="main-current-input-seibies ${actualInputClass} number-input-seibies" />
              </div>
            </div>
          </div>
        `;
      };

      const attachForecastEventListeners = (): void => {
        document.querySelectorAll<HTMLInputElement>('.number-input-seibies').forEach(input => {
          allowOnlyNumbers(input);
        });

        document.querySelectorAll<HTMLInputElement>('.number-input-seibies:not([readonly])').forEach(input => {
          input.addEventListener('focus', function() {
            this.setAttribute('data-old-value', getNumericValue(this).toString());
          });
        });

        // Main current inputs
        document.querySelectorAll<HTMLInputElement>('.main-current-input-seibies:not([readonly])').forEach(input => {
          input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
              const allowByOBL = allowInputIncrease(this, currentValue);
              
              if (!allowByOBL) {
                setNumericValue(this, oldValue);
                updateOBLValidationDisplay(this);
                return;
              }
            }
            
            if (currentValue === 0) {
              this.className = this.className.replace('input-with-value-seibies', 'input-empty-seibies');
            } else {
              this.className = this.className.replace('input-empty-seibies', 'input-with-value-seibies');
            }

            updateOBLValidationDisplay(this);
          });
        });

        // Main forecast inputs
        document.querySelectorAll<HTMLInputElement>('.main-forecast-input-seibies:not([readonly])').forEach(input => {
          input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
              const allowByOBL = allowInputIncrease(this, currentValue);
              
              if (!allowByOBL) {
                setNumericValue(this, oldValue);
                updateOBLValidationDisplay(this);
                return;
              }
            }
            
            if (currentValue === 0) {
              this.className = this.className.replace('input-with-value-seibies', 'input-empty-seibies');
            } else {
              this.className = this.className.replace('input-empty-seibies', 'input-with-value-seibies');
            }

            updateOBLValidationDisplay(this);
          });
        });

        // Yearly current inputs
        document.querySelectorAll<HTMLInputElement>('.yearly-current-input-seibies:not([readonly])').forEach(input => {
          input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
              const allowByOBL = allowInputIncrease(this, currentValue);
              
              if (!allowByOBL) {
                setNumericValue(this, oldValue);
                updateOBLValidationDisplay(this);
                return;
              }
            }
            
            if (currentValue === 0) {
              this.className = this.className.replace('input-with-value-seibies', 'input-empty-seibies');
            } else {
              this.className = this.className.replace('input-empty-seibies', 'input-with-value-seibies');
            }

            updateOBLValidationDisplay(this);
          });
        });

        // Main date inputs
        document.querySelectorAll<HTMLInputElement>('.forecast-date-input-seibies:not([readonly])').forEach(input => {
          input.addEventListener('change', function() {
            if (this.value === '') {
              this.className = this.className.replace('input-with-value-seibies', 'input-empty-seibies');
            } else {
              this.className = this.className.replace('input-empty-seibies', 'input-with-value-seibies');
            }
          });
        });

        // Real-time OBL validation
        const validationInputs = document.querySelectorAll<HTMLInputElement>(`
          .main-current-input-seibies:not([readonly]),
          .yearly-current-input-seibies:not([readonly]),
          .main-forecast-input-seibies:not([readonly])
        `);

        validationInputs.forEach(input => {
          input.addEventListener('input', function() {
            setTimeout(() => {
              updateOBLValidationDisplay(this);
            }, 100);
          });
        });
      };

      const editForecast = async (id: number): Promise<void> => {
        editingId = id;
        const forecast = forecasts.find(f => f.Id === id);
        if (!forecast) {
          toast("error", "SEIBIES forecast not found");
          return;
        }

        showForm(true);
        
        let forecastData: ForecastData = {};
        
        try {
          let forecastDataString = forecast.ForecastData || "{}";
          forecastDataString = forecastDataString.trim();
          
          if (!forecastDataString || forecastDataString === '""' || forecastDataString === "null") {
            forecastDataString = "{}";
          }
          
          forecastData = JSON.parse(forecastDataString);
           
        } catch (e) { 
          forecastData = createFreshForecastStructure();
          
          toast("warning", "Corrupted SEIBIES forecast data detected. Loaded empty structure.");
        }
        
        forecastData = propagateMonthValues(forecastData);
        
        const displayOBL = forecast.OBL || 0;
        
        console.log(displayOBL);
        
        if (forecast.Project) {
          projectSelect.value = String(forecast.Project.Id);
          onProjectChange(forecast.Project.Id, forecast);
        }
        
        toast("info", `Editing SEIBIES forecast for ${forecast.Title}`);
      };

      // ========== FORM SUBMISSION ==========

      form.addEventListener("submit", async (e: Event) => {
        e.preventDefault();
        
        const projectId = parseInt(projectSelect.value);
        const project = projects.find(p => p.Id === projectId);
        
        if (!project) {
          toast("error", "Please select a project");
          return;
        }

        const isNewProject = !editingId && !forecasts.some(f => f.Project?.Id === projectId);
        
        if (!isNewProject && forecasts.some(f => f.Project?.Id === projectId && f.Id !== editingId)) {
          toast("error", "SEIBIES forecast already exists for this project!");
          return;
        }

        const oblValue = getNumericValue(oblLastMonthInput);
        if (isNewProject && oblValue === 0) {
          const confirmZeroOBL = await Swal.fire({
            icon: "question",
            title: "Zero OBL Value",
            text: "You're setting OBL to zero for a new project. This means there's no budget limit. Continue?",
            showCancelButton: true,
            confirmButtonText: "Yes, Continue",
            cancelButtonText: "No, Set OBL"
          });
          
          if (!confirmZeroOBL.isConfirmed) {
            oblLastMonthInput.focus();
            return;
          }
        }

        const totalCurrent = calculateTotalCurrentValue();
        
        if (oblValue > 0 && totalCurrent > oblValue) {
          toast("error", "Total current value cannot exceed OBL!");
          return;
        }

        try {
          const forecastData: ForecastData = {};

          const allStorageMonths = getAllMonthsForStorage(); 
          
          allStorageMonths.forEach(monthKey => {
            const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input-seibies[data-month="${monthKey}"]`);
            const mainPlanInput = document.querySelector<HTMLInputElement>(`input.main-plan-input-seibies[data-month="${monthKey}"]`);
            const mainForecastInput = document.querySelector<HTMLInputElement>(`input.main-forecast-input-seibies[data-month="${monthKey}"]`);
            const mainDateInput = document.querySelector<HTMLInputElement>(`input.forecast-date-input-seibies[data-month="${monthKey}"]`);
            
            if (mainCurrentInput && mainPlanInput) {
              const monthData: ForecastMonthData = {
                plan: getNumericValue(mainPlanInput),
                actual: getNumericValue(mainCurrentInput)
              };

              if (mainForecastInput) {
                monthData.forecast = getNumericValue(mainForecastInput);
              }

              if (mainDateInput && mainDateInput.value) {
                monthData.date = mainDateInput.value;
              }

              forecastData[monthKey] = monthData;
            }
          });

          const yearlyData: YearlyForecastData = {};
          const yearlyPlanInputs = document.querySelectorAll<HTMLInputElement>('.yearly-plan-input-seibies');
          
          if (yearlyPlanInputs.length > 0) {
            const years = new Set<string>();
            yearlyPlanInputs.forEach(input => {
              const year = input.dataset.year;
              if (year) years.add(year);
            });
            
            Array.from(years).sort().forEach(year => {
              const planInput = document.querySelector<HTMLInputElement>(`input.yearly-plan-input-seibies[data-year="${year}"]`);
              const currentInput = document.querySelector<HTMLInputElement>(`input.yearly-current-input-seibies[data-year="${year}"]`);
              
              if (planInput && currentInput) {
                yearlyData[year] = {
                  plan: getNumericValue(planInput),
                  actual: getNumericValue(currentInput)
                };
              }
            });
            
            forecastData.yearly = yearlyData;
          }

          const propagatedData = propagateCollectionValues(forecastData);
          const digest = await getDigest();
          
          const payload: any = {
             __metadata: { type: "SP.Data.SEIBIESListItem" },
                Title: generateForecastTitle(project, propagatedData),
                ProjectId: project.Id,
                ProfitCentre: project.PC || "",
                ForecastData: JSON.stringify(propagatedData),
                UpdatedDate: new Date().toISOString()
              };

              // Ensure OBL is properly handled
              if (!editingId && isNewProject) {
                const oblValueToSave = getNumericValue(oblLastMonthInput);
                payload.OBL = oblValueToSave; // This should be a number, which is correct for number fields
              }

              // For new items, ensure CreatedDate is properly formatted
              if (!editingId) {
                payload.CreatedDate = new Date().toISOString();
              } 
          const url = editingId 
            ? `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${editingId})`
            : `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;
          
          const headers: any = {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest
          };
          
          if (editingId) {
            headers["IF-MATCH"] = "*";
            headers["X-HTTP-Method"] = "MERGE";
          }

          const res = await fetch(url, { 
            method: "POST", 
            headers, 
            body: JSON.stringify(payload) 
          });
          
          if (res.ok) {
            toast("success", editingId ? "SEIBIES Forecast Updated!" : "SEIBIES Forecast Added!");
            await loadForecasts();
            initializePagination(forecasts);
            hideForm();
            resetForm();
          } else {
            const errorText = await res.text();
            console.error("SharePoint Error:", errorText);
            toast("error", `Error saving SEIBIES forecast: ${res.status}`);
          }
        } catch (error) {
          console.error("Error saving SEIBIES forecast:", error);
          toast("error", "Error saving SEIBIES forecast!");
        }
      });

      const propagateCollectionValues = (forecastData: ForecastData): ForecastData => {
        const updatedData: ForecastData = { ...forecastData };
        
        if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) {
          const longTermMonths = generateIdealMonthStructure().slice(6);
          const lastMonthKey = longTermMonths[longTermMonths.length - 1];
          updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
        }

        const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
        const idealMonths = generateIdealMonthStructure();
        const isNewMonth = originalMonths[0] !== idealMonths[0];
         
        const monthlyProgressed = propagateMonthValues(updatedData);
        const yearlyProgressed = propagateYearlyValues(monthlyProgressed, isNewMonth); 
        return yearlyProgressed;
      };

      const propagateYearlyValues = (forecastData: ForecastData, isNewMonth: boolean = false): ForecastData => {
        if (!isNewMonth) { 
          return forecastData;
        }

        const updatedData: ForecastData = { ...forecastData };
        
        if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) { 
          return updatedData;
        }

        const yearlyData = updatedData.yearly; 
        const updatedYearlyData: YearlyForecastData = {};

        Object.keys(yearlyData).forEach(year => {
          const yearData = yearlyData[year];
          if (yearData) {
            updatedYearlyData[year] = {
              plan: yearData.actual,
              actual: 0,
            };
          }
        });

        updatedData.yearly = updatedYearlyData; 
        return updatedData;
      };

const initializeFilters = (): void => {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  
  // Year filter
  filterYear.innerHTML = '<option value="">All Years</option>';
  for (let year = currentYear - 1; year <= currentYear + 2; year++) {
    const selected = year === currentYear ? 'selected' : '';
    filterYear.innerHTML += `<option value="${year}" ${selected}>${year}</option>`;
  }
  
  // Month filter
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  filterMonth.innerHTML = '<option value="">All Months</option>';
  for (let month = 1; month <= 12; month++) {
    const selected = month === currentMonth ? 'selected' : '';
    filterMonth.innerHTML += `<option value="${month}" ${selected}>${monthNames[month - 1]}</option>`;
  }

  // Apply role-based filtering to get accessible forecasts
  const roleFilteredForecasts = filterDataByRole(forecasts);
  
  // Get accessible project titles
  const accessibleProjectTitles = roleFilteredForecasts
    .map(f => f.Project?.Title)
    .filter((title): title is string => !!title);
  
  // Project filter - only projects from accessible forecasts
  filterProject.innerHTML = '<option value="">All Projects</option>' + 
    [...new Set(accessibleProjectTitles)]
      .sort()
      .map(project => `<option value="${project}">${project}</option>`)
      .join("");

  // Customer filter - only customers from accessible projects
  const accessibleProjects = projects.filter(p => accessibleProjectTitles.includes(p.Title));
  const accessibleCustomers = accessibleProjects
    .map(p => p.CustomerName)
    .filter((customer): customer is string => !!customer);
    
  filterCustomer.innerHTML = '<option value="">All Customers</option>' + 
    [...new Set(accessibleCustomers)]
      .sort()
      .map(customer => `<option value="${customer}">${customer}</option>`)
      .join("");

  // Project Manager filter - based on role
  let accessibleManagers: string[] = [];
  
  // Helper function to extract manager name
  const getManagerName = (project: ProjectItem): string | undefined => {
    if (!project.ProjectManager) return undefined;
    
    if (typeof project.ProjectManager === 'string') {
      return project.ProjectManager;
    }
    
    return project.ProjectManager.Title;
  };
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all managers
    accessibleManagers = projects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isGroupHead) {
    // Group Head sees managers in their groups
    const groupHeadProjects = projects.filter(p => 
      currentUser.managedGroups?.some(group => p.GroupHead === group)
    );
    accessibleManagers = groupHeadProjects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isProjectManager) {
    // Project Manager sees only themselves
    accessibleManagers = [currentUser.displayName];
  }
  
  // Remove duplicates and sort
  accessibleManagers = [...new Set(accessibleManagers)].sort();
  
  filterProjectManager.innerHTML = '<option value="">All Managers</option>' + 
    accessibleManagers.map(manager => `<option value="${manager}">${manager}</option>`).join("");

  // Group Head filter - based on role
  let accessibleGroupHeads: string[] = [];
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all group heads
    accessibleGroupHeads = projects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  } else if (currentUser.isGroupHead) {
    // Group Head sees only themselves
    accessibleGroupHeads = [currentUser.displayName];
  } else if (currentUser.isProjectManager) {
    // Project Manager sees group heads of their projects
    const pmProjects = projects.filter(p => 
      currentUser.managedProjects?.includes(p.Title)
    );
    accessibleGroupHeads = pmProjects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  }
  
  // Remove duplicates and sort
  accessibleGroupHeads = [...new Set(accessibleGroupHeads)].sort();
  
  filterGroupHead.innerHTML = '<option value="">All Group Heads</option>' + 
    accessibleGroupHeads.map(head => `<option value="${head}">${head}</option>`).join("");

  // Project Reference filter - only from accessible projects
  const accessibleReferences = accessibleProjects
    .map(p => p.ProjectReference)
    .filter((ref): ref is string => !!ref);
    
  filterProjectReference.innerHTML = '<option value="">All References</option>' + 
    [...new Set(accessibleReferences)]
      .sort()
      .map(ref => `<option value="${ref}">${ref}</option>`)
      .join("");
};

const filterTable = (): void => {
  const year = filterYear.value;
  const month = filterMonth.value;
  const project = filterProject.value;
  const customer = filterCustomer.value;
  const projectManager = filterProjectManager.value;
  const groupHead = filterGroupHead.value;
  const projectReference = filterProjectReference.value; 
  
  let filtered = [...forecasts]; // Create a copy

  // Apply additional filters first
  filtered = filtered.filter(forecast => { 
    if (year && month) {
      const monthKey = `${year}-${month.padStart(2, "0")}`;
      const data: ForecastData = safeJsonParse(forecast.ForecastData, {});
      if (!(monthKey in data)) return false;
    }
    
    if (project && forecast.Project?.Title !== project) return false;
    
    if (customer) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.CustomerName !== customer) return false;
    }
    
    if (projectManager) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      const managerName = typeof proj?.ProjectManager === 'object' ? proj.ProjectManager?.Title : proj?.ProjectManager;
      if (managerName !== projectManager) return false;
    }
    
    if (groupHead) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.GroupHead !== groupHead) return false;
    }
    
    if (projectReference) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.ProjectReference !== projectReference) return false;
    }
    
    return true;
  }); 
  
  // Apply role-based filtering LAST
  filtered = filterDataByRole(filtered); 
  
  if (filtered.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="25" style="text-align:center;padding:20px;">No SEIBIES records found for selected filters</td></tr>`;
    
    // Clear totals header
    const totalsHeader = document.querySelector("#totalsHeaderSeibies") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = '';
    
    initializePagination([]);
  } else {
    initializePagination(filtered);
    
    // Refresh totals header after filtering
    const displayMonths = getDisplayMonths();
    const currentMonthKey = formatMonthKey(new Date());
    setTimeout(() => {
      renderTotalsHeader(displayMonths, currentMonthKey);
    }, 100);
  }
};

      // ========== AUTO PROGRESSION FUNCTIONS ==========

      const applyAutoProgression = async (): Promise<void> => { 
        if (forecasts.length === 0) { 
          return;
        }

        const digest = await getDigest();
        let progressedCount = 0;
        let errorCount = 0;
        
        for (const forecast of forecasts) {
          try {
            if (!forecast.ForecastData) { 
              continue;
            }
            
            const originalData = safeJsonParse(forecast.ForecastData, {});
            
            if (checkIfNeedsProgression(originalData)) { 
              
              const progressedData = propagateCollectionValues(originalData);
              
              const payload = {
                __metadata: { type: "SP.Data.SEIBIESListItem" },
                ForecastData: JSON.stringify(progressedData),
                UpdatedDate: new Date().toISOString()
              };
              
              const response = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`, {
                method: "POST",
                headers: {
                  Accept: "application/json;odata=verbose",
                  "Content-Type": "application/json;odata=verbose",
                  "X-RequestDigest": digest,
                  "IF-MATCH": "*",
                  "X-HTTP-Method": "MERGE"
                },
                body: JSON.stringify(payload)
              });
              
              if (response.ok) {
                progressedCount++; 
              } else {
                errorCount++; 
              }
              
              await new Promise(resolve => setTimeout(resolve, 100));
            } else { 
            }
          } catch (error) {
            errorCount++; 
          }
        }
        
        if (progressedCount > 0) { 
          await loadForecasts();
          toast("success", `Monthly and yearly data progressed for ${progressedCount} SEIBIES forecasts`);
        } else if (errorCount > 0) { 
          toast("warning", `Some errors occurred during SEIBIES monthly and yearly progression`);
        } else { 
        }
      };

      const checkIfNeedsProgression = (forecastData: ForecastData): boolean => {
        const months = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
        
        if (months.length === 0) return true;

        const idealMonths = generateIdealMonthStructure();
        const firstIdealMonth = idealMonths[0];
        const firstDataMonth = months[0];
        
        const monthlyProgressionNeeded = firstDataMonth !== firstIdealMonth;
        
        const currentYear = new Date().getFullYear();
        let yearlyProgressionNeeded = false;
        
        if (forecastData.yearly) {
          const years = Object.keys(forecastData.yearly).map(y => parseInt(y)).sort();
          yearlyProgressionNeeded = years.length > 0 && years[0] < currentYear;
        } else {
          yearlyProgressionNeeded = true;
        } 
        
        return monthlyProgressionNeeded || yearlyProgressionNeeded;
      };

const initialize = async (): Promise<void> => {
  try { 
    currentUser = await getUserContext(); 
    await loadProjects(); 
    await loadForecasts(); 
    if (forecasts.length > 0) { 
      await applyAutoProgression();
    }
    
    initializeFilters(); 
    setupPaginationEventListeners(); // Add this
    initializePagination(forecasts); 
    updateUIForRole();
    filterProjectSelectByRole();
  } catch (error) { 
    toast("error", "Failed to initialize SEIBIES application");
  }
};

      // ========== IMPORT ACTUAL DATA FUNCTION ==========

      const importActualData = (): void => { 
        const modalHTML = `
          <div class="import-modal-seibies">
            <div class="import-modal-content-seibies">
              <div class="import-modal-header-seibies">
                <h3>Import Monthly Actual SEIBIES Data</h3>
                <button class="close-modal-seibies">&times;</button>
              </div>

              <div class="import-section-seibies">
                <h4>Step 1: Download Template</h4>
                <button class="btn-primary-seibies" id="downloadTemplateSeibies">⬇️ Download Template</button>
              </div>

              <div class="import-section-seibies">
                <h4>Step 2: Upload Excel File</h4>
                <div class="file-upload-area-seibies" id="fileUploadAreaSeibies">
                  <div class="upload-icon-seibies">📁</div>
                  <p>Click to upload or drag & drop Excel file</p>
                  <p><small>Supported format: Excel with Project Reference, Month, and Actual SEIBIES columns</small></p>
                  <input type="file" id="excelFileSeibies" class="file-input-seibies" accept=".xlsx,.xls">
                  <div class="file-info-seibies" id="fileInfoSeibies"></div>
                </div>
              </div>

              <div class="import-section-seibies" id="previewSectionSeibies" style="display:none;">
                <h4>Step 3: Preview & Import</h4>
                <div class="import-preview-seibies" id="importPreviewSeibies"></div>
                <div class="import-actions-seibies">
                  <button class="btn-secondary-seibies" id="cancelImportSeibies">Cancel</button>
                  <button class="btn-primary-seibies" id="confirmImportSeibies">Import SEIBIES Data</button>
                </div>
                <div class="import-status-seibies" id="importStatusSeibies"></div>
              </div>
            </div>
          </div>
        `;

        document.body.insertAdjacentHTML("beforeend", modalHTML);
        const modal = document.querySelector(".import-modal-seibies") as HTMLElement;
        modal.style.display = "flex";

        // Elements
        const fileUploadArea = document.querySelector("#fileUploadAreaSeibies") as HTMLElement;
        const excelFileInput = document.querySelector("#excelFileSeibies") as HTMLInputElement;
        const fileInfo = document.querySelector("#fileInfoSeibies") as HTMLElement;
        const previewSection = document.querySelector("#previewSectionSeibies") as HTMLElement;
        const importPreview = document.querySelector("#importPreviewSeibies") as HTMLElement;
        const confirmImport = document.querySelector("#confirmImportSeibies") as HTMLButtonElement;
        const cancelImport = document.querySelector("#cancelImportSeibies") as HTMLButtonElement;
        const closeModal = document.querySelector(".close-modal-seibies") as HTMLButtonElement;
        const importStatus = document.querySelector("#importStatusSeibies") as HTMLElement;
        const downloadTemplateBtn = document.querySelector("#downloadTemplateSeibies") as HTMLButtonElement;

        let importData: any[] = [];
        let listEntityType: string = "";

        const monthMap: { [key: string]: number } = {
          'jan': 1, 'january': 1, 'jan-': 1,
          'feb': 2, 'february': 2, 'feb-': 2,
          'mar': 3, 'march': 3, 'mar-': 3,
          'apr': 4, 'april': 4, 'apr-': 4,
          'may': 5, 'may-': 5,
          'jun': 6, 'june': 6, 'jun-': 6,
          'jul': 7, 'july': 7, 'jul-': 7,
          'aug': 8, 'august': 8, 'aug-': 8,
          'sep': 9, 'september': 9, 'sep-': 9,
          'oct': 10, 'october': 10, 'oct-': 10,
          'nov': 11, 'november': 11, 'nov-': 11,
          'dec': 12, 'december': 12, 'dec-': 12
        };

        const parseMonth = (monthStr: string): string => {
          if (!monthStr) return '';
          
          if (/^\d{4}-\d{2}$/.test(monthStr)) {
            return monthStr;
          }
          
          const match = monthStr.toLowerCase().match(/([a-z]+)[-\s]*'?(\d{2,4})?/);
          if (match) {
            const monthName = match[1];
            let year = match[2];
            
            const monthNum = monthMap[monthName];
            if (monthNum) {
              if (!year) {
                year = new Date().getFullYear().toString();
              } else if (year.length === 2) {
                const currentYear = new Date().getFullYear();
                const century = Math.floor(currentYear / 100) * 100;
                const yearNum = parseInt(year);
                year = (century + yearNum).toString();
              }
              
              return `${year}-${monthNum.toString().padStart(2, '0')}`;
            }
          }
          
          return '';
        };

        const getListEntityType = async (): Promise<string> => {
          if (listEntityType) return listEntityType;
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`, {
            headers: { Accept: "application/json;odata=verbose" },
          });
          const data = await res.json();
          listEntityType = data.d.ListItemEntityTypeFullName; 
          return listEntityType;
        };

        const updateSeibiesData = (existingData: string, month: string, actualSeibies: number): string => { 
          let finalData: { [key: string]: number } = {};
          
          if (existingData && existingData.trim() !== '' && existingData !== '{}' && existingData !== 'null' && existingData !== 'undefined') {
            try {
              const parsed = JSON.parse(existingData); 
              finalData = { ...parsed };
            } catch (parseError) { 
              finalData = {};
            }
          } else { 
            finalData = {};
          }
           
          finalData[month] = actualSeibies; 
          const getFourMonthWindow = (): string[] => {
            const currentDate = new Date();
            const validMonths: string[] = [];
            
            for (let i = 0; i < 4; i++) {
              const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
              const yearStr = date.getFullYear();
              const monthStr = (date.getMonth() + 1).toString().padStart(2, '0');
              validMonths.push(`${yearStr}-${monthStr}`);
            }
            
            return validMonths.sort().reverse();
          };
          
          const fourMonthWindow = getFourMonthWindow(); 
          const resultData: { [key: string]: number } = {};
          
          fourMonthWindow.forEach(monthKey => {
            resultData[monthKey] = finalData[monthKey] !== undefined ? finalData[monthKey] : 0;
          });
           
          return JSON.stringify(resultData);
        };

        // File Upload Handling
        fileUploadArea.addEventListener("click", () => excelFileInput.click());
        fileUploadArea.addEventListener("dragover", (e) => {
          e.preventDefault();
          fileUploadArea.classList.add("dragover-seibies");
        });
        fileUploadArea.addEventListener("dragleave", () => fileUploadArea.classList.remove("dragover-seibies"));
        fileUploadArea.addEventListener("drop", (e) => {
          e.preventDefault();
          fileUploadArea.classList.remove("dragover-seibies");
          const files = e.dataTransfer?.files;
          if (files && files[0]) {
            excelFileInput.files = files;
            handleFileSelection(files[0]);
          }
        });
        excelFileInput.addEventListener("change", (e) => {
          const files = (e.target as HTMLInputElement).files;
          if (files && files[0]) handleFileSelection(files[0]);
        });

        const handleFileSelection = async (file: File) => { 
          
          if (!file.name.toLowerCase().match(/\.(xlsx|xls)$/)) {
            toast("error", "Please select an Excel file (.xlsx or .xls)");
            return;
          }

          fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`;

          try {
            const parsedData = await parseExcelFile(file); 
            if (validateImportData(parsedData)) { 
              importData = parsedData;
              showImportPreview(parsedData);
              previewSection.style.display = "block";
              previewSection.style.opacity = "1"; 
            } else { 
              toast("error", "Invalid Excel format. Please check the required columns.");
            }
          } catch (error) { 
            toast("error", "Error reading SEIBIES Excel file");
          }
        };

        const parseExcelFile = (file: File): Promise<any[]> => {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
              try {
                const data = new Uint8Array(e.target?.result as ArrayBuffer);
                const workbook = XLSX.read(data, { type: "array" });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); 

                if (jsonData.length < 2) { 
                  return resolve([]);
                }

                const headers = jsonData[0] as string[]; 
                
                const rows: any[] = [];

                for (let i = 1; i < jsonData.length; i++) {
                  const rowData = jsonData[i] as any[];
                  if (!rowData || rowData.length === 0) continue;

                  const row: any = {};
                  
                  headers.forEach((header, idx) => {
                    if (header && rowData[idx] !== undefined && rowData[idx] !== null) {
                      row[header.trim()] = rowData[idx];
                    }
                  }); 
                  if (row["Month"] || row["month"]) {
                    let monthValue = row["Month"] || row["month"];
                    
                    if (typeof monthValue === "number") {
                      const excelDate = new Date(Math.round((monthValue - 25569) * 86400 * 1000));
                      const yyyy = excelDate.getFullYear();
                      const mm = String(excelDate.getMonth() + 1).padStart(2, "0");
                      monthValue = `${yyyy}-${mm}`;
                    }

                    const monthStr = monthValue.toString();
                    row.parsedMonth = parseMonth(monthStr); 
                  }

                  const hasProjectRef = row["Project Reference"] || row["project_reference"];
                  const hasMonth = row.parsedMonth;
                  
                  if (hasProjectRef && hasMonth) {
                    rows.push(row); 
                  } else { 
                  }
                }
 
                resolve(rows);
              } catch (err) { 
                reject(err);
              }
            };
            reader.onerror = (error) => { 
              reject(new Error("Failed to read SEIBIES file"));
            };
            reader.readAsArrayBuffer(file);
          });
        };

        const validateImportData = (data: any[]): boolean => { 
          
          if (data.length === 0) { 
            return false;
          }
 
          
          const first = data[0];
          const keys = Object.keys(first).map(k => k.toLowerCase());
           
          const hasProjectRef = keys.some(k => k.includes('project') && k.includes('reference'));
          const hasMonth = keys.some(k => k.includes('month'));
          const hasSeibies = keys.some(k => 
            k.includes('actual') && (k.includes('seibies') || k.includes('seib'))
          );

          console.log(   hasSeibies );

          return hasProjectRef && hasMonth;
        };

        const showImportPreview = (data: any[]) => { 
          const monthSummary: { [key: string]: number } = {};
          
          data.forEach(row => {
            const month = row.parsedMonth;
            if (month) {
              monthSummary[month] = (monthSummary[month] || 0) + 1;
            }
          });

          const monthSummaryText = Object.keys(monthSummary)
            .map(month => {
              return `${month}: ${monthSummary[month]} records`;
            })
            .join(', ');

          const previewHTML = `
            <div style="padding: 20px; background: #f8f9fa; border-radius: 8px;">
              <h4 style="color: #28a745; margin-bottom: 15px;">✅ SEIBIES File Ready for Import</h4>
              <p><strong>Found ${data.length} SEIBIES records to import:</strong></p>
              <p><strong>Month Summary:</strong> ${monthSummaryText || 'No months found'}</p>
              <div class="preview-table-container-seibies" style="max-height: 400px; overflow-y: auto;">
                <table class="preview-table-seibies" style="width: 100%; border-collapse: collapse;">
                  <thead style="background: #007bff; color: white;">
                    <tr>
                      <th style="padding: 10px; border: 1px solid #ddd;">Project Reference</th>
                      <th style="padding: 10px; border: 1px solid #ddd;">Month</th>
                      <th style="padding: 10px; border: 1px solid #ddd;">Actual SEIBIES</th>
                      <th style="padding: 10px; border: 1px solid #ddd;">Project Match</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${data
                      .slice(0, 10)
                      .map((row, index) => {
                        const projectRef = row["Project Reference"] || row["project_reference"] || 'N/A';
                        const month = row["Month"] || row["month"] || 'N/A';
                        const actualSeibies = row["Actual SEIBIES"] || row["actual_seibies"] || row["Actual"] || row["actual"] || '0';
                        const project = projects.find((p) => p.ProjectReference === projectRef);
                        
                        return `
                          <tr style="${index % 2 === 0 ? 'background: #f8f9fa;' : 'background: white;'}">
                            <td style="padding: 8px; border: 1px solid #ddd;">${projectRef}</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">${month} (${row.parsedMonth || 'Invalid'})</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">${actualSeibies}</td>
                            <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${project ? "✅" : "❌"}</td>
                          </tr>
                        `;
                      })
                      .join("")}
                  </tbody>
                </table>
              </div>
              ${data.length > 10 ? `<p style="margin-top: 10px; font-style: italic;">... and ${data.length - 10} more SEIBIES records</p>` : ''}
              <div style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 5px;">
                <p style="margin: 0; color: #0056b3;"><strong>Ready to import SEIBIES data?</strong> Click the "Import SEIBIES Data" button below.</p>
                <p style="margin: 5px 0 0 0; font-size: 12px;"><strong>Note:</strong> Only the imported month will be updated, all other SEIBIES data preserved</p>
              </div>
            </div>`;
          
          importPreview.innerHTML = previewHTML; 
        };

        const performImport = async () => {
          confirmImport.disabled = true;
          confirmImport.textContent = "Importing SEIBIES...";
          importStatus.style.display = "block";
          importStatus.textContent = "Updating SEIBIES Data...";

          let success = 0, error = 0, notFound = 0, invalidMonth = 0, skipped = 0;
          const entityType = await getListEntityType();
 

          for (const row of importData) {
            const projectRef = row["Project Reference"] || row["project_reference"];
            const month = row.parsedMonth;
            const actualSeibies = parseFloat(
              row["Actual SEIBIES"] || row["actual_seibies"] || row["Actual"] || row["actual"] || 0
            );
 
            if (!month) { 
              invalidMonth++;
              continue;
            }

            const project = projects.find((p) => p.ProjectReference === projectRef);
            if (!project) { 
              notFound++;
              continue;
            }

            const forecast = forecasts.find((f) => f.Project?.Title === project.Title);
            if (!forecast?.Id) { 
              notFound++;
              continue;
            }

            try {
              const digest = await getDigest();
 
              const currentForecastResponse = await fetch(
                `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})?$select=Id,SeibiesActual`,
                {
                  method: "GET",
                  headers: { 
                    Accept: "application/json;odata=verbose",
                  },
                }
              );
              
              if (!currentForecastResponse.ok) {
                throw new Error(`Failed to fetch current SEIBIES data: ${currentForecastResponse.status}`);
              }
              
              const currentData = await currentForecastResponse.json();
              const currentSeibiesData = currentData.d.SeibiesActual || "{}";
               
              const updatedSeibiesData = updateSeibiesData(currentSeibiesData, month, actualSeibies); 

              try {
                const before = JSON.parse(currentSeibiesData);
                const after = JSON.parse(updatedSeibiesData);
                const changedMonths = Object.keys(after).filter(m => before[m] !== after[m]);
                console.log(`${changedMonths.join(', ')}`);
              } catch (e) { 
              }

              const payload = {
                __metadata: { type: entityType },
                SeibiesActual: updatedSeibiesData,
                UpdatedDate: new Date().toISOString(),
              }; 
              const res = await fetch(
                `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`,
                {
                  method: "POST",
                  headers: {
                    Accept: "application/json;odata=verbose",
                    "Content-Type": "application/json;odata=verbose",
                    "X-RequestDigest": digest,
                    "IF-MATCH": "*",
                    "X-HTTP-Method": "MERGE",
                  },
                  body: JSON.stringify(payload),
                }
              );

              if (res.ok) {
                success++; 
              } else {
                error++;
                const text = await res.text();
                console.warn( text);
              }

              await new Promise((r) => setTimeout(r, 100));
            } catch (err) {
              error++; 
            }
          }

          skipped = importData.length - (success + error + notFound + invalidMonth);
 
          importStatus.className = "import-status-seibies success-seibies";
          importStatus.innerHTML = `
            <strong>SEIBIES Import Complete!</strong><br>
            ✅ Success: ${success} SEIBIES records imported<br>
            ❌ Errors: ${error} SEIBIES records<br>
            🔍 Project Not Found: ${notFound} SEIBIES records<br>
            📅 Invalid Month: ${invalidMonth} SEIBIES records<br>
            ⏭️ Skipped: ${skipped} SEIBIES records<br>
            <small>Only the imported month was updated, all other SEIBIES data preserved</small>
          `;

          await loadForecasts();
          initializePagination(forecasts);

          confirmImport.disabled = false;
          confirmImport.textContent = "Import SEIBIES Data";
        };

        downloadTemplateBtn.addEventListener("click", () => {
          if (!projects || projects.length === 0) {
            toast("error", "No projects available to create SEIBIES template");
            return;
          }

          const wsData = [["Project Reference", "Month", "Actual SEIBIES"]];
          
          projects.forEach((p) => {
            wsData.push([p.ProjectReference || "", "", ""]);
          });

          const ws = XLSX.utils.aoa_to_sheet(wsData);
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "SEIBIES Template");

          const fileName = `SEIBIES_Import_Template.xlsx`;

          XLSX.writeFile(wb, fileName);
        });

        const closeModalHandler = () => modal.remove();
        closeModal.addEventListener("click", closeModalHandler);
        cancelImport.addEventListener("click", closeModalHandler);
        modal.addEventListener("click", (e) => {
          if (e.target === modal) closeModalHandler();
        });

        confirmImport.addEventListener("click", performImport);
      };        
   
      
      // ========== EVENT LISTENERS ==========

      showFormBtn.addEventListener("click", () => {
        resetForm();
        showForm(false);
      });       
              
      backBtn.addEventListener("click", hideForm);
      
projectSelect.addEventListener("change", (e) => {
  if (editingId) {
    toast("warning", "Cannot change project in SEIBIES edit mode");
    const forecast = forecasts.find(f => f.Id === editingId);
    if (forecast?.Project) {
      projectSelect.value = String(forecast.Project.Id);
    }
    return;
  }

  const projectId = parseInt((e.target as HTMLSelectElement).value);
  if (projectId) {
    const project = projects.find(p => p.Id === projectId);
    if (project) {
      // Add role-based access check
      if (!currentUser.isSuperAdmin) {
        let hasAccess = false;
        
        if (currentUser.isGroupHead) {
          hasAccess = currentUser.managedGroups?.some(group => 
            project.GroupHead === group
          ) || false;
        } else if (currentUser.isProjectManager) {
          hasAccess = currentUser.managedProjects?.includes(project.Title) || false;
        }
        
        if (!hasAccess) {
          toast("error", "You don't have access to this project");
          projectSelect.value = "";
          return;
        }
      }
      
      const existingForecast = forecasts.find(f => f.Project?.Id === projectId);
      if (existingForecast && !editingId) {
        Swal.fire({
          icon: "question",
          title: "Existing SEIBIES Forecast Found",
          text: `A SEIBIES forecast already exists for ${project.Title}. Would you like to edit it?`,
          showCancelButton: true,
          confirmButtonText: "Yes, Edit",
          cancelButtonText: "No, Create New"
        }).then((result) => {
          if (result.isConfirmed) {
            editingId = existingForecast.Id;
            showForm(true);
            onProjectChange(projectId, existingForecast);
          } else {
            onProjectChange(projectId);
          }
        });
      } else {
        onProjectChange(projectId, existingForecast);
      }
    }
  }
});

      // Pagination event listeners
      firstPageBtn.addEventListener("click", () => goToPage(1));
      prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
      nextPageBtn.addEventListener("click", () => goToPage(currentPage + 1));
      lastPageBtn.addEventListener("click", () => goToPage(totalPages));

      // Filter event listeners
      filterYear.addEventListener("change", filterTable);
      filterMonth.addEventListener("change", filterTable);
      filterProject.addEventListener("change", filterTable);
      filterCustomer.addEventListener("change", filterTable);
      filterProjectManager.addEventListener("change", filterTable);
      filterGroupHead.addEventListener("change", filterTable);
      filterProjectReference.addEventListener("change", filterTable);

      // Action button event listeners
      exportBtn.addEventListener("click", exportToExcelWithFullStyle); 
      clearFiltersBtn.addEventListener("click", clearFilters);
      importActualBtn.addEventListener("click", importActualData);

      // Initialize the application
      initialize();
    }, 100);
  }
};