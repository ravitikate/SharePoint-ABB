declare const _spPageContextInfo: any;
import Swal from "sweetalert2";
import * as XLSX from 'xlsx-js-style';
import "../styles/common.css";
import "../styles/inventory.css";

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead?: string;
}

interface SortConfig {
  column: string;
  direction: 'asc' | 'desc';
  subColumn?: string;
  monthIndex?: number;
}

let currentSortConfig: SortConfig = {
  column: '',
  direction: 'asc'
};

interface InventoryForecastItem {
  Id: number;
  Title: string;
  Project?: { 
    Id: number;
    Title: string;
  };
  ProfitCentre?: string;
  OBL?: number;
  ForecastData?: string;
  InventoryActual?: string; 
  CreatedDate?: string;
  UpdatedDate?: string;
  [key: string]: any;
}

interface SharePointResponse<T> {
  d: {
    results: T[];
  };
}
 
interface ForecastMonthData {
    plan: number;
    actual: number;
    forecast?: number;
    date?: string;
}

interface YearlyForecastData {
    [year: string]: {
        plan: number;
        actual: number;
        forecast?: number;
    };
}

interface ForecastData {
    [monthKey: string]: ForecastMonthData | YearlyForecastData | undefined;
    yearly?: YearlyForecastData;
}

interface UserContext {
  loginName: string;
  displayName: string;
  groups: string[];
  isSuperAdmin: boolean;
  isGroupHead: boolean;
  isProjectManager: boolean;
  userGroups?: string[];
  managedProjects?: string[];
  managedGroups?: string[];
}

export default {
  content: `
<div class="inventory-page fade-in">
  <section class="table-section-inventory card">
    <div class="page-header-inventory">
      <h1>Inventory Forecast Management</h1>
      <button class="btn-primary-inventory show-form-btn-inventory">+ Add Inventory Forecast</button>
    </div>
    
    <div class="table-actions-inventory">
       <div class="table-actions-row-inventory">
    <div class="tableColp4-inventory">
      <label for="filterProjectInventory">Project</label>
      <select id="filterProjectInventory"><option value="">All Projects</option></select>
    </div>
    <div class="tableColp4-inventory">
      <label for="filterCustomerInventory">Customer</label>
      <select id="filterCustomerInventory"><option value="">All Customers</option></select>
    </div>
    <div class="tableColp4-inventory">
      <label for="filterProjectManagerInventory">Project Manager</label>
      <select id="filterProjectManagerInventory"><option value="">All Managers</option></select>
    </div>
    <div class="tableColp4-inventory">
      <label for="filterGroupHeadInventory">Group Head</label>
      <select id="filterGroupHeadInventory"><option value="">All Group Heads</option></select>
    </div>
    <div class="tableColp4-inventory">
      <label for="filterProjectReferenceInventory">Project Reference</label>
      <select id="filterProjectReferenceInventory"><option value="">All References</option></select>
    </div>
    <div class="tableColp4-inventory"> 
      <label>&nbsp;</label>
      <button class="btn-secondary-inventory clear-filters-btn-inventory" title="Clear All Filters">Reset Filter</button> 
    </div>
  </div>
      
      <div class="table-actions-row-inventory">
        <div class="tableColp4-inventory">
          <label for="filterYearInventory">Year</label>
          <select id="filterYearInventory"><option value="">All Years</option></select>
        </div>
        <div class="tableColp4-inventory">
          <label for="filterMonthInventory">Month</label>
          <select id="filterMonthInventory"><option value="">All Months</option></select>
        </div>
        <div class="tableColp4-inventory"> 
          <label>&nbsp;</label>
          <button class="btn-secondary-inventory import-actual-btn-inventory">📥 Import Actual</button>
        </div>
        <div class="tableColp4-inventory"> 
          <label>&nbsp;</label>
          <button class="btn-secondary-inventory export-btn-inventory">📊 Export Excel</button>
        </div> 
      </div>
    </div>
       
    <div class="table-container-inventory">
      <div style="overflow-x:auto;">
        <table class="month-columns-table-inventory">
          <thead id="totalsHeaderInventory"></thead>
          <thead id="monthColumnsHeaderInventory"></thead>
          <tbody class="inventory-table-body"></tbody>
        </table>
      </div>
      
      <div class="pagination-container-inventory">
        <button class="pagination-btn-inventory" id="firstPageInventory" disabled>First</button>
        <button class="pagination-btn-inventory" id="prevPageInventory" disabled>Previous</button>
        
        <div class="pagination-info-inventory">
          Page <span id="currentPageInventory">1</span> of <span id="totalPagesInventory">1</span>
        </div>
        
        <div class="pagination-pages-inventory" id="pageNumbersInventory"></div>
        
        <button class="pagination-btn-inventory" id="nextPageInventory" disabled>Next</button>
        <button class="pagination-btn-inventory" id="lastPageInventory" disabled>Last</button>
        
        <div class="pagination-info-inventory">
          Showing <span id="startItemInventory">0</span>-<span id="endItemInventory">0</span> of <span id="totalItemsInventory">0</span> records
        </div>
      </div>
    </div>
  </section>

  <section class="form-section-inventory card" style="display:none;">
    <div class="page-header-inventory">
      <h1 id="formTitleInventory">Add / Edit Inventory Forecast</h1>
    </div>
    <form id="inventoryForm">
      <div class="form-row-inventory">
        <div class="form-group-inventory project-select-container-inventory">
          <label>Project</label>
          <select id="projectSelectInventory" required></select>
        </div>
        <div id="projectDetailsInventory"></div>
      </div>
      
      <div class="obl-section-container-inventory hidden-section">
        <div class="obl-main-section-inventory">
          <div class="form-group-inventory">
            <label>Inventory 
              <span class="info-tooltip-inventory" title="For new projects, enter the initial OBL value. For existing projects, this will be auto-populated from last month's data.">ℹ️</span>
            </label>
            <input type="text" id="oblLastMonthInventory" class="obl-input-inventory number-input-inventory" placeholder="Enter Inventory" readonly />
            <div class="field-note-inventory">For new projects: Enter initial Inventory value</div>
          </div>
          <div class="validation-summary-inventory">
            <div class="validation-item-inventory">
              <span class="validation-label-inventory">Total Current Value:</span>
              <span class="validation-value-inventory" id="totalCurrentValueInventory">0</span>
            </div>
            <div class="validation-item-inventory">
              <span class="validation-label-inventory">Remaining Balance:</span>
              <span class="validation-value-inventory" id="remainingValueInventory">0</span>
            </div>
            <div class="validation-line-inventory">
              <div class="line-fill-inventory" id="oblLineFillInventory"></div>
            </div>
          </div>
        </div>
        <div class="validation-message-inventory" id="oblValidationMessageInventory">
          ✅ All values are within Inventory limit
        </div>
      </div>
      
      <div class="forecast-section-inventory hidden-section" id="historicalForecastSectionInventory">
        <h3>Historical Data (Last 3 Months - Readonly)</h3>
        <div id="historicalContainerInventory" class="historical-container-inventory"></div>
      </div>
      
      <div class="forecast-section-inventory hidden-section" id="detailedForecastSectionInventory">
        <h3>Detailed Forecast (Current + Next 2 Months)</h3>
        <div id="firstRowContainerInventory" class="first-row-container-inventory"></div>
      </div>
      
      <div class="forecast-section-inventory hidden-section" id="longtermForecastSectionInventory">
        <h3>Long-term Forecast (Next 15 Months)</h3>
        <div id="remainingContainerInventory" class="remaining-container-inventory"></div>
      </div>

      <div class="forecast-section-inventory hidden-section" id="yearlyForecastSectionInventory">
        <h3>5-Year Forecast</h3>
        <div id="yearlyContainerInventory" class="yearly-container-inventory"></div>
      </div>
      
      <div class="form-actions-inventory">
        <button type="submit" class="btn-primary-inventory">💾 Save Inventory Forecast</button>
        <button type="button" class="btn-secondary-inventory back-to-table-inventory">⬅ Back</button>
      </div>
    </form>
  </section>
</div>
  `,

  style: `
  .totals-header-table-inventory {
  margin-bottom: 10px;
  background-color: #f8f9fa;
  border-collapse: separate;
  border-spacing: 0;
}

.totals-header-table-inventory th {
  padding: 8px 5px;
  font-size: 12px;
  font-weight: bold;
  text-align: center;
  vertical-align: middle;
  border: 1px solid #dee2e6;
  border-bottom: 2px solid #007bff;
  background-color: #e9ecef;
}

.totals-header-table-inventory .totals-label-inventory {
  font-weight: 600;
  color: #495057;
  background-color: #f1f3f4 !important;
}

.totals-header-table-inventory .all-projects-total-inventory {
  background-color: #d1ecf1 !important;
  color: #0c5460;
}

.totals-header-table-inventory .filtered-total-inventory {
  background-color: #d4edda !important;
  color: #155724;
}

.totals-header-table-inventory .total-value-inventory {
  font-weight: bold;
  font-size: 13px;
}

.tr.filtered-total-inventory {
    background-color: #00ffff;
}
.tr.all-projects-total-inventory {
    background-color: #fff8dc;
}

.page-number.dots {
  background-color: transparent;
  border: none;
  cursor: default;
  color: #6c757d;
}

.pagination-btn:focus,
.page-number:focus,
.page-size-select:focus {
  outline: 2px solid #007bff;
  outline-offset: 2px;
}

/* Loading state for table */
.table-loading {
  opacity: 0.7;
  pointer-events: none;
}

/* Animation for page transitions */
@keyframes fadeIn {
  from { opacity: 0.5; }
  to { opacity: 1; }
}

.revenue-table-body-rev tr {
  animation: fadeIn 0.3s ease-in;
}

/* Responsive table container */
.table-container-rev {
  overflow-x: auto;
  max-height: calc(100vh - 300px);
  position: relative;
}

.table-container-rev::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.table-container-rev::-webkit-scrollbar-track {
  background: #f1f1f1;
}

.table-container-rev::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 4px;
}

.table-container-rev::-webkit-scrollbar-thumb:hover {
  background: #555;
}

.pagination-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  padding: 15px;
  background-color: #f8f9fa;
  border-radius: 8px;
  border: 1px solid #dee2e6;
  flex-wrap: wrap;
  gap: 15px;
}

.pagination-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.pagination-right {
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
}

.page-size-selector {
  display: flex;
  align-items: center;
  gap: 8px;
}

.page-size-select {
  padding: 5px 10px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  background-color: white;
  font-size: 14px;
  cursor: pointer;
}

.page-size-select:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25);
}

.pagination-btn {
  padding: 6px 12px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.2s;
}

.pagination-btn:hover:not(:disabled) {
  background-color: #0056b3;
}

.pagination-btn:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
  opacity: 0.6;
}

.pagination-info {
  font-size: 14px;
  color: #495057;
  white-space: nowrap;
}

.pagination-pages {
  display: flex;
  gap: 5px;
}

.page-number {
  padding: 6px 12px;
  background-color: white;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s;
}

.page-number:hover:not(.active) {
  background-color: #f8f9fa;
  border-color: #007bff;
}

.page-number.active {
  background-color: #007bff;
  color: white;
  border-color: #007bff;
}

/* Responsive styles */
@media (max-width: 768px) {
  .pagination-container {
    flex-direction: column;
    align-items: stretch;
    gap: 15px;
  }
  
  .pagination-left, .pagination-right {
    justify-content: center;
    width: 100%;
  }
} 

/* Totals Header Styles */
.totals-header-table {
  margin-bottom: 10px;
  background-color: #f8f9fa;
  border-collapse: separate;
  border-spacing: 0;
}

.totals-header-table th {
  padding: 8px 5px;
  font-size: 12px;
  font-weight: bold;
  text-align: center;
  vertical-align: middle;
  border: 1px solid #dee2e6;
  border-bottom: 2px solid #007bff;
  background-color: #e9ecef;
}

.totals-header-table .totals-label {
  font-weight: 600;
  color: #495057;
  background-color: #f1f3f4 !important;
}

.totals-header-table .all-projects-total-inventory {
  background-color: #d1ecf1 !important;
  color: #0c5460;
}

.totals-header-table .filtered-total-inventory {
  background-color: #d4edda !important;
  color: #155724;
}

.totals-header-table .total-value {
  font-weight: bold;
  font-size: 13px;
}

/* Adjust main table margin */
.table-container-rev > div > table:last-child {
  margin-top: 0;
}

/* Ensure proper column alignment */
.totals-header-table th,
.month-columns-table-rev th {
  min-width: 100px;
  box-sizing: border-box;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .totals-header-table th {
    font-size: 10px;
    padding: 5px 3px;
  }
  
  .totals-header-table .total-value {
    font-size: 11px;
  }
}

tr.filtered-total-inventory {
    background-color: #00ffff;
}
tr.all-projects-total-inventory {
    background-color: #fff8dc;
}
.role-indicator-inventory {
    display: none;
}

.hidden-by-role-inventory {
  display: none !important;
}
  `,

  script: () => {
    setTimeout(async () => {
      const siteUrl = typeof _spPageContextInfo !== "undefined" ? _spPageContextInfo.webAbsoluteUrl : window.location.origin + "/sites/Kriya";
      const listName = "Inventory";
      const projectListName = "Project List";

      // DOM Elements - Updated with Inventory-specific IDs
      const tableBody = document.querySelector(".inventory-table-body") as HTMLElement;
      const monthColumnsHeader = document.querySelector("#monthColumnsHeaderInventory") as HTMLElement;
      const formSection = document.querySelector(".form-section-inventory") as HTMLElement;
      const tableSection = document.querySelector(".table-section-inventory") as HTMLElement;
      const showFormBtn = document.querySelector(".show-form-btn-inventory") as HTMLButtonElement;
      const projectSelect = document.querySelector("#projectSelectInventory") as HTMLSelectElement;
      const historicalContainer = document.querySelector("#historicalContainerInventory") as HTMLElement;
      const firstRowContainer = document.querySelector("#firstRowContainerInventory") as HTMLElement;
      const remainingContainer = document.querySelector("#remainingContainerInventory") as HTMLElement;
      const yearlyContainer = document.querySelector("#yearlyContainerInventory") as HTMLElement;
      const projectDetails = document.querySelector("#projectDetailsInventory") as HTMLElement;
      const backBtn = document.querySelector(".back-to-table-inventory") as HTMLButtonElement;
      const form = document.querySelector("#inventoryForm") as HTMLFormElement;
      const exportBtn = document.querySelector(".export-btn-inventory") as HTMLButtonElement;
      const oblLastMonthInput = document.querySelector("#oblLastMonthInventory") as HTMLInputElement;
      const totalCurrentValueSpan = document.querySelector("#totalCurrentValueInventory") as HTMLSpanElement;
      const remainingValueSpan = document.querySelector("#remainingValueInventory") as HTMLSpanElement;
      const oblLineFill = document.querySelector("#oblLineFillInventory") as HTMLDivElement;
      const oblValidationMessage = document.querySelector("#oblValidationMessageInventory") as HTMLDivElement;
      const formTitle = document.querySelector("#formTitleInventory") as HTMLElement;

      // Filter Elements - Updated with Inventory-specific IDs
      const filterYear = document.querySelector("#filterYearInventory") as HTMLSelectElement;
      const filterMonth = document.querySelector("#filterMonthInventory") as HTMLSelectElement;
      const filterProject = document.querySelector("#filterProjectInventory") as HTMLSelectElement;
      const filterCustomer = document.querySelector("#filterCustomerInventory") as HTMLSelectElement;
      const filterProjectManager = document.querySelector("#filterProjectManagerInventory") as HTMLSelectElement;
      const filterGroupHead = document.querySelector("#filterGroupHeadInventory") as HTMLSelectElement;
      const filterProjectReference = document.querySelector("#filterProjectReferenceInventory") as HTMLSelectElement;

      // Action Buttons - Updated with Inventory-specific IDs
      const importActualBtn = document.querySelector(".import-actual-btn-inventory") as HTMLButtonElement;
      const clearFiltersBtn = document.querySelector(".clear-filters-btn-inventory") as HTMLButtonElement; 

      // Pagination Elements - Updated with Inventory-specific IDs
      const firstPageBtn = document.querySelector("#firstPageInventory") as HTMLButtonElement;
      const prevPageBtn = document.querySelector("#prevPageInventory") as HTMLButtonElement;
      const nextPageBtn = document.querySelector("#nextPageInventory") as HTMLButtonElement;
      const lastPageBtn = document.querySelector("#lastPageInventory") as HTMLButtonElement;
      const currentPageSpan = document.querySelector("#currentPageInventory") as HTMLSpanElement;
      const totalPagesSpan = document.querySelector("#totalPagesInventory") as HTMLSpanElement;
      const pageNumbersDiv = document.querySelector("#pageNumbersInventory") as HTMLDivElement;
      const startItemSpan = document.querySelector("#startItemInventory") as HTMLSpanElement;
      const endItemSpan = document.querySelector("#endItemInventory") as HTMLSpanElement;
      const totalItemsSpan = document.querySelector("#totalItemsInventory") as HTMLSpanElement;

      let projects: ProjectItem[] = [];
      let forecasts: InventoryForecastItem[] = [];
      let editingId: number | null = null;
      let allMonths: string[] = [];
      
      // Pagination variables
      let currentPage = 1;
      const pageSize = 10;
      let totalPages = 1;
      let filteredData: InventoryForecastItem[] = [];

      let currentUser: UserContext;
      let userGroups: string[] = [];
      let managedProjects: string[] = [];
      let managedGroups: string[] = [];

      const getUserContext = async (): Promise<UserContext> => {
        try {
          const userRes = await fetch(`${siteUrl}/_api/web/currentuser`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const userData = await userRes.json();
          const loginName = userData.d.LoginName;
          const displayName = userData.d.Title;

          const groupsRes = await fetch(`${siteUrl}/_api/web/currentuser/groups`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const groupsData = await groupsRes.json();
          userGroups = groupsData.d.results.map((g: any) => g.Title);
          
          const isSuperAdmin = userGroups.some(g => 
            g.toLowerCase().includes("super admin") || 
            g.toLowerCase() === "site owners" ||
            g === "Super Admin"
          );
          
          const isGroupHead = userGroups.some(g => 
            g.toLowerCase().includes("group head") || 
            g === "Group Head"
          );
          
          const isProjectManager = userGroups.some(g => 
            g.toLowerCase().includes("project manager") || 
            g === "Project Manager"
          );

          if (isGroupHead) {
            const groupHeadName = displayName;
            managedGroups = [groupHeadName]; 
          }

          if (isProjectManager) {
            const pmProjectsRes = await fetch(
              `${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$filter=ProjectManager/Title eq '${displayName}'&$select=Id,Title`,
              { headers: { Accept: "application/json;odata=verbose" } }
            );
            const pmProjectsData = await pmProjectsRes.json();
            managedProjects = pmProjectsData.d.results.map((p: any) => p.Title); 
          }

          return {
            loginName,
            displayName,
            groups: userGroups,
            isSuperAdmin,
            isGroupHead,
            isProjectManager,
            userGroups,
            managedProjects,
            managedGroups
          };
        } catch (error) {
          console.error("Error getting user context:", error);
          return {
            loginName: "",
            displayName: "",
            groups: [],
            isSuperAdmin: false,
            isGroupHead: false,
            isProjectManager: false,
            managedProjects: [],
            managedGroups: []
          };
        }
      };

const filterDataByRole = (data: InventoryForecastItem[]): InventoryForecastItem[] => {
  // Super Admin sees everything
  if (currentUser.isSuperAdmin) {
    return data;
  }

  return data.filter(forecast => {
    const projectTitle = forecast.Project?.Title;
    
    if (!projectTitle) {
      return false; // No project title, can't check access
    }

    const project = projects.find(p => p.Title === projectTitle);
    
    if (!project) {
      return false; // Project not found in projects list
    }

    if (currentUser.isGroupHead) {
      // Group Head can see projects where they are the Group Head
      const hasAccess = currentUser.managedGroups?.some(group => 
        project.GroupHead === group
      ) || false;
      
      return hasAccess;
    }

    if (currentUser.isProjectManager) {
      // Project Manager can see projects where they are the Project Manager
      const managerName = typeof project.ProjectManager === 'object' 
        ? project.ProjectManager?.Title 
        : project.ProjectManager;
      
      return managerName === currentUser.displayName;
    }

    // Default: no access
    return false;
  });
};

const updateUIForRole = (): void => {
  const pageHeader = document.querySelector(".page-header-inventory") as HTMLElement;
  const roleIndicator = document.createElement("div");
  
  let roleText = "";
  let roleClass = "";
  
  if (currentUser.isSuperAdmin) {
    roleText = "Super Admin - Full Access";
    roleClass = "super-admin-role";
  } else if (currentUser.isGroupHead) {
    roleText = `Group Head - ${currentUser.displayName}`;
    roleClass = "group-head-role";
  } else if (currentUser.isProjectManager) {
    roleText = `Project Manager - ${currentUser.displayName}`;
    roleClass = "project-manager-role";
  } else {
    roleText = "Limited Access";
    roleClass = "limited-access-role";
  }
  
  roleIndicator.innerHTML = `
    <div class="role-indicator-inventory ${roleClass}">
      <span class="role-badge">👤 ${roleText}</span>
    </div>
  `;
  
  // Insert role indicator after the header
  pageHeader.parentNode?.insertBefore(roleIndicator, pageHeader.nextSibling);

  // Disable "Add Forecast" button for non-Super Admins if needed
  if (!currentUser.isSuperAdmin) {
    showFormBtn.disabled = false; // Allow all to add, but filter projects
  }

  // Apply CSS classes for role-based UI elements
  setTimeout(() => {
    applyRoleBasedUIClasses();
  }, 100);
};

  const applyRoleBasedUIClasses = (): void => {
        if (currentUser.isSuperAdmin) {
          document.querySelectorAll('.hidden-by-role-inventory').forEach(element => {
            element.classList.remove('hidden-by-role-inventory');
          });
          return;
        }
        
        const tableHeaders = document.querySelectorAll('.month-columns-table-inventory th');
        
        tableHeaders.forEach(header => {
          const headerText = header.textContent?.toLowerCase() || '';
          
          if (headerText.includes('project manager') || headerText.includes('manager')) {
            if (currentUser.isProjectManager) {
              header.classList.add('hidden-by-role-inventory');
            } else {
              header.classList.remove('hidden-by-role-inventory');
            }
          }
          
          if (headerText.includes('group head') || headerText.includes('head')) {
            if (currentUser.isGroupHead) {
              header.classList.add('hidden-by-role-inventory');
            } else {
              header.classList.remove('hidden-by-role-inventory');
            }
          }
        });

        const projectManagerFilter = document.querySelector('#filterProjectManagerInventory')?.closest('.tableColp4-inventory');
        const groupHeadFilter = document.querySelector('#filterGroupHeadInventory')?.closest('.tableColp4-inventory');
        
        if (projectManagerFilter) {
          if (currentUser.isProjectManager) {
            projectManagerFilter.classList.add('hidden-by-role-inventory');
          } else {
            projectManagerFilter.classList.remove('hidden-by-role-inventory');
          }
        }
        
        if (groupHeadFilter) {
          if (currentUser.isGroupHead) {
            groupHeadFilter.classList.add('hidden-by-role-inventory');
          } else {
            groupHeadFilter.classList.remove('hidden-by-role-inventory');
          }
        }
      };

const filterProjectSelectByRole = (): void => {
  if (!projectSelect || projectSelect.options.length === 0) return;
  
  if (currentUser.isSuperAdmin) {
    return; // Super Admin sees all projects
  }

  const options = projectSelect.querySelectorAll("option");
  options.forEach((option, index) => {
    if (index === 0) return; // Skip "Select Project" option
    
    const projectId = parseInt(option.value);
    const project = projects.find(p => p.Id === projectId);
    
    if (!project) {
      option.style.display = "none";
      return;
    }

    let showOption = false;
    
    if (currentUser.isGroupHead) {
      showOption = currentUser.managedGroups?.some(group => 
        project.GroupHead === group
      ) || false;
    } else if (currentUser.isProjectManager) {
      const managerName = typeof project.ProjectManager === 'object' 
        ? project.ProjectManager?.Title 
        : project.ProjectManager;
      showOption = managerName === currentUser.displayName;
    }
    
    option.style.display = showOption ? "" : "none";
    option.disabled = !showOption;
  });

  // Reset selection if current selection is hidden
  if (projectSelect.value) {
    const selectedOption = projectSelect.selectedOptions[0];
    if (selectedOption.style.display === "none") {
      projectSelect.value = "";
      toast("warning", "Your current project selection is not accessible with your role");
    }
  }
};

      // ========== UTILITY FUNCTIONS ==========

      const toast = (icon: any, title: string) => Swal.fire({ toast: true, icon, title, position: "top-end", timer: 2000, showConfirmButton: false });

      const getDigest = async (): Promise<string> => {
        const res = await fetch(`${siteUrl}/_api/contextinfo`, { 
          method: "POST", 
          headers: { Accept: "application/json;odata=verbose" } 
        });
        const data = await res.json();
        return data.d.GetContextWebInformation.FormDigestValue;
      };

      // Safe JSON parsing function
      const safeJsonParse = (jsonString: string | undefined, fallback: any = {}): any => {
        try {
          if (!jsonString || jsonString.trim() === '') {
            return fallback;
          }
          
          const cleanedString = jsonString.trim();
          
          if (cleanedString === '""' || cleanedString === "null") {
            return fallback;
          }
          
          return JSON.parse(cleanedString);
        } catch (error) {
          console.error("JSON parse error:", error, "Input:", jsonString);
          return fallback;
        }
      };

      const formatMonthKey = (date: Date): string => {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      };

      const formatMonthLabel = (date: Date): string => {
        return date.toLocaleString("default", { month: "short", year: "2-digit" });
      };

      const generateForecastTitle = (project: ProjectItem, forecastData: ForecastData): string => {
        const currentYear = new Date().getFullYear();
        let totalValue = 0;
        
        Object.keys(forecastData).forEach(key => {
          if (key.match(/^\d{4}-\d{2}$/)) {
            const monthData = forecastData[key] as ForecastMonthData;
            if (monthData) {
              totalValue += monthData.actual;
            }
          }
        });
        
        return `${project.Title} - ${currentYear} Inventory Forecast - ${totalValue.toLocaleString()}`;
      };

      // Get current and next 2 months for display
      const getDisplayMonths = (): string[] => {
        const now = new Date();
        const months: string[] = [];
        
        for (let i = 0; i < 3; i++) {
          const month = new Date(now.getFullYear(), now.getMonth() + i, 1);
          months.push(formatMonthKey(month));
        }
        
        return months;
      };

      const getAllMonthsForStorage = (): string[] => {
        return generateIdealMonthStructure();
      };

      // Utility function to allow only numbers 0-9 in text inputs
      const allowOnlyNumbers = (input: HTMLInputElement): void => {
        input.addEventListener('input', function() {
          let value = this.value.replace(/[^\d]/g, '');
          
          if (value.length > 1 && value.startsWith('0')) {
            value = value.replace(/^0+/, '');
            if (value === '') value = '0';
          }
          
          this.value = value;
          
          if (value === '' || value === '0') {
            this.className = this.className.replace('input-with-value-inventory', 'input-empty-inventory');
          } else {
            this.className = this.className.replace('input-empty-inventory', 'input-with-value-inventory');
          }
        });
        
        input.addEventListener('keydown', function(e) {
          if ([8, 9, 13, 27, 46].includes(e.keyCode) || 
              (e.keyCode === 65 && e.ctrlKey === true) || 
              (e.keyCode === 67 && e.ctrlKey === true) ||
              (e.keyCode === 86 && e.ctrlKey === true) ||
              (e.keyCode === 88 && e.ctrlKey === true) ||
              (e.keyCode >= 35 && e.keyCode <= 39)) {
            return;
          }
          
          if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
          }
        });
        
        input.addEventListener('paste', function(e) {
          const clipboardData = e.clipboardData || (window as any).clipboardData;
          const pastedData = clipboardData?.getData('Text') || '';
          
          if (/[^\d]/.test(pastedData)) {
            e.preventDefault();
          }
        });
      };

      // Function to get numeric value from text input - 0 is placeholder
      const getNumericValue = (input: HTMLInputElement): number => {
        const value = input.value.trim();
        if (value === '' || value === '0') return 0;
        return parseInt(value) || 0;
      };

      // Function to set numeric value to text input - 0 shows as empty
      const setNumericValue = (input: HTMLInputElement, value: number): void => {
        if (value === 0) {
          input.value = '';
          input.className = input.className.replace('input-with-value-inventory', 'input-empty-inventory');
        } else {
          input.value = value.toString();
          input.className = input.className.replace('input-empty-inventory', 'input-with-value-inventory');
        }
      };

      // Enhanced OBL validation with toast notifications
      const showOBLErrorToast = (message: string, isWarning: boolean = false): void => {
        const existingToast = document.querySelector('.obl-error-toast-inventory');
        if (existingToast) existingToast.remove();
        
        const toast = document.createElement('div');
        toast.className = `obl-error-toast-inventory ${isWarning ? 'warning-inventory' : ''}`;
        toast.innerHTML = `
          ${message}
          <button class="toast-close-inventory">&times;</button>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
          if (toast.parentNode) {
            toast.remove();
          }
        }, 5000);
        
        toast.querySelector('.toast-close-inventory')?.addEventListener('click', () => {
          toast.remove();
        });
      };

      // ========== MONTH STRUCTURE FUNCTIONS ==========

      const generateIdealMonthStructure = (): string[] => {
        const months: string[] = [];
        const currentDate = new Date();
         
        // Historical: 3 months before current (readonly)
        for (let i = -3; i < 0; i++) {
          const historicalDate = new Date(currentDate);
          historicalDate.setMonth(historicalDate.getMonth() + i);
          months.push(formatMonthKey(historicalDate));
        }
        
        // Detailed: Current + Next 2 months (editable with items)
        for (let i = 0; i < 3; i++) {
          const detailedDate = new Date(currentDate);
          detailedDate.setMonth(detailedDate.getMonth() + i);
          months.push(formatMonthKey(detailedDate));
        }
        
        // Future: Next 15 months (simple inputs)
        for (let i = 3; i < 18; i++) {
          const futureDate = new Date(currentDate);
          futureDate.setMonth(futureDate.getMonth() + i);
          months.push(formatMonthKey(futureDate));
        }
         
        return months;
      };

      // ========== YEARLY FORECAST FUNCTIONS ==========

      const getLastMonthKey = (existingData: ForecastData): string | undefined => {
        const monthKeys = Object.keys(existingData).filter(key => key.match(/^\d{4}-\d{2}$/));
        
        if (monthKeys.length === 0) {
          return undefined;
        }
        
        const sortedMonths = monthKeys.sort();
        const lastMonth = sortedMonths[sortedMonths.length - 1];
         
        return lastMonth;
      };

      const createFreshYearlyStructure = (lastMonthKey?: string): YearlyForecastData => {
        const yearlyData: YearlyForecastData = {};
        
        let startYear: number;
        
        if (lastMonthKey) {
          startYear = parseInt(lastMonthKey.split('-')[0]); 
        } else {
          const futureDate = new Date();
          futureDate.setMonth(futureDate.getMonth() + 15);
          startYear = futureDate.getFullYear(); 
        }
        
        const endYear = startYear + 4;
         
        
        for (let year = startYear; year <= endYear; year++) {
          yearlyData[year.toString()] = {
            plan: 0,
            actual: 0
          };
        }
        
        return yearlyData;
      };

      const createFreshForecastStructure = (): ForecastData => {
        const idealMonths = generateIdealMonthStructure();
        const freshData: ForecastData = {};
        
        const currentMonthKey = formatMonthKey(new Date());
        
        idealMonths.forEach((monthKey, index) => {
          const isCurrentMonth = monthKey === currentMonthKey;
          freshData[monthKey] = {
            plan: 0,
            actual: 0,
            forecast: 0,
            date: isCurrentMonth ? '' : undefined
          };
        });
        
        const lastMonthKey = idealMonths[idealMonths.length - 1];
        freshData.yearly = createFreshYearlyStructure(lastMonthKey);
        
        return freshData;
      };

      // Type guard to check if data is ForecastMonthData
      const isForecastMonthData = (data: any): data is ForecastMonthData => {
        return data && 
               typeof data.plan === 'number' && 
               typeof data.actual === 'number';
      };

      const handleMonthProgression = (forecastData: ForecastData): ForecastData => {
        const now = new Date();
        const currentMonthKey = formatMonthKey(now);
         

        const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
        const idealMonths = generateIdealMonthStructure();
        
        if (originalMonths[0] === idealMonths[0]) { 
          return forecastData;
        }
 
        const updatedData: ForecastData = {};

        idealMonths.forEach((monthKey, index) => {
          const existingData = forecastData[monthKey];
          if (existingData && isForecastMonthData(existingData)) {
            updatedData[monthKey] = JSON.parse(JSON.stringify(existingData));
          } else {
            updatedData[monthKey] = {
              plan: 0,
              actual: 0
            };
          }
        }); 
        const currentMonthIndex = idealMonths.indexOf(currentMonthKey);
        
        idealMonths.forEach((monthKey, index) => {
          const monthData = updatedData[monthKey];
          
          if (monthData && isForecastMonthData(monthData)) {
            const isCurrentOrFuture = index >= currentMonthIndex;
            
            if (isCurrentOrFuture) {
              const oldActual = monthData.actual;
              
              monthData.plan = oldActual;
              monthData.actual = 0;
             } else {
             }
          }
        });

        if (forecastData.yearly) {
          updatedData.yearly = JSON.parse(JSON.stringify(forecastData.yearly));
        } else {
          const lastMonthKey = idealMonths[idealMonths.length - 1];
          updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
        }
 
        return updatedData;
      };

      const propagateMonthValues = (forecastData: ForecastData): ForecastData => {
        if (Object.keys(forecastData).length === 0) {
          return forecastData;
        }
        
        return handleMonthProgression(forecastData);
      };

      // ========== DATA LOADING FUNCTIONS ==========

      const loadProjects = async (): Promise<void> => {
        try {
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$select=Id,Title,CustomerName,GroupHead,PC,ProjectReference,ProjectManager/Title&$expand=ProjectManager`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const data: SharePointResponse<ProjectItem> = await res.json();
          const rawProjects: ProjectItem[] = data.d?.results || [];
          
          projects = Array.from(new Map(rawProjects.map((p: ProjectItem) => [p.Title, p])).values());
          
          projectSelect.innerHTML = `<option value="">Select Project</option>` + 
            projects.map(p => `<option value="${p.Id}">${p.Title}</option>`).join("");
        } catch (error) {
          console.error("Error loading projects:", error);
          toast("error", "Failed to load projects");
        }        
      };

      const loadForecasts = async (): Promise<void> => {
        try {
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Id,Title,Project/Id,Project/Title,ProfitCentre,OBL,ForecastData,InventoryActual,CreatedDate,UpdatedDate&$expand=Project&$top=5000`, {
            headers: { Accept: "application/json;odata=verbose" }
          });
          const data: SharePointResponse<InventoryForecastItem> = await res.json();
          
          forecasts = (data.d?.results || []).map(forecast => ({
            ...forecast,
            ForecastData: typeof forecast.ForecastData === 'string' ? 
              forecast.ForecastData : 
              JSON.stringify(forecast.ForecastData || {}),
            InventoryActual: typeof forecast.InventoryActual === 'string' ? 
              forecast.InventoryActual : 
              JSON.stringify(forecast.InventoryActual || {})
          }));
           
          
        } catch (error) {
          console.error("Error loading Inventory forecasts:", error);
          toast("error", "Failed to load Inventory forecasts");
        }
      };

      // ========== EXPORT FUNCTIONS ==========

      const getMonthName = (monthNumber: string): string => {
        const months = [
          "Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        return months[parseInt(monthNumber) - 1] || "Month";
      };

      const exportToExcelWithFullStyle = (): void => { 
        const selectedYear = filterYear.value;
        const selectedMonth = filterMonth.value;
        
        if (!selectedYear || !selectedMonth) {
          toast("error", "Please select year and month to export");
          return;
        }

        const exportData = filteredData.length > 0 ? filteredData : forecasts;
        
        if (exportData.length === 0) {
          toast("error", "No Inventory data available to export");
          return;
        }

        try {
          const { headers, allMonths, lastFiveYears } = generateHeadersStructure(selectedYear, selectedMonth, exportData);
           
          const excelData = exportData.map(forecast => {
            const projectTitle = forecast.Project?.Title || "-";
            const proj = projects.find(p => p.Title === projectTitle);
            
            const inventoryActualData = safeJsonParse(forecast.InventoryActual, {});
            const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
            
            const oblValue = forecast.OBL || 0;
            
            const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
            const monthName = getMonthName(selectedMonth);
            
            const selectedMonthForecastData = forecastData[selectedMonthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            const selectedMonthPlan = selectedMonthForecastData.plan || 0;
            const selectedMonthCurrent = selectedMonthForecastData.actual || 0;
            const selectedMonthActual = inventoryActualData[selectedMonthKey] || 0;
            const selectedMonthForecast = selectedMonthForecastData.forecast || 0;

            const rowData: any = {
              "Profit Centre": forecast.ProfitCentre || "-",
              "SO/Project Ref": proj?.ProjectReference || "-",
              "Customer Name": proj?.CustomerName || "-",
              "Project Name": projectTitle,
              "Group Head": proj?.GroupHead || "-",
              "Project Manager": typeof proj?.ProjectManager === "object" ? proj.ProjectManager?.Title : proj?.ProjectManager || "-",
              "Inventory": oblValue,
              [`${monthName} ${selectedYear} (P)`]: selectedMonthPlan,
              [`${monthName} ${selectedYear} (C)`]: selectedMonthCurrent,
              [`${monthName} ${selectedYear} (R)`]: selectedMonthActual,
              [`${monthName} ${selectedYear} (F)`]: selectedMonthForecast,
            };
            
            allMonths.forEach(monthKey => {
              const [year, month] = monthKey.split('-');
              const monthLabel = getMonthName(month);
              const displayLabel = `${monthLabel} ${year}`;
              
              const forecastMonthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
              const planValue = forecastMonthData.plan || 0;
              const currentValue = forecastMonthData.actual || 0;
              
              rowData[`${displayLabel} (P)`] = planValue;
              rowData[`${displayLabel} (C)`] = currentValue;
            });
            
            lastFiveYears.forEach(year => {
              const yearData = forecastData.yearly?.[year] || { plan: 0, actual: 0 };
              rowData[`${year} (P)`] = yearData.plan;
              rowData[`${year} (C)`] = yearData.actual;
            });     
            
            const totalMonthlyCurrent = Object.keys(forecastData)
              .filter(key => key.match(/^\d{4}-\d{2}$/))
              .reduce((sum, monthKey) => {
                const monthData = forecastData[monthKey] as ForecastMonthData;
                return sum + (monthData?.actual || 0);
              }, 0);

            const totalYearlyCurrent = forecastData.yearly ? 
              Object.values(forecastData.yearly).reduce((sum, yearData) => {
                return sum + (yearData.actual || 0);
              }, 0) : 0;

            rowData["Balance"] = oblValue - (totalMonthlyCurrent + totalYearlyCurrent);
            
            return rowData;
          });
 
          const wb = XLSX.utils.book_new();
          
          const ws = XLSX.utils.json_to_sheet(excelData, { header: headers });

          const headerStyle = {
            fill: {
              fgColor: { rgb: "FF0078D4" }
            },
            font: {
              name: "Arial",
              sz: 10,
              bold: true,
              color: { rgb: "FFFFFFFF" }
            },
            alignment: {
              horizontal: "center",
              vertical: "center"
            },
            border: {
              top: { style: "thin", color: { rgb: "FF000000" } },
              left: { style: "thin", color: { rgb: "FF000000" } },
              bottom: { style: "thin", color: { rgb: "FF000000" } },
              right: { style: "thin", color: { rgb: "FF000000" } }
            }
          };

          const dataStyle = {
            font: {
              name: "Arial",
              sz: 10
            },
            alignment: {
              horizontal: "center",
              vertical: "center"
            },
            border: {
              top: { style: "thin", color: { rgb: "FFD0D0D0" } },
              left: { style: "thin", color: { rgb: "FFD0D0D0" } },
              bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
              right: { style: "thin", color: { rgb: "FFD0D0D0" } }
            }
          };

          const numberStyle = {
            ...dataStyle,
            alignment: {
              horizontal: "right",
              vertical: "center"
            }
          };

          const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
          
          for (let col = range.s.c; col <= range.e.c; col++) {
            const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
            if (!ws[cellAddress]) continue;
            
            if (!ws[cellAddress].s) {
              ws[cellAddress].s = {};
            }
            ws[cellAddress].s = headerStyle;
          }
          
          for (let row = range.s.r + 1; row <= range.e.r; row++) {
            for (let col = range.s.c; col <= range.e.c; col++) {
              const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
              if (!ws[cellAddress]) continue;
              
              const isNumberColumn = col >= 6;
              const styleToApply = isNumberColumn ? numberStyle : dataStyle;
              
              if (!ws[cellAddress].s) {
                ws[cellAddress].s = {};
              }
              ws[cellAddress].s = styleToApply;
            }
          }

          const colWidths = headers.map((header: string) => {
            if (header.includes('Project Name')) return { wch: 25 };
            if (header.includes('Customer Name')) return { wch: 20 };
            if (header.includes('Profit Centre') || header.includes('SO/Project Ref')) return { wch: 12 };
            if (header.includes('Group Head') || header.includes('Project Manager')) return { wch: 15 };
            if (header.includes('OBL') || header.includes('Balance')) return { wch: 12 };
            if (header.includes('(P)') || header.includes('(C)') || header.includes('(F)')) return { wch: 10 };
            return { wch: 12 };
          });
          ws['!cols'] = colWidths;

          ws['!freeze'] = { x: 0, y: 1 };

          XLSX.utils.book_append_sheet(wb, ws, "Inventory Forecast");

          const monthName = getMonthName(selectedMonth);
          const fileName = `Inventory_Forecast_${monthName}_${selectedYear}_Filtered.xlsx`;
          
          XLSX.writeFile(wb, fileName);
           
          toast("success", `Exported ${exportData.length} filtered Inventory records for ${monthName} ${selectedYear}`);
          
        } catch (error) {
          console.error("❌ Error during styled Inventory Excel export:", error);
          toast("error", "Failed to export Inventory data to Excel");
        }
      };

      const generateHeadersStructure = (selectedYear: string, selectedMonth: string, exportData: InventoryForecastItem[]) => {
        const baseHeaders = [
          "Profit Centre", 
          "SO/Project Ref", 
          "Customer Name", 
          "Project Name", 
          "Group Head", 
          "Project Manager", 
          "Inventory",
        ];

        const selectedMonthName = getMonthName(selectedMonth);
        const selectedMonthHeaders = [
          `${selectedMonthName} ${selectedYear} (P)`,
          `${selectedMonthName} ${selectedYear} (C)`,
          `${selectedMonthName} ${selectedYear} (R)`,
          `${selectedMonthName} ${selectedYear} (F)`
        ];

        const allMonthKeys = new Set<string>();
        
        exportData.forEach(forecast => {
          const forecastData = safeJsonParse(forecast.ForecastData, {});
          Object.keys(forecastData).forEach(key => {
            if (key && key.match(/^\d{4}-\d{2}$/)) {
              allMonthKeys.add(key);
            }
          });
        });

        const sortedMonthKeys = Array.from(allMonthKeys).sort();
        const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
        const selectedIndex = sortedMonthKeys.indexOf(selectedMonthKey);
        
        const startIndex = selectedIndex >= 0 ? selectedIndex + 1 : 0;
        const next17Months = sortedMonthKeys.slice(startIndex, startIndex + 17);
 
        const monthlyHeaders: string[] = [];
        next17Months.forEach(monthKey => {
          const [year, month] = monthKey.split('-');
          const monthLabel = getMonthName(month);
          const displayLabel = `${monthLabel} ${year}`;
          monthlyHeaders.push(`${displayLabel} (P)`, `${displayLabel} (C)`);
        });

        const lastFiveYears = getLastFiveYears(exportData);
        const yearlyHeaders: string[] = [];
        lastFiveYears.forEach(year => {
          yearlyHeaders.push(`${year} (P)`, `${year} (C)`);
        });

        const finalHeaders = [
          ...baseHeaders,
          ...selectedMonthHeaders,
          ...monthlyHeaders,
          ...yearlyHeaders,
          "Balance"
        ];
        
        return { 
          headers: finalHeaders, 
          allMonths: next17Months,
          lastFiveYears
        };
      };

      const getLastFiveYears = (data: InventoryForecastItem[]): string[] => {
        const years = new Set<string>();
        
        data.forEach(forecast => {
          const forecastData = safeJsonParse(forecast.ForecastData, {});
          if (forecastData.yearly) {
            Object.keys(forecastData.yearly).forEach(year => {
              years.add(year);
            });
          }
        });
        
        const sortedYears = Array.from(years).sort();
        return sortedYears.slice(-5);
      };

        
      // ======  PAGINATION FUNCTIONS ======

const initializePagination = (data: InventoryForecastItem[]): void => { 
  const roleFilteredData = filterDataByRole(data);
  filteredData = roleFilteredData; 
  totalPages = Math.ceil(filteredData.length / pageSize);
  currentPage = 1;
  updatePaginationControls();
  renderCurrentPage();
  
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
};

      const updatePaginationControls = (): void => {
        currentPageSpan.textContent = currentPage.toString();
        totalPagesSpan.textContent = totalPages.toString();
        
        const startItem = (currentPage - 1) * pageSize + 1;
        const endItem = Math.min(currentPage * pageSize, filteredData.length);
        startItemSpan.textContent = startItem.toString();
        endItemSpan.textContent = endItem.toString();
        totalItemsSpan.textContent = filteredData.length.toString();
        
        firstPageBtn.disabled = currentPage === 1;
        prevPageBtn.disabled = currentPage === 1;
        nextPageBtn.disabled = currentPage === totalPages;
        lastPageBtn.disabled = currentPage === totalPages;
        
        updatePageNumbers();
      };

      const updatePageNumbers = (): void => {
        pageNumbersDiv.innerHTML = '';
        
        const maxVisiblePages = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
        
        if (endPage - startPage + 1 < maxVisiblePages) {
          startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
          const pageBtn = document.createElement('button');
          pageBtn.className = `page-number-inventory ${i === currentPage ? 'active-inventory' : ''}`;
          pageBtn.textContent = i.toString();
          pageBtn.addEventListener('click', () => goToPage(i));
          pageNumbersDiv.appendChild(pageBtn);
        }
      };

      const goToPage = (page: number): void => {
        if (page < 1 || page > totalPages || page === currentPage) return;
        
        currentPage = page;
        updatePaginationControls();
        renderCurrentPage();
      };
 
      const renderCurrentPage = (): void => {
        const startIndex = (currentPage - 1) * pageSize;
        const endIndex = Math.min(startIndex + pageSize, filteredData.length);
        const pageData = filteredData.slice(startIndex, endIndex);
        
        renderTableWithMonthColumns(pageData);
      };

      const calculateTotals = (
  data: InventoryForecastItem[],
  displayMonths: string[],
  currentMonthKey: string
): any => {

  let dataToCalculate = currentUser.isSuperAdmin
    ? data
    : filterDataByRole(data);

  const totals = {
    obl: 0,
    actualInventory: 0,
    monthly: {} as {
      [key: string]: { plan: number; current: number; forecast: number; total: number }
    }
  };

  displayMonths.forEach(monthKey => {
    totals.monthly[monthKey] = { plan: 0, current: 0, forecast: 0, total: 0 };
  });

  dataToCalculate.forEach(forecast => {
    totals.obl += Math.round(Number(forecast.OBL) || 0);

    const forecastData = safeJsonParse(forecast.ForecastData, {});

    displayMonths.forEach(monthKey => {
      const m = forecastData[monthKey] || {};
      const isCurrent = monthKey === currentMonthKey;

      const plan = Math.round(Number(m.plan) || 0);
      const current = Math.round(Number(m.actual) || 0);
      const forecastVal = Math.round(Number(m.forecast) || 0);

      totals.monthly[monthKey].plan += plan;
      totals.monthly[monthKey].current += current;

      if (isCurrent) {
        totals.monthly[monthKey].forecast += forecastVal;
        totals.monthly[monthKey].total += plan + current + forecastVal;
      } else {
        totals.monthly[monthKey].total += plan + current;
      }
    });
  });

  return totals;
};

const renderTotalsHeader = (displayMonths: string[], currentMonthKey: string): void => {
  const totalsHeader = document.querySelector("#totalsHeaderInventory") as HTMLElement;
  if (!totalsHeader) return;

  totalsHeader.innerHTML = '';

  const allData = forecasts;
  const roleFiltered = filterDataByRole(allData);
  const filtered = filteredData.length ? filteredData : roleFiltered;

  const allTotals = calculateTotals(allData, displayMonths, currentMonthKey);
  const filteredTotals = calculateTotals(filtered, displayMonths, currentMonthKey);

  const showPM = currentUser.isSuperAdmin || !currentUser.isProjectManager;
  const showGH = currentUser.isSuperAdmin || !currentUser.isGroupHead;

  const buildTotalsRow = (label: string, totals: any, css: string) => `
    <tr class="${css}">
      <td class="totals-label-inventory">${label}</td>
      <td></td>
      ${showPM ? `<td></td>` : ''}
      ${showGH ? `<td></td>` : ''}
      <td></td>
      <td class="total-value-inventory">${totals.obl.toLocaleString('en-IN')}</td>
      <td class="total-value-inventory">${totals.actualInventory.toLocaleString('en-IN')}</td>
      ${displayMonths.map(m => {
        const isCurrent = m === currentMonthKey;
        const t = totals.monthly[m] || { plan: 0, current: 0, forecast: 0, total: 0 };

        return isCurrent
          ? `
            <td>${t.plan}</td>
            <td>${t.current}</td>
            <td>${t.forecast}</td>
            <td class="total-value-inventory">${t.total}</td>
          `
          : `
            <td>${t.plan}</td>
            <td>${t.current}</td>
            <td class="total-value-inventory">${t.total}</td>
          `;
      }).join('')}
      <td></td>
    </tr>
  `;

  totalsHeader.innerHTML = `
    <table class="totals-header-table-inventory" style="width: 100%;">
      ${buildTotalsRow(`All`, allTotals, 'all-projects-total-inventory')}
      ${buildTotalsRow(`Filtered (${filtered.length})`, filteredTotals, 'filtered-total-inventory')}
    </table>
  `;
};
      // ========== TABLE RENDERING FUNCTIONS ==========
const renderTableWithMonthColumns = (data: InventoryForecastItem[]): void => {
  // Apply role-based filtering
  const roleFilteredForecasts = filterDataByRole(data); 
  
  if (!roleFilteredForecasts.length) {
    tableBody.innerHTML = `<tr><td colspan="21" style="text-align:center;padding:20px;">
      ${currentUser.isSuperAdmin ? 'No Inventory records found' : 
        currentUser.isGroupHead ? 'No Inventory records found in your groups' : 
        currentUser.isProjectManager ? 'No assigned Inventory projects found' : 
        'No access to view any Inventory records'}
    </td></tr>`; 
    
    // Clear totals header
    const totalsHeader = document.querySelector("#totalsHeaderInventory") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = ''; 
    return;
  } 

  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  
  // First, render the totals rows above the main header
  renderTotalsHeader(displayMonths, currentMonthKey);
  
  // Determine which columns to show based on role
  const showProjectManagerColumn = currentUser.isSuperAdmin ? true : !currentUser.isProjectManager;
  const showGroupHeadColumn = currentUser.isSuperAdmin ? true : !currentUser.isGroupHead;
  
  // Build main table header
  const headerHTML = `
    <!-- Main Header Row 1 -->
    <tr>
      <!-- Project Reference Column -->
      <th rowspan="2" class="project-info-cell-inventory">Project Reference</th>
      
      <!-- Project Column with Sort -->
      <th rowspan="2" class="project-info-cell-inventory">
        <div class="sort-header-container-inventory">
          <span class="header-label-inventory">Project</span>
          <div class="sort-buttons-container-inventory">
            <button class="sort-btn-inventory ${currentSortConfig.column === 'project' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                    data-sort="project" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-inventory ${currentSortConfig.column === 'project' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                    data-sort="project" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Customer Column with Sort -->
      <th rowspan="2" class="project-info-cell-inventory">
        <div class="sort-header-container-inventory">
          <span class="header-label-inventory">Customer</span>
          <div class="sort-buttons-container-inventory">
            <button class="sort-btn-inventory ${currentSortConfig.column === 'customer' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                    data-sort="customer" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-inventory ${currentSortConfig.column === 'customer' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                    data-sort="customer" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Project Manager Column (conditional based on role) -->
      ${showProjectManagerColumn ? `
        <th rowspan="2" class="project-info-cell-inventory">Project Manager</th>
      ` : ''}
      
      <!-- Group Head Column (conditional based on role) -->
      ${showGroupHeadColumn ? `
        <th rowspan="2" class="project-info-cell-inventory">Group Head</th>
      ` : ''}
      
      <!-- Inventory Column with Sort -->
      <th rowspan="2" class="month-column-header-inventory">
        <div class="sort-header-container-inventory">
          <span class="header-label-inventory">Inventory</span>
          <div class="sort-buttons-container-inventory">
            <button class="sort-btn-inventory ${currentSortConfig.column === 'obl' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                    data-sort="obl" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-inventory ${currentSortConfig.column === 'obl' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                    data-sort="obl" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Actual Inventory Column with Sort -->
      <th rowspan="2" class="month-column-header-inventory">
        <div class="sort-header-container-inventory">
          <span class="header-label-inventory">Actual Inventory</span>
          <div class="sort-buttons-container-inventory">
            <button class="sort-btn-inventory ${currentSortConfig.column === 'actualInventory' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                    data-sort="actualInventory" data-direction="asc" title="Sort Ascending">▲</button>
            <button class="sort-btn-inventory ${currentSortConfig.column === 'actualInventory' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                    data-sort="actualInventory" data-direction="desc" title="Sort Descending">▼</button>
          </div>
        </div>
      </th>
      
      <!-- Month Columns -->
      ${displayMonths.map((month, monthIndex) => {
        const isCurrentMonth = month === currentMonthKey;
        const colspan = isCurrentMonth ? 4 : 3;
        return `
          <th colspan="${colspan}" class="month-column-header-inventory ${isCurrentMonth ? 'current-month-header-inventory' : ''}">
            <div class="sort-header-container-inventory">
              <span class="header-label-inventory">${formatMonthLabel(new Date(month + "-01"))}</span>
              <div class="sort-buttons-container-inventory">
                <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                        data-sort="month" data-direction="asc" data-month-index="${monthIndex}" title="Sort by Month Total Ascending">▲</button>
                <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && !currentSortConfig.subColumn && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                        data-sort="month" data-direction="desc" data-month-index="${monthIndex}" title="Sort by Month Total Descending">▼</button>
              </div>
            </div>
            ${isCurrentMonth ? ' <span style="font-size:10px;color:#ffeb3b;">(Current Month)</span>' : ''}
          </th>
        `;
      }).join('')}
      <th rowspan="2">Actions</th>
    </tr>
    
    <!-- Main Header Row 2 (Sub-headers) -->
    <tr>
      ${displayMonths.map((month, monthIndex) => {
        const isCurrentMonth = month === currentMonthKey;
        if (isCurrentMonth) {
          return `
            <th class="month-subheader-inventory current-month-header-table-inventory">
              <div class="sort-header-container-inventory">
                <span>Previous</span>
                <div class="sort-buttons-container-inventory">
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Ascending">▲</button>
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-inventory current-month-header-table-inventory">
              <div class="sort-header-container-inventory">
                <span>Current</span>
                <div class="sort-buttons-container-inventory">
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Ascending">▲</button>
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-inventory current-month-header-table-inventory">
              <div class="sort-header-container-inventory">
                <span>Forecast</span>
                <div class="sort-buttons-container-inventory">
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'forecast' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="forecast" data-month-index="${monthIndex}" title="Sort Forecast Ascending">▲</button>
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'forecast' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="forecast" data-month-index="${monthIndex}" title="Sort Forecast Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-inventory current-month-header-table-inventory">
              <div class="sort-header-container-inventory">
                <span>Total</span>
                <div class="sort-buttons-container-inventory">
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Ascending">▲</button>
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Descending">▼</button>
                </div>
              </div>
            </th>
          `;
        } else {
          return `
            <th class="month-subheader-inventory">
              <div class="sort-header-container-inventory">
                <span>Previous</span>
                <div class="sort-buttons-container-inventory">
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Ascending">▲</button>
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'plan' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="plan" data-month-index="${monthIndex}" title="Sort Plan Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-inventory">
              <div class="sort-header-container-inventory">
                <span>Current</span>
                <div class="sort-buttons-container-inventory">
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Ascending">▲</button>
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'current' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="current" data-month-index="${monthIndex}" title="Sort Current Descending">▼</button>
                </div>
              </div>
            </th>
            <th class="month-subheader-inventory">
              <div class="sort-header-container-inventory">
                <span>Total</span>
                <div class="sort-buttons-container-inventory">
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'asc' ? 'sort-asc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="asc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Ascending">▲</button>
                  <button class="sort-btn-inventory ${currentSortConfig.column === 'month' && currentSortConfig.monthIndex === monthIndex && currentSortConfig.subColumn === 'total' && currentSortConfig.direction === 'desc' ? 'sort-desc-inventory active-inventory' : ''}" 
                          data-sort="month" data-direction="desc" data-subcolumn="total" data-month-index="${monthIndex}" title="Sort Total Descending">▼</button>
                </div>
              </div>
            </th>
          `;
        }
      }).join('')}
    </tr>
  `;

  // Set main header HTML
  monthColumnsHeader.innerHTML = headerHTML;

  // Build table body with actual data
  let tableBodyHTML = '';

  roleFilteredForecasts.forEach((forecast, index) => {
    const projectTitle = forecast.Project?.Title || "-";
    const proj = projects.find(p => p.Title === projectTitle);
    
    // Parse forecast data
    const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
    const inventoryActualData = safeJsonParse(forecast.InventoryActual, {});
    
    // Get selected year and month for actual inventory
    const selectedYear = filterYear.value;
    const selectedMonth = filterMonth.value;
    const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
    const actualInventory = selectedMonthKey ? inventoryActualData[selectedMonthKey] || 0 : 0;
    
    const formattedOBL = Math.round(forecast.OBL || 0).toLocaleString('en-IN');
    const formattedActualInventory = Math.round(actualInventory || 0).toLocaleString('en-IN');
    
    // Start building the row
    let rowHTML = `
      <tr>
        <td class="project-info-cell-inventory">${getSafeString(proj?.ProjectReference)}</td>
        <td class="project-info-cell-inventory">${projectTitle}</td>
        <td class="project-info-cell-inventory">${getSafeString(proj?.CustomerName)}</td>
    `;

    // Add Project Manager column if visible
    if (showProjectManagerColumn) {
      rowHTML += `<td class="project-info-cell-inventory">${proj ? getSafeString(proj.ProjectManager) : "-"}</td>`;
    }

    // Add Group Head column if visible
    if (showGroupHeadColumn) {
      rowHTML += `<td class="project-info-cell-inventory">${proj ? getSafeString(proj.GroupHead) : "-"}</td>`;
    }

    rowHTML += `
        <td class="month-column-cell-inventory">${formattedOBL}</td>
        <td class="month-column-cell-inventory">${formattedActualInventory}</td>
    `;

    // Add month columns data with totals
    displayMonths.forEach((monthKey, monthIndex) => {
      const monthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
      const isCurrentMonth = monthKey === currentMonthKey;
      
      // Calculate totals
      const planValue = monthData.plan || 0;
      const currentValue = monthData.actual || 0;
      const forecastValue = monthData.forecast || 0;
      
      if (isCurrentMonth) {
        // Current month: show plan, current, forecast, and total (plan + current + forecast)
        const totalValue = planValue + currentValue + forecastValue;
        rowHTML += `
          <td class="month-column-cell-inventory">${planValue}</td>
          <td class="month-column-cell-inventory">${currentValue}</td>
          <td class="month-column-cell-inventory">${forecastValue}</td>
          <td class="month-column-cell-inventory total-cell-inventory" style="font-weight: bold; background-color: #f0f8ff;">${totalValue}</td>
        `;
      } else {
        // Other months: show plan, current, and total (plan + current)
        const totalValue = planValue + currentValue;
        rowHTML += `
          <td class="month-column-cell-inventory">${planValue}</td>
          <td class="month-column-cell-inventory">${currentValue}</td>
          <td class="month-column-cell-inventory total-cell-inventory" style="font-weight: bold; background-color: #f5f5f5;">${totalValue}</td>
        `;
      }
    });

    // Add actions column
    rowHTML += `
        <td class="actions-cell-inventory">
          <button class="edit-btn-inventory edit-action-btn-inventory" data-id="${forecast.Id}">✏️ Edit</button>
        </td>
      </tr>
    `;

    tableBodyHTML += rowHTML;
  });

  tableBody.innerHTML = tableBodyHTML;
  
  // Attach event listeners
  attachSortButtonListeners();
  attachTableEventListeners();
};
const getSafeString = (value: any, defaultValue: string = "-"): string => {
  if (value === null || value === undefined) {
    return defaultValue;
  }
  
  if (typeof value === 'string') {
    return value.trim() || defaultValue;
  }
  
  if (typeof value === 'object' && 'Title' in value) {
    return value.Title?.trim() || defaultValue;
  }
  
  return String(value) || defaultValue;
};

      const attachSortButtonListeners = (): void => {
        document.querySelectorAll('.sort-btn-inventory[data-sort]').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const button = e.currentTarget as HTMLButtonElement;
            const sortColumn = button.dataset.sort;
            const direction = button.dataset.direction as 'asc' | 'desc';
            const subColumn = button.dataset.subcolumn;
            const monthIndex = button.dataset.monthIndex ? parseInt(button.dataset.monthIndex) : undefined;
            
            if (sortColumn && direction) {
              handleInventorySort(sortColumn, direction, subColumn, monthIndex);
            }
          });
        });
      };

      const attachTableEventListeners = (): void => {
        tableBody.querySelectorAll(".edit-btn-inventory").forEach(btn => {
          btn.addEventListener("click", () => {
            const id = parseInt((btn as HTMLButtonElement).dataset.id!);
            editForecast(id);
          });
        });
      };

      const handleInventorySort = (column: string, direction: 'asc' | 'desc', subColumn?: string, monthIndex?: number): void => {
        currentSortConfig = {
          column,
          direction,
          subColumn,
          monthIndex
        };

        const dataToSort = filteredData.length > 0 ? filteredData : forecasts;
        
        if (dataToSort.length === 0) return;

        const sortedData = [...dataToSort].sort((a, b) => {
          let valueA: any = 0;
          let valueB: any = 0;

          switch (column) {
            case 'obl':
              valueA = a.OBL || 0;
              valueB = b.OBL || 0;
              break;
            
            case 'actualInventory':
              const selectedYear = filterYear.value;
              const selectedMonth = filterMonth.value;
              const selectedMonthKey = selectedYear && selectedMonth ? `${selectedYear}-${selectedMonth.padStart(2, '0')}` : '';
              
              if (selectedMonthKey) {
                const inventoryA = safeJsonParse(a.InventoryActual, {});
                const inventoryB = safeJsonParse(b.InventoryActual, {});
                valueA = inventoryA[selectedMonthKey] || 0;
                valueB = inventoryB[selectedMonthKey] || 0;
              } else {
                valueA = 0;
                valueB = 0;
              }
              break;
            
            case 'month':
              const displayMonths = getDisplayMonths();
              
              const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
              const monthKeyToUse = displayMonths[monthIndexToUse];
              
              const dataA = safeJsonParse(a.ForecastData, {});
              const dataB = safeJsonParse(b.ForecastData, {});
              const monthDataA = dataA[monthKeyToUse] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
              const monthDataB = dataB[monthKeyToUse] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
              
              if (subColumn) {
                switch (subColumn) {
                  case 'plan':
                    valueA = monthDataA.plan || 0;
                    valueB = monthDataB.plan || 0;
                    break;
                  case 'current':
                    valueA = monthDataA.actual || 0;
                    valueB = monthDataB.actual || 0;
                    break;
                  case 'forecast':
                    valueA = monthDataA.forecast || 0;
                    valueB = monthDataB.forecast || 0;
                    break;
                  default:
                    valueA = monthDataA.actual || 0;
                    valueB = monthDataB.actual || 0;
                }
              } else {
                valueA = monthDataA.actual || 0;
                valueB = monthDataB.actual || 0;
              }
              break;
            
            case 'project':
              valueA = a.Project?.Title || "";
              valueB = b.Project?.Title || "";
              break;
            
            case 'customer':
              const projA = projects.find(p => p.Title === a.Project?.Title);
              const projB = projects.find(p => p.Title === b.Project?.Title);
              valueA = projA?.CustomerName || "";
              valueB = projB?.CustomerName || "";
              break;
            
            default:
              return 0;
          }

          if (typeof valueA === 'number' && typeof valueB === 'number') {
            return direction === 'asc' ? valueA - valueB : valueB - valueA;
          } else {
            const strA = String(valueA).toLowerCase();
            const strB = String(valueB).toLowerCase();
            return direction === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
          }
        });

        if (filteredData.length > 0) {
          filteredData = sortedData;
        } else {
          forecasts = sortedData;
        }

        currentPage = 1;
        updatePaginationControls();
        renderCurrentPage();
        
        const sortDirectionText = direction === 'asc' ? 'Ascending' : 'Descending';
        let columnName = '';
        
        if (subColumn) {
          columnName = subColumn.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
        } else if (column === 'obl') {
          columnName = 'OBL';
        } else if (column === 'actualInventory') {
          columnName = 'Actual Inventory';
        } else if (column === 'project') {
          columnName = 'Project';
        } else if (column === 'customer') {
          columnName = 'Customer';
        } else {
          const displayMonths = getDisplayMonths();
          const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
          const monthKey = displayMonths[monthIndexToUse];
          const monthDate = new Date(monthKey + "-01");
          columnName = formatMonthLabel(monthDate);
        }
        
        toast("info", `Sorted by ${columnName} (${sortDirectionText})`);
      };

const clearFilters = (): void => {
  filterYear.value = "";
  filterMonth.value = "";
  filterProject.value = "";
  filterCustomer.value = "";
  filterProjectManager.value = "";
  filterGroupHead.value = "";
  filterProjectReference.value = "";
  
  currentSortConfig = {
    column: '',
    direction: 'asc'
  };
  
  initializePagination(forecasts);
  
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
  
  toast("info", "All Inventory filters and sorting cleared");
};

      // ========== FORM MANAGEMENT FUNCTIONS ==========

      const showForm = (isEditMode: boolean = false): void => {
        formSection.style.display = "block";
        tableSection.style.display = "none";
        showFormBtn.style.display = "none";
        
        if (isEditMode) {
          formSection.classList.add('edit-mode-inventory');
          projectSelect.disabled = true;
          formTitle.textContent = "Edit Inventory Forecast";
        } else {
          formSection.classList.remove('edit-mode-inventory');
          projectSelect.disabled = false;
          formTitle.textContent = "Add Inventory Forecast";
        }
      };

      const hideForm = (): void => {
        formSection.style.display = "none";
        tableSection.style.display = "block";
        showFormBtn.style.display = "inline-block";
        formSection.classList.remove('edit-mode-inventory');
        projectSelect.disabled = false;
      };

      const resetForm = (): void => {
        editingId = null;
        form.reset();
        projectSelect.value = "";
        projectDetails.innerHTML = "";
        historicalContainer.innerHTML = "";
        firstRowContainer.innerHTML = "";
        remainingContainer.innerHTML = "";
        yearlyContainer.innerHTML = "";
        
        toggleForecastSections(false);
        
        const oblContainer = document.querySelector('.obl-section-container-inventory') as HTMLElement;
        oblContainer.className = 'obl-section-container-inventory hidden-section';
        oblLastMonthInput.removeAttribute('readonly');
        oblLastMonthInput.placeholder = "Enter OBL";
        setNumericValue(oblLastMonthInput, 0);
        
        const fieldNote = oblContainer.querySelector('.field-note-inventory') as HTMLElement;
        if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
        
        oblValidationMessage.textContent = "✅ All values are within OBL limit";
        oblValidationMessage.className = 'validation-message-inventory';
        
        updateOBLValidationDisplay();
      };
    
      // ========== VALIDATION FUNCTIONS ==========

      const calculateTotalCurrentValue = (): number => {
        let total = 0;
        
        const editableMonths = allMonths.slice(3);
        
        editableMonths.forEach(monthKey => {
          const currentInputs = document.querySelectorAll<HTMLInputElement>(`input.main-current-input-inventory[data-month="${monthKey}"]:not([readonly])`);
          currentInputs.forEach(input => {
            total += getNumericValue(input);
          });
        });
        
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.yearly-current-input-inventory:not([readonly])`);
        yearlyCurrentInputs.forEach(input => {
          total += getNumericValue(input);
        });
        
        return total;
      };

      const validateOBLLimit = (changedInput?: HTMLInputElement): boolean => {
        const oblValue = getNumericValue(oblLastMonthInput);
        const totalCurrent = calculateTotalCurrentValue();
        
        totalCurrentValueSpan.textContent = totalCurrent.toLocaleString();
        
        const remaining = oblValue - totalCurrent;
        remainingValueSpan.textContent = remaining.toLocaleString();
        
        if (oblValue === 0) {
          oblLineFill.style.width = `0%`;
          oblLineFill.className = 'line-fill-inventory';
          
          if (totalCurrent > 0) {
            showOBLErrorToast('⚠️ OBL is zero but current values exist. Please set OBL value.', true);
            blockAllCurrentInputs();
            return false;
          } else {
            const existingToast = document.querySelector('.obl-error-toast-inventory');
            if (existingToast) existingToast.remove();
            unblockAllCurrentInputs();
            return true;
          }
        }
        
        const percentage = Math.min((totalCurrent / oblValue) * 100, 100);
        oblLineFill.style.width = `${percentage}%`;
        
        oblLineFill.className = 'line-fill-inventory';
        if (percentage > 90) {
          oblLineFill.classList.add('danger-inventory');
        } else if (percentage > 75) {
          oblLineFill.classList.add('warning-inventory');
        }
        
        oblValidationMessage.className = 'validation-message-inventory';
        
        if (totalCurrent > oblValue) {
          const exceedAmount = totalCurrent - oblValue;
          showOBLErrorToast(`❌ Total current value exceeds OBL by ${exceedAmount.toLocaleString()}! Reduce values to continue.`);
          oblValidationMessage.classList.add('danger-inventory');
          blockIncreasingCurrentInputs(changedInput);
          return false;
        } else if (percentage > 90) {
          showOBLErrorToast('⚠️ OBL limit nearly reached! Consider reducing values.', true);
          oblValidationMessage.classList.add('warning-inventory');
          unblockAllCurrentInputs();
          return true;
        } else {
          const existingToast = document.querySelector('.obl-error-toast-inventory');
          if (existingToast) existingToast.remove();
          
          oblValidationMessage.textContent = '✅ All values are within OBL limit';
          unblockAllCurrentInputs();
          return true;
        }
      };

      const blockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-inventory:not([readonly])');
        
        currentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
      };

      const blockIncreasingCurrentInputs = (allowedInput?: HTMLInputElement): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-inventory:not([readonly])');
        
        currentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
        
        yearlyCurrentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
      };

      const unblockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([data-month="0"])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.yearly-current-input-inventory');
        
        currentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.style.backgroundColor = '';
          input.style.cursor = '';
          input.removeAttribute('data-block-increase');
          input.removeAttribute('readonly');
        });
      };

      const allowInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
        const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
        const isIncreasing = newValue > oldValue;
        
        if (!isIncreasing) {
          return true;
        }
        
        const oblValue = getNumericValue(oblLastMonthInput);
        const currentTotal = calculateTotalCurrentValue();
        const increaseAmount = newValue - oldValue;
        
        return (currentTotal + increaseAmount) <= oblValue;
      };

      const updateOBLValidationDisplay = (changedInput?: HTMLInputElement): void => {
        validateOBLLimit(changedInput);
      };

      // ========== FORECAST FORM FUNCTIONS ==========

      const onProjectChange = (projectId: number, existingForecast?: InventoryForecastItem): void => {
        const project = projects.find(p => p.Id === projectId);
        if (!project) return;

        toggleForecastSections(true);

        renderProjectDetails(project);
        
        let forecastData: ForecastData = {};
        if (existingForecast) {
          forecastData = safeJsonParse(existingForecast.ForecastData, {});
        }

        const isNewProject = !existingForecast;
        
        const oblContainer = document.querySelector('.obl-section-container-inventory') as HTMLElement;
        const fieldNote = oblContainer.querySelector('.field-note-inventory') as HTMLElement;
        
        if (isNewProject) {
          oblContainer.className = 'obl-section-container-inventory visible-section-inventory new-project-inventory';
          oblLastMonthInput.removeAttribute('readonly');
          oblLastMonthInput.placeholder = "Enter initial OBL for new project";
          if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
          oblValidationMessage.textContent = "Enter initial OBL value for new project";
          oblValidationMessage.className = 'validation-message-inventory';
          
          const defaultOBL = project.PC ? 100000 : 0;
          setNumericValue(oblLastMonthInput, defaultOBL);
        } else {
          oblContainer.className = 'obl-section-container-inventory visible-section-inventory existing-project-inventory';
          oblLastMonthInput.setAttribute('readonly', 'true');
          
          const oblValue = existingForecast?.OBL || 0;
          setNumericValue(oblLastMonthInput, oblValue);
          
          oblLastMonthInput.placeholder = "OBL value from database";
          if (fieldNote) fieldNote.textContent = "OBL value from database record";
          
          if (oblValue > 0) {
            oblLastMonthInput.value = oblValue.toString();
            oblLastMonthInput.className = oblLastMonthInput.className.replace('input-empty-inventory', 'input-with-value-inventory');
          }
        }

        renderForecastInterface(forecastData, getNumericValue(oblLastMonthInput), existingForecast);
      };

      const toggleForecastSections = (show: boolean): void => {
        const sections = [
          '.obl-section-container-inventory',
          '#historicalForecastSectionInventory',
          '#detailedForecastSectionInventory', 
          '#longtermForecastSectionInventory',
          '#yearlyForecastSectionInventory'
        ];
        
        sections.forEach(selector => {
          const element = document.querySelector(selector) as HTMLElement;
          if (element) {
            if (show) {
              element.classList.remove('hidden-section');
              element.classList.add('visible-section-inventory');
            } else {
              element.classList.remove('visible-section-inventory');
              element.classList.add('hidden-section');
            }
          }
        });
      };

      const renderProjectDetails = (project: ProjectItem): void => { 
        projectDetails.innerHTML =
          `<p><b>Profit Center:</b> ${project.PC || "-"}</p>
           <p><b>Customer:</b> ${project.CustomerName || "-"}</p>
           <p><b>Project Ref:</b> ${project.ProjectReference || "-"}</p>
           <p><b>Group Head:</b> ${project.GroupHead || "-"}</p>
           <p><b>Project Manager:</b> ${typeof project.ProjectManager === "object" ? project.ProjectManager?.Title : project.ProjectManager || "-"}</p>`;
      };

      const getForecastMonths = (): string[] => {
        return generateIdealMonthStructure();
      };

      const renderForecastInterface = (existingData: ForecastData, displayOBL: number, existingForecast?: InventoryForecastItem): void => {
        allMonths = getForecastMonths();
        
        setNumericValue(oblLastMonthInput, displayOBL);

        renderHistoricalMonths(allMonths.slice(0, 3), existingData);
        renderFirstRow(allMonths.slice(3, 6), existingData);
        renderRemainingMonths(allMonths.slice(6), existingData);
        renderYearlyForecast(existingData.yearly || createFreshYearlyStructure(getLastMonthKey(existingData)));

        protectHistoricalElements();
        
        updateOBLValidationDisplay();
        attachForecastEventListeners();
      };

      const protectHistoricalElements = (): void => {
        document.querySelectorAll('.historical-month-inventory input, .historical-month-inventory select, .historical-month-inventory button').forEach(element => {
          const newElement = element.cloneNode(true) as HTMLElement;
          element.parentNode?.replaceChild(newElement, element);
        });
        
        document.querySelectorAll('.historical-month-inventory').forEach(section => {
          section.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toast("warning", "Historical Inventory data cannot be modified");
            return false;
          });
          
          section.addEventListener('keydown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            return false;
          });
          
          section.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            return false;
          });
        });
      };

      const renderHistoricalMonths = (months: string[], existingData: ForecastData): void => {
        let html = '';

        months.forEach((monthKey, index) => {
          const monthDate = new Date(monthKey + "-01");
          const monthLabel = formatMonthLabel(monthDate);
          const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
          
          html += renderHistoricalMonthBox(monthKey, monthLabel, data, index);
        });

        historicalContainer.innerHTML = html;
      };

      const renderHistoricalMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, index: number): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        const actualInputClass = data.actual > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        
        return `
          <div class="month-box-inventory historical-month-inventory">
            <div class="month-header-inventory">${monthLabel} (Historical - Readonly)</div>
            
            <div class="month-block-inventory">
              <div class="main-inputs-container-inventory">
                <div class="main-input-group-inventory">
                  <label>Previous</label>
                  <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                        readonly class="main-plan-input-inventory ${planInputClass} number-input-inventory" />
                </div>
                <div class="main-input-group-inventory">
                  <label>Current</label>
                  <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                        readonly class="main-current-input-inventory ${actualInputClass} number-input-inventory" />
                </div>
              </div>
            </div>
          </div>
        `;
      };

      const renderFirstRow = (months: string[], existingData: ForecastData): void => {
        let html = '';

        html += `<div class="detailed-months-row-inventory">`;
        
        const currentMonth = months[0];
        if (currentMonth) {
          const monthDate = new Date(currentMonth + "-01");
          const monthLabel = formatMonthLabel(monthDate);
          const data = existingData[currentMonth] as ForecastMonthData || { plan: 0, actual: 0 };
          
          html += `<div class="current-month-container-inventory">`;
          html += renderDetailedMonthBox(currentMonth, monthLabel, data, true);
          html += `</div>`;
        }
        
        html += `<div class="next-months-container-inventory">`;
        for (let i = 1; i <= 2; i++) {
          if (i < months.length) {
            const monthKey = months[i];
            const monthDate = new Date(monthKey + "-01");
            const monthLabel = formatMonthLabel(monthDate);
            const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            
            html += `<div class="next-month-box-inventory">`;
            html += renderDetailedMonthBox(monthKey, monthLabel, data, false);
            html += `</div>`;
          }
        }
        html += `</div>`;
        
        html += `</div>`;

        firstRowContainer.innerHTML = html;
      };

      const renderRemainingMonths = (months: string[], existingData: ForecastData): void => {
        let html = '';

        for (let row = 0; row < 3; row++) {
          html += `<div class="remaining-row-inventory">`;
          for (let col = 0; col < 5; col++) {
            const index = (row * 5) + col;
            if (index >= months.length) break;
            
            const monthKey = months[index];
            const monthDate = new Date(monthKey + "-01");
            const monthLabel = formatMonthLabel(monthDate);
            const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            
            html += renderSimpleMonthBox(monthKey, monthLabel, data);
          }
          html += `</div>`;
        }

        remainingContainer.innerHTML = html;
      };

      const renderYearlyForecast = (yearlyData: YearlyForecastData): void => {
        let html = '';

        const years = Object.keys(yearlyData).sort();
        
        years.forEach(year => {
          const data = yearlyData[year] || { plan: 0, actual: 0 };
          html += renderYearlyBox(year, data);
        });

        yearlyContainer.innerHTML = html;
      };

      const renderYearlyBox = (year: string, data: { plan: number; actual: number }): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        const actualInputClass = data.actual > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        
        return `
          <div class="yearly-box-inventory">
            <div class="yearly-header-inventory">${year}</div>
            
            <div class="yearly-inputs-container-inventory">
              <div class="yearly-input-group-inventory">
                <label>Previous</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-year="${year}"
                      readonly class="yearly-plan-input-inventory ${planInputClass} number-input-inventory" />
              </div>
              <div class="yearly-input-group-inventory">
                <label>Current</label>
                <input type="text" value="${displayActualValue}" data-type="actual" data-year="${year}"
                      class="yearly-current-input-inventory ${actualInputClass} number-input-inventory" />
              </div>
            </div>
          </div>
        `;
      };

      const renderDetailedMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, isCurrentMonth: boolean = false): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const displayForecastValue = data.forecast || 0;
        const displayDateValue = data.date || '';
        
        const planInputClass = data.plan > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        const actualInputClass = data.actual > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        const forecastInputClass = displayForecastValue > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        const dateInputClass = displayDateValue ? 'input-with-value-inventory' : 'input-empty-inventory';
        
        return `
          <div class="detailed-month-box-inventory ${isCurrentMonth ? 'current-month-box-inventory' : 'next-month-box-inventory'}">
            <div class="month-header-inventory">
              ${monthLabel}
              ${isCurrentMonth ? '<span class="current-month-indicator-inventory">Current</span>' : ''}
            </div>
            
            <div class="month-block-inventory">
              <div class="enhanced-inputs-container-inventory">
                <div class="enhanced-input-group-inventory">
                  <label>Previous</label>
                  <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                        readonly class="main-plan-input-inventory ${planInputClass} number-input-inventory" />
                </div>
                
                <div class="enhanced-input-group-inventory">
                  <label>Current</label>
                  <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                        class="main-current-input-inventory ${actualInputClass} number-input-inventory" />
                </div>
                
                ${isCurrentMonth ? `
                  <div class="enhanced-input-group-inventory">
                    <label>Forecast</label>
                    <input type="text" value="${displayForecastValue}" data-type="forecast" data-month="${monthKey}"
                          class="main-forecast-input-inventory ${forecastInputClass} number-input-inventory" />
                  </div>
                  
                  <div class="enhanced-input-group-inventory">
                    <label>Date</label>
                    <input type="date" value="${displayDateValue}" data-type="date" data-month="${monthKey}"
                          class="forecast-date-input-inventory ${dateInputClass}" />
                  </div>
                ` : ''}
              </div>
            </div>
          </div>
        `;
      };

      const renderSimpleMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        const actualInputClass = data.actual > 0 ? 'input-with-value-inventory' : 'input-empty-inventory';
        
        return `
          <div class="month-box-inventory simple-month-inventory">
            <div class="month-header-inventory">${monthLabel}</div>
            
            <div class="main-inputs-container-inventory">
              <div class="main-input-group-inventory">
                <label>Previous</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}" 
                      readonly class="main-plan-input-inventory ${planInputClass} number-input-inventory" />
              </div>
              <div class="main-input-group-inventory">
                <label>Current</label>
                <input type="text" value="${displayActualValue}"  id="actualCurrent" data-type="actual" data-month="${monthKey}" 
                      class="main-current-input-inventory ${actualInputClass} number-input-inventory" />
              </div>
            </div>
          </div>
        `;
      };

      const attachForecastEventListeners = (): void => {
        document.querySelectorAll<HTMLInputElement>('.number-input-inventory').forEach(input => {
          allowOnlyNumbers(input);
        });

        document.querySelectorAll<HTMLInputElement>('.number-input-inventory:not([readonly])').forEach(input => {
          input.addEventListener('focus', function() {
            this.setAttribute('data-old-value', getNumericValue(this).toString());
          });
        });

        // Main current inputs
        document.querySelectorAll<HTMLInputElement>('.main-current-input-inventory:not([readonly])').forEach(input => {
          input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
              const allowByOBL = allowInputIncrease(this, currentValue);
              
              if (!allowByOBL) {
                setNumericValue(this, oldValue);
                updateOBLValidationDisplay(this);
                return;
              }
            }
            
            if (currentValue === 0) {
              this.className = this.className.replace('input-with-value-inventory', 'input-empty-inventory');
            } else {
              this.className = this.className.replace('input-empty-inventory', 'input-with-value-inventory');
            }

            updateOBLValidationDisplay(this);
          });
        });

        // Main forecast inputs
        document.querySelectorAll<HTMLInputElement>('.main-forecast-input-inventory:not([readonly])').forEach(input => {
          input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
              const allowByOBL = allowInputIncrease(this, currentValue);
              
              if (!allowByOBL) {
                setNumericValue(this, oldValue);
                updateOBLValidationDisplay(this);
                return;
              }
            }
            
            if (currentValue === 0) {
              this.className = this.className.replace('input-with-value-inventory', 'input-empty-inventory');
            } else {
              this.className = this.className.replace('input-empty-inventory', 'input-with-value-inventory');
            }

            updateOBLValidationDisplay(this);
          });
        });

        // Yearly current inputs
        document.querySelectorAll<HTMLInputElement>('.yearly-current-input-inventory:not([readonly])').forEach(input => {
          input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
              const allowByOBL = allowInputIncrease(this, currentValue);
              
              if (!allowByOBL) {
                setNumericValue(this, oldValue);
                updateOBLValidationDisplay(this);
                return;
              }
            }
            
            if (currentValue === 0) {
              this.className = this.className.replace('input-with-value-inventory', 'input-empty-inventory');
            } else {
              this.className = this.className.replace('input-empty-inventory', 'input-with-value-inventory');
            }

            updateOBLValidationDisplay(this);
          });
        });

        // Main date inputs
        document.querySelectorAll<HTMLInputElement>('.forecast-date-input-inventory:not([readonly])').forEach(input => {
          input.addEventListener('change', function() {
            if (this.value === '') {
              this.className = this.className.replace('input-with-value-inventory', 'input-empty-inventory');
            } else {
              this.className = this.className.replace('input-empty-inventory', 'input-with-value-inventory');
            }
          });
        });

        // Real-time OBL validation
        const validationInputs = document.querySelectorAll<HTMLInputElement>(`
          .main-current-input-inventory:not([readonly]),
          .yearly-current-input-inventory:not([readonly]),
          .main-forecast-input-inventory:not([readonly])
        `);

        validationInputs.forEach(input => {
          input.addEventListener('input', function() {
            setTimeout(() => {
              updateOBLValidationDisplay(this);
            }, 100);
          });
        });
      };

      const editForecast = async (id: number): Promise<void> => {
        editingId = id;
        const forecast = forecasts.find(f => f.Id === id);
        if (!forecast) {
          toast("error", "Inventory forecast not found");
          return;
        }

        showForm(true);
        
        let forecastData: ForecastData = {};
        
        try {
          let forecastDataString = forecast.ForecastData || "{}";
          forecastDataString = forecastDataString.trim();
          
          if (!forecastDataString || forecastDataString === '""' || forecastDataString === "null") {
            forecastDataString = "{}";
          }
          
          forecastData = JSON.parse(forecastDataString);
           
          
        } catch (e) { 
          
          forecastData = createFreshForecastStructure();
          
          toast("warning", "Corrupted Inventory forecast data detected. Loaded empty structure.");
        }
        
        forecastData = propagateMonthValues(forecastData);
        
        
         
        
        if (forecast.Project) {
          projectSelect.value = String(forecast.Project.Id);
          onProjectChange(forecast.Project.Id, forecast);
        }
        
        toast("info", `Editing Inventory forecast for ${forecast.Title}`);
      };

      // ========== FORM SUBMISSION ==========

      form.addEventListener("submit", async (e: Event) => {
        e.preventDefault();
        
        const projectId = parseInt(projectSelect.value);
        const project = projects.find(p => p.Id === projectId);
        
        if (!project) {
          toast("error", "Please select a project");
          return;
        }

        const isNewProject = !editingId && !forecasts.some(f => f.Project?.Id === projectId);
        
        if (!isNewProject && forecasts.some(f => f.Project?.Id === projectId && f.Id !== editingId)) {
          toast("error", "Inventory forecast already exists for this project!");
          return;
        }

        const oblValue = getNumericValue(oblLastMonthInput);
        if (isNewProject && oblValue === 0) {
          const confirmZeroOBL = await Swal.fire({
            icon: "question",
            title: "Zero OBL Value",
            text: "You're setting OBL to zero for a new project. This means there's no budget limit. Continue?",
            showCancelButton: true,
            confirmButtonText: "Yes, Continue",
            cancelButtonText: "No, Set OBL"
          });
          
          if (!confirmZeroOBL.isConfirmed) {
            oblLastMonthInput.focus();
            return;
          }
        }

        const totalCurrent = calculateTotalCurrentValue();
        
        if (oblValue > 0 && totalCurrent > oblValue) {
          toast("error", "Total current value cannot exceed OBL!");
          return;
        }

        try {
          const forecastData: ForecastData = {};

          const allStorageMonths = getAllMonthsForStorage(); 
          
          allStorageMonths.forEach(monthKey => {
            const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.main-current-input-inventory[data-month="${monthKey}"]`);
            const mainPlanInput = document.querySelector<HTMLInputElement>(`input.main-plan-input-inventory[data-month="${monthKey}"]`);
            const mainForecastInput = document.querySelector<HTMLInputElement>(`input.main-forecast-input-inventory[data-month="${monthKey}"]`);
            const mainDateInput = document.querySelector<HTMLInputElement>(`input.forecast-date-input-inventory[data-month="${monthKey}"]`);
            
            if (mainCurrentInput && mainPlanInput) {
              const monthData: ForecastMonthData = {
                plan: getNumericValue(mainPlanInput),
                actual: getNumericValue(mainCurrentInput)
              };

              if (mainForecastInput) {
                monthData.forecast = getNumericValue(mainForecastInput);
              }

              if (mainDateInput && mainDateInput.value) {
                monthData.date = mainDateInput.value;
              }

              forecastData[monthKey] = monthData;
            }
          });

          const yearlyData: YearlyForecastData = {};
          const yearlyPlanInputs = document.querySelectorAll<HTMLInputElement>('.yearly-plan-input-inventory');
          
          if (yearlyPlanInputs.length > 0) {
            const years = new Set<string>();
            yearlyPlanInputs.forEach(input => {
              const year = input.dataset.year;
              if (year) years.add(year);
            });
            
            Array.from(years).sort().forEach(year => {
              const planInput = document.querySelector<HTMLInputElement>(`input.yearly-plan-input-inventory[data-year="${year}"]`);
              const currentInput = document.querySelector<HTMLInputElement>(`input.yearly-current-input-inventory[data-year="${year}"]`);
              
              if (planInput && currentInput) {
                yearlyData[year] = {
                  plan: getNumericValue(planInput),
                  actual: getNumericValue(currentInput)
                };
              }
            });
            
            forecastData.yearly = yearlyData;
          }

          const propagatedData = propagateCollectionValues(forecastData);
          const digest = await getDigest();
          
          const payload: any = {
             __metadata: { type: "SP.Data.InventoryListItem" },
                Title: generateForecastTitle(project, propagatedData),
                ProjectId: project.Id,
                ProfitCentre: project.PC || "",
                ForecastData: JSON.stringify(propagatedData),
                UpdatedDate: new Date().toISOString()
              };

              // Ensure OBL is properly handled
              if (!editingId && isNewProject) {
                const oblValueToSave = getNumericValue(oblLastMonthInput);
                payload.OBL = oblValueToSave; // This should be a number, which is correct for number fields
              }

              // For new items, ensure CreatedDate is properly formatted
              if (!editingId) {
                payload.CreatedDate = new Date().toISOString();
              }
 
          const url = editingId 
            ? `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${editingId})`
            : `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;
          
          const headers: any = {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest
          };
          
          if (editingId) {
            headers["IF-MATCH"] = "*";
            headers["X-HTTP-Method"] = "MERGE";
          }

          const res = await fetch(url, { 
            method: "POST", 
            headers, 
            body: JSON.stringify(payload) 
          });
          
          if (res.ok) {
            toast("success", editingId ? "Inventory Forecast Updated!" : "Inventory Forecast Added!");
            await loadForecasts();
            initializePagination(forecasts);
            hideForm();
            resetForm();
          } else {
            const errorText = await res.text();
            console.error("SharePoint Error:", errorText);
            toast("error", `Error saving Inventory forecast: ${res.status}`);
          }
        } catch (error) {
          console.error("Error saving Inventory forecast:", error);
          toast("error", "Error saving Inventory forecast!");
        }
      });

      const propagateCollectionValues = (forecastData: ForecastData): ForecastData => {
        const updatedData: ForecastData = { ...forecastData };
        
        if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) {
          const longTermMonths = generateIdealMonthStructure().slice(6);
          const lastMonthKey = longTermMonths[longTermMonths.length - 1];
          updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
        }

        const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
        const idealMonths = generateIdealMonthStructure();
        const isNewMonth = originalMonths[0] !== idealMonths[0];
         
        const monthlyProgressed = propagateMonthValues(updatedData);
        const yearlyProgressed = propagateYearlyValues(monthlyProgressed, isNewMonth); 
        return yearlyProgressed;
      };

      const propagateYearlyValues = (forecastData: ForecastData, isNewMonth: boolean = false): ForecastData => {
        if (!isNewMonth) { 
          return forecastData;
        }

        const updatedData: ForecastData = { ...forecastData };
        
        if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) { 
          return updatedData;
        }

        const yearlyData = updatedData.yearly; 
        const updatedYearlyData: YearlyForecastData = {};

        Object.keys(yearlyData).forEach(year => {
          const yearData = yearlyData[year];
          if (yearData) {
            updatedYearlyData[year] = {
              plan: yearData.actual,
              actual: 0,
            };
          }
        });

        updatedData.yearly = updatedYearlyData; 
        return updatedData;
      };

const initializeFilters = (): void => {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  
  // Year filter - always show all years
  filterYear.innerHTML = '<option value="">All Years</option>';
  for (let year = currentYear - 1; year <= currentYear + 2; year++) {
    const selected = year === currentYear ? 'selected' : '';
    filterYear.innerHTML += `<option value="${year}" ${selected}>${year}</option>`;
  }
  
  // Month filter - always show all months
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  filterMonth.innerHTML = '<option value="">All Months</option>';
  for (let month = 1; month <= 12; month++) {
    const selected = month === currentMonth ? 'selected' : '';
    filterMonth.innerHTML += `<option value="${month}" ${selected}>${monthNames[month - 1]}</option>`;
  }

  // Get accessible forecasts based on role
  // const accessibleForecasts = filterDataByRole(forecasts);
  
  // Get accessible projects based on role
  let accessibleProjects: ProjectItem[] = [];
  
  if (currentUser.isSuperAdmin) {
    // Super Admin: All projects
    accessibleProjects = [...projects];
  } else if (currentUser.isGroupHead) {
    // Group Head: Projects in their groups
    accessibleProjects = projects.filter(p => 
      currentUser.managedGroups?.some(group => p.GroupHead === group)
    );
  } else if (currentUser.isProjectManager) {
    // Project Manager: Their own projects
    accessibleProjects = projects.filter(p => {
      const managerName = typeof p.ProjectManager === 'object' 
        ? p.ProjectManager?.Title 
        : p.ProjectManager;
      return managerName === currentUser.displayName;
    });
  }

  // Project filter - only accessible projects
  const accessibleProjectTitles = accessibleProjects.map(p => p.Title).filter(Boolean);
  filterProject.innerHTML = '<option value="">All Projects</option>' + 
    [...new Set(accessibleProjectTitles)]
      .sort()
      .map(project => `<option value="${project}">${project}</option>`)
      .join("");

  // Customer filter - only from accessible projects
  const accessibleCustomers = accessibleProjects
    .map(p => p.CustomerName)
    .filter((customer): customer is string => !!customer);
    
  filterCustomer.innerHTML = '<option value="">All Customers</option>' + 
    [...new Set(accessibleCustomers)]
      .sort()
      .map(customer => `<option value="${customer}">${customer}</option>`)
      .join("");

  // Helper function to extract manager name
  const getManagerName = (project: ProjectItem): string | undefined => {
    if (!project.ProjectManager) return undefined;
    
    if (typeof project.ProjectManager === 'string') {
      return project.ProjectManager;
    }
    
    return project.ProjectManager.Title;
  };
  
  // Project Manager filter - based on role
  let accessibleManagers: string[] = [];
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all managers from accessible projects
    accessibleManagers = accessibleProjects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isGroupHead) {
    // Group Head sees managers in their groups
    accessibleManagers = accessibleProjects
      .map(getManagerName)
      .filter((manager): manager is string => !!manager);
  } else if (currentUser.isProjectManager) {
    // Project Manager sees only themselves
    accessibleManagers = [currentUser.displayName];
  }
  
  filterProjectManager.innerHTML = '<option value="">All Managers</option>' + 
    [...new Set(accessibleManagers)]
      .sort()
      .map(manager => `<option value="${manager}">${manager}</option>`)
      .join("");

  // Group Head filter - based on role
  let accessibleGroupHeads: string[] = [];
  
  if (currentUser.isSuperAdmin) {
    // Super Admin sees all group heads from accessible projects
    accessibleGroupHeads = accessibleProjects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  } else if (currentUser.isGroupHead) {
    // Group Head sees only themselves
    accessibleGroupHeads = [currentUser.displayName];
  } else if (currentUser.isProjectManager) {
    // Project Manager sees group heads of their projects
    accessibleGroupHeads = accessibleProjects
      .map(p => p.GroupHead)
      .filter((head): head is string => !!head);
  }
  
  filterGroupHead.innerHTML = '<option value="">All Group Heads</option>' + 
    [...new Set(accessibleGroupHeads)]
      .sort()
      .map(head => `<option value="${head}">${head}</option>`)
      .join("");

  // Project Reference filter - only from accessible projects
  const accessibleReferences = accessibleProjects
    .map(p => p.ProjectReference)
    .filter((ref): ref is string => !!ref);
    
  filterProjectReference.innerHTML = '<option value="">All References</option>' + 
    [...new Set(accessibleReferences)]
      .sort()
      .map(ref => `<option value="${ref}">${ref}</option>`)
      .join("");
};

const filterTable = (): void => {
  const year = filterYear.value;
  const month = filterMonth.value;
  const project = filterProject.value;
  const customer = filterCustomer.value;
  const projectManager = filterProjectManager.value;
  const groupHead = filterGroupHead.value;
  const projectReference = filterProjectReference.value;
  
  // Start with ALL forecasts (not role-filtered yet)
  let filtered = [...forecasts];

  // Apply user's filters first
  filtered = filtered.filter(forecast => {
    if (year && month) {
      const monthKey = `${year}-${month.padStart(2, "0")}`;
      const data: ForecastData = safeJsonParse(forecast.ForecastData, {});
      if (!(monthKey in data)) return false;
    }
    
    if (project && forecast.Project?.Title !== project) return false;
    
    if (customer) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.CustomerName !== customer) return false;
    }
    
    if (projectManager) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      const managerName = typeof proj?.ProjectManager === 'object' ? proj.ProjectManager?.Title : proj?.ProjectManager;
      if (managerName !== projectManager) return false;
    }
    
    if (groupHead) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.GroupHead !== groupHead) return false;
    }
    
    if (projectReference) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.ProjectReference !== projectReference) return false;
    }
    
    return true;
  });
  
  // Apply role-based filtering LAST
  filtered = filterDataByRole(filtered);
  
  if (filtered.length === 0) {
    const noDataMessage = currentUser.isSuperAdmin 
      ? 'No Inventory records found for selected filters' 
      : currentUser.isGroupHead 
        ? 'No Inventory records found in your groups for selected filters'
        : currentUser.isProjectManager
          ? 'No assigned Inventory projects found for selected filters'
          : 'No access to view any Inventory records';
    
    tableBody.innerHTML = `<tr><td colspan="20" style="text-align:center;padding:20px;">${noDataMessage}</td></tr>`;
    
    const totalsHeader = document.querySelector("#totalsHeaderInventory") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = '';
    
    // Initialize pagination with empty data
    filteredData = [];
    totalPages = 1;
    currentPage = 1;
    updatePaginationControls();
    
  } else {
    // Initialize pagination with filtered data
    initializePagination(filtered);
    
    const displayMonths = getDisplayMonths();
    const currentMonthKey = formatMonthKey(new Date());
    setTimeout(() => {
      renderTotalsHeader(displayMonths, currentMonthKey);
    }, 100);
  }
};

      // ========== AUTO PROGRESSION FUNCTIONS ==========

      const applyAutoProgression = async (): Promise<void> => { 
        
        if (forecasts.length === 0) { 
          return;
        }

        const digest = await getDigest();
        let progressedCount = 0;
        let errorCount = 0;
        
        for (const forecast of forecasts) {
          try {
            if (!forecast.ForecastData) { 
              continue;
            }
            
            const originalData = safeJsonParse(forecast.ForecastData, {});
            
            if (checkIfNeedsProgression(originalData)) { 
              
              const progressedData = propagateCollectionValues(originalData);
              
              const payload = {
                __metadata: { type: "SP.Data.InventoryListItem" },
                ForecastData: JSON.stringify(progressedData),
                UpdatedDate: new Date().toISOString()
              };
              
              const response = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`, {
                method: "POST",
                headers: {
                  Accept: "application/json;odata=verbose",
                  "Content-Type": "application/json;odata=verbose",
                  "X-RequestDigest": digest,
                  "IF-MATCH": "*",
                  "X-HTTP-Method": "MERGE"
                },
                body: JSON.stringify(payload)
              });
              
              if (response.ok) {
                progressedCount++; 
              } else {
                errorCount++; 
              }
              
              await new Promise(resolve => setTimeout(resolve, 100));
            } else { 
            }
          } catch (error) {
            errorCount++; 
          }
        }
        
        if (progressedCount > 0) { 
          await loadForecasts();
          toast("success", `Monthly and yearly data progressed for ${progressedCount} Inventory forecasts`);
        } else if (errorCount > 0) { 
          toast("warning", `Some errors occurred during Inventory monthly and yearly progression`);
        } else { 
        }
      };

      const checkIfNeedsProgression = (forecastData: ForecastData): boolean => {
        const months = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
        
        if (months.length === 0) return true;

        const idealMonths = generateIdealMonthStructure();
        const firstIdealMonth = idealMonths[0];
        const firstDataMonth = months[0];
        
        const monthlyProgressionNeeded = firstDataMonth !== firstIdealMonth;
        
        const currentYear = new Date().getFullYear();
        let yearlyProgressionNeeded = false;
        
        if (forecastData.yearly) {
          const years = Object.keys(forecastData.yearly).map(y => parseInt(y)).sort();
          yearlyProgressionNeeded = years.length > 0 && years[0] < currentYear;
        } else {
          yearlyProgressionNeeded = true;
        }
       
        
        return monthlyProgressionNeeded || yearlyProgressionNeeded;
      };

const initialize = async (): Promise<void> => {
  try {
    currentUser = await getUserContext();
    await loadProjects();
    await loadForecasts();
    
    if (forecasts.length > 0) { 
      await applyAutoProgression();
    }
    
    initializeFilters(); // This now includes role-based filtering
    initializePagination(forecasts);
    updateUIForRole();
    
    // Filter project select dropdown by role
    filterProjectSelectByRole();
    
  } catch (error) { 
    console.error("Error initializing Inventory:", error);
    toast("error", "Failed to initialize Inventory application");
  }
};

      // ========== IMPORT ACTUAL DATA FUNCTION ==========

      const importActualData = (): void => { 

        const modalHTML = `
          <div class="import-modal-inventory">
            <div class="import-modal-content-inventory">
              <div class="import-modal-header-inventory">
                <h3>Import Monthly Actual Inventory Data</h3>
                <button class="close-modal-inventory">&times;</button>
              </div>

              <div class="import-section-inventory">
                <h4>Step 1: Download Template</h4>
                <button class="btn-primary-inventory" id="downloadTemplateInventory">⬇️ Download Template</button>
              </div>

              <div class="import-section-inventory">
                <h4>Step 2: Upload Excel File</h4>
                <div class="file-upload-area-inventory" id="fileUploadAreaInventory">
                  <div class="upload-icon-inventory">📁</div>
                  <p>Click to upload or drag & drop Excel file</p>
                  <p><small>Supported format: Excel with Project Reference, Month, and Actual Inventory columns</small></p>
                  <input type="file" id="excelFileInventory" class="file-input-inventory" accept=".xlsx,.xls">
                  <div class="file-info-inventory" id="fileInfoInventory"></div>
                </div>
              </div>

              <div class="import-section-inventory" id="previewSectionInventory" style="display:none;">
                <h4>Step 3: Preview & Import</h4>
                <div class="import-preview-inventory" id="importPreviewInventory"></div>
                <div class="import-actions-inventory">
                  <button class="btn-secondary-inventory" id="cancelImportInventory">Cancel</button>
                  <button class="btn-primary-inventory" id="confirmImportInventory">Import Inventory Data</button>
                </div>
                <div class="import-status-inventory" id="importStatusInventory"></div>
              </div>
            </div>
          </div>
        `;

        document.body.insertAdjacentHTML("beforeend", modalHTML);
        const modal = document.querySelector(".import-modal-inventory") as HTMLElement;
        modal.style.display = "flex";

        // Elements
        const fileUploadArea = document.querySelector("#fileUploadAreaInventory") as HTMLElement;
        const excelFileInput = document.querySelector("#excelFileInventory") as HTMLInputElement;
        const fileInfo = document.querySelector("#fileInfoInventory") as HTMLElement;
        const previewSection = document.querySelector("#previewSectionInventory") as HTMLElement;
        const importPreview = document.querySelector("#importPreviewInventory") as HTMLElement;
        const confirmImport = document.querySelector("#confirmImportInventory") as HTMLButtonElement;
        const cancelImport = document.querySelector("#cancelImportInventory") as HTMLButtonElement;
        const closeModal = document.querySelector(".close-modal-inventory") as HTMLButtonElement;
        const importStatus = document.querySelector("#importStatusInventory") as HTMLElement;
        const downloadTemplateBtn = document.querySelector("#downloadTemplateInventory") as HTMLButtonElement;

        let importData: any[] = [];
        let listEntityType: string = "";

        const monthMap: { [key: string]: number } = {
          'jan': 1, 'january': 1, 'jan-': 1,
          'feb': 2, 'february': 2, 'feb-': 2,
          'mar': 3, 'march': 3, 'mar-': 3,
          'apr': 4, 'april': 4, 'apr-': 4,
          'may': 5, 'may-': 5,
          'jun': 6, 'june': 6, 'jun-': 6,
          'jul': 7, 'july': 7, 'jul-': 7,
          'aug': 8, 'august': 8, 'aug-': 8,
          'sep': 9, 'september': 9, 'sep-': 9,
          'oct': 10, 'october': 10, 'oct-': 10,
          'nov': 11, 'november': 11, 'nov-': 11,
          'dec': 12, 'december': 12, 'dec-': 12
        };

        const parseMonth = (monthStr: string): string => {
          if (!monthStr) return '';
          
          if (/^\d{4}-\d{2}$/.test(monthStr)) {
            return monthStr;
          }
          
          const match = monthStr.toLowerCase().match(/([a-z]+)[-\s]*'?(\d{2,4})?/);
          if (match) {
            const monthName = match[1];
            let year = match[2];
            
            const monthNum = monthMap[monthName];
            if (monthNum) {
              if (!year) {
                year = new Date().getFullYear().toString();
              } else if (year.length === 2) {
                const currentYear = new Date().getFullYear();
                const century = Math.floor(currentYear / 100) * 100;
                const yearNum = parseInt(year);
                year = (century + yearNum).toString();
              }
              
              return `${year}-${monthNum.toString().padStart(2, '0')}`;
            }
          }
          
          return '';
        };

        const getListEntityType = async (): Promise<string> => {
          if (listEntityType) return listEntityType;
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`, {
            headers: { Accept: "application/json;odata=verbose" },
          });
          const data = await res.json();
          listEntityType = data.d.ListItemEntityTypeFullName; 
          return listEntityType;
        };

        const updateInventoryData = (existingData: string, month: string, actualInventory: number): string => {
          let finalData: { [key: string]: number } = {};
          
          if (existingData && existingData.trim() !== '' && existingData !== '{}' && existingData !== 'null' && existingData !== 'undefined') {
            try {
              const parsed = JSON.parse(existingData);
               finalData = { ...parsed };
            } catch (parseError) {
               finalData = {};
            }
          } else {
            finalData = {};
          }
          
          finalData[month] = actualInventory;
           const getFourMonthWindow = (): string[] => {
            const currentDate = new Date();
            const validMonths: string[] = [];
            
            for (let i = 0; i < 4; i++) {
              const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
              const yearStr = date.getFullYear();
              const monthStr = (date.getMonth() + 1).toString().padStart(2, '0');
              validMonths.push(`${yearStr}-${monthStr}`);
            }
            
            return validMonths.sort().reverse();
          };
          
          const fourMonthWindow = getFourMonthWindow();
           const resultData: { [key: string]: number } = {};
          
          fourMonthWindow.forEach(monthKey => {
            resultData[monthKey] = finalData[monthKey] !== undefined ? finalData[monthKey] : 0;
          });
           
          return JSON.stringify(resultData);
        };

        // File Upload Handling
        fileUploadArea.addEventListener("click", () => excelFileInput.click());
        fileUploadArea.addEventListener("dragover", (e) => {
          e.preventDefault();
          fileUploadArea.classList.add("dragover-inventory");
        });
        fileUploadArea.addEventListener("dragleave", () => fileUploadArea.classList.remove("dragover-inventory"));
        fileUploadArea.addEventListener("drop", (e) => {
          e.preventDefault();
          fileUploadArea.classList.remove("dragover-inventory");
          const files = e.dataTransfer?.files;
          if (files && files[0]) {
            excelFileInput.files = files;
            handleFileSelection(files[0]);
          }
        });
        excelFileInput.addEventListener("change", (e) => {
          const files = (e.target as HTMLInputElement).files;
          if (files && files[0]) handleFileSelection(files[0]);
        });

        const handleFileSelection = async (file: File) => {
           
          if (!file.name.toLowerCase().match(/\.(xlsx|xls)$/)) {
            toast("error", "Please select an Excel file (.xlsx or .xls)");
            return;
          }

          fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`;

          try {
            const parsedData = await parseExcelFile(file);
            
            if (validateImportData(parsedData)) {
               importData = parsedData;
              showImportPreview(parsedData);
              previewSection.style.display = "block";
              previewSection.style.opacity = "1";
              } else {
               toast("error", "Invalid Excel format. Please check the required columns.");
            }
          } catch (error) {
              toast("error", "Error reading Inventory Excel file");
          }
        };

        const parseExcelFile = (file: File): Promise<any[]> => {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
              try {
                const data = new Uint8Array(e.target?.result as ArrayBuffer);
                const workbook = XLSX.read(data, { type: "array" });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
         
                if (jsonData.length < 2) {
                   return resolve([]);
                }

                const headers = jsonData[0] as string[];
                 const rows: any[] = [];

                for (let i = 1; i < jsonData.length; i++) {
                  const rowData = jsonData[i] as any[];
                  if (!rowData || rowData.length === 0) continue;

                  const row: any = {};
                  
                  headers.forEach((header, idx) => {
                    if (header && rowData[idx] !== undefined && rowData[idx] !== null) {
                      row[header.trim()] = rowData[idx];
                    }
                  });

         
                  if (row["Month"] || row["month"]) {
                    let monthValue = row["Month"] || row["month"];
                    
                    if (typeof monthValue === "number") {
                      const excelDate = new Date(Math.round((monthValue - 25569) * 86400 * 1000));
                      const yyyy = excelDate.getFullYear();
                      const mm = String(excelDate.getMonth() + 1).padStart(2, "0");
                      monthValue = `${yyyy}-${mm}`;
                    }

                    const monthStr = monthValue.toString();
                    row.parsedMonth = parseMonth(monthStr);
                  }

                  const hasProjectRef = row["Project Reference"] || row["project_reference"];
                  const hasMonth = row.parsedMonth;
                  
                  if (hasProjectRef && hasMonth) {
                    rows.push(row);
                   } else {
                   }
                }

                 resolve(rows);
              } catch (err) {
                 reject(err);
              }
            };
            reader.onerror = (error) => {
               reject(new Error("Failed to read Inventory file"));
            };
            reader.readAsArrayBuffer(file);
          });
        };

        const validateImportData = (data: any[]): boolean => {
           
          if (data.length === 0) {
             return false;
          }
   const first = data[0];
          const keys = Object.keys(first).map(k => k.toLowerCase());
          
          
          const hasProjectRef = keys.some(k => k.includes('project') && k.includes('reference'));
          const hasMonth = keys.some(k => k.includes('month'));
          

          return hasProjectRef && hasMonth;
        };

        const showImportPreview = (data: any[]) => {
           
          const monthSummary: { [key: string]: number } = {};
          
          data.forEach(row => {
            const month = row.parsedMonth;
            if (month) {
              monthSummary[month] = (monthSummary[month] || 0) + 1;
            }
          });

          const monthSummaryText = Object.keys(monthSummary)
            .map(month => {
              return `${month}: ${monthSummary[month]} records`;
            })
            .join(', ');

          const previewHTML = `
            <div style="padding: 20px; background: #f8f9fa; border-radius: 8px;">
              <h4 style="color: #28a745; margin-bottom: 15px;">✅ Inventory File Ready for Import</h4>
              <p><strong>Found ${data.length} Inventory records to import:</strong></p>
              <p><strong>Month Summary:</strong> ${monthSummaryText || 'No months found'}</p>
              <div class="preview-table-container-inventory" style="max-height: 400px; overflow-y: auto;">
                <table class="preview-table-inventory" style="width: 100%; border-collapse: collapse;">
                  <thead style="background: #007bff; color: white;">
                    <tr>
                      <th style="padding: 10px; border: 1px solid #ddd;">Project Reference</th>
                      <th style="padding: 10px; border: 1px solid #ddd;">Month</th>
                      <th style="padding: 10px; border: 1px solid #ddd;">Actual Inventory</th>
                      <th style="padding: 10px; border: 1px solid #ddd;">Project Match</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${data
                      .slice(0, 10)
                      .map((row, index) => {
                        const projectRef = row["Project Reference"] || row["project_reference"] || 'N/A';
                        const month = row["Month"] || row["month"] || 'N/A';
                        const actualInventory = row["Actual Inventory"] || row["actual_inventory"] || row["Actual"] || row["actual"] || '0';
                        const project = projects.find((p) => p.ProjectReference === projectRef);
                        
                        return `
                          <tr style="${index % 2 === 0 ? 'background: #f8f9fa;' : 'background: white;'}">
                            <td style="padding: 8px; border: 1px solid #ddd;">${projectRef}</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">${month} (${row.parsedMonth || 'Invalid'})</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">${actualInventory}</td>
                            <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${project ? "✅" : "❌"}</td>
                          </tr>
                        `;
                      })
                      .join("")}
                  </tbody>
                </table>
              </div>
              ${data.length > 10 ? `<p style="margin-top: 10px; font-style: italic;">... and ${data.length - 10} more Inventory records</p>` : ''}
              <div style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 5px;">
                <p style="margin: 0; color: #0056b3;"><strong>Ready to import Inventory data?</strong> Click the "Import Inventory Data" button below.</p>
                <p style="margin: 5px 0 0 0; font-size: 12px;"><strong>Note:</strong> Only the imported month will be updated, all other Inventory data preserved</p>
              </div>
            </div>`;
          
          importPreview.innerHTML = previewHTML; 
        };

        const performImport = async () => {
          confirmImport.disabled = true;
          confirmImport.textContent = "Importing Inventory...";
          importStatus.style.display = "block";
          importStatus.textContent = "Updating Inventory Data...";

          let success = 0, error = 0, notFound = 0, invalidMonth = 0, skipped = 0;
          const entityType = await getListEntityType();
 
          for (const row of importData) {
            const projectRef = row["Project Reference"] || row["project_reference"];
            const month = row.parsedMonth;
            const actualInventory = parseFloat(
              row["Actual Inventory"] || row["actual_inventory"] || row["Actual"] || row["actual"] || 0
            );
 
            if (!month) { 
              invalidMonth++;
              continue;
            }

            const project = projects.find((p) => p.ProjectReference === projectRef);
            if (!project) { 
              notFound++;
              continue;
            }

            const forecast = forecasts.find((f) => f.Project?.Title === project.Title);
            if (!forecast?.Id) { 
              notFound++;
              continue;
            }

            try {
              const digest = await getDigest();
 
              const currentForecastResponse = await fetch(
                `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})?$select=Id,InventoryActual`,
                {
                  method: "GET",
                  headers: { 
                    Accept: "application/json;odata=verbose",
                  },
                }
              );
              
              if (!currentForecastResponse.ok) {
                throw new Error(`Failed to fetch current Inventory data: ${currentForecastResponse.status}`);
              }
              
              const currentData = await currentForecastResponse.json();
              const currentInventoryData = currentData.d.InventoryActual || "{}";
              
            
              const updatedInventoryData = updateInventoryData(currentInventoryData, month, actualInventory);
             
              

              const payload = {
                __metadata: { type: entityType },
                InventoryActual: updatedInventoryData,
                UpdatedDate: new Date().toISOString(),
              };

             
              const res = await fetch(
                `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`,
                {
                  method: "POST",
                  headers: {
                    Accept: "application/json;odata=verbose",
                    "Content-Type": "application/json;odata=verbose",
                    "X-RequestDigest": digest,
                    "IF-MATCH": "*",
                    "X-HTTP-Method": "MERGE",
                  },
                  body: JSON.stringify(payload),
                }
              );

              if (res.ok) {
              } else {
                error++;
                const text = await res.text();
                console.warn(`⚠️ Failed for Inventory ${projectRef} (${month}):`, text);
              }

              await new Promise((r) => setTimeout(r, 100));
            } catch (err) {
              error++;
              console.error(`❌ Error updating Inventory ${projectRef} (${month}):`, err);
            }
          }

          skipped = importData.length - (success + error + notFound + invalidMonth);
  
          importStatus.className = "import-status-inventory success-inventory";
          importStatus.innerHTML = `
            <strong>Inventory Import Complete!</strong><br>
            ✅ Success: ${success} Inventory records imported<br>
            ❌ Errors: ${error} Inventory records<br>
            🔍 Project Not Found: ${notFound} Inventory records<br>
            📅 Invalid Month: ${invalidMonth} Inventory records<br>
            ⏭️ Skipped: ${skipped} Inventory records<br>
            <small>Only the imported month was updated, all other Inventory data preserved</small>
          `;

          await loadForecasts();
          initializePagination(forecasts);

          confirmImport.disabled = false;
          confirmImport.textContent = "Import Inventory Data";
        };

        downloadTemplateBtn.addEventListener("click", () => {
          if (!projects || projects.length === 0) {
            toast("error", "No projects available to create Inventory template");
            return;
          }

          const wsData = [["Project Reference", "Month", "Actual Inventory"]];
          
          projects.forEach((p) => {
            wsData.push([p.ProjectReference || "", "", ""]);
          });

          const ws = XLSX.utils.aoa_to_sheet(wsData);
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "Inventory Template");

          const fileName = `Inventory_Import_Template.xlsx`;

          XLSX.writeFile(wb, fileName);
        });

        const closeModalHandler = () => modal.remove();
        closeModal.addEventListener("click", closeModalHandler);
        cancelImport.addEventListener("click", closeModalHandler);
        modal.addEventListener("click", (e) => {
          if (e.target === modal) closeModalHandler();
        });

        confirmImport.addEventListener("click", performImport);
      };        
   
      
      // ========== EVENT LISTENERS ==========

      showFormBtn.addEventListener("click", () => {
        resetForm();
        showForm(false);
      });       
              
      backBtn.addEventListener("click", hideForm);
      
projectSelect.addEventListener("change", (e) => {
  if (editingId) {
    toast("warning", "Cannot change project in Inventory edit mode");
    const forecast = forecasts.find(f => f.Id === editingId);
    if (forecast?.Project) {
      projectSelect.value = String(forecast.Project.Id);
    }
    return;
  }

  const projectId = parseInt((e.target as HTMLSelectElement).value);
  if (projectId) {
    const project = projects.find(p => p.Id === projectId);
    if (project) {
      // Check if user has access to this project
      if (!currentUser.isSuperAdmin) {
        let hasAccess = false;
        
        if (currentUser.isGroupHead) {
          hasAccess = currentUser.managedGroups?.some(group => 
            project.GroupHead === group
          ) || false;
        } else if (currentUser.isProjectManager) {
          const managerName = typeof project.ProjectManager === 'object' 
            ? project.ProjectManager?.Title 
            : project.ProjectManager;
          hasAccess = managerName === currentUser.displayName;
        }
        
        if (!hasAccess) {
          toast("error", "You don't have access to this project");
          projectSelect.value = "";
          return;
        }
      }
      
      const existingForecast = forecasts.find(f => f.Project?.Id === projectId);
      if (existingForecast && !editingId) {
        Swal.fire({
          icon: "question",
          title: "Existing Inventory Forecast Found",
          text: `An Inventory forecast already exists for ${project.Title}. Would you like to edit it?`,
          showCancelButton: true,
          confirmButtonText: "Yes, Edit",
          cancelButtonText: "No, Create New"
        }).then((result) => {
          if (result.isConfirmed) {
            editingId = existingForecast.Id;
            showForm(true);
            onProjectChange(projectId, existingForecast);
          } else {
            onProjectChange(projectId);
          }
        });
      } else {
        onProjectChange(projectId, existingForecast);
      }
    }
  }
});

      // Pagination event listeners
      firstPageBtn.addEventListener("click", () => goToPage(1));
      prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
      nextPageBtn.addEventListener("click", () => goToPage(currentPage + 1));
      lastPageBtn.addEventListener("click", () => goToPage(totalPages));

      // Filter event listeners
      filterYear.addEventListener("change", filterTable);
      filterMonth.addEventListener("change", filterTable);
      filterProject.addEventListener("change", filterTable);
      filterCustomer.addEventListener("change", filterTable);
      filterProjectManager.addEventListener("change", filterTable);
      filterGroupHead.addEventListener("change", filterTable);
      filterProjectReference.addEventListener("change", filterTable);

      // Action button event listeners
      exportBtn.addEventListener("click", exportToExcelWithFullStyle); 
      clearFiltersBtn.addEventListener("click", clearFilters);
      importActualBtn.addEventListener("click", importActualData);

      // Initialize the application
      initialize();
    }, 100);
  }
};