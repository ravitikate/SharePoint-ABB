console.log("Footer loaded");
