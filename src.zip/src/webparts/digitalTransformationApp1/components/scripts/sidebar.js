console.log("Sidebar loaded");
