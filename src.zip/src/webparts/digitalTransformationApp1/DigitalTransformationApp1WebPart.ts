// src/webparts/digitalTransformationApp1/DigitalTransformationApp1WebPart.ts

import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';

import sidebarModule, { getSidebarContent } from './components/Sidebar';
import headerModule from './components/Header';
import footerModule from './components/Footer';
import dashboardPage from './components/pages/dashboard';
import projectPage from './components/pages/project'; 
import dciPage from './components/pages/dci';
import bomPage from './components/pages/bom';
import procurementPage from './components/pages/procurement';
import revenuePage from './components/pages/revenue';
import collectionPage from './components/pages/collection';
import knowledgePage from './components/pages/knowledge';
import invoicingPage from './components/pages/invoicing';
import inventoryPage from './components/pages/inventory';
import seibiesPage from './components/pages/seibies';
import masterPage from './components/pages/master';

interface IPageModule {
  content: string;
  style?: string;
  script?: () => void;
}

const pages: { [key: string]: IPageModule } = {
  dashboard: dashboardPage,
  master: masterPage,
  project: projectPage, 
  dci: dciPage,
  bom: bomPage,
  procurement: procurementPage,
  revenue: revenuePage,
  collection: collectionPage,
  knowledge: knowledgePage,
  invoicing: invoicingPage,
  inventory: inventoryPage,
  seibies: seibiesPage
};

export interface IDigitalTransformationApp1WebPartProps {
  page: string;
}

export default class DigitalTransformationApp1WebPart extends BaseClientSideWebPart<IDigitalTransformationApp1WebPartProps> {

  public async render(): Promise<void> {
    /** HIDE EVERYTHING FROM SHAREPOINT (FULL APP MODE) */
    this.hideSharePointUI();

    /** Get dynamic sidebar content based on user role */
    const sidebarHtml = await getSidebarContent(this.context);

    /** MAIN HTML */
    this.domElement.innerHTML = `
      <div class="dt-app">
        <header class="dt-header">${headerModule.content}</header>
        <div class="dt-main">
          <aside class="dt-sidebar">${sidebarHtml}</aside>
          <main class="dt-body">Welcome to Digital Transformation</main>
        </div>
        <footer class="dt-footer">${footerModule.content}</footer>
      </div>
    `;

    this.applyGlobalStyles();

    /** Load component styles/scripts */
    [headerModule, footerModule].forEach(mod => {
      if (mod.style) {
        const styleTag = document.createElement('style');
        styleTag.innerHTML = mod.style;
        this.domElement.appendChild(styleTag);
      }
      if (mod.script) mod.script();
    });

    // Add sidebar styles
    const sidebarStyleTag = document.createElement('style');
    sidebarStyleTag.innerHTML = sidebarModule.style;
    this.domElement.appendChild(sidebarStyleTag);

    if (sidebarModule.script) sidebarModule.script();

    this.attachSidebarEvents();
    this.attachSidebarToggle();
    this.loadPage(this.properties.page || 'dashboard');
  }

  /** ---------------------------
   *   FULL APP MODE
   *   REMOVE ALL SHAREPOINT UI
   * --------------------------- */
  private hideSharePointUI(): void {
    const hideList = [
      "#SuiteNavWrapper",
      ".ms-compositeHeader",
      ".ms-CommandBar",
      ".spAppBar",
      "#spCommandBar",
      "header[data-automationid='SiteHeader']",
      "div[data-automationid='PageHeader']",
      "div[data-automationid='PageTitle']",
      "div[data-automationid='PageBreadcrumb']",
      "footer",
      ".od-SuiteNav",
      ".CanvasZone",
      ".CanvasSection",
      ".spLeftNav",
      "div[data-automationid='PageNavigation']"
    ];

    hideList.forEach(sel => {
      const el = document.querySelector(sel) as HTMLElement;
      if (el) el.style.display = "none";
    });

    /** Make Page Background White / Clean */
    const canvas = document.querySelector(".SPPageChrome") as HTMLElement;
    if (canvas) {
      canvas.style.margin = "0";
      canvas.style.padding = "0";
      canvas.style.background = "#f5f5f9";
    }

    /** Make WebPart FULL SCREEN */
    const wpContainer = this.domElement.closest(".ControlZone") as HTMLElement;
    if (wpContainer) {
      wpContainer.style.position = "fixed";
      wpContainer.style.top = "0";
      wpContainer.style.left = "0";
      wpContainer.style.width = "100vw";
      wpContainer.style.height = "100vh";
      wpContainer.style.margin = "0";
      wpContainer.style.padding = "0";
      wpContainer.style.zIndex = "99999";
      wpContainer.style.background = "#f5f5f9";
      wpContainer.style.overflow = "hidden";
    }

    /** Remove Scrolling of SharePoint Page */
    document.body.style.margin = "0";
    document.body.style.padding = "0";
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";

    console.log("✔ SharePoint hidden — FULL APP MODE ENABLED");
  }

  private applyGlobalStyles(): void {
    const styleEl = document.createElement("style");
    styleEl.innerHTML = `
      html, body {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        overflow: hidden;
      }
      .dt-app {
        display: flex;
        flex-direction: column;
        width: 100vw;
        height: 100vh;
        background: #f5f5f9;
        overflow: hidden;
      }
      .dt-main {
        display: flex;
        flex: 1;
        overflow: hidden;
      }
      .dt-sidebar {
        width: 230px;
        overflow-y: auto;
        background: #ffffff;
        border-right: 1px solid #eee;
      }
      .dt-body {
        flex: 1;
        overflow-y: auto;
        padding: 15px;
        background: #fafafa;
      }
      .dt-header, .dt-footer {
        flex-shrink: 0;
        background: #fff;
      }
    `;
    this.domElement.appendChild(styleEl);
  }

  private loadPage(pageKey: string): void {
    const body = this.domElement.querySelector('.dt-body');
    if (!body) return;
    
    // Check if user is admin before loading master page
    if (pageKey === 'master') {
      this.checkAndLoadMasterPage(body);
      return;
    }
    
    const page = pages[pageKey];
    if (page) {
      body.innerHTML = page.content;
      const prevStyle = this.domElement.querySelector('#page-style');
      if (prevStyle) prevStyle.remove();
      if (page.style) {
        const styleEl = document.createElement('style');
        styleEl.id = 'page-style';
        styleEl.innerHTML = page.style;
        this.domElement.appendChild(styleEl);
      }
      if (page.script) page.script();
    }
  }

  private async checkAndLoadMasterPage(body: Element): Promise<void> {
    // Check if user is in admin group
    const isAdmin = await this.checkUserInGroup("Super Admin");
    
    if (isAdmin) {
      const page = pages['master'];
      if (page) {
        body.innerHTML = page.content;
        const prevStyle = this.domElement.querySelector('#page-style');
        if (prevStyle) prevStyle.remove();
        if (page.style) {
          const styleEl = document.createElement('style');
          styleEl.id = 'page-style';
          styleEl.innerHTML = page.style;
          this.domElement.appendChild(styleEl);
        }
        if (page.script) page.script();
      }
    } else {
      // Redirect non-admin users to dashboard
      body.innerHTML = `
        <div style="text-align: center; padding: 50px;">
          <h2>Access Denied</h2>
          <p>You don't have permission to access the Master Data page.</p>
          <button onclick="window.location='#'" data-page="dashboard" style="padding: 10px 20px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Go to Dashboard
          </button>
        </div>
      `;
    }
  }

  private async checkUserInGroup(groupName: string): Promise<boolean> {
    try {
      // Get the current web's site groups
      const siteGroupsEndpoint = `${this.context.pageContext.web.absoluteUrl}/_api/web/sitegroups`;
      const siteGroupsResponse: SPHttpClientResponse = await this.context.spHttpClient.get(
        siteGroupsEndpoint,
        SPHttpClient.configurations.v1
      );
      const siteGroupsData = await siteGroupsResponse.json();
      
      // Find the specific group by name
      const adminGroup = siteGroupsData.value.find((group: any) => 
        group.Title.toLowerCase() === groupName.toLowerCase()
      );
      
      if (!adminGroup) {
        console.warn(`Group "${groupName}" not found.`);
        return false;
      }
      
      // Check if current user is a member of that group
      const userCheckEndpoint = `${this.context.pageContext.web.absoluteUrl}/_api/web/sitegroups(${adminGroup.Id})/Users?$filter=Id eq ${this.context.pageContext.legacyPageContext.userId}`;
      const userCheckResponse: SPHttpClientResponse = await this.context.spHttpClient.get(
        userCheckEndpoint,
        SPHttpClient.configurations.v1
      );
      const userCheckData = await userCheckResponse.json();
      
      return userCheckData.value.length > 0;
      
    } catch (error) {
      console.error('Error checking user group membership:', error);
      return false;
    }
  }

  private attachSidebarEvents(): void {
    const links = this.domElement.querySelectorAll('.dt-sidebar a');
    links.forEach(link => {
      link.addEventListener('click', (e: Event) => {
        e.preventDefault();
        const page = (e.currentTarget as HTMLElement).dataset.page;
        if (page) this.loadPage(page);
      });
    });
  }

  private attachSidebarToggle(): void {
    const toggleBtn = this.domElement.querySelector('.toggle-sidebar');
    const sidebar = this.domElement.querySelector('.dt-sidebar');
    if (toggleBtn && sidebar) {
      toggleBtn.addEventListener('click', () => sidebar.classList.toggle('collapsed'));
    }
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
}