declare const _spPageContextInfo: any;
import Swal from "sweetalert2";
import * as XLSX from 'xlsx-js-style';
import "../styles/common.css";
import "../styles/revenue.css";
import { 
  authManager,
  hasFullControl,
  canContribute,
  canRead,
  canFreeze,
  isGHHead,
  getUserGroups,
  getCurrentUserFullName,
  getPermissionLevel,
  canEditProject as authCanEditProject,
  canCreateRecord,
  getAssignedProjects,
  updateUIBasedOnPermissions as authUpdateUI
} from "./auth";

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string; Email?: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead1?: string | { Title: string; Email?: string };  // ✅ Changed to Person/Group
  GroupHead1Id?: number;  // ✅ Person/Group ID
} 

interface SortConfig {
  column: string;
  direction: 'asc' | 'desc';
  subColumn?: string;
  monthIndex?: number;
}

let currentSortConfig: SortConfig = {
  column: '',
  direction: 'asc'
};

interface RevenueForecastItem {
  Id: number;
  Title: string;
  Project?: { 
    Id: number;
    Title: string;
  };
  ProfitCentre?: string;
  OBL?: number;
  ForecastData?: string;
  RevenueActual?: string;
  Remarks?: string | null;
  CreatedDate?: string;
  UpdatedDate?: string;
  Freeze?: boolean;
  [key: string]: any;
}

interface SharePointResponse<T> {
  d: {
    results: T[];
  };
}

interface ForecastItem {
    name: string;
    plan: number;
    actual: number;
    forecast?: number;
    date?: string;
    previous?: number;
}

interface ForecastMonthData {
    plan: number;
    actual: number;
    forecast?: number;
    date?: string;

    // Revenue actual belongs to this specific month
    monthActual?: number;

    items?: {
        [itemNumber: string]: ForecastItem;
    };
}

interface YearlyForecastData {
    [year: string]: {
        plan: number;
        actual: number;
        forecast?: number;
    };
}

interface ForecastData {
    [monthKey: string]: ForecastMonthData | YearlyForecastData | undefined;
    yearly?: YearlyForecastData;
}

export default {
  content: `
<div class="revenue-page fade-in">
  <section class="table-section revenue-card">
    <div class="page-header">
      <h1>Revenue Forecast Management</h1>
       
    </div>
    
    <div class="revenue-table-actions">
          <div class="revenue-table-actions-row">
        <div class="revenue-table-col-p4">
          <label for="filterProject">Project</label>
          <select id="filterProject"><option value="">All Projects</option></select>
        </div>
        <div class="revenue-table-col-p4">
          <label for="filterCustomer">Customer</label>
          <select id="filterCustomer"><option value="">All Customers</option></select>
        </div>
        <div class="revenue-table-col-p4">
          <label for="filterProjectManager">Project Manager</label>
          <select id="filterProjectManager"><option value="">All Managers</option></select>
        </div>
        <div class="revenue-table-col-p4">
          <label for="filterGroupHead">Group Head</label>
          <select id="filterGroupHead"><option value="">All Group Heads</option></select>
        </div>
        <div class="revenue-table-col-p4">
          <label for="filterProjectReference">Project Reference</label>
          <select id="filterProjectReference"><option value="">All References</option></select>
        </div>
        <div class="revenue-table-col-p4"> 
          <label> </label>
          <button class="revenue-btn-secondary revenue-clear-filters-btn" title="Clear All Filters">Reset Filter</button> 
        </div>
      </div>
      
      <div class="revenue-table-actions-row">
        <div class="revenue-table-col-p4">
          <label for="filterYear">Year</label>
          <select id="filterYear"><option value="">All Years</option></select>
        </div>
        <div class="revenue-table-col-p4">
          <label for="filterMonth">Month</label>
          <select id="filterMonth"><option value="">All Months</option></select>
        </div>
        <div class="revenue-table-col-p4"> 
          <label> </label>
          <button class="revenue-btn-secondary revenue-import-actual-btn">📥 Upload Actual</button>
        </div>
        <div class="revenue-table-col-p4"> 
          <label> </label>
          <button class="revenue-btn-secondary revenue-export-btn">📊 Export Excel</button>
        </div>
        <div class="revenue-table-col-p4"> 
          <label> </label>
          <button class="revenue-btn-secondary revenue-export-details-btn">📋 Details Export Excel</button>
        </div>
        <div class="revenue-table-col-p4"> 
          <label> </label>
          <button class="revenue-btn-secondary revenue-export-historical-btn">📈 Historical Export</button>
        </div>
      </div>
    </div>
       
    <div class="revenue-table-container-rev">
      <div class="revenue-table-scroll-wrapper">
        <table class="revenue-month-columns-table-rev"> 
           <thead id="totalsHeader"></thead> 
           <thead id="monthColumnsHeader"></thead> 
        <tbody class="revenue-table-body-rev"></tbody>
      </table>
      </div>
      
      <div class="revenue-pagination-container">
  <div class="revenue-pagination-left">
    <button class="revenue-pagination-btn" id="firstPage" disabled>First</button>
    <button class="revenue-pagination-btn" id="prevPage" disabled>Previous</button>
    
    <div class="revenue-pagination-info">
      Page <span id="currentPage">1</span> of <span id="totalPages">1</span>
    </div>
    
    <div class="revenue-pagination-pages" id="pageNumbers"></div>
    
    <button class="revenue-pagination-btn" id="nextPage" disabled>Next</button>
    <button class="revenue-pagination-btn" id="lastPage" disabled>Last</button>
  </div>
  
  <div class="revenue-pagination-right">
    <div class="revenue-page-size-selector">
      <label for="pageSizeSelect">Show:</label>
      <select id="pageSizeSelect" class="revenue-page-size-select">
        <option value="10">10</option>
        <option value="25">25</option>
        <option value="50">50</option>
        <option value="100">100</option>
      </select>
      <span>per page</span>
    </div>
    
    <div class="revenue-pagination-info">
      Showing <span id="startItem">0</span>-<span id="endItem">0</span> of <span id="totalItems">0</span> records
    </div>
  </div>
</div>
    </div>
  </section>
 <section class="form-section revenue-card" style="display:none;">
  <div class="page-header">
    <h1 id="formTitle">Add / Edit Forecast</h1>
  </div>
  <form id="revenueForm">
    
    <!-- Project Selection -->
    <div class="revenue-form-row revenue-hidden-section">
      <div class="revenue-form-group revenue-project-select-container">
        <label>Project</label>
        <select id="projectSelect" required></select>
      </div>
    </div>

    <!-- MAIN WRAPPER - 2 Column Layout -->
    <div class="revenue-project-main-wrapper">

      <!-- LEFT SIDE - Project Details (6 Rows) -->
<div class="revenue-project-left-side" id="projectDetails">
  <div class="revenue-detail-item">
    <span class="revenue-detail-label">Project:</span>
    <span class="revenue-detail-value" id="projectNameDisplay">-</span>
  </div>
  <div class="revenue-detail-item">
    <span class="revenue-detail-label">Project Ref:</span>
    <span class="revenue-detail-value" id="projectRef">-</span>
  </div>
  <div class="revenue-detail-item">
    <span class="revenue-detail-label">Profit Center:</span>
    <span class="revenue-detail-value" id="profitCenter">-</span>
  </div>
  <div class="revenue-detail-item">
    <span class="revenue-detail-label">Project Manager:</span>
    <span class="revenue-detail-value" id="projectManager">-</span>
  </div>
  <div class="revenue-detail-item">
    <span class="revenue-detail-label">Group Head:</span>
    <span class="revenue-detail-value" id="groupHead">-</span>
  </div>
  <div class="revenue-detail-item">
    <span class="revenue-detail-label">Customer:</span>
    <span class="revenue-detail-value" id="customer">-</span>
  </div>
</div>

      <!-- RIGHT SIDE - Remarks & OBL -->
      <div class="revenue-project-right-side">
        <!-- Remarks Internal -->
        <div class="revenue-remarks-group">
          <label for="remarksInternal">REMARKS (INTERNAL)</label>
          <textarea id="remarksInternal" class="revenue-remarks-textarea" rows="3" placeholder="Enter internal remarks..."></textarea>
        </div>
        
        <!-- Remarks Sprint Cell  -->
        <div class="revenue-remarks-group">
          <label for="remarksSprintCell">REMARKS (SPRINT CELL)</label>
          <textarea id="remarksSprintCell" class="revenue-remarks-textarea" rows="3" placeholder="Enter sprint cell remarks..."></textarea>
        </div>
        
        <!-- OBL Section -->
        <div class="revenue-obl-section-container revenue-hidden-section" id="oblContainer">
          <div class="revenue-obl-content">
            <div class="revenue-obl-left">
              <div class="revenue-obl-label-group">
                <label>OBL</label>
                
              </div>
              <div class="revenue-obl-value-display">
                <input type="text" id="oblLastMonth" class="revenue-obl-input revenue-number-input" placeholder="Enter OBL" readonly />
                 
              </div>
            </div>
            <div class="revenue-obl-right">
              <div class="revenue-validation-summary">
                <div class="revenue-validation-item">
                  <span class="revenue-validation-label">Total Current Value:</span>
                  <span class="revenue-validation-value" id="totalCurrentValue">0</span>
                </div>
                <div class="revenue-validation-item">
                  <span class="revenue-validation-label">Remaining Balance:</span>
                  <span class="revenue-validation-value" id="remainingValue">0</span>
                </div>
                <div class="revenue-validation-line">
                  <div class="revenue-line-fill" id="oblLineFill"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="revenue-validation-message" id="oblValidationMessage">
            ✅ All values are within OBL limit
          </div> 
        </div>
      </div>

    </div>

    <!-- Forecast Sections -->
<div class="revenue-forecast-section revenue-hidden-section" id="historicalForecastSection">
  <div class="revenue-historical-toggle-header">
  <h3>📊 Historical Data (Last 3 Months - Read only)</h3>

  <button
    type="button"
    id="revenue-toggle-historical-btn"
    class="revenue-btn-secondary revenue-historical-icon-btn"
    aria-controls="historicalContainer"
    aria-expanded="false"
    aria-label="Show historical data"
    title="Show historical data"
  >
    <span class="revenue-historical-toggle-icon" aria-hidden="true">▸</span>
  </button>
</div>
  <div id="historicalContainer" class="revenue-historical-container"></div>
</div>
    
    
    <div class="revenue-forecast-section revenue-hidden-section" id="detailedForecastSection">
      <h3>Detailed Forecast (Current + Next 2 Months)</h3>
      <div id="firstRowContainer" class="revenue-first-row-container"></div>
    </div>
    
    <div class="revenue-forecast-section revenue-hidden-section" id="longtermForecastSection">
      <h3>Long-term Forecast (Next 15 Months)</h3>
      <div id="remainingContainer" class="revenue-remaining-container"></div>
    </div>

    <div class="revenue-forecast-section revenue-hidden-section" id="yearlyForecastSection">
      <h3>5-Year Forecast</h3>
      <div id="yearlyContainer" class="revenue-yearly-container-rev"></div>
    </div>
    
    <div class="form-actions">
      <button type="submit" class="revenue-btn-primary">💾 Save Revenue Plan</button>
      <button type="button" class="revenue-btn-secondary revenue-back-to-table">⬅ Back</button>
    </div>
  </form>
</section>
    
   
</div>
  `,

 script: () => {
    setTimeout(async () => {
      const siteUrl = typeof _spPageContextInfo !== "undefined" ? _spPageContextInfo.webAbsoluteUrl : window.location.origin + "/sites/DigitalTransformationTest";
      const listName = "Revenue Forecast List";
      const projectListName = "Project List";

      
 

// ============================================
// LOCAL PERMISSION WRAPPERS
// ============================================

// Re-export auth functions with consistent naming for local use
const canEditProject = (project?: ProjectItem, forecast?: RevenueForecastItem): boolean => authCanEditProject(project);
const canCreateForecast = (): boolean => canCreateRecord();
// const getAssignedProjectsLocal = (allProjects: ProjectItem[]): ProjectItem[] => getAssignedProjects(allProjects);
const canImportData = (): boolean => canContribute();
const canExportData = (): boolean => canRead();

// ============================================
// UI PERMISSION UPDATE
// ============================================

const updateUIBasedOnPermissions = (): void => {
  // Use authUpdateUI with correct selectors
  authUpdateUI({
    importBtn: '.revenue-import-actual-btn',
    exportBtn: '.revenue-export-btn',
    addBtn: '.show-form-btn',
    saveBtn: '.revenue-btn-primary[type="submit"]',
    freezeCheckboxes: '.revenue-freeze-checkbox'
  });
  
  // Additional UI updates specific to this page
  const exportDetailsBtn = document.querySelector('.revenue-export-details-btn') as HTMLElement;
  if (exportDetailsBtn) {
    exportDetailsBtn.style.display = canExportData() ? '' : 'none';
  }

  // In the event listeners section, after exportDetailsBtn
const exportHistoricalBtn = document.querySelector('.revenue-export-historical-btn') as HTMLElement;
if (exportHistoricalBtn) {
  exportHistoricalBtn.style.display = canExportData() ? '' : 'none';
}
};

// ============================================
// PERMISSION CHECK FUNCTIONS
// ============================================

const canViewForm = (isEdit: boolean = false, project?: ProjectItem, forecast?: RevenueForecastItem): boolean => {
  if (!canRead()) return false;
  
  if (isEdit) {
    return canEditProject(project, forecast);
  } else {
    return canCreateForecast();
  }
};

      // DOM Elements
      const tableBody = document.querySelector(".revenue-table-body-rev") as HTMLElement;
      const monthColumnsHeader = document.querySelector("#monthColumnsHeader") as HTMLElement;
      const formSection = document.querySelector(".form-section") as HTMLElement;
      const tableSection = document.querySelector(".table-section") as HTMLElement; 
      const projectSelect = document.querySelector("#projectSelect") as HTMLSelectElement;
      const historicalContainer = document.querySelector("#historicalContainer") as HTMLElement;
      const firstRowContainer = document.querySelector("#firstRowContainer") as HTMLElement;
      const remainingContainer = document.querySelector("#remainingContainer") as HTMLElement;
      const yearlyContainer = document.querySelector("#yearlyContainer") as HTMLElement;
      const projectDetails = document.querySelector("#projectDetails") as HTMLElement;
      const backBtn = document.querySelector(".revenue-back-to-table") as HTMLButtonElement;
      const form = document.querySelector("#revenueForm") as HTMLFormElement;
      const exportBtn = document.querySelector(".revenue-export-btn") as HTMLButtonElement;
      const oblLastMonthInput = document.querySelector("#oblLastMonth") as HTMLInputElement;
      const totalCurrentValueSpan = document.querySelector("#totalCurrentValue") as HTMLSpanElement;
      const remainingValueSpan = document.querySelector("#remainingValue") as HTMLSpanElement;
      const oblLineFill = document.querySelector("#oblLineFill") as HTMLDivElement;
      const oblValidationMessage = document.querySelector("#oblValidationMessage") as HTMLDivElement;
      const formTitle = document.querySelector("#formTitle") as HTMLElement;

      // Filter Elements
      const filterYear = document.querySelector("#filterYear") as HTMLSelectElement;
      const filterMonth = document.querySelector("#filterMonth") as HTMLSelectElement;
      const filterProject = document.querySelector("#filterProject") as HTMLSelectElement;
      const filterCustomer = document.querySelector("#filterCustomer") as HTMLSelectElement;
      const filterProjectManager = document.querySelector("#filterProjectManager") as HTMLSelectElement;
      const filterGroupHead = document.querySelector("#filterGroupHead") as HTMLSelectElement;
      const filterProjectReference = document.querySelector("#filterProjectReference") as HTMLSelectElement;

      // Action Buttons
      const importActualBtns = document.querySelector(".revenue-import-actual-btn") as HTMLButtonElement;
      const clearFiltersBtn = document.querySelector(".revenue-clear-filters-btn") as HTMLButtonElement;
      
      const exportDetailsBtn = document.querySelector(".revenue-export-details-btn") as HTMLButtonElement;

      // Pagination Elements
      const firstPageBtn = document.querySelector("#firstPage") as HTMLButtonElement;
      const prevPageBtn = document.querySelector("#prevPage") as HTMLButtonElement;
      const nextPageBtn = document.querySelector("#nextPage") as HTMLButtonElement;
      const lastPageBtn = document.querySelector("#lastPage") as HTMLButtonElement;
      const currentPageSpan = document.querySelector("#currentPage") as HTMLSpanElement;
      const totalPagesSpan = document.querySelector("#totalPages") as HTMLSpanElement;
      const pageNumbersDiv = document.querySelector("#pageNumbers") as HTMLDivElement;
      const startItemSpan = document.querySelector("#startItem") as HTMLSpanElement;
      const endItemSpan = document.querySelector("#endItem") as HTMLSpanElement;
      const totalItemsSpan = document.querySelector("#totalItems") as HTMLSpanElement; 
      const remarksInternal = document.querySelector("#remarksInternal") as HTMLTextAreaElement;
      const remarksSprintCell = document.querySelector("#remarksSprintCell") as HTMLTextAreaElement;

      let projects: ProjectItem[] = [];
      let forecasts: RevenueForecastItem[] = [];
      let editingId: number | null = null;
      let allMonths: string[] = [];

      // Pagination variables
      let currentPage = 1;
      let pageSize = 10;
      let totalPages = 1;
      let filteredData: RevenueForecastItem[] = [];

      const pageSizeSelect = document.querySelector("#pageSizeSelect") as HTMLSelectElement;

      const getSafeString = (value: any, defaultValue: string = "-"): string => {
        if (value === null || value === undefined) {
          return defaultValue;
        }
        
        if (typeof value === 'string') {
          return value.trim() || defaultValue;
        }
        
        if (typeof value === 'object' && 'Title' in value) {
          return value.Title?.trim() || defaultValue;
        }
        
        return String(value) || defaultValue;
      };

      const toast = (icon: any, title: string) => Swal.fire({ toast: true, icon, title, position: "top-end", timer: 2000, showConfirmButton: false });

      const getDigest = async (): Promise<string> => {
        const res = await fetch(`${siteUrl}/_api/contextinfo`, { 
          method: "POST", 
          headers: { Accept: "application/json;odata=verbose" } 
        });
        const data = await res.json();
        return data.d.GetContextWebInformation.FormDigestValue;
      };

      const safeJsonParse = (jsonString: string | undefined, fallback: any = {}): any => {
        try {
          if (!jsonString || jsonString.trim() === '') {
            return fallback;
          }
          
          const cleanedString = jsonString.trim();
          
          if (cleanedString === '""' || cleanedString === "null") {
            return fallback;
          }
          
          return JSON.parse(cleanedString);
        } catch (error) {
          console.error("JSON parse error:", error, "Input:", jsonString);
          return fallback;
        }
      };

      const formatMonthKey = (date: Date): string => {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      };

      const formatMonthLabel = (date: Date): string => {
        return date.toLocaleString("default", { month: "short", year: "2-digit" });
      };

      const generateForecastTitle = (project: ProjectItem, forecastData: ForecastData): string => {
        const currentYear = new Date().getFullYear();
        let totalValue = 0;
        
        Object.keys(forecastData).forEach(key => {
          if (key.match(/^\d{4}-\d{2}$/)) {
            const monthData = forecastData[key] as ForecastMonthData;
            if (monthData) {
              totalValue += monthData.actual;
            }
          }
        });
        
        return `${project.Title} - ${currentYear} Forecast - ${totalValue.toLocaleString()}`;
      };

      const getDisplayMonths = (): string[] => {
        const now = new Date();
        const months: string[] = [];
        
        for (let i = 0; i < 3; i++) {
          const month = new Date(now.getFullYear(), now.getMonth() + i, 1);
          months.push(formatMonthKey(month));
        }
        
        return months;
      };

const getAllMonthsForStorage = (): string[] => {
  return generateIdealMonthStructure(); // Returns all months including 36 historical
};

      const allowOnlyNumbers = (input: HTMLInputElement): void => {
        input.addEventListener('input', function() {
          let value = this.value.replace(/[^\d]/g, '');
          
          if (value.length > 1 && value.startsWith('0')) {
            value = value.replace(/^0+/, '');
            if (value === '') value = '0';
          }
          
          this.value = value;
          
          if (value === '' || value === '0') {
            this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
          } else {
            this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
          }
        });
        
        input.addEventListener('keydown', function(e) {
          if ([8, 9, 13, 27, 46].includes(e.keyCode) || 
              (e.keyCode === 65 && e.ctrlKey === true) || 
              (e.keyCode === 67 && e.ctrlKey === true) ||
              (e.keyCode === 86 && e.ctrlKey === true) ||
              (e.keyCode === 88 && e.ctrlKey === true) ||
              (e.keyCode >= 35 && e.keyCode <= 39)) {
            return;
          }
          
          if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
          }
        });
        
        input.addEventListener('paste', function(e) {
          const clipboardData = e.clipboardData || (window as any).clipboardData;
          const pastedData = clipboardData?.getData('Text') || '';
          
          if (/[^\d]/.test(pastedData)) {
            e.preventDefault();
          }
        });
      };
// ============================================
// OBL TOAST FUNCTIONS - CORRECTED
// ============================================

// Helper function to get numeric value from input
const getNumericValue = (input: HTMLInputElement): number => {
  const value = input.value.trim();
  if (value === '' || value === '0') return 0;
  return parseInt(value) || 0;
};

// Helper function to set numeric value in input
const setNumericValue = (input: HTMLInputElement, value: number): void => {
  if (value === 0) {
    input.value = '';
    input.className = input.className.replace('revenue-input-with-value', 'revenue-input-empty');
  } else {
    input.value = value.toString();
    input.className = input.className.replace('revenue-input-empty', 'revenue-input-with-value');
  }
};

// SHOW OBL TOAST - CORRECTED 
const showOBLToast = (
  type: "success" | "info" | "warning" | "danger",
  message: string
): void => {
  document
    .querySelector(".revenue-obl-error-toast")
    ?.remove();

  const toastElement = document.createElement("div");
  toastElement.className =
    `revenue-obl-error-toast revenue-${type}`;

  const messageElement = document.createElement("span");
  messageElement.className = "revenue-toast-message";
  messageElement.textContent = message;

  const closeButton = document.createElement("button");
  closeButton.type = "button";
  closeButton.className = "revenue-toast-close";
  closeButton.textContent = "×";
  closeButton.setAttribute("aria-label", "Close notification");

  toastElement.append(messageElement, closeButton);
  document.body.appendChild(toastElement);

  const removeToast = (): void => {
    if (!toastElement.isConnected) return;

    toastElement.classList.add(
      "revenue-obl-error-toast-out"
    );

    window.setTimeout(() => {
      toastElement.remove();
    }, 300);
  };

  const timeoutId = window.setTimeout(
    removeToast,
    5000
  );

  closeButton.addEventListener("click", () => {
    window.clearTimeout(timeoutId);
    removeToast();
  });
};

// CALCULATE TOTAL CURRENT VALUE - CORRECTED 
const calculateTotalCurrentValue = (): number => {
  let total = 0;
  
  // Helper to get numeric value
  const getVal = (input: HTMLInputElement): number => getNumericValue(input);
  
  // ONLY count revenue-item-current-input values (these represent individual line items)
  // The main "Curr. Plan" is the sum of all items, so counting both would double count
  document.querySelectorAll<HTMLInputElement>('.revenue-detailed-month-box .revenue-item-current-input').forEach(input => {
    total += getVal(input);
  });
  
  // Long-term Forecast (Next 15 Months) - Curr. Plan values (these are standalone, not itemized)
  document.querySelectorAll<HTMLInputElement>('.revenue-simple-month-rev .revenue-main-current-input:not([readonly])').forEach(input => {
    total += getVal(input);
  });
  
  // 5-Year Forecast - Curr. Plan values (these are standalone, not itemized)
  document.querySelectorAll<HTMLInputElement>('.revenue-yearly-current-input-rev:not([readonly])').forEach(input => {
    total += getVal(input);
  });
  
  return total;
};

// VALIDATE OBL LIMIT - FIXED
const validateOBLLimit = (
  changedInput?: HTMLInputElement
): boolean => {
  const oblValue = getNumericValue(oblLastMonthInput);
  const totalCurrent = calculateTotalCurrentValue();

  totalCurrentValueSpan.textContent =
    totalCurrent.toLocaleString();

  const remaining = oblValue - totalCurrent;

  remainingValueSpan.textContent =
    remaining.toLocaleString();

  // Remove existing OBL toast
  const existingToast =
    document.querySelector(".revenue-obl-error-toast");

  if (existingToast) {
    existingToast.remove();
  }

  // =====================================================
  // OBL = 0
  // =====================================================
  if (oblValue === 0) {
    oblLineFill.style.width = "0%";
    oblLineFill.className = "revenue-line-fill";

    if (totalCurrent > 0) {
      oblValidationMessage.textContent =
        `❌ Liquidation is more than OBL (More by ${totalCurrent.toLocaleString()})`;

      oblValidationMessage.className =
        "revenue-validation-message danger";

      showOBLToast(
        "danger",
        `❌ Liquidation is more than OBL (More by ${totalCurrent.toLocaleString()})`
      );

      blockAllCurrentInputs();

      return false;
    }

    oblValidationMessage.textContent =
      "ℹ️ OBL is set to zero.";

    oblValidationMessage.className =
      "revenue-validation-message";

    showOBLToast(
      "info",
      "ℹ️ OBL is set to zero."
    );

    unblockAllCurrentInputs();

    return true;
  }

  // =====================================================
  // Calculate percentage
  // =====================================================
  const percentage =
    Math.min(
      (totalCurrent / oblValue) * 100,
      100
    );

  oblLineFill.style.width =
    `${percentage}%`;

  oblLineFill.className =
    "revenue-line-fill";

  if (percentage > 90) {
    oblLineFill.classList.add("danger");
  } else if (percentage > 75) {
    oblLineFill.classList.add("warning");
  }

  // =====================================================
  // 1. LIQUIDATION > OBL
  // =====================================================
  if (totalCurrent > oblValue) {
    const exceedAmount =
      totalCurrent - oblValue;

    oblValidationMessage.textContent =
      `❌ Liquidation is more than OBL (More by ${exceedAmount.toLocaleString()})`;

    oblValidationMessage.className =
      "revenue-validation-message danger";

    showOBLToast(
      "danger",
      `❌ Liquidation is more than OBL (More by ${exceedAmount.toLocaleString()})`
    );

    blockIncreasingCurrentInputs(
      changedInput
    );

    return false;
  }

  // =====================================================
  // 2. LIQUIDATION = OBL
  // =====================================================
  if (totalCurrent === oblValue) {
    oblValidationMessage.textContent =
      `✅ OBL is fully liquidated (${totalCurrent.toLocaleString()})`;

    oblValidationMessage.className =
      "revenue-validation-message success";

    showOBLToast(
      "success",
      `✅ OBL is fully liquidated (${totalCurrent.toLocaleString()})`
    );

    // Don't allow increasing values beyond OBL
    blockIncreasingCurrentInputs(
      changedInput
    );

    return true;
  }

  // =====================================================
  // 3. LIQUIDATION < OBL
  // =====================================================
  if (totalCurrent < oblValue) {
    const remainingAmount =
      oblValue - totalCurrent;

    oblValidationMessage.textContent =
      `⚠️ OBL is not fully liquidated (Remaining ${remainingAmount.toLocaleString()})`;

    oblValidationMessage.className =
      "revenue-validation-message warning";

    showOBLToast(
      "warning",
      `⚠️ OBL is not fully liquidated (Remaining ${remainingAmount.toLocaleString()})`
    );

    unblockAllCurrentInputs();

    return true;
  }

  // =====================================================
  // Default
  // =====================================================
  unblockAllCurrentInputs();

  return true;
};

// UPDATE OBL VALIDATION DISPLAY - CORRECTED
const updateOBLValidationDisplay = (changedInput?: HTMLInputElement): void => {
  validateOBLLimit(changedInput);
  validateMonthItemTotals(changedInput);
};

// ============================================
// ATTACH FORECAST EVENT LISTENERS - ADD OBL REAL-TIME VALIDATION
// ============================================



      const createEmptyItems = (): { [key: string]: ForecastItem } => {
          const items: { [key: string]: ForecastItem } = {};
          for (let i = 1; i <= 10; i++) {
              items[i.toString()] = { 
                  name: '', 
                  plan: 0, 
                  actual: 0, 
                  forecast: 0, 
                  date: '' 
              };
          }
          return items;
      };

const generateIdealMonthStructure = (): string[] => {
    const months: string[] = [];

    // IMPORTANT:
    // Always use the FIRST day of the current month.
    // Otherwise dates like 29/30/31 can cause month skipping
    // when setMonth() is used.
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    // 36 historical months
    // Includes the previous 36 months.
    for (let i = -36; i < 0; i++) {
        const date = new Date(currentYear, currentMonth + i, 1);
        months.push(formatMonthKey(date));
    }

    // 3 detailed months:
    // Current month + next 2 months
    for (let i = 0; i < 3; i++) {
        const date = new Date(currentYear, currentMonth + i, 1);
        months.push(formatMonthKey(date));
    }

    // 15 future months
    for (let i = 3; i < 18; i++) {
        const date = new Date(currentYear, currentMonth + i, 1);
        months.push(formatMonthKey(date));
    }

    // Remove duplicates and make sure months are chronological
    return Array.from(new Set(months)).sort();
};

      const getLastMonthKey = (existingData: ForecastData): string | undefined => {
        const monthKeys = Object.keys(existingData).filter(key => key.match(/^\d{4}-\d{2}$/));
        
        if (monthKeys.length === 0) {
          return undefined;
        }
        
        const sortedMonths = monthKeys.sort();
        const lastMonth = sortedMonths[sortedMonths.length - 1];
         
        return lastMonth;
      };

      const createFreshYearlyStructure = (lastMonthKey?: string): YearlyForecastData => {
        const yearlyData: YearlyForecastData = {};
        
        let startYear: number;
        
        if (lastMonthKey) {
          startYear = parseInt(lastMonthKey.split('-')[0]); 
        } else {
          const futureDate = new Date();
          futureDate.setMonth(futureDate.getMonth() + 15);
          startYear = futureDate.getFullYear(); 
        }
        
        const endYear = startYear + 4;
        
        for (let year = startYear; year <= endYear; year++) {
          yearlyData[year.toString()] = {
            plan: 0,
            actual: 0
          };
        }
        
        return yearlyData;
      };

const createFreshForecastStructure = (): ForecastData => {
    const allMonths = generateIdealMonthStructure();
    const freshData: ForecastData = {};

    const now = new Date();
    const currentMonthKey = formatMonthKey(now);

    const currentMonthIndex = allMonths.indexOf(currentMonthKey);

    let detailedStartIndex = 0;

    if (currentMonthIndex !== -1) {
        detailedStartIndex = currentMonthIndex;
    } else {
        detailedStartIndex = 36;
    }

    allMonths.forEach((monthKey, index) => {

        const isDetailedMonth =
            index >= detailedStartIndex &&
            index < detailedStartIndex + 3;

        const monthData: ForecastMonthData = {
            plan: 0,
            actual: 0,
            forecast: 0,
            monthActual: 0,  // ✅ Initialize monthActual
            items: isDetailedMonth
                ? createEmptyItems()
                : {}
        };

        freshData[monthKey] = monthData;
    });

    const lastMonthKey = allMonths[allMonths.length - 1];

    freshData.yearly =
        createFreshYearlyStructure(lastMonthKey);

    return freshData;
};

      const isForecastMonthData = (data: any): data is ForecastMonthData => {
          return data && 
                typeof data.plan === 'number' && 
                typeof data.actual === 'number';
      };

// const handleMonthProgression = (forecastData: ForecastData): ForecastData => {
//     const now = new Date();
//     const currentMonthKey = formatMonthKey(now);
    
//     const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
//     const idealMonths = generateIdealMonthStructure();
    
//     // Check if we need progression
//     const hasCurrentMonth = originalMonths.includes(currentMonthKey);
//     const lastDataMonth = originalMonths[originalMonths.length - 1];
//     const lastIdealMonth = idealMonths[idealMonths.length - 1];
    
//     // If data already has current month and last month matches, NO progression needed
//     if (hasCurrentMonth && lastDataMonth === lastIdealMonth) {
//         return forecastData;
//     }
    
//     // Find current month index in idealMonths
//     const currentMonthIndex = idealMonths.indexOf(currentMonthKey);
//     // Detailed months start at current month
//     const detailedStartIndex = currentMonthIndex !== -1 ? currentMonthIndex : 36;
    
//     // If we get here, we need to add new months and carry values forward
//     const updatedData: ForecastData = {};
    
//     // Copy all existing data first
//     idealMonths.forEach((monthKey, index) => {
//         const existingData = forecastData[monthKey];
//         const isDetailedMonth = index >= detailedStartIndex && index < detailedStartIndex + 3;
        
//         if (existingData && isForecastMonthData(existingData)) {
//             updatedData[monthKey] = JSON.parse(JSON.stringify(existingData));
//         } else {
//             updatedData[monthKey] = {
//                 plan: 0,
//                 actual: 0,
//                 items: isDetailedMonth ? createEmptyItems() : {}
//             };
//         }
//     });
    
//     console.log("=== APPLYING VALUE PROPAGATION ===");
    
//     // ✅ FIX: Only carry values from OLD months to NEW months
//     // Carry values forward: previous month's actual becomes next month's plan
//     for (let i = 1; i < idealMonths.length; i++) {
//         const prevMonthKey = idealMonths[i - 1];
//         const currMonthKey = idealMonths[i];
        
//         const prevMonthData = updatedData[prevMonthKey];
//         const currMonthData = updatedData[currMonthKey];
        
//         if (prevMonthData && isForecastMonthData(prevMonthData) && 
//             currMonthData && isForecastMonthData(currMonthData)) {
            
//             // Only apply progression if the current month is NEW (doesn't exist in original data)
//             // OR if the previous month is older than current month and current month is new
//             const isPrevMonthOlder = prevMonthKey < currentMonthKey;
//             const isCurrMonthNew = !originalMonths.includes(currMonthKey);
            
//             if (isPrevMonthOlder && isCurrMonthNew) {
//                 // Carry forward: previous month's actual becomes current month's plan
//                 currMonthData.plan = prevMonthData.actual;
//                 // Keep current month's actual as 0 (ready for new input)
//                 currMonthData.actual = 0;
                
//                 // Also carry forward items for detailed months
//                 const monthIndex = idealMonths.indexOf(currMonthKey);
//                 const isDetailedMonth = monthIndex >= detailedStartIndex && monthIndex < detailedStartIndex + 3;
                
//                 if (isDetailedMonth && currMonthData.items) {
//                     const prevItems = prevMonthData.items || {};
//                     Object.keys(currMonthData.items).forEach(itemKey => {
//                         const prevItem = prevItems[itemKey];
//                         const currItem = currMonthData.items![itemKey];
//                         if (prevItem && currItem) {
//                             currItem.plan = prevItem.actual || 0;
//                             currItem.actual = 0;
//                         }
//                     });
//                 }
                
//                 console.log(`📊 ${prevMonthKey} (actual: ${prevMonthData.actual}) → ${currMonthKey} (plan: ${currMonthData.plan})`);
//             }
//         }
//     }
    
//     // Preserve yearly data
//     if (forecastData.yearly) {
//         updatedData.yearly = JSON.parse(JSON.stringify(forecastData.yearly));
//     } else {
//         const lastMonthKey = idealMonths[idealMonths.length - 1];
//         updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
//     }
    
//     return updatedData;
// };

const propagateMonthValues = (forecastData: ForecastData): ForecastData => {
    const now = new Date();
    const currentMonthKey = formatMonthKey(now);
    
    const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
    const idealMonths = generateIdealMonthStructure();
    
    const hasCurrentMonth = originalMonths.includes(currentMonthKey);
    const lastDataMonth = originalMonths[originalMonths.length - 1];
    const lastIdealMonth = idealMonths[idealMonths.length - 1];
    
    if (hasCurrentMonth && lastDataMonth === lastIdealMonth) {
        return forecastData;
    }
    
    const currentMonthIndex = idealMonths.indexOf(currentMonthKey);
    const detailedStartIndex = currentMonthIndex !== -1 ? currentMonthIndex : 36;
    
    const updatedData: ForecastData = {};
    
    idealMonths.forEach((monthKey, index) => {
        const existingData = forecastData[monthKey];
        const isDetailedMonth = index >= detailedStartIndex && index < detailedStartIndex + 3;
        
        if (existingData && isForecastMonthData(existingData)) {
            updatedData[monthKey] = JSON.parse(JSON.stringify(existingData));
        } else {
            updatedData[monthKey] = {
                plan: 0,
                actual: 0,
                monthActual: 0,
                items: isDetailedMonth ? createEmptyItems() : {}
            };
        }
    });
    
    console.log("=== APPLYING VALUE PROPAGATION ===");
    
    for (let i = 1; i < idealMonths.length; i++) {
        const prevMonthKey = idealMonths[i - 1];
        const currMonthKey = idealMonths[i];
        
        const prevMonthData = updatedData[prevMonthKey];
        const currMonthData = updatedData[currMonthKey];
        
        if (prevMonthData && isForecastMonthData(prevMonthData) && 
            currMonthData && isForecastMonthData(currMonthData)) {
            
            const isPrevMonthOlder = prevMonthKey < currentMonthKey;
            const isCurrMonthNew = !originalMonths.includes(currMonthKey);
            
            if (isPrevMonthOlder && isCurrMonthNew) {
                // ✅ Use monthActual from previous month if available
                const prevMonthActual = prevMonthData.monthActual || 0;
                
                if (prevMonthActual > 0) {
                    currMonthData.plan = prevMonthActual;
                } else {
                    currMonthData.plan = prevMonthData.actual;
                }
                
                currMonthData.actual = 0;
                currMonthData.monthActual = 0;
                
                const monthIndex = idealMonths.indexOf(currMonthKey);
                const isDetailedMonth = monthIndex >= detailedStartIndex && monthIndex < detailedStartIndex + 3;
                
                if (isDetailedMonth && currMonthData.items) {
                    const prevItems = prevMonthData.items || {};
                    Object.keys(currMonthData.items).forEach(itemKey => {
                        const prevItem = prevItems[itemKey];
                        const currItem = currMonthData.items![itemKey];
                        if (prevItem && currItem) {
                            if (prevMonthActual > 0) {
                                currItem.plan = prevMonthActual;
                            } else {
                                currItem.plan = prevItem.actual || 0;
                            }
                            currItem.actual = 0;
                        }
                    });
                }
            }
        }
    }
    
    if (forecastData.yearly) {
        updatedData.yearly = JSON.parse(JSON.stringify(forecastData.yearly));
    } else {
        const lastMonthKey = idealMonths[idealMonths.length - 1];
        updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
    }
    
    return updatedData;
};
const applyAutoProgression = async (): Promise<void> => { 
    if (forecasts.length === 0) { 
        return;
    }

    const digest = await getDigest();
    let progressedCount = 0;
    let errorCount = 0;
    const entityType = await getListEntityType();
    
    for (const forecast of forecasts) {
        try {
            if (!forecast.ForecastData) { 
                continue;
            }
            
            const originalData = safeJsonParse(forecast.ForecastData, {});
            
            if (checkIfNeedsProgression(originalData)) {  
                // ✅ FIX: Call with only 1 argument
                const progressedData = propagateCollectionValues(originalData);
                
                const payload = {
                    __metadata: { type: entityType },
                    ForecastData: JSON.stringify(progressedData),
                    UpdatedDate: new Date().toISOString()
                };
                
                const response = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`, {
                    method: "POST",
                    headers: {
                        Accept: "application/json;odata=verbose",
                        "Content-Type": "application/json;odata=verbose",
                        "X-RequestDigest": digest,
                        "IF-MATCH": "*",
                        "X-HTTP-Method": "MERGE"
                    },
                    body: JSON.stringify(payload)
                });
                
                if (response.ok) {
                    progressedCount++; 
                } else {
                    errorCount++; 
                }
                
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        } catch (error) {
            errorCount++; 
        }
    }
    
    if (progressedCount > 0) { 
        await loadForecasts();
        toast("success", `Monthly data progressed for ${progressedCount} revenue forecasts`);
    }
};

const loadProjects = async (): Promise<void> => {
  try {
    // ✅ Include GroupHead1 with expand
    const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items?$select=Id,Title,CustomerName,GroupHead1/Title,GroupHead1Id,PC,ProjectReference,ProjectManager/Title,ProjectManagerId&$expand=GroupHead1,ProjectManager`, {
      headers: { Accept: "application/json;odata=verbose" }
    });
    const data: SharePointResponse<ProjectItem> = await res.json();
    const rawProjects: ProjectItem[] = data.d?.results || [];
    
    const cleanedProjects = rawProjects.map((p: ProjectItem) => ({
      ...p,
      CustomerName: p.CustomerName || "",
      GroupHead1: p.GroupHead1 || "",
      GroupHead1Id: p.GroupHead1Id,
      PC: p.PC || "",
      ProjectReference: p.ProjectReference || "",
      ProjectManager: p.ProjectManager || "",
      ProjectManagerId: p.ProjectManagerId
    }));
    
    const projectMap = new Map<string, ProjectItem>();
    cleanedProjects.forEach(p => {
      projectMap.set(p.Title, p);
    });
    
    projects = Array.from(projectMap.values());
    
    // Log all projects with PMs and Group Heads for debugging
    console.log('📋 All projects with PMs and Group Heads:');
    projects.forEach(p => {
      const pmName = typeof p.ProjectManager === 'object' 
        ? p.ProjectManager?.Title 
        : p.ProjectManager;
      const ghName = typeof p.GroupHead1 === 'object'
        ? p.GroupHead1?.Title
        : p.GroupHead1;
      console.log(`  - ${p.Title}: PM = ${pmName || 'None'}, GH = ${ghName || 'None'}`);
    });
    
    // Get assigned projects based on user permissions
    const assignedProjects = getAssignedProjects(projects);
    
    console.log(`📋 Total projects: ${projects.length}, Assigned projects: ${assignedProjects.length}`);
    console.log('📋 Assigned project titles:', assignedProjects.map(p => p.Title));
    
    // ✅ Populate project select dropdown with assigned projects ONLY
    projectSelect.innerHTML = `<option value="">Select Project</option>` + 
      assignedProjects.map(p => `<option value="${p.Id}">${p.Title}</option>`).join("");
    
    // ✅ Also update the filter dropdown with assigned projects
    filterProject.innerHTML = '<option value="">All Projects</option>' + 
      [...new Set(assignedProjects.map(p => p.Title))]
        .sort()
        .map(project => `<option value="${project}">${project}</option>`)
        .join("");
        
  } catch (error) {
    console.error("Error loading projects:", error);
    toast("error", "Failed to load projects");
  }
};

// Helper functions for Person/Group display
const getGroupHeadDisplayName = (groupHead: string | { Title: string; Email?: string } | undefined): string => {
  if (!groupHead) return "";
  if (typeof groupHead === "object" && groupHead !== null) {
    return groupHead.Title || "";
  }
  return groupHead;
};

const getProjectManagerDisplayName = (manager: string | { Title: string; Email?: string } | undefined): string => {
  if (!manager) return "";
  if (typeof manager === "object" && manager !== null) {
    return manager.Title || "";
  }
  return manager;
};

const getAssignedProjectValues = (key: keyof ProjectItem): string[] => {
  const assignedProjects = getAssignedProjects(projects);
  const values = new Set<string>();
  
  assignedProjects.forEach(project => {
    let value = project[key];
    if (value) {
      // Handle ProjectManager which can be string or object
      if (key === 'ProjectManager' && typeof value === 'object') {
        value = (value as { Title: string }).Title;
      }
      // ✅ Handle GroupHead1 which can be string or object
      if (key === 'GroupHead1' && typeof value === 'object') {
        value = (value as { Title: string }).Title;
      }
      if (typeof value === 'string' && value.trim()) {
        values.add(value.trim());
      }
    }
  });
  
  return Array.from(values).sort();
};

  const loadForecasts = async (): Promise<void> => {
  try {
    const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=Id,Title,Project/Id,Project/Title,ProfitCentre,OBL,ForecastData,RevenueActual,Remarks,CreatedDate,UpdatedDate,Freeze&$expand=Project&$top=5000`, {
      headers: { Accept: "application/json;odata=verbose" }
    });
    const data: SharePointResponse<RevenueForecastItem> = await res.json();
    
    forecasts = (data.d?.results || []).map(forecast => ({
      ...forecast,
      ForecastData: typeof forecast.ForecastData === 'string' ? 
        forecast.ForecastData : 
        JSON.stringify(forecast.ForecastData || {}),
      RevenueActual: typeof forecast.RevenueActual === 'string' ? 
        forecast.RevenueActual : 
        JSON.stringify(forecast.RevenueActual || {}),
      Freeze: forecast.Freeze || false
    }));
    
    console.log("✅ Forecasts loaded:", forecasts.length);
  } catch (error) { 
    console.error("Error loading forecasts:", error);
    toast("error", "Failed to load forecasts");
  }
};

const getMonthName = (monthNumber: string): string => {
  const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];
  return months[parseInt(monthNumber) - 1] || "Month";
};
const exportToExcelWithFullStyle = (): void => { 
  const selectedYear = filterYear.value;
  const selectedMonth = filterMonth.value;
  
  if (!selectedYear || !selectedMonth) {
    toast("error", "Please select year and month to export");
    return;
  }

  const exportData = filteredData.length > 0 ? filteredData : forecasts;
  
  if (exportData.length === 0) {
    toast("error", "No data available to export");
    return;
  }

  try {
    const { headers, allMonths, lastFiveYears } = generateHeadersStructure(selectedYear, selectedMonth, exportData);
     
    const excelData = exportData.map(forecast => {
      const projectTitle = forecast.Project?.Title || "-";
      const proj = projects.find(p => p.Title === projectTitle);
      
      const revenueActualData = safeJsonParse(forecast.RevenueActual, {});
      const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
      
      const oblValue = forecast.OBL || 0;
      
      const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
      const monthName = getMonthName(selectedMonth);
      
      const selectedMonthForecastData = forecastData[selectedMonthKey] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
      const selectedMonthPlan = selectedMonthForecastData.plan || 0;
      const selectedMonthCurrent = selectedMonthForecastData.actual || 0;
      const selectedMonthActual = revenueActualData[selectedMonthKey] || 0;
      // Further = forecast value from backend
      const selectedMonthFurther = selectedMonthForecastData.forecast || 0;
      // Forecast = Curr. Plan + Further
      const selectedMonthForecast = selectedMonthCurrent + selectedMonthFurther;

      const rowData: any = {
        "Profit Centre": forecast.ProfitCentre || "-",
        "SO/Project Ref": proj?.ProjectReference || "-",
        "Customer Name": proj?.CustomerName || "-",
        "Project Name": projectTitle,
       "Group Head": getGroupHeadDisplayName(proj?.GroupHead1),
        "Project Manager": getProjectManagerDisplayName(proj?.ProjectManager),
        "OBL": oblValue,
        // Order: Prev. Plan → Curr. Plan → Actual → Further → Forecast
        [`${monthName} ${selectedYear} (Prev. Plan)`]: selectedMonthPlan,
        [`${monthName} ${selectedYear} (Curr. Plan)`]: selectedMonthCurrent,
        [`${monthName} ${selectedYear} (Actual)`]: selectedMonthActual,
        [`${monthName} ${selectedYear} (Further)`]: selectedMonthFurther,  // backend forecast field
        [`${monthName} ${selectedYear} (Forecast)`]: selectedMonthForecast, // Curr. Plan + Further
      };
      
      allMonths.forEach(monthKey => {
        const [year, month] = monthKey.split('-');
        const monthLabel = getMonthName(month);
        const displayLabel = `${monthLabel} ${year}`;
        
        const forecastMonthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
        const planValue = forecastMonthData.plan || 0;
        const currentValue = forecastMonthData.actual || 0;
        
        rowData[`${displayLabel} (Prev. Plan)`] = planValue;
        rowData[`${displayLabel} (Curr. Plan)`] = currentValue;
      });
      
      lastFiveYears.forEach(year => {
        const yearData = forecastData.yearly?.[year] || { plan: 0, actual: 0 };
        rowData[`${year} (Prev. Plan)`] = yearData.plan;
        rowData[`${year} (Curr. Plan)`] = yearData.actual;
      });     
      
      const totalMonthlyCurrent = Object.keys(forecastData)
        .filter(key => key.match(/^\d{4}-\d{2}$/))
        .reduce((sum, monthKey) => {
          const monthData = forecastData[monthKey] as ForecastMonthData;
          return sum + (monthData?.actual || 0);
        }, 0);

      const totalYearlyCurrent = forecastData.yearly ? 
        Object.values(forecastData.yearly).reduce((sum, yearData) => {
          return sum + (yearData.actual || 0);
        }, 0) : 0;

      rowData["Balance"] = oblValue - (totalMonthlyCurrent + totalYearlyCurrent);
      
      return rowData;
    });

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(excelData, { header: headers });

    const headerStyle = {
      fill: {
        fgColor: { rgb: "FF0078D4" }
      },
      font: {
        name: "Arial",
        sz: 10,
        bold: true,
        color: { rgb: "FFFFFFFF" }
      },
      alignment: {
        horizontal: "center",
        vertical: "center"
      },
      border: {
        top: { style: "thin", color: { rgb: "FF000000" } },
        left: { style: "thin", color: { rgb: "FF000000" } },
        bottom: { style: "thin", color: { rgb: "FF000000" } },
        right: { style: "thin", color: { rgb: "FF000000" } }
      }
    };

    const dataStyle = {
      font: {
        name: "Arial",
        sz: 10
      },
      alignment: {
        horizontal: "center",
        vertical: "center"
      },
      border: {
        top: { style: "thin", color: { rgb: "FFD0D0D0" } },
        left: { style: "thin", color: { rgb: "FFD0D0D0" } },
        bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
        right: { style: "thin", color: { rgb: "FFD0D0D0" } }
      }
    };

    const numberStyle = {
      ...dataStyle,
      alignment: {
        horizontal: "right",
        vertical: "center"
      }
    };

    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
    
    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      if (!ws[cellAddress]) continue;
      
      if (!ws[cellAddress].s) {
        ws[cellAddress].s = {};
      }
      ws[cellAddress].s = headerStyle;
    }
    
    for (let row = range.s.r + 1; row <= range.e.r; row++) {
      for (let col = range.s.c; col <= range.e.c; col++) {
        const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
        if (!ws[cellAddress]) continue;
        
        const isNumberColumn = col >= 6;
        const styleToApply = isNumberColumn ? numberStyle : dataStyle;
        
        if (!ws[cellAddress].s) {
          ws[cellAddress].s = {};
        }
        ws[cellAddress].s = styleToApply;
      }
    }

    const colWidths = headers.map((header: string) => {
      if (header.includes('Project Name')) return { wch: 25 };
      if (header.includes('Customer Name')) return { wch: 20 };
      if (header.includes('Profit Centre') || header.includes('SO/Project Ref')) return { wch: 12 };
      if (header.includes('Group Head') || header.includes('Project Manager')) return { wch: 15 };
      if (header.includes('OBL') || header.includes('Balance')) return { wch: 12 };
      if (header.includes('(Prev. Plan)') || header.includes('(Curr. Plan)') || header.includes('(Further)') || header.includes('(Actual)') || header.includes('(Forecast)')) return { wch: 10 };
      return { wch: 12 };
    });
    ws['!cols'] = colWidths;

    ws['!freeze'] = { x: 0, y: 1 };

    XLSX.utils.book_append_sheet(wb, ws, "Revenue Forecast");

    const monthName = getMonthName(selectedMonth);
    const fileName = `Revenue_Forecast_${monthName}_${selectedYear}_Filtered.xlsx`;
    
    XLSX.writeFile(wb, fileName);
     
    toast("success", `Exported ${exportData.length} filtered records for ${monthName} ${selectedYear}`);
    
  } catch (error) { 
    toast("error", "Failed to export data to Excel");
  }
};

const generateHeadersStructure = (selectedYear: string, selectedMonth: string, exportData: RevenueForecastItem[]) => {
  const baseHeaders = [
    "Profit Centre", 
    "SO/Project Ref", 
    "Customer Name", 
    "Project Name", 
    "Group Head", 
    "Project Manager", 
    "OBL",
  ];

  const selectedMonthName = getMonthName(selectedMonth);
  // Order: Prev. Plan → Curr. Plan → Actual → Further → Forecast
  const selectedMonthHeaders = [
    `${selectedMonthName} ${selectedYear} (Prev. Plan)`,
    `${selectedMonthName} ${selectedYear} (Curr. Plan)`,
    `${selectedMonthName} ${selectedYear} (Actual)`,
    `${selectedMonthName} ${selectedYear} (Further)`,   // backend forecast field
    `${selectedMonthName} ${selectedYear} (Forecast)`   // Curr. Plan + Further
  ];

  const allMonthKeys = new Set<string>();
  
  exportData.forEach(forecast => {
    const forecastData = safeJsonParse(forecast.ForecastData, {});
    Object.keys(forecastData).forEach(key => {
      if (key && key.match(/^\d{4}-\d{2}$/)) {
        allMonthKeys.add(key);
      }
    });
  });

  const sortedMonthKeys = Array.from(allMonthKeys).sort();
  const selectedMonthKey = `${selectedYear}-${selectedMonth.padStart(2, '0')}`;
  const selectedIndex = sortedMonthKeys.indexOf(selectedMonthKey);
  
  const startIndex = selectedIndex >= 0 ? selectedIndex + 1 : 0;
  const next17Months = sortedMonthKeys.slice(startIndex, startIndex + 17);

  const monthlyHeaders: string[] = [];
  next17Months.forEach(monthKey => {
    const [year, month] = monthKey.split('-');
    const monthLabel = getMonthName(month);
    const displayLabel = `${monthLabel} ${year}`;
    monthlyHeaders.push(`${displayLabel} (Prev. Plan)`, `${displayLabel} (Curr. Plan)`);
  });

  const lastFiveYears = getLastFiveYears(exportData);
  const yearlyHeaders: string[] = [];
  lastFiveYears.forEach(year => {
    yearlyHeaders.push(`${year} (Prev. Plan)`, `${year} (Curr. Plan)`);
  });

  const finalHeaders = [
    ...baseHeaders,
    ...selectedMonthHeaders,
    ...monthlyHeaders,
    ...yearlyHeaders,
    "Balance"
  ];
  
  return { 
    headers: finalHeaders, 
    allMonths: next17Months,
    lastFiveYears
  };
};

const getLastFiveYears = (data: RevenueForecastItem[]): string[] => {
  const years = new Set<string>();
  
  data.forEach(forecast => {
    const forecastData = safeJsonParse(forecast.ForecastData, {});
    if (forecastData.yearly) {
      Object.keys(forecastData.yearly).forEach(year => {
        years.add(year);
      });
    }
  });
  
  const sortedYears = Array.from(years).sort();
  return sortedYears.slice(-5);
};

const exportDetailedItemsToExcel = (): void => { 
  const selectedYear = filterYear.value;
  const selectedMonth = filterMonth.value;
  
  if (!selectedYear || !selectedMonth) {
    toast("error", "Please select year and month to export");
    return;
  }

  const exportData = filteredData.length > 0 ? filteredData : forecasts;
  
  if (exportData.length === 0) {
    toast("error", "No data available to export");
    return;
  }

  try {
    const currentDate = new Date();
    const detailedMonths: string[] = [];
    for (let i = 0; i < 3; i++) {
      const monthDate = new Date(currentDate);
      monthDate.setMonth(monthDate.getMonth() + i);
      const monthKey = formatMonthKey(monthDate);
      if (monthKey) {
        detailedMonths.push(monthKey);
      }
    }

    const nextFifteenMonths: string[] = [];
    for (let i = 3; i < 18; i++) {
      const monthDate = new Date(currentDate);
      monthDate.setMonth(monthDate.getMonth() + i);
      const monthKey = formatMonthKey(monthDate);
      if (monthKey) {
        nextFifteenMonths.push(monthKey);
      }
    }

    const lastFiveYears = getLastFiveYearsFromForecastData(exportData);

    const selectedMonthName = getMonthName(selectedMonth) || selectedMonth;
    const currentMonthName = getMonthName(detailedMonths[0]?.split('-')[1] || '') || detailedMonths[0]?.split('-')[1] || '';
    const nextMonth1Name = getMonthName(detailedMonths[1]?.split('-')[1] || '') || detailedMonths[1]?.split('-')[1] || '';
    const nextMonth2Name = getMonthName(detailedMonths[2]?.split('-')[1] || '') || detailedMonths[2]?.split('-')[1] || '';
    const currentMonthYear = detailedMonths[0]?.split('-')[0] || '';
    const nextMonth1Year = detailedMonths[1]?.split('-')[0] || '';
    const nextMonth2Year = detailedMonths[2]?.split('-')[0] || '';

    const excelData: any[][] = [];

    // First row headers - Order: Prev. Plan → Curr. Plan → Actual → Further → Forecast
    const firstRowHeaders = [
      "SO/Project Ref", 
      "Project Name", 
      "Customer Name",
      "Profit Centre", 
      "Group Head", 
      "Project Manager", 
      "OBL",
      
      `${selectedMonthName} ${selectedYear} (Prev. Plan)`,
      `${selectedMonthName} ${selectedYear} (Curr. Plan)`,
      `${selectedMonthName} ${selectedYear} (Actual)`,
      `${selectedMonthName} ${selectedYear} (Further)`,   // backend forecast field
      `${selectedMonthName} ${selectedYear} (Forecast)`,  // Curr. Plan + Further
      
      `${currentMonthName} ${currentMonthYear}`.toUpperCase(),
      "", "", "", "", "", "",
      
      `${nextMonth1Name} ${nextMonth1Year} (Prev. Plan)`,
      `${nextMonth1Name} ${nextMonth1Year} (Curr. Plan)`,
      
      `${nextMonth1Name} ${nextMonth1Year}`.toUpperCase(),
      "", "", "", "",
      
      `${nextMonth2Name} ${nextMonth2Year} (Prev. Plan)`,
      `${nextMonth2Name} ${nextMonth2Year} (Curr. Plan)`,
      
      `${nextMonth2Name} ${nextMonth2Year}`.toUpperCase(),
      "", "", "", "",
    ];

    nextFifteenMonths.forEach(monthKey => {
      const [year, month] = monthKey.split('-');
      const monthLabel = getMonthName(month) || month;
      firstRowHeaders.push(`${monthLabel} ${year} (Prev. Plan)`, `${monthLabel} ${year} (Curr. Plan)`);
    });

    lastFiveYears.forEach(year => {
      firstRowHeaders.push(`${year} (Prev. Plan)`, `${year} (Curr. Plan)`);
    });

    firstRowHeaders.push("Balance");

    // Second row headers - Order: Item Description → Prev. Plan → Curr. Plan → Actual → Further → Forecast
    const secondRowHeaders = [
      "", "", "", "", "", "", "",
      "", "", "", "", "",
      "Item", "Prev. Plan", "Curr. Plan", "Actual", "Further", "Forecast",
      "", "",
      "Item", "Prev. Plan", "Curr. Plan", "Actual", "Further", "Forecast",
      "", "",
      "Item", "Prev. Plan", "Curr. Plan", "Actual", "Further", "Forecast",
    ];

    const remainingColumns = firstRowHeaders.length - secondRowHeaders.length;
    for (let i = 0; i < remainingColumns; i++) {
      secondRowHeaders.push("");
    }

    excelData.push(firstRowHeaders);
    excelData.push(secondRowHeaders);

    exportData.forEach(forecast => {
      const projectTitle = forecast.Project?.Title || "-";
      const proj = projects.find(p => p.Title === projectTitle);
      
      const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
      const revenueActualData = safeJsonParse(forecast.RevenueActual, {});
      
      const oblValue = forecast.OBL || 0;

      const detailedMonthsData: any[] = [];
      for (let i = 0; i < 3; i++) {
        const monthKey = detailedMonths[i];
        if (monthKey) {
          const monthForecastData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0, items: createEmptyItems() };
          const monthActualData = revenueActualData[monthKey] || 0;
          // Further = forecast value from backend
          const further = monthForecastData.forecast || 0;
          // Forecast = Curr. Plan + Further
          const totalForecast = (monthForecastData.actual || 0) + further;
          detailedMonthsData.push({
            plan: monthForecastData.plan || 0,
            current: monthForecastData.actual || 0,
            actual: monthActualData,
            further: further,
            total: totalForecast,
            items: monthForecastData.items || createEmptyItems()
          });
        } else {
          detailedMonthsData.push({
            plan: 0,
            current: 0,
            actual: 0,
            further: 0,
            total: 0,
            items: createEmptyItems()
          });
        }
      }

      const totalMonthlyCurrent = Object.keys(forecastData)
        .filter(key => key.match(/^\d{4}-\d{2}$/))
        .reduce((sum, monthKey) => {
          const monthData = forecastData[monthKey] as ForecastMonthData;
          return sum + (monthData?.actual || 0);
        }, 0);

      const totalYearlyCurrent = forecastData.yearly ? 
        Object.values(forecastData.yearly).reduce((sum: number, yearData: any) => {
          return sum + (yearData.actual || 0);
        }, 0) : 0;

      const balance = oblValue - (totalMonthlyCurrent + totalYearlyCurrent);

      for (let itemNum = 1; itemNum <= 10; itemNum++) {
        const itemKey = itemNum.toString();
        
        const rowData: any[] = [
  proj?.ProjectReference || "-",
  projectTitle,
  proj?.CustomerName || "-",
  forecast.ProfitCentre || "-",
  // ✅ GroupHead1 - Person/Group type
  getGroupHeadDisplayName(proj?.GroupHead1),
  // ✅ ProjectManager - Person/Group type
  getProjectManagerDisplayName(proj?.ProjectManager),
  oblValue,
  
  detailedMonthsData[0]?.plan || 0,
  detailedMonthsData[0]?.current || 0,
  detailedMonthsData[0]?.actual || 0,
  detailedMonthsData[0]?.further || 0,   // backend forecast field
  detailedMonthsData[0]?.total || 0,      // Curr. Plan + Further
];

        const currentMonthItems = detailedMonthsData[0]?.items || createEmptyItems();
        const currentMonthItem = currentMonthItems[itemKey] || { name: '', plan: 0, actual: 0, forecast: 0, date: '' };
        // Further = forecast value from backend
        const furtherValue = currentMonthItem.forecast || 0;
        // Forecast = Curr. Plan + Further
        const itemTotal = (currentMonthItem.actual || 0) + furtherValue;
        rowData.push(
          currentMonthItem.name || `Item ${itemNum}`,
          currentMonthItem.plan,
          currentMonthItem.actual,
          currentMonthItem.forecast || 0,  // Further (backend forecast field)
          furtherValue,                    // Further (same value)
          itemTotal                       // Forecast = Curr. Plan + Further
        );

        rowData.push(
          detailedMonthsData[1]?.plan || 0,
          detailedMonthsData[1]?.current || 0
        );

        const nextMonth1Items = detailedMonthsData[1]?.items || createEmptyItems();
        const nextMonth1Item = nextMonth1Items[itemKey] || { name: '', plan: 0, actual: 0, forecast: 0 };
        const nextMonth1Further = nextMonth1Item.forecast || 0;
        const nextMonth1Total = (nextMonth1Item.actual || 0) + nextMonth1Further;
        rowData.push(
          nextMonth1Item.name || `Item ${itemNum}`,
          nextMonth1Item.plan,
          nextMonth1Item.actual,
          nextMonth1Item.forecast || 0,  // Further (backend forecast field)
          nextMonth1Further,              // Further (same value)
          nextMonth1Total                 // Forecast = Curr. Plan + Further
        );

        rowData.push(
          detailedMonthsData[2]?.plan || 0,
          detailedMonthsData[2]?.current || 0
        );

        const nextMonth2Items = detailedMonthsData[2]?.items || createEmptyItems();
        const nextMonth2Item = nextMonth2Items[itemKey] || { name: '', plan: 0, actual: 0, forecast: 0 };
        const nextMonth2Further = nextMonth2Item.forecast || 0;
        const nextMonth2Total = (nextMonth2Item.actual || 0) + nextMonth2Further;
        rowData.push(
          nextMonth2Item.name || `Item ${itemNum}`,
          nextMonth2Item.plan,
          nextMonth2Item.actual,
          nextMonth2Item.forecast || 0,  // Further (backend forecast field)
          nextMonth2Further,              // Further (same value)
          nextMonth2Total                 // Forecast = Curr. Plan + Further
        );

        nextFifteenMonths.forEach(monthKey => {
          const monthForecastData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
          rowData.push(
            monthForecastData.plan || 0,
            monthForecastData.actual || 0
          );
        });

        lastFiveYears.forEach(year => {
          const yearData = forecastData.yearly?.[year] || { plan: 0, actual: 0 };
          rowData.push(
            yearData.plan,
            yearData.actual
          );
        });

        if (itemNum === 1) {
          rowData.push(balance);
        } else {
          rowData.push("");
        }

        excelData.push(rowData);
      }
    });

    if (excelData.length <= 2) {
      toast("info", "No detailed items data found for export");
      return;
    }
    
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(excelData);

    const mainHeaderStyle = {
      fill: { fgColor: { rgb: "FF0078D4" } },
      font: { name: "Arial", sz: 10, bold: true, color: { rgb: "FFFFFFFF" } },
      alignment: { horizontal: "center", vertical: "center" },
      border: {
        top: { style: "thin", color: { rgb: "FF000000" } },
        left: { style: "thin", color: { rgb: "FF000000" } },
        bottom: { style: "thin", color: { rgb: "FF000000" } },
        right: { style: "thin", color: { rgb: "FF000000" } }
      }
    };

    const subHeaderStyle = {
      fill: { fgColor: { rgb: "FF0056B3" } },
      font: { name: "Arial", sz: 10, bold: true, color: { rgb: "FFFFFFFF" } },
      alignment: { horizontal: "center", vertical: "center" },
      border: {
        top: { style: "thin", color: { rgb: "FF000000" } },
        left: { style: "thin", color: { rgb: "FF000000" } },
        bottom: { style: "thin", color: { rgb: "FF000000" } },
        right: { style: "thin", color: { rgb: "FF000000" } }
      }
    };

    const dataStyle = {
      font: { name: "Arial", sz: 10 },
      alignment: { horizontal: "center", vertical: "center" },
      border: {
        top: { style: "thin", color: { rgb: "FFD0D0D0" } },
        left: { style: "thin", color: { rgb: "FFD0D0D0" } },
        bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
        right: { style: "thin", color: { rgb: "FFD0D0D0" } }
      }
    };

    const numberStyle = {
      ...dataStyle,
      alignment: { horizontal: "right", vertical: "center" }
    };

    const textStyle = {
      ...dataStyle,
      alignment: { horizontal: "left", vertical: "center" }
    };

    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
    
    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      if (!ws[cellAddress]) continue;
      if (!ws[cellAddress].s) ws[cellAddress].s = {};
      ws[cellAddress].s = mainHeaderStyle;
    }
    
    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 1, c: col });
      if (!ws[cellAddress]) continue;
      if (!ws[cellAddress].s) ws[cellAddress].s = {};
      ws[cellAddress].s = subHeaderStyle;
    }
    
    for (let row = range.s.r + 2; row <= range.e.r; row++) {
      for (let col = range.s.c; col <= range.e.c; col++) {
        const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
        if (!ws[cellAddress]) continue;
        
        let styleToApply = dataStyle;
        
        if (col === 0 || col === 1 || col === 2 ||
            col === 12 || col === 21 || col === 30) {
          styleToApply = textStyle;
        } 
        else if (col === 6 ||
                (col >= 7 && col <= 11) ||
                col === 13 || col === 14 || col === 15 || col === 16 || col === 17 || col === 18 || col === 19 || col === 20 ||
                col === 22 || col === 23 ||
                col === 31 || col === 32 ||
                (col >= 33)
        ) {
          styleToApply = numberStyle;
        }
        
        if (!ws[cellAddress].s) {
          ws[cellAddress].s = {};
        }
        ws[cellAddress].s = styleToApply;
      }
    }

    // Updated colWidths - Order: Prev. Plan → Curr. Plan → Actual → Further → Forecast
    const colWidths = [
      { wch: 12 },  // SO/Project Ref
      { wch: 25 },  // Project Name
      { wch: 20 },  // Customer Name
      { wch: 12 },  // Profit Centre
      { wch: 15 },  // Group Head
      { wch: 15 },  // Project Manager
      { wch: 10 },  // OBL
      { wch: 12 },  // Selected Month Prev. Plan
      { wch: 12 },  // Selected Month Curr. Plan
      { wch: 12 },  // Selected Month Actual
      { wch: 12 },  // Selected Month Further
      { wch: 12 },  // Selected Month Forecast
      { wch: 20 },  // Current Month Header
      { wch: 15 },  // Item Description
      { wch: 10 },  // Prev. Plan
      { wch: 10 },  // Curr. Plan
      { wch: 10 },  // Actual
      { wch: 10 },  // Further (backend forecast)
      { wch: 10 },  // Forecast (Curr. Plan + Further)
      { wch: 12 },  // Next Month 1 Prev. Plan
      { wch: 12 },  // Next Month 1 Curr. Plan
      { wch: 20 },  // Next Month 1 Header
      { wch: 15 },  // Item Description
      { wch: 10 },  // Prev. Plan
      { wch: 10 },  // Curr. Plan
      { wch: 10 },  // Actual
      { wch: 10 },  // Further (backend forecast)
      { wch: 10 },  // Forecast (Curr. Plan + Further)
      { wch: 12 },  // Next Month 2 Prev. Plan
      { wch: 12 },  // Next Month 2 Curr. Plan
      { wch: 20 },  // Next Month 2 Header
      { wch: 15 },  // Item Description
      { wch: 10 },  // Prev. Plan
      { wch: 10 },  // Curr. Plan
      { wch: 10 },  // Actual
      { wch: 10 },  // Further (backend forecast)
      { wch: 10 },  // Forecast (Curr. Plan + Further)
    ];

    for (let i = 0; i < nextFifteenMonths.length * 2; i++) {
      colWidths.push({ wch: 12 });
    }

    for (let i = 0; i < lastFiveYears.length * 2; i++) {
      colWidths.push({ wch: 12 });
    }

    colWidths.push({ wch: 12 }); // Balance

    ws['!cols'] = colWidths;

    if (!ws['!merges']) {
      ws['!merges'] = [];
    }

    // Merge headers for Current Month (columns 12-20)
    ws['!merges'].push({ s: { r: 0, c: 12 }, e: { r: 0, c: 20 } });
    // Merge headers for Next Month 1 (columns 22-29)
    ws['!merges'].push({ s: { r: 0, c: 22 }, e: { r: 0, c: 29 } });
    // Merge headers for Next Month 2 (columns 31-38)
    ws['!merges'].push({ s: { r: 0, c: 31 }, e: { r: 0, c: 38 } });

    // Merge rows for each project (10 items per project)
    let currentRow = 2;
    while (currentRow < excelData.length) {
      const endRow = Math.min(currentRow + 9, excelData.length - 1);
      
      // Merge project info columns (0-6) for all 10 items
      for (let col = 0; col < 7; col++) {
        if (currentRow < endRow && ws['!merges']) {
          ws['!merges'].push({ s: { r: currentRow, c: col }, e: { r: endRow, c: col } });
        }
      }
      
      // Merge numeric columns for the 10 items
      const totalColumnsToMerge = [
        7, 8, 9, 10, 11,  // Selected Month values (Prev Plan, Curr Plan, Actual, Further, Forecast)
        21, 22,           // Next Month 1 Prev Plan, Curr Plan
        30, 31,           // Next Month 2 Prev Plan, Curr Plan
      ];
      
      const monthlyStartCol = 39;
      for (let col = monthlyStartCol; col < firstRowHeaders.length; col++) {
        totalColumnsToMerge.push(col);
      }
      
      totalColumnsToMerge.forEach(col => {
        if (currentRow < endRow && ws['!merges']) {
          ws['!merges'].push({ s: { r: currentRow, c: col }, e: { r: endRow, c: col } });
        }
      });
      
      currentRow = endRow + 1;
    }

    // Remove empty cells from merged areas
    for (let col = 13; col <= 20; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      delete ws[cellAddress];
    }
    for (let col = 23; col <= 29; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      delete ws[cellAddress];
    }
    for (let col = 32; col <= 38; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      delete ws[cellAddress];
    }

    ws['!freeze'] = { x: 7, y: 2 };

    XLSX.utils.book_append_sheet(wb, ws, "Detailed Items");

    const monthName = getMonthName(selectedMonth) || selectedMonth;
    const fileName = `Revenue_Forecast_Detailed_Items_${monthName}_${selectedYear}.xlsx`;
    
    XLSX.writeFile(wb, fileName); 
    toast("success", `Exported ${excelData.length - 2} detailed item records`);
    
  } catch (error) { 
    toast("error", "Failed to export detailed items data to Excel");
  }
};

const getLastFiveYearsFromForecastData = (data: RevenueForecastItem[]): string[] => {
  const years = new Set<string>();
  
  data.forEach(forecast => {
    const forecastData = safeJsonParse(forecast.ForecastData, {});
    if (forecastData.yearly) {
      Object.keys(forecastData.yearly).forEach(year => {
        years.add(year);
      });
    }
  });
  
  const sortedYears = Array.from(years).sort();
  return sortedYears.slice(-5);
};

const exportHistoricalToExcel = (): void => {
  const exportData = filteredData.length > 0 ? filteredData : forecasts;
  
  if (exportData.length === 0) {
    toast("error", "No data available to export");
    return;
  }

  try {
    // Get all 36 historical months + current month
    const allMonths = generateIdealMonthStructure();
    const historicalMonths = allMonths.slice(0, 36); // All 36 historical months
    const currentMonthKey = formatMonthKey(new Date());
    
    // Build headers
    const baseHeaders = [
      "Profit Centre",
      "SO/Project Ref",
      "Customer Name",
      "Project Name",
      "Group Head",
      "Project Manager",
      "OBL"
    ];
    
    // Historical month headers (36 months × 2 = 72 columns)
    const historicalHeaders: string[] = [];
    historicalMonths.forEach(monthKey => {
      const [year, month] = monthKey.split('-');
      const monthLabel = getMonthName(month) || month;
      const displayLabel = `${monthLabel} ${year}`;
      historicalHeaders.push(`${displayLabel} (Curr. Plan)`, `${displayLabel} (Revenue Actual)`);
    });
    
    // Current month headers - 5 columns: Prev. Plan, Curr. Plan, Actual, Further, Forecast
    const currentMonthHeaders = [
      `${getMonthName(currentMonthKey.split('-')[1])} ${currentMonthKey.split('-')[0]} (Prev. Plan)`,
      `${getMonthName(currentMonthKey.split('-')[1])} ${currentMonthKey.split('-')[0]} (Curr. Plan)`,
      `${getMonthName(currentMonthKey.split('-')[1])} ${currentMonthKey.split('-')[0]} (Actual)`,
      `${getMonthName(currentMonthKey.split('-')[1])} ${currentMonthKey.split('-')[0]} (Further)`,
      `${getMonthName(currentMonthKey.split('-')[1])} ${currentMonthKey.split('-')[0]} (Forecast)`
    ];
    
    const headers = [...baseHeaders, ...historicalHeaders, ...currentMonthHeaders];

    // Build data rows
    const excelData = exportData.map(forecast => {
      const projectTitle = forecast.Project?.Title || "-";
      const proj = projects.find(p => p.Title === projectTitle);
      
      const forecastData: ForecastData = safeJsonParse(forecast.ForecastData, {});
      const revenueActualData = safeJsonParse(forecast.RevenueActual, {});
      const oblValue = forecast.OBL || 0;
      
      const rowData: any = {
        "Profit Centre": forecast.ProfitCentre || "-",
        "SO/Project Ref": proj?.ProjectReference || "-",
        "Customer Name": proj?.CustomerName || "-",
        "Project Name": projectTitle,
        "Group Head": getGroupHeadDisplayName(proj?.GroupHead1),
  "Project Manager": getProjectManagerDisplayName(proj?.ProjectManager), 
        "OBL": oblValue
      };
      
      // Add historical month data (Curr. Plan and Revenue Actual)
      historicalMonths.forEach(monthKey => {
        const monthData = forecastData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
        const currentValue = monthData.actual || 0;
        const actualValue = revenueActualData[monthKey] || 0;
        
        const [year, month] = monthKey.split('-');
        const monthLabel = getMonthName(month) || month;
        const displayLabel = `${monthLabel} ${year}`;
        
        rowData[`${displayLabel} (Curr. Plan)`] = currentValue;
        rowData[`${displayLabel} (Revenue Actual)`] = actualValue;
      });
      
      // Add current month data
      const currentMonthData = forecastData[currentMonthKey] as ForecastMonthData || { plan: 0, actual: 0, forecast: 0 };
      const currentMonthActual = revenueActualData[currentMonthKey] || 0;
      const currentMonthForecast = currentMonthData.forecast || 0;
      const totalForecast = currentMonthActual + currentMonthForecast;
      
      const monthName = getMonthName(currentMonthKey.split('-')[1]) || currentMonthKey.split('-')[1];
      const yearName = currentMonthKey.split('-')[0];
      const label = `${monthName} ${yearName}`;
      
      rowData[`${label} (Prev. Plan)`] = currentMonthData.plan || 0;
      rowData[`${label} (Curr. Plan)`] = currentMonthData.actual || 0;
      rowData[`${label} (Actual)`] = currentMonthActual;
      rowData[`${label} (Further)`] = currentMonthForecast;
      rowData[`${label} (Forecast)`] = totalForecast;
      
      return rowData;
    });

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(excelData, { header: headers });

    // Styling
    const headerStyle = {
      fill: { fgColor: { rgb: "FF0078D4" } },
      font: { name: "Arial", sz: 10, bold: true, color: { rgb: "FFFFFFFF" } },
      alignment: { horizontal: "center", vertical: "center" },
      border: {
        top: { style: "thin", color: { rgb: "FF000000" } },
        left: { style: "thin", color: { rgb: "FF000000" } },
        bottom: { style: "thin", color: { rgb: "FF000000" } },
        right: { style: "thin", color: { rgb: "FF000000" } }
      }
    };

    const dataStyle = {
      font: { name: "Arial", sz: 10 },
      alignment: { horizontal: "center", vertical: "center" },
      border: {
        top: { style: "thin", color: { rgb: "FFD0D0D0" } },
        left: { style: "thin", color: { rgb: "FFD0D0D0" } },
        bottom: { style: "thin", color: { rgb: "FFD0D0D0" } },
        right: { style: "thin", color: { rgb: "FFD0D0D0" } }
      }
    };

    const numberStyle = {
      ...dataStyle,
      alignment: { horizontal: "right", vertical: "center" }
    };

    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
    
    // Apply header style
    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });
      if (!ws[cellAddress]) continue;
      if (!ws[cellAddress].s) ws[cellAddress].s = {};
      ws[cellAddress].s = headerStyle;
    }
    
    // Apply data styles
    for (let row = range.s.r + 1; row <= range.e.r; row++) {
      for (let col = range.s.c; col <= range.e.c; col++) {
        const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
        if (!ws[cellAddress]) continue;
        
        const isNumberColumn = col >= 6;
        const styleToApply = isNumberColumn ? numberStyle : dataStyle;
        if (!ws[cellAddress].s) ws[cellAddress].s = {};
        ws[cellAddress].s = styleToApply;
      }
    }

    // Column widths
    const colWidths = headers.map((header: string) => {
      if (header.includes('Project Name')) return { wch: 25 };
      if (header.includes('Customer Name')) return { wch: 20 };
      if (header.includes('Profit Centre') || header.includes('SO/Project Ref')) return { wch: 12 };
      if (header.includes('Group Head') || header.includes('Project Manager')) return { wch: 15 };
      if (header.includes('OBL')) return { wch: 12 };
      if (header.includes('Curr. Plan') || header.includes('Revenue Actual') || header.includes('Prev. Plan') || header.includes('Actual') || header.includes('Further') || header.includes('Forecast')) return { wch: 12 };
      return { wch: 12 };
    });
    ws['!cols'] = colWidths;
    ws['!freeze'] = { x: 7, y: 1 };

    XLSX.utils.book_append_sheet(wb, ws, "Historical Revenue");

    const fileName = `Revenue_Historical_36Months_${formatMonthLabel(new Date())}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    toast("success", `Exported ${exportData.length} records with 36 months historical data`);
    
  } catch (error) {
    console.error("Error exporting historical data:", error);
    toast("error", "Failed to export historical data");
  }
};
 
// COMPLETE REPLACEMENT FOR setupPaginationEventListeners
const setupPaginationEventListeners = (): void => {
  pageSize =
    parseInt(pageSizeSelect?.value || "10", 10) ||
    10;

  firstPageBtn.onclick = (): void => {
    goToPage(1);
  };

  prevPageBtn.onclick = (): void => {
    goToPage(currentPage - 1);
  };

  nextPageBtn.onclick = (): void => {
    goToPage(currentPage + 1);
  };

  lastPageBtn.onclick = (): void => {
    goToPage(totalPages);
  };

  if (pageSizeSelect) {
    pageSizeSelect.onchange = (): void => {
      const newPageSize =
        parseInt(pageSizeSelect.value, 10);

      changePageSize(newPageSize);
    };
  }
};

const collectDetailedItemsFromDOM = (
  monthKey: string,
  existingItems:
    | { [itemNumber: string]: ForecastItem }
    | undefined,
  isFrozen: boolean
): { [itemNumber: string]: ForecastItem } => {
  const updatedItems: {
    [itemNumber: string]: ForecastItem;
  } = existingItems
    ? JSON.parse(JSON.stringify(existingItems))
    : {};

  for (let itemNumber = 1; itemNumber <= 10; itemNumber++) {
    const itemKey = itemNumber.toString();

    const nameInput =
      document.querySelector<HTMLInputElement>(
        `.revenue-item-description-input[data-item="${itemKey}"][data-month="${monthKey}"]`
      );

    const planInput =
      document.querySelector<HTMLInputElement>(
        `.revenue-item-plan-input[data-item="${itemKey}"][data-month="${monthKey}"]`
      );

    const currentInput =
      document.querySelector<HTMLInputElement>(
        `.revenue-item-current-input[data-item="${itemKey}"][data-month="${monthKey}"]`
      );

    const furtherInput =
      document.querySelector<HTMLInputElement>(
        `.revenue-item-forecast-input[data-item="${itemKey}"][data-month="${monthKey}"]`
      );

    const dateInput =
      document.querySelector<HTMLInputElement>(
        `.revenue-item-date-input[data-item="${itemKey}"][data-month="${monthKey}"]`
      );

    // Month is not currently rendered.
    if (
      !nameInput &&
      !planInput &&
      !currentInput &&
      !furtherInput &&
      !dateInput
    ) {
      continue;
    }

    const existingItem =
      updatedItems[itemKey] || {
        name: "",
        plan: 0,
        actual: 0,
        forecast: 0,
        date: ""
      };

    updatedItems[itemKey] = {
      // Item is editable in normal and frozen mode.
      name: nameInput
        ? nameInput.value.trim()
        : existingItem.name || "",

      // Preserve Plan when frozen.
      plan: isFrozen
        ? Number(existingItem.plan) || 0
        : planInput
          ? getNumericValue(planInput)
          : Number(existingItem.plan) || 0,

      // Preserve Curr. Plan when frozen.
      actual: isFrozen
        ? Number(existingItem.actual) || 0
        : currentInput
          ? getNumericValue(currentInput)
          : Number(existingItem.actual) || 0,

      // Further is editable in both modes.
      forecast: furtherInput
        ? getNumericValue(furtherInput)
        : Number(existingItem.forecast) || 0,

      // Date is editable in both modes and can be cleared.
      date: dateInput
        ? dateInput.value
        : existingItem.date || ""
    };
  }

  return updatedItems;
};

// COMPLETE REPLACEMENT FOR changePageSize
const changePageSize = (newSize: number): void => {
  if (!newSize || newSize <= 0) {
    return;
  }

  console.log(`📊 Changing page size from ${pageSize} to ${newSize}`);
  console.log(`📊 Current filteredData length: ${filteredData.length}`);
  console.log(`📊 Current page: ${currentPage}`);

  // Update page size
  pageSize = newSize;

  // Reset to page 1 when changing page size
  currentPage = 1;

  // Recalculate total pages using the new page size
  calculateTotalPages();

  // Update pagination UI
  updatePaginationControls();

  // CRITICAL: Force re-render the table with new page data
  renderCurrentPage();

  // Re-render totals header
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);

  toast("info", `Showing ${pageSize} records per page`);
};

// COMPLETE REPLACEMENT FOR renderCurrentPage
const renderCurrentPage = (): void => {
  console.log(`📊 renderCurrentPage called - filteredData length: ${filteredData.length}, pageSize: ${pageSize}, currentPage: ${currentPage}`);
  
  if (!filteredData || filteredData.length === 0) {
    console.log("📊 No data to render");
    renderTableWithMonthColumns([]);
    return;
  }

  // Ensure currentPage is within bounds
  if (currentPage > totalPages) {
    currentPage = totalPages;
  }

  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(startIndex + pageSize, filteredData.length);
  const pageData = filteredData.slice(startIndex, endIndex);
  
  console.log(`📊 Rendering page ${currentPage}: items ${startIndex + 1} to ${endIndex} of ${filteredData.length}`);
  console.log(`📊 Page data length: ${pageData.length}`);
  
  // Force re-render the table
  renderTableWithMonthColumns(pageData);
};

// COMPLETE REPLACEMENT FOR updatePaginationControls
const updatePaginationControls = (): void => {
  console.log(`📊 updatePaginationControls - currentPage: ${currentPage}, totalPages: ${totalPages}, filteredData length: ${filteredData.length}`);
  
  currentPageSpan.textContent = currentPage.toString();
  totalPagesSpan.textContent = totalPages.toString();

  if (filteredData.length === 0) {
    startItemSpan.textContent = '0';
    endItemSpan.textContent = '0';
    totalItemsSpan.textContent = '0';
  } else {
    const startItem = ((currentPage - 1) * pageSize) + 1;
    const endItem = Math.min(currentPage * pageSize, filteredData.length);

    startItemSpan.textContent = startItem.toString();
    endItemSpan.textContent = endItem.toString();
    totalItemsSpan.textContent = filteredData.length.toString();
    
    console.log(`📊 Showing items ${startItem} to ${endItem} of ${filteredData.length}`);
  }

  // Keep dropdown synchronized with actual pageSize - IMPORTANT!
  if (pageSizeSelect) {
    pageSizeSelect.value = pageSize.toString();
    console.log(`📊 Set pageSizeSelect value to: ${pageSize}`);
  }

  firstPageBtn.disabled = currentPage === 1 || filteredData.length === 0;
  prevPageBtn.disabled = currentPage === 1 || filteredData.length === 0;
  nextPageBtn.disabled = currentPage >= totalPages || filteredData.length === 0;
  lastPageBtn.disabled = currentPage >= totalPages || filteredData.length === 0;

  updatePageNumbers();
};

// COMPLETE REPLACEMENT FOR goToPage
const goToPage = (page: number): void => {
  console.log(`📊 goToPage called: ${page}, totalPages: ${totalPages}`);
  
  if (page < 1 || page > totalPages || page === currentPage) return;
  if (filteredData.length === 0) return;
  
  currentPage = page;
  updatePaginationControls();
  renderCurrentPage();
  
  const tableContainer = document.querySelector('.revenue-table-container-rev') as HTMLElement;
  if (tableContainer) {
    tableContainer.scrollTop = 0;
  }
};

// COMPLETE REPLACEMENT FOR initializePagination
const initializePagination = (data: RevenueForecastItem[]): void => { 
  console.log("🔍 initializePagination called with data length:", data.length);
  filteredData = data; 
  console.log("📊 filteredData set to:", filteredData.length);
  
  // Ensure pageSize is set from dropdown
  if (pageSizeSelect) {
    pageSize = parseInt(pageSizeSelect.value) || 10;
  }
  console.log(`📊 Using page size: ${pageSize}`);
  
  // Reset to page 1
  currentPage = 1;
  
  // Calculate total pages
  calculateTotalPages();
  
  // Update pagination controls
  updatePaginationControls();
  
  // Render the first page
  renderCurrentPage();
  
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
};

// COMPLETE REPLACEMENT FOR calculateTotalPages
const calculateTotalPages = (): void => {
  totalPages = Math.ceil(filteredData.length / pageSize);
  if (totalPages === 0) totalPages = 1;
  console.log(`📄 Total pages: ${totalPages} (${filteredData.length} items / ${pageSize} per page)`);
};

// COMPLETE REPLACEMENT FOR updatePageNumbers
const updatePageNumbers = (): void => {
  pageNumbersDiv.innerHTML = '';
  
  if (totalPages <= 1) {
    // Only show page 1 if there's data
    if (filteredData.length > 0) {
      const pageBtn = document.createElement('button');
      pageBtn.className = `revenue-page-number revenue-active`;
      pageBtn.textContent = '1';
      pageBtn.addEventListener('click', () => goToPage(1));
      pageNumbersDiv.appendChild(pageBtn);
    }
    return;
  }
  
  const maxVisiblePages = 5;
  let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
  let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
  
  if (endPage - startPage + 1 < maxVisiblePages) {
    startPage = Math.max(1, endPage - maxVisiblePages + 1);
  }
  
  if (startPage > 1) {
    const dotsBtn = document.createElement('button');
    dotsBtn.className = 'revenue-page-number revenue-dots';
    dotsBtn.textContent = '...';
    dotsBtn.disabled = true;
    pageNumbersDiv.appendChild(dotsBtn);
  }
  
  for (let i = startPage; i <= endPage; i++) {
    const pageBtn = document.createElement('button');
    pageBtn.className = `revenue-page-number ${i === currentPage ? 'revenue-active' : ''}`;
    pageBtn.textContent = i.toString();
    pageBtn.addEventListener('click', () => goToPage(i));
    pageNumbersDiv.appendChild(pageBtn);
  }
  
  if (endPage < totalPages) {
    const dotsBtn = document.createElement('button');
    dotsBtn.className = 'revenue-page-number revenue-dots';
    dotsBtn.textContent = '...';
    dotsBtn.disabled = true;
    pageNumbersDiv.appendChild(dotsBtn);
  }
}; 
 

const calculateTotals = (
  data: RevenueForecastItem[],
  displayMonths: string[],
  currentMonthKey: string
): any => {
  const totals = {
    obl: 0,
    monthly: {} as {
      [key: string]: { plan: number; current: number; actual: number; forecast: number; total: number }
    }
  };

  // Initialize monthly totals
  displayMonths.forEach(monthKey => {
    totals.monthly[monthKey] = { plan: 0, current: 0, actual: 0, forecast: 0, total: 0 };
  });

  data.forEach(forecast => {
    totals.obl += Math.round(Number(forecast.OBL) || 0);

    const forecastData = safeJsonParse(forecast.ForecastData, {});
    const revenueActualData = safeJsonParse(forecast.RevenueActual, {});

    displayMonths.forEach(monthKey => {
      const m = forecastData[monthKey] || {};
      
      // Ensure all values are numbers
      const plan = Math.round(Number(m.plan) || 0);
      const current = Math.round(Number(m.actual) || 0);
      const actual = Math.round(Number(revenueActualData[monthKey]) || 0);
      const forecastVal = Math.round(Number(m.forecast) || 0);

      totals.monthly[monthKey].plan += plan;
      totals.monthly[monthKey].current += current;
      totals.monthly[monthKey].actual += actual;
      totals.monthly[monthKey].forecast += forecastVal;
      
      // ✅ FIX: Forecast = Actual + Further (RevenueActual + forecast field)
      totals.monthly[monthKey].total = totals.monthly[monthKey].actual + totals.monthly[monthKey].forecast;
    });
  });

  return totals;
};
 
const setFormReadOnly = (
  isFrozen: boolean,
  userCanEdit: boolean = true
): void => {
  const setControlState = (
    control: HTMLInputElement | HTMLTextAreaElement,
    editable: boolean,
    highlight: boolean = false
  ): void => {
    control.disabled = false;

    if (editable) {
      control.removeAttribute("readonly");
      control.style.backgroundColor = "#ffffff";
      control.style.color = "#000000";
      control.style.cursor = "text";
      control.style.opacity = "1";
      control.style.pointerEvents = "auto";

      if (highlight) {
        control.style.borderColor = "#28a745";
        control.style.borderWidth = "2px";
        control.style.borderStyle = "solid";
      } else {
        control.style.borderColor = "";
        control.style.borderWidth = "";
        control.style.borderStyle = "";
      }
    } else {
      control.setAttribute("readonly", "true");
      control.style.backgroundColor = "#f5f5f5";
      control.style.color = "#6c757d";
      control.style.cursor = "not-allowed";
      control.style.opacity = "0.7";
      control.style.pointerEvents = "none";
    }
  };

  // Locked when frozen
  const standardInputs =
    document.querySelectorAll<
      HTMLInputElement | HTMLTextAreaElement
    >(
      [
        ".revenue-simple-month-rev .revenue-main-current-input",
        ".revenue-yearly-current-input-rev",
        ".revenue-detailed-month-box .revenue-item-current-input",
        "#remarksInternal",
        "#remarksSprintCell"
      ].join(",")
    );

  const standardEditable =
    userCanEdit && !isFrozen;

  standardInputs.forEach(input => {
    setControlState(
      input,
      standardEditable
    );
  });

  // Detailed main Curr. Plan is calculated from Items
  // and must always remain read-only.
  document
    .querySelectorAll<HTMLInputElement>(
      ".revenue-detailed-month-box .revenue-main-current-input"
    )
    .forEach(input => {
      setControlState(input, false);
    });

  // Item name is editable for authorized users,
  // including when the project is frozen.
  document
    .querySelectorAll<HTMLInputElement>(
      ".revenue-item-description-input"
    )
    .forEach(input => {
      setControlState(
        input,
        userCanEdit,
        isFrozen && userCanEdit
      );
    });

  // Further fields are editable when frozen.
  document
    .querySelectorAll<HTMLInputElement>(
      [
        ".revenue-main-forecast-input",
        ".revenue-item-forecast-input"
      ].join(",")
    )
    .forEach(input => {
      setControlState(
        input,
        userCanEdit,
        isFrozen && userCanEdit
      );
    });

  // Date fields are editable when frozen.
  document
    .querySelectorAll<HTMLInputElement>(
      [
        ".revenue-forecast-date-input",
        ".revenue-item-date-input"
      ].join(",")
    )
    .forEach(input => {
      setControlState(
        input,
        userCanEdit,
        isFrozen && userCanEdit
      );
    });

  // OBL is editable only for a new, unfrozen record.
  const oblInput = document.querySelector(
    "#oblLastMonth"
  ) as HTMLInputElement | null;

  if (oblInput) {
    const oblEditable =
      editingId === null &&
      !isFrozen &&
      userCanEdit;

    setControlState(
      oblInput,
      oblEditable
    );
  }
};
 
const escapeHtml = (value: unknown): string => {
  const characters: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  };

  return String(value ?? "").replace(
    /[&<>"']/g,
    character => characters[character]
  );
};

const buildSortButtons = (
  column: string,
  subColumn?: string,
  monthIndex?: number
): string => {
  const buildButton = (direction: "asc" | "desc"): string => {
    const active =
      currentSortConfig.column === column &&
      currentSortConfig.direction === direction &&
      currentSortConfig.subColumn === subColumn &&
      currentSortConfig.monthIndex === monthIndex;

    const subColumnAttribute = subColumn
      ? `data-subcolumn="${subColumn}"`
      : "";

    const monthIndexAttribute = monthIndex !== undefined
      ? `data-month-index="${monthIndex}"`
      : "";

    return `
      <button
        type="button"
        class="revenue-sort-btn ${
          active
            ? direction === "asc"
              ? "revenue-sort-asc revenue-active"
              : "revenue-sort-desc revenue-active"
            : ""
        }"
        data-sort="${column}"
        data-direction="${direction}"
        ${subColumnAttribute}
        ${monthIndexAttribute}
        title="Sort ${direction === "asc" ? "Ascending" : "Descending"}"
        aria-label="Sort ${direction === "asc" ? "ascending" : "descending"}"
      >
        ${direction === "asc" ? "▲" : "▼"}
      </button>
    `;
  };

  return `
    <div class="revenue-sort-buttons-container">
      ${buildButton("asc")}
      ${buildButton("desc")}
    </div>
  `;
}; 

 // STICKY TABLE HEADER — SAME BEHAVIOUR AS COLLECTION
// totals rows (#totalsHeader) are NOT sticky; only the column headers stick,
// below the totals block, offset by the totals height.
const updateRevenueStickyHeaderOffsets = (): void => {
  const totalsHeader =
    document.querySelector("#totalsHeader") as HTMLElement | null;
  const monthColumnsHeader =
    document.querySelector("#monthColumnsHeader") as HTMLElement | null;

  if (!monthColumnsHeader) return;

  const totalsHeight = totalsHeader ? totalsHeader.offsetHeight : 0;
  let offset = totalsHeight;

  monthColumnsHeader
    .querySelectorAll<HTMLTableRowElement>("tr")
    .forEach(row => {
      row.querySelectorAll<HTMLElement>("th, td").forEach(cell => {
        cell.style.position = "sticky";
        cell.style.top = `${offset}px`;
      });
      offset += row.getBoundingClientRect().height;
    });

  // totals rows: plain, scroll away (no stick on either axis, otherwise the
  // totals cells stay left-stuck while the row scrolls up and tear apart)
  if (totalsHeader) {
    totalsHeader.querySelectorAll<HTMLElement>("th, td").forEach(cell => {
      cell.style.position = "static";
      cell.style.top = "auto";
      cell.style.left = "auto";
      cell.style.zIndex = "";
      cell.classList.remove("revenue-sticky-header-cell");
    });
  }
};
    
 
window.addEventListener("resize", () => {
  clearTimeout((window as any)._revenueStickyResizeTimer);
  (window as any)._revenueStickyResizeTimer = setTimeout(
    updateRevenueStickyHeaderOffsets, 150
  );
});

const renderTotalsHeader = (
  displayMonths: string[],
  currentMonthKey: string
): void => {
  const totalsHeader = document.querySelector(
    "#totalsHeader"
  ) as HTMLElement;

  if (!totalsHeader) return;

  const allData = forecasts;
  const filtered = filteredData.length > 0
    ? filteredData
    : allData;

  const allTotals = calculateTotals(
    allData,
    displayMonths,
    currentMonthKey
  );

  const filteredTotals = calculateTotals(
    filtered,
    displayMonths,
    currentMonthKey
  );

  const hasFilters =
    filteredData.length > 0 &&
    filteredData.length !== allData.length;

  const baseColumns = 7;
  const monthColumns = displayMonths.length * 2;
  const currentMonthExtraColumns =
    displayMonths.includes(currentMonthKey) ? 3 : 0;

  const totalColspan =
    baseColumns +
    monthColumns +
    currentMonthExtraColumns;

  const buildTotalsRow = (
    label: string,
    totals: any,
    cssClass: string
  ): string => {
    const monthCells = displayMonths
      .map(monthKey => {
        const isCurrentMonth =
          monthKey === currentMonthKey;

        const monthTotal =
          totals.monthly[monthKey] || {
            plan: 0,
            current: 0,
            actual: 0,
            forecast: 0,
            total: 0
          };

        if (isCurrentMonth) {
          return `
            <td class="revenue-month-scroll-col">
              ${monthTotal.plan.toLocaleString("en-IN")}
            </td>

            <td class="revenue-month-scroll-col">
              ${monthTotal.current.toLocaleString("en-IN")}
            </td>

            <td class="revenue-month-scroll-col revenue-actual-total-cell">
              ${monthTotal.actual.toLocaleString("en-IN")}
            </td>

            <td class="revenue-month-scroll-col">
              ${monthTotal.forecast.toLocaleString("en-IN")}
            </td>

            <td class="revenue-month-scroll-col revenue-total-value">
              ${monthTotal.total.toLocaleString("en-IN")}
            </td>
          `;
        }

        return `
          <td class="revenue-month-scroll-col">
            ${monthTotal.plan.toLocaleString("en-IN")}
          </td>

          <td class="revenue-month-scroll-col">
            ${monthTotal.current.toLocaleString("en-IN")}
          </td>
        `;
      })
      .join("");

    return `
      <tr class="${cssClass}">
        <!-- Lock -->
        <td class="revenue-freeze-col revenue-total-fixed-cell">
          ${cssClass === "revenue-all-projects-total" ? "★" : "●"}
        </td>

        <!-- Project Reference -->
        <td class="revenue-project-ref-col revenue-total-fixed-cell"></td>

        <!-- Customer -->
        <td class="revenue-customer-col revenue-total-fixed-cell"></td>

        <!-- Project -->
        <td class="revenue-project-col revenue-total-project-cell">
          ${escapeHtml(label)}
        </td>

        <!-- Group Head -->
        <td class="revenue-gh-col revenue-total-fixed-cell"></td>

        <!-- Project Manager -->
        <td class="revenue-pm-col revenue-total-fixed-cell"></td>

        <!-- OBL -->
        <td class="revenue-obl-col revenue-total-obl-cell">
          ${totals.obl.toLocaleString("en-IN")}
        </td>

        ${monthCells}
      </tr>
    `;
  };

  let html = `
    <tr class="revenue-totals-title-row">
      <th colspan="${totalColspan}">
        📊 Revenue Totals
      </th>
    </tr>
  `;

  if (allData.length > 0) {
    html += buildTotalsRow(
      `All Projects (${allData.length})`,
      allTotals,
      "revenue-all-projects-total"
    );
  }

  if (hasFilters && filtered.length > 0) {
    html += buildTotalsRow(
      `Filtered (${filtered.length})`,
      filteredTotals,
      "revenue-filtered-total"
    );
  }

  totalsHeader.innerHTML = html;
  updateRevenueStickyHeaderOffsets();
};

  

// Move attachEditTriggerListeners BEFORE renderTableWithMonthColumns
const attachEditTriggerListeners = (): void => {
  document.querySelectorAll('.revenue-edit-trigger').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const id = parseInt((e.currentTarget as HTMLElement).dataset.id!);
      editForecast(id);
    });
  });
};
// COMPLETE REPLACEMENT FOR renderTableWithMonthColumns
const renderTableWithMonthColumns = (
  data: RevenueForecastItem[]
): void => {
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());

  const totalColumns =
    7 +
    displayMonths.length * 2 +
    (displayMonths.includes(currentMonthKey) ? 3 : 0);

  const monthMainHeaders = displayMonths
    .map((monthKey, monthIndex) => {
      const isCurrentMonth =
        monthKey === currentMonthKey;

      const monthDate = new Date(`${monthKey}-01`);
      const monthLabel = formatMonthLabel(monthDate);
      const colspan = isCurrentMonth ? 5 : 2;

      return `
        <th
          colspan="${colspan}"
          class="
            revenue-month-scroll-col
            revenue-month-column-header
            ${isCurrentMonth ? "revenue-current-month-header" : ""}
          "
        >
          <div class="revenue-sort-header-container">
            <span class="revenue-header-label">
              ${monthLabel}
              ${isCurrentMonth ? " (Current Month)" : ""}
            </span>

            ${buildSortButtons(
              "month",
              undefined,
              monthIndex
            )}
          </div>
        </th>
      `;
    })
    .join("");

  const monthSubHeaders = displayMonths
    .map((monthKey, monthIndex) => {
      const isCurrentMonth =
        monthKey === currentMonthKey;

      const columns: Array<{
        label: string;
        sort: string;
      }> = isCurrentMonth
        ? [
            { label: "Prev. Plan", sort: "plan" },
            { label: "Curr. Plan", sort: "current" },
            { label: "Actual", sort: "actual" },
            { label: "Further", sort: "forecast" },
            { label: "Forecast", sort: "total" }
          ]
        : [
            { label: "Prev. Plan", sort: "plan" },
            { label: "Curr. Plan", sort: "current" }
          ];

      return columns
        .map(column => `
          <th
            class="
              revenue-month-scroll-col
              revenue-month-subheader
              ${
                isCurrentMonth
                  ? "revenue-current-month-header-table"
                  : ""
              }
            "
          >
            <div class="revenue-sort-header-container">
              <span>${column.label}</span>

              ${buildSortButtons(
                "month",
                column.sort,
                monthIndex
              )}
            </div>
          </th>
        `)
        .join("");
    })
    .join("");

  // Correct fixed-header sequence:
  // Lock, PR, Customer, Project, GH, PM, OBL
  monthColumnsHeader.innerHTML = `
    <tr class="revenue-main-column-header-row">
      <th
        rowspan="2"
        class="revenue-freeze-col"
      >
        #
      </th>

      <th
        rowspan="2"
        class="revenue-project-ref-col"
      >
        Project Reference
      </th>

      <th
        rowspan="2"
        class="revenue-customer-col"
      >
        <div class="revenue-sort-header-container">
          <span class="revenue-header-label">
            Customer
          </span>

          ${buildSortButtons("customer")}
        </div>
      </th>

      <th
        rowspan="2"
        class="revenue-project-col"
      >
        <div class="revenue-sort-header-container">
          <span class="revenue-header-label">
            Project
          </span>

          ${buildSortButtons("project")}
        </div>
      </th>

      <th
        rowspan="2"
        class="revenue-gh-col"
      >
        Group Head
      </th>

      <th
        rowspan="2"
        class="revenue-pm-col"
      >
        Project Manager
      </th>

      <th
        rowspan="2"
        class="revenue-obl-col"
      >
        <div class="revenue-sort-header-container">
          <span class="revenue-header-label">
            OBL
          </span>

          ${buildSortButtons("obl")}
        </div>
      </th>

      ${monthMainHeaders}
    </tr>

    <tr class="revenue-month-subheader-row">
      ${monthSubHeaders}
    </tr>
  `;

  const validData = (data || []).filter(forecast => {
    const projectTitle = forecast.Project?.Title;
    return Boolean(projectTitle?.trim());
  });

  if (validData.length === 0) {
    const totalsHeader = document.querySelector(
      "#totalsHeader"
    ) as HTMLElement;

    if (totalsHeader) {
      totalsHeader.innerHTML = "";
    }

    tableBody.innerHTML = `
      <tr>
        <td
          colspan="${totalColumns}"
          class="revenue-no-records-cell"
        >
          No records found
        </td>
      </tr>
    `;

    attachSortButtonListeners();
    updateRevenueStickyHeaderOffsets();
    return;
  }

  renderTotalsHeader(
    displayMonths,
    currentMonthKey
  );

  let tableBodyHTML = "";

  validData.forEach(forecast => {
    const projectTitle =
      forecast.Project?.Title || "Unknown Project";

    const project = projects.find(
      item => item.Title === projectTitle
    );

    const forecastData: ForecastData =
      safeJsonParse(forecast.ForecastData, {});

    const revenueActualData: Record<string, number> =
      safeJsonParse(forecast.RevenueActual, {});

    const formattedOBL = Math.round(
      Number(forecast.OBL) || 0
    ).toLocaleString("en-IN");

    const isFrozen = forecast.Freeze === true;
    const canUserEdit =
      canEditProject(project, forecast);

    const canUserFreeze = canFreeze();
    const checkboxDisabled = !canUserFreeze;

    const projectReference =
      getSafeString(project?.ProjectReference);

    // PR remains the edit link
    const projectReferenceContent =
      projectReference !== "-"
        ? canUserEdit
          ? `
            <a
              href="#"
              class="revenue-edit-trigger"
              data-id="${forecast.Id}"
            >
              ${escapeHtml(projectReference)}
            </a>
          `
          : `
            <span class="revenue-readonly-value">
              ${escapeHtml(projectReference)}
            </span>
          `
        : `<span class="revenue-empty-value">-</span>`;

    // Project is plain text: no hyperlink
    const projectContent = `
      <span class="revenue-project-plain-text">
        ${escapeHtml(projectTitle)}
      </span>
      ${isFrozen ? '<span title="Frozen"> 🔒</span>' : ""}
    `;

    const customerName =
      getSafeString(project?.CustomerName);

    const groupHeadName =
      getGroupHeadDisplayName(
        project?.GroupHead1
      ) || "-";

    const projectManagerName =
      getProjectManagerDisplayName(
        project?.ProjectManager
      ) || "-";

    let rowHTML = `
      <tr
        data-forecast-id="${forecast.Id}"
        class="${isFrozen ? "revenue-frozen-row" : ""}"
      >
        <!-- Lock -->
        <td class="revenue-freeze-col">
          <input
            type="checkbox"
            class="revenue-freeze-checkbox"
            data-id="${forecast.Id}"
            data-freeze="${isFrozen}"
            ${isFrozen ? "checked" : ""}
            ${checkboxDisabled ? "disabled" : ""}
            title="${
              canUserFreeze
                ? "Toggle freeze status"
                : "Freeze permission restricted"
            }"
          />
        </td>

        <!-- Project Reference -->
        <td class="revenue-project-ref-col">
          ${projectReferenceContent}
        </td>

        <!-- Customer -->
        <td class="revenue-customer-col">
          ${escapeHtml(customerName)}
        </td>

        <!-- Project: no hyperlink -->
        <td class="revenue-project-col">
          ${projectContent}
        </td>

        <!-- Group Head -->
        <td class="revenue-gh-col">
          ${escapeHtml(groupHeadName)}
        </td>

        <!-- Project Manager -->
        <td class="revenue-pm-col">
          ${escapeHtml(projectManagerName)}
        </td>

        <!-- OBL -->
        <td class="revenue-obl-col">
          ${formattedOBL}
        </td>
    `;

    displayMonths.forEach(monthKey => {
      const monthData =
        forecastData[monthKey] as
          | ForecastMonthData
          | undefined;

      const planValue =
        Number(monthData?.plan) || 0;

      const currentValue =
        Number(monthData?.actual) || 0;

      const isCurrentMonth =
        monthKey === currentMonthKey;

      if (isCurrentMonth) {
        const actualValue =
          Number(revenueActualData[monthKey]) || 0;

        const furtherValue =
          Number(monthData?.forecast) || 0;

        const forecastValue =
          actualValue + furtherValue;

        rowHTML += `
          <td class="revenue-month-scroll-col">
            ${planValue.toLocaleString("en-IN")}
          </td>

          <td class="revenue-month-scroll-col">
            ${currentValue.toLocaleString("en-IN")}
          </td>

          <td class="revenue-month-scroll-col revenue-actual-cell">
            ${actualValue.toLocaleString("en-IN")}
          </td>

          <td class="revenue-month-scroll-col">
            ${furtherValue.toLocaleString("en-IN")}
          </td>

          <td class="revenue-month-scroll-col revenue-total-cell">
            ${forecastValue.toLocaleString("en-IN")}
          </td>
        `;
      } else {
        rowHTML += `
          <td class="revenue-month-scroll-col">
            ${planValue.toLocaleString("en-IN")}
          </td>

          <td class="revenue-month-scroll-col">
            ${currentValue.toLocaleString("en-IN")}
          </td>
        `;
      }
    });

    rowHTML += `</tr>`;
    tableBodyHTML += rowHTML;
  });

  tableBody.innerHTML = tableBodyHTML;

  attachSortButtonListeners();
  attachFreezeEventListeners();
  attachEditTriggerListeners();
  updateRevenueStickyHeaderOffsets();
};

const attachSortButtonListeners = (): void => {
  document.querySelectorAll('.revenue-sort-btn[data-sort]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const button = e.currentTarget as HTMLButtonElement;
      const sortColumn = button.dataset.sort;
      const direction = button.dataset.direction as 'asc' | 'desc';
      const subColumn = button.dataset.subcolumn;
      const monthIndex = button.dataset.monthIndex ? parseInt(button.dataset.monthIndex) : undefined;
      
      if (sortColumn && direction) {
        handleRevenueSort(sortColumn, direction, subColumn, monthIndex);
      }
    });
  });
};


const attachFreezeEventListeners = (): void => {
  console.log("🔧 Attaching freeze event listeners...");
  
  const checkboxes = document.querySelectorAll('.revenue-freeze-checkbox');
  const canUserFreeze = canFreeze();
  
  checkboxes.forEach(checkbox => {
    const cb = checkbox as HTMLInputElement;
    
    // Remove existing listeners
    cb.onchange = null;
    
    // Force proper checkbox appearance
    cb.style.pointerEvents = canUserFreeze ? 'auto' : 'none';
    cb.style.cursor = canUserFreeze ? 'pointer' : 'not-allowed';
    cb.style.opacity = canUserFreeze ? '1' : '0.6';
    cb.style.display = 'inline-block';
    cb.style.width = '18px';
    cb.style.height = '18px';
    cb.style.accentColor = '#0078d4';
    cb.style.verticalAlign = 'middle';
    cb.style.position = 'relative';
    cb.style.zIndex = '100';
    cb.style.margin = '0 auto';
    
    // Set checked state
    const isFrozen = cb.dataset.freeze === 'true';
    cb.checked = isFrozen;
    
    // Set disabled based on permission
    cb.disabled = !canUserFreeze;
    
    console.log(`✅ Checkbox ${cb.dataset.id} rendered, checked: ${cb.checked}, disabled: ${cb.disabled}`);
    
    // Only attach change listener if NOT disabled
    if (!cb.disabled) {
      cb.addEventListener('change', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const target = e.target as HTMLInputElement;
        const id = parseInt(target.dataset.id!);
        const isChecked = target.checked;
        
        console.log(`🔄 Checkbox changed: ID=${id}, checked=${isChecked}`);
        
        // Verify user has permission (double-check)
        if (!canFreeze()) {
          toast("error", "❌ You don't have permission to freeze/unfreeze projects");
          target.checked = !isChecked;
          return;
        }
        
        // Get the forecast
        const forecast = forecasts.find(f => f.Id === id);
        if (!forecast) {
          toast("error", "Forecast not found");
          target.checked = !isChecked;
          return;
        }
        
        try {
          const digest = await getDigest();
          const entityType = await getListEntityType();
          
          // Create payload
          const payload = {
            __metadata: { type: entityType },
            Freeze: isChecked
          };
          
          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${id})`, {
            method: "POST",
            headers: {
              Accept: "application/json;odata=verbose",
              "Content-Type": "application/json;odata=verbose",
              "X-RequestDigest": digest,
              "IF-MATCH": "*",
              "X-HTTP-Method": "MERGE"
            },
            body: JSON.stringify(payload)
          });
          
          if (res.ok) {
            // Update the freeze status
            forecast.Freeze = isChecked;
            
            // Update filteredData
            const filteredForecast = filteredData.find(f => f.Id === id);
            if (filteredForecast) {
              filteredForecast.Freeze = isChecked;
            }
            
            // If this is the currently edited project, update the form
            const currentEditingId = editingId;
            if (currentEditingId === id) {
              const editedProject = projects.find(
  project =>
    project.Id === forecast.Project?.Id
);

setFormReadOnly(
  isChecked,
  canEditProject(editedProject, forecast)
);
            }
            
            toast("success", `Project ${isChecked ? 'frozen' : 'unfrozen'} successfully`);
            
            // Re-render table
            renderCurrentPage();
          } else {
            const errorText = await res.text();
            console.error("❌ Error response:", errorText);
            toast("error", "Failed to update freeze status");
            target.checked = !isChecked;
          }
        } catch (error) {
          console.error("Error updating freeze status:", error);
          toast("error", "Failed to update freeze status");
          target.checked = !isChecked;
        }
      });
    }
  });
};
 
const getListEntityType = async (): Promise<string> => {
  try {
    const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`, {
      headers: { Accept: "application/json;odata=verbose" },
    });
    const data = await res.json();
    return data.d.ListItemEntityTypeFullName;
  } catch (error) {
    console.error("Error getting entity type:", error);
    // Fallback to a common type name
    return "SP.Data.Revenue_x0020_Forecast_x0020_ListListItem";
  }
};   

      const handleRevenueSort = (column: string, direction: 'asc' | 'desc', subColumn?: string, monthIndex?: number): void => {
        currentSortConfig = {
          column,
          direction,
          subColumn,
          monthIndex
        };

        const dataToSort = filteredData.length > 0 ? filteredData : forecasts;
        
        if (dataToSort.length === 0) return;

        const sortedData = [...dataToSort].sort((a, b) => {
          let valueA: any = 0;
          let valueB: any = 0;

          switch (column) {
            case 'obl':
              valueA = a.OBL || 0;
              valueB = b.OBL || 0;
              break;
            
             case "month": {
  const displayMonths = getDisplayMonths();

  const selectedMonthIndex =
    monthIndex !== undefined
      ? monthIndex
      : 0;

  const monthKey =
    displayMonths[selectedMonthIndex];

  const forecastDataA: ForecastData =
    safeJsonParse(a.ForecastData, {});

  const forecastDataB: ForecastData =
    safeJsonParse(b.ForecastData, {});

  const revenueActualA: Record<string, number> =
    safeJsonParse(a.RevenueActual, {});

  const revenueActualB: Record<string, number> =
    safeJsonParse(b.RevenueActual, {});

  const monthDataA =
    forecastDataA[monthKey] as
      | ForecastMonthData
      | undefined;

  const monthDataB =
    forecastDataB[monthKey] as
      | ForecastMonthData
      | undefined;

  switch (subColumn) {
    case "plan":
      valueA = Number(monthDataA?.plan) || 0;
      valueB = Number(monthDataB?.plan) || 0;
      break;

    case "current":
      valueA = Number(monthDataA?.actual) || 0;
      valueB = Number(monthDataB?.actual) || 0;
      break;

    case "actual":
      valueA = Number(revenueActualA[monthKey]) || 0;
      valueB = Number(revenueActualB[monthKey]) || 0;
      break;

    case "forecast":
      // Further
      valueA = Number(monthDataA?.forecast) || 0;
      valueB = Number(monthDataB?.forecast) || 0;
      break;

    case "total":
      // Forecast = Actual + Further
      valueA =
        (Number(revenueActualA[monthKey]) || 0) +
        (Number(monthDataA?.forecast) || 0);

      valueB =
        (Number(revenueActualB[monthKey]) || 0) +
        (Number(monthDataB?.forecast) || 0);
      break;

    default:
      valueA = Number(monthDataA?.actual) || 0;
      valueB = Number(monthDataB?.actual) || 0;
  }

  break;
}

            case 'project':
              valueA = a.Project?.Title || "";
              valueB = b.Project?.Title || "";
              break;
            
            case 'customer':
              const projA = projects.find(p => p.Title === a.Project?.Title);
              const projB = projects.find(p => p.Title === b.Project?.Title);
              valueA = projA?.CustomerName || "";
              valueB = projB?.CustomerName || "";
              break;
            
            default:
              return 0;
          }

          if (typeof valueA === 'number' && typeof valueB === 'number') {
            return direction === 'asc' ? valueA - valueB : valueB - valueA;
          } else {
            const strA = String(valueA).toLowerCase();
            const strB = String(valueB).toLowerCase();
            return direction === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
          }
        });

        if (filteredData.length > 0) {
          filteredData = sortedData;
        } else {
          forecasts = sortedData;
        }

        currentPage = 1;
        updatePaginationControls();
        renderCurrentPage();
        
        const sortDirectionText = direction === 'asc' ? 'Ascending' : 'Descending';
        let columnName = '';
        
        if (subColumn) {
          const subColNames: Record<string, string> = {
              plan: "Prev. Plan",
              current: "Curr. Plan",
              actual: "Actual",
              forecast: "Further",
              total: "Forecast"
            };
          columnName = subColNames[subColumn] || subColumn;
        } else if (column === 'obl') {
          columnName = 'OBL';
        } else if (column === 'project') {
          columnName = 'Project';
        } else if (column === 'customer') {
          columnName = 'Customer';
        } else {
          const displayMonths = getDisplayMonths();
          const monthIndexToUse = monthIndex !== undefined ? monthIndex : 0;
          const monthKey = displayMonths[monthIndexToUse];
          const monthDate = new Date(monthKey + "-01");
          columnName = formatMonthLabel(monthDate);
        }
        
        toast("info", `Sorted by ${columnName} (${sortDirectionText})`);
      };

const clearFilters = (): void => {
  filterYear.value = "";
  filterMonth.value = "";
  filterProject.value = "";
  filterCustomer.value = "";
  filterProjectManager.value = "";
  filterGroupHead.value = "";
  filterProjectReference.value = "";
  
  currentSortConfig = {
    column: '',
    direction: 'asc'
  };
  
  // ✅ After clearing, re-apply the project filter
  filterTable();
  
  const displayMonths = getDisplayMonths();
  const currentMonthKey = formatMonthKey(new Date());
  setTimeout(() => {
    renderTotalsHeader(displayMonths, currentMonthKey);
  }, 100);
  
  toast("info", "All filters cleared");
};

const showForm = (isEditMode: boolean = false, project?: ProjectItem, forecast?: RevenueForecastItem): void => {
  // Check if user can view this form
  if (!canViewForm(isEditMode, project, forecast)) {
    if (!canRead()) {
      toast("error", "❌ You don't have permission to access this form");
      return;
    }
    if (isEditMode && !canEditProject(project, forecast)) {
      toast("error", "❌ You don't have permission to edit this project");
      return;
    }
    toast("error", "❌ You don't have permission to create forecasts");
    return;
  }

  // ✅ FIX: Show form section, hide table section
  if (formSection) {
    formSection.style.display = "block";
    formSection.style.visibility = "visible";
    formSection.style.opacity = "1";
  }
  
  if (tableSection) {
    tableSection.style.display = "none";
  }
  
  // Show/hide save button based on permissions
  const saveBtn = document.querySelector('.revenue-btn-primary[type="submit"]') as HTMLElement;
  if (saveBtn) {
    const canSave = isEditMode ? canEditProject(project, forecast) : canCreateForecast();
    saveBtn.style.display = canSave ? '' : 'none';
  }
  
  if (isEditMode) {
    formSection?.classList.add('revenue-edit-mode');
    if (projectSelect) {
      projectSelect.disabled = true;
    }
    if (formTitle) {
      formTitle.textContent = "Edit Forecast";
    }
  } else {
    formSection?.classList.remove('revenue-edit-mode');
    if (projectSelect) {
      projectSelect.disabled = false;
    }
    if (formTitle) {
      formTitle.textContent = "Add Forecast";
    }
  }
  
  // ✅ Force scroll to form
  setTimeout(() => {
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, 100);
};

      const hideForm = (): void => {
        formSection.style.display = "none";
        tableSection.style.display = "block";
        
        formSection.classList.remove('revenue-edit-mode');
        projectSelect.disabled = false;
      };

      const resetForm = (): void => {
        editingId = null;
        form.reset();
        projectSelect.value = "";
        projectDetails.innerHTML = "";
        historicalContainer.innerHTML = "";
        firstRowContainer.innerHTML = "";
        remainingContainer.innerHTML = "";
        yearlyContainer.innerHTML = "";

        if (remarksInternal) {
          remarksInternal.value = "";
        }
        if (remarksSprintCell) {
          remarksSprintCell.value = "";
        }
        
        toggleForecastSections(false);
  
        const oblContainer = document.querySelector('.revenue-obl-section-container') as HTMLElement;
        oblContainer.className = 'revenue-obl-section-container revenue-hidden-section';
        oblLastMonthInput.removeAttribute('readonly');
        oblLastMonthInput.placeholder = "Enter OBL";
        setNumericValue(oblLastMonthInput, 0);
        
        const fieldNote = oblContainer.querySelector('.revenue-field-note') as HTMLElement;
        if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
        
        oblValidationMessage.textContent = "✅ All values are within OBL limit";
        oblValidationMessage.className = 'revenue-validation-message';
        
        updateOBLValidationDisplay();
      };
 
 
 

      const blockAllCurrentInputs = (): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>('input[data-type="actual"]:not([readonly])');
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.revenue-yearly-current-input-rev:not([readonly])');
        
        currentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
        
        yearlyCurrentInputs.forEach(input => {
          input.setAttribute('readonly', 'true');
          input.style.backgroundColor = '#f8f9fa';
          input.style.cursor = 'not-allowed';
        });
      };

      const blockIncreasingCurrentInputs = (allowedInput?: HTMLInputElement): void => {
        const currentInputs = document.querySelectorAll<HTMLInputElement>(
  'input.revenue-item-current-input:not([readonly])'
);
        const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>('input.revenue-yearly-current-input-rev:not([readonly])');
        
        currentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
        
        yearlyCurrentInputs.forEach(input => {
          if (input === allowedInput) {
            input.style.backgroundColor = '';
            input.style.cursor = '';
            input.removeAttribute('readonly');
          } else {
            input.setAttribute('data-block-increase', 'true');
            input.style.backgroundColor = '#fff3cd';
            input.style.cursor = 'not-allowed';
          }
        });
      };

const unblockAllCurrentInputs = (): void => {

  // Editable Current Plan inputs
  // Long-term Forecast + 5-Year Forecast
  const currentInputs = document.querySelectorAll<HTMLInputElement>(
    'input.revenue-item-current-input'
  );

  const yearlyCurrentInputs = document.querySelectorAll<HTMLInputElement>(
    'input.revenue-yearly-current-input-rev'
  );

  currentInputs.forEach(input => {
    input.style.backgroundColor = '';
    input.style.cursor = '';
    input.removeAttribute('data-block-increase');

    // Editable
    input.removeAttribute('readonly');
  });

  yearlyCurrentInputs.forEach(input => {
    input.style.backgroundColor = '';
    input.style.cursor = '';
    input.removeAttribute('data-block-increase');

    // Editable
    input.removeAttribute('readonly');
  });

  // IMPORTANT:
  // Detailed Forecast main Curr. Plan must stay readonly.
  document.querySelectorAll<HTMLInputElement>(
    '.revenue-detailed-month-box .revenue-main-current-input'
  ).forEach(input => {
    input.setAttribute('readonly', 'true');
    input.style.cursor = 'default';
  });
};

      const allowInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
        const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
        const isIncreasing = newValue > oldValue;
        
        if (!isIncreasing) {
          return true;
        }
        
        const oblValue = getNumericValue(oblLastMonthInput);
        const currentTotal = calculateTotalCurrentValue();
        const increaseAmount = newValue - oldValue;
        
        return (currentTotal + increaseAmount) <= oblValue;
      };

      const allowItemInputIncrease = (input: HTMLInputElement, newValue: number): boolean => {
        const oldValue = parseInt(input.getAttribute('data-old-value') || '0');
        const isIncreasing = newValue > oldValue;
        
        if (!isIncreasing) {
            return true;
        }
        
        const monthKey = input.dataset.month!;
        const mainCurrentInput = document.querySelector<HTMLInputElement>(`input.revenue-main-current-input[data-month="${monthKey}"]`);
        
        if (!mainCurrentInput) return true;
        
        const mainCurrentValue = getNumericValue(mainCurrentInput);
        const itemCurrentInputs = document.querySelectorAll<HTMLInputElement>(`input.revenue-item-current-input[data-month="${monthKey}"]`);
        
        let currentItemsTotal = 0;
        itemCurrentInputs.forEach(itemInput => {
            if (itemInput === input) {
                currentItemsTotal += newValue;
            } else {
                currentItemsTotal += getNumericValue(itemInput);
            }
        });
        
        return currentItemsTotal <= mainCurrentValue;
      };

      const validateMonthItemTotals = (changedInput?: HTMLInputElement): boolean => {
        let allValid = true;
        
        for (let i = 3; i <= 5; i++) {
          if (i < allMonths.length) {
            const monthKey = allMonths[i];
            const monthValid = validateSingleMonthItems(monthKey, changedInput);
            if (!monthValid) {
              allValid = false;
            }
          }
        }
        
        return allValid;
      };

      const validateSingleMonthItems = (monthKey: string, changedInput?: HTMLInputElement): boolean => {
       
        
        return true;
      
      };

      // const blockIncreasingMonthItemInputs = (monthKey: string, allowedInput?: HTMLInputElement): void => {
         
      // };

      // const unblockAllMonthItemInputs = (monthKey: string): void => {
      //   const itemInputs = document.querySelectorAll<HTMLInputElement>(`input.revenue-item-current-input[data-month="${monthKey}"]`);
        
      //   itemInputs.forEach(input => {
      //       input.style.backgroundColor = '';
      //       input.style.cursor = '';
      //       input.removeAttribute('data-block-increase');
      //       input.removeAttribute('readonly');
      //   });
      // };

     

      const onProjectChange = (projectId: number, existingForecast?: RevenueForecastItem): void => {
        const project = projects.find(p => p.Id === projectId);
        if (!project) return;

        toggleForecastSections(true);

        renderProjectDetails(project);
        
        let forecastData: ForecastData = {};
        if (existingForecast) {
          forecastData = safeJsonParse(existingForecast.ForecastData, {});
        }

        const isNewProject = !existingForecast;
        
        const oblContainer = document.querySelector('.revenue-obl-section-container') as HTMLElement;
        const fieldNote = oblContainer.querySelector('.revenue-field-note') as HTMLElement;
        
        if (isNewProject) {
          oblContainer.className = 'revenue-obl-section-container revenue-visible-section revenue-new-project';
          oblLastMonthInput.removeAttribute('readonly');
          oblLastMonthInput.placeholder = "Enter initial OBL for new project";
          if (fieldNote) fieldNote.textContent = "For new projects: Enter initial OBL value";
          oblValidationMessage.textContent = "Enter initial OBL value for new project";
          oblValidationMessage.className = 'revenue-validation-message';
          
          const defaultOBL = project.PC ? 100000 : 0;
          setNumericValue(oblLastMonthInput, defaultOBL);
        } else {
          oblContainer.className = 'revenue-obl-section-container revenue-visible-section revenue-existing-project';
          oblLastMonthInput.setAttribute('readonly', 'true');
          
          const oblValue = existingForecast?.OBL || 0;
          setNumericValue(oblLastMonthInput, oblValue);
          
          oblLastMonthInput.placeholder = "OBL from database";
          if (fieldNote) fieldNote.textContent = "OBL value from database record";
          
          if (oblValue > 0) {
            oblLastMonthInput.value = oblValue.toString();
            oblLastMonthInput.className = oblLastMonthInput.className.replace('revenue-input-empty', 'revenue-input-with-value');
          }
        }

        renderForecastInterface(forecastData, getNumericValue(oblLastMonthInput), existingForecast);
      };

      const toggleForecastSections = (show: boolean): void => {
        const sections = [
          '.revenue-obl-section-container',
          '#historicalForecastSection',
          '#detailedForecastSection', 
          '#longtermForecastSection',
          '#yearlyForecastSection'
        ];
        
        sections.forEach(selector => {
          const element = document.querySelector(selector) as HTMLElement;
          if (element) {
            if (show) {
              element.classList.remove('revenue-hidden-section');
              element.classList.add('revenue-visible-section');
            } else {
              element.classList.remove('revenue-visible-section');
              element.classList.add('revenue-hidden-section');
            }
          }
        });
      };

const renderProjectDetails = (project: ProjectItem): void => {

   const canEdit = canEditProject(project);
  
  // Update Project Name
  const projectNameDisplay = document.querySelector('#projectNameDisplay');
  if (projectNameDisplay) {
    projectNameDisplay.textContent = project.Title || "-";
    // Add lock icon if read-only
    if (!canEdit) {
      projectNameDisplay.innerHTML = `${project.Title || "-"} 🔒`;
    }
  }
  
  // Update Project Name (this should be the FIRST row) 
  if (projectNameDisplay) projectNameDisplay.textContent = project.Title || "-";
  
  // Update Project Ref (this should be the SECOND row)  
  const projectRef = document.querySelector('#projectRef');
  if (projectRef) projectRef.textContent = project.ProjectReference || "-";
  
  // Update Profit Center (third row)
  const profitCenter = document.querySelector('#profitCenter');
  if (profitCenter) profitCenter.textContent = project.PC || "-";
  
  // Update Project Manager (fourth row)
   const projectManager = document.querySelector('#projectManager');
  if (projectManager) {
    projectManager.textContent = getProjectManagerDisplayName(project.ProjectManager) || "-";
  }
  
  // ✅ Group Head - Person/Group type
  const groupHead = document.querySelector('#groupHead');
  if (groupHead) {
    groupHead.textContent = getGroupHeadDisplayName(project.GroupHead1) || "-";
  }
  // Update Customer (sixth row)
  const customer = document.querySelector('#customer');
  if (customer) customer.textContent = project.CustomerName || "-";
};
const getForecastMonths = (): string[] => {
  return generateIdealMonthStructure(); // This should generate 36+ months
};

// COMPLETE REPLACEMENT FOR renderForecastInterface
const renderForecastInterface = (existingData: ForecastData, displayOBL: number, existingForecast?: RevenueForecastItem): void => {
    allMonths = getForecastMonths();
    
    setNumericValue(oblLastMonthInput, displayOBL);
    
    // IMPORTANT: Get all existing months from the data to preserve them
    const existingMonths = Object.keys(existingData).filter(key => key.match(/^\d{4}-\d{2}$/));
    
    // Get all 54 months
    const allStorageMonths = generateIdealMonthStructure();
    
    // Store ALL 36 historical months
    const storeHistoricalMonths = allStorageMonths.slice(0, 36);
    const displayHistoricalMonths = allStorageMonths.slice(33, 36);
    
    // Ensure ALL historical months exist in the data (preserve existing values)
    storeHistoricalMonths.forEach((monthKey) => {
        if (!existingData[monthKey]) {
            existingData[monthKey] = {
                plan: 0,
                actual: 0,
                items: {}
            };
        } else {
            // Keep existing data, don't overwrite
            // Just ensure items exists
            const monthData = existingData[monthKey] as ForecastMonthData;
            if (!monthData.items) {
                monthData.items = {};
            }
        }
    });
    
    // Also preserve any months that might be outside the ideal structure
    existingMonths.forEach(monthKey => {
        if (!storeHistoricalMonths.includes(monthKey) && 
            !allStorageMonths.slice(36).includes(monthKey)) {
            if (!existingData[monthKey]) {
                existingData[monthKey] = {
                    plan: 0,
                    actual: 0,
                    items: {}
                };
            }
        }
    });
    
    // Render only the LAST 3 months in the UI
    renderHistoricalMonths(displayHistoricalMonths, existingData);
    
    setTimeout(() => {
        setupHistoricalToggle();
    }, 50);
    
    // Pass existingForecast to get RevenueActual for current month
    renderFirstRow(allStorageMonths.slice(36, 39), existingData, existingForecast);
    renderRemainingMonths(allStorageMonths.slice(39), existingData);
    renderYearlyForecast(existingData.yearly || createFreshYearlyStructure(getLastMonthKey(existingData)));
    
    protectHistoricalElements();
    
    updateOBLValidationDisplay();
    attachForecastEventListeners();
    
    // Apply freeze state
    if (existingForecast) {
    const isFrozen = existingForecast.Freeze === true;

    setTimeout(() => {
        const existingProject = projects.find(
  project =>
    project.Id === existingForecast.Project?.Id
);

const userCanEdit = canEditProject(
  existingProject,
  existingForecast
);

setFormReadOnly(
  isFrozen,
  userCanEdit
);

        const formTitleEl =
            document.querySelector("#formTitle") as HTMLElement;

        if (formTitleEl) {
            if (isFrozen) {
                formTitleEl.innerHTML =
                    '🔒 Edit Forecast (Frozen - Further fields editable)';
                formTitleEl.style.color = '#856404';
            } else {
                formTitleEl.innerHTML = 'Edit Forecast';
                formTitleEl.style.color = '';
            }
        }
    }, 250);
}
};

const setupHistoricalToggle = (): void => {
  const button = document.querySelector(
    "#revenue-toggle-historical-btn"
  ) as HTMLButtonElement;

  const container = document.querySelector(
    "#historicalContainer"
  ) as HTMLElement;

  const header = document.querySelector(
    ".revenue-historical-toggle-header"
  ) as HTMLElement;

  if (!button || !container) return;

  const setExpanded = (expanded: boolean): void => {
    container.style.display = expanded ? "" : "none";

    button.setAttribute("aria-expanded", String(expanded));
    button.setAttribute(
      "aria-label",
      expanded ? "Hide historical data" : "Show historical data"
    );

    button.title = expanded
      ? "Hide historical data"
      : "Show historical data";

    button.innerHTML = `
      <span class="revenue-historical-toggle-icon" aria-hidden="true">
        ${expanded ? "▾" : "▸"}
      </span>
    `;
  };

  // Collapsed by default
  setExpanded(false);

  button.onclick = (event: MouseEvent): void => {
    event.preventDefault();
    event.stopPropagation();

    const expanded =
      button.getAttribute("aria-expanded") === "true";

    setExpanded(!expanded);
  };

  // Allow clicking the header, excluding the button itself
  if (header) {
    header.onclick = (event: MouseEvent): void => {
      const target = event.target as HTMLElement;

      if (target.closest("#revenue-toggle-historical-btn")) {
        return;
      }

      button.click();
    };
  }
};

       const protectHistoricalElements = (): void => {
        document.querySelectorAll('.revenue-historical-month input, .revenue-historical-month select, .revenue-historical-month button').forEach(element => {
          const newElement = element.cloneNode(true) as HTMLElement;
          element.parentNode?.replaceChild(newElement, element);
        });
        
        document.querySelectorAll('.revenue-historical-month').forEach(section => {
          section.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toast("warning", "Historical data cannot be modified");
            return false;
          });
          
          section.addEventListener('keydown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            return false;
          });
          
          section.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            return false;
          });
        });
      };

const renderHistoricalMonths = (months: string[], existingData: ForecastData): void => {
  let html = '';

  months.forEach((monthKey, index) => {
    const monthDate = new Date(monthKey + "-01");
    const monthLabel = formatMonthLabel(monthDate);
    const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0, items: {} };
    
    html += renderHistoricalMonthBox(monthKey, monthLabel, data, index);
  });

  historicalContainer.innerHTML = html;
};

      const renderHistoricalMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, index: number): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
        const actualInputClass = data.actual > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
        
        const items = data.items || createEmptyItems();
        
        return `
          <div class="revenue-month-box-rev revenue-historical-month">
            <div class="revenue-month-header-rev">${monthLabel} (Historical - Readonly)</div>
            
            <div class="revenue-month-block">
              <div class="revenue-main-inputs-container-rev">
                <div class="revenue-main-input-group-rev">
                  <label>Prev. Plan</label>
                  <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                        readonly class="revenue-main-plan-input ${planInputClass} revenue-number-input" />
                </div>
                <div class="revenue-main-input-group-rev">
                  <label>Curr. Plan</label>
                  <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                        readonly class="revenue-main-current-input ${actualInputClass} revenue-number-input" />
                </div>
              </div>
            </div>

            <div class="revenue-items-section revenue-historical-items-section">
              <div class="revenue-items-header revenue-historical-items-header">
                <div>Item </div>
                <div>Prev. Plan</div>
                <div>Curr. Plan</div>
              </div>
              
              ${Array.from({length: 10}, (_, i) => {
                const itemNum = i + 1;
                const itemKey = itemNum.toString();
                const item = items[itemKey] || { name: '', plan: 0, actual: 0 };
                const itemPlanValue = item.plan > 0 ? item.plan.toString() : '';
                const itemActualValue = item.actual > 0 ? item.actual.toString() : '';
                const itemPlanClass = item.plan > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
                const itemActualClass = item.actual > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
                const itemNameClass = item.name ? 'revenue-input-with-value' : 'revenue-input-empty';
                
                return `
                  <div class="revenue-item-row revenue-historical-item-row">
                   <input type="text" placeholder="Item ${itemNum}" value="${escapeHtml(item.name)}"
      data-item="${itemNum}" data-month="${monthKey}" 
      class="${itemNameClass}" style="pointer-events: auto !important; cursor: text !important;" />
                    <input type="text" value="${itemPlanValue}" data-item-type="plan" data-item="${itemKey}" data-month="${monthKey}" 
                          readonly class="revenue-item-plan-input ${itemPlanClass} revenue-number-input" />
                    <input type="text" value="${itemActualValue}" data-item-type="actual" data-item="${itemKey}" data-month="${monthKey}" 
                          readonly class="revenue-item-current-input ${itemActualClass} revenue-number-input" />
                  </div>
                `;
              }).join('')}
            </div>
          </div>
        `;
      };

const renderFirstRow = (months: string[], existingData: ForecastData, existingForecast?: RevenueForecastItem): void => {
    let html = '';

    html += `<div class="revenue-detailed-months-row">`;
    
    // Get current month key
    const now = new Date();
    const currentMonthKey = formatMonthKey(now);
    
    // Find current month in the months array
    const currentMonthIndex = months.indexOf(currentMonthKey);
    
    // Detailed months: current month and next 2 months
    let detailedMonths: string[] = [];
    if (currentMonthIndex !== -1 && currentMonthIndex + 3 <= months.length) {
        detailedMonths = months.slice(currentMonthIndex, currentMonthIndex + 3);
    } else if (currentMonthIndex !== -1) {
        detailedMonths = months.slice(currentMonthIndex);
    } else {
        detailedMonths = months.slice(0, 3);
    }
    
    console.log(`📊 Detailed months for rendering: ${detailedMonths.join(', ')}`);
    
    // ✅ Load RevenueActual data from separate column
    let revenueActualData: { [key: string]: number } = {};
    if (existingForecast) {
        revenueActualData = safeJsonParse(existingForecast.RevenueActual, {});
        console.log("📊 RevenueActual data:", revenueActualData);
    }
    
    // Current month is the first of the detailed months
    const currentMonth = detailedMonths[0];
    if (currentMonth) {
        const monthDate = new Date(currentMonth + "-01");
        const monthLabel = formatMonthLabel(monthDate);
        const data = existingData[currentMonth] as ForecastMonthData || { 
            plan: 0, 
            actual: 0, 
            monthActual: 0,
            items: {} 
        };
        
        // ✅ Set monthActual from RevenueActual column for current month
        if (revenueActualData[currentMonth] !== undefined) {
            data.monthActual = revenueActualData[currentMonth];
            console.log(`📊 Set monthActual for ${currentMonth}:`, data.monthActual);
        }
        
        html += `<div class="revenue-current-month-container">`;
        html += renderDetailedMonthBox(currentMonth, monthLabel, data, true);
        html += `</div>`;
    }
    
    // Next 2 months - also get monthActual from RevenueActual if available
    html += `<div class="revenue-next-months-container">`;
    for (let i = 1; i < 3 && i < detailedMonths.length; i++) {
        const monthKey = detailedMonths[i];
        const monthDate = new Date(monthKey + "-01");
        const monthLabel = formatMonthLabel(monthDate);
        const data = existingData[monthKey] as ForecastMonthData || { 
            plan: 0, 
            actual: 0, 
            monthActual: 0,
            items: {} 
        };
        
        // ✅ Set monthActual from RevenueActual column for next months
        if (revenueActualData[monthKey] !== undefined) {
            data.monthActual = revenueActualData[monthKey];
        }
        
        html += `<div class="revenue-next-month-box">`;
        html += renderDetailedMonthBox(monthKey, monthLabel, data, false);
        html += `</div>`;
    }
    html += `</div>`;
    
    html += `</div>`;

    firstRowContainer.innerHTML = html;
};

      const renderRemainingMonths = (months: string[], existingData: ForecastData): void => {
        let html = '';

        for (let row = 0; row < 3; row++) {
          html += `<div class="revenue-remaining-row-rev">`;
          for (let col = 0; col < 5; col++) {
            const index = (row * 5) + col;
            if (index >= months.length) break;
            
            const monthKey = months[index];
            const monthDate = new Date(monthKey + "-01");
            const monthLabel = formatMonthLabel(monthDate);
            const data = existingData[monthKey] as ForecastMonthData || { plan: 0, actual: 0 };
            
            html += renderSimpleMonthBox(monthKey, monthLabel, data);
          }
          html += `</div>`;
        }

        remainingContainer.innerHTML = html;
      };

      const renderYearlyForecast = (yearlyData: YearlyForecastData): void => {
        let html = '';

        const years = Object.keys(yearlyData).sort();
        
        years.forEach(year => {
          const data = yearlyData[year] || { plan: 0, actual: 0 };
          html += renderYearlyBox(year, data);
        });

        yearlyContainer.innerHTML = html;
      };

      const renderYearlyBox = (year: string, data: { plan: number; actual: number }): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
        const actualInputClass = data.actual > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
        
        return `
          <div class="revenue-yearly-box-rev">
            <div class="revenue-yearly-header-rev">${year}</div>
            
            <div class="revenue-yearly-inputs-container-rev">
              <div class="revenue-yearly-input-group-rev">
                <label>Prev. Plan</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-year="${year}"
                      readonly class="revenue-yearly-plan-input-rev ${planInputClass} revenue-number-input" />
              </div>
              <div class="revenue-yearly-input-group-rev">
                <label>Curr. Plan</label>
                <input type="text" value="${displayActualValue}" data-type="actual" data-year="${year}"
                      class="revenue-yearly-current-input-rev ${actualInputClass} revenue-number-input" />
              </div>
            </div>
          </div>
        `;
      };

const renderDetailedMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData, isCurrentMonth: boolean = false): string => {
    console.log(`📊 renderDetailedMonthBox for ${monthLabel} (${monthKey}):`, {
        plan: data.plan,
        actual: data.actual,
        monthActual: data.monthActual,
        itemsCount: data.items ? Object.keys(data.items).length : 0
    });
    
    const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
    const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
    const displayForecastValue = data.forecast || 0;
    const displayDateValue = data.date || '';
    const displayMonthActual = data.monthActual || 0;
    
    const planInputClass = data.plan > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
    const actualInputClass = data.actual > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
    const forecastInputClass = displayForecastValue > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
    const dateInputClass = displayDateValue ? 'revenue-input-with-value' : 'revenue-input-empty';
    
    const items = data.items || createEmptyItems();
    
    // Month Actual badge
    let monthActualBadge = '';
    if (isCurrentMonth) {
        const hasMonthActual = displayMonthActual > 0;
        monthActualBadge = `
            <span class="revenue-month-actual-badge ${hasMonthActual ? 'revenue-has-value' : ''}" style="
                background-color: ${hasMonthActual ? '#c8e6c9' : '#f5f5f5'};
                border: 1px solid ${hasMonthActual ? '#4caf50' : '#ddd'};
                border-radius: 4px;
                padding: 2px 12px;
                margin-left: auto;
                font-size: 13px;
                font-weight: 600;
                color: ${hasMonthActual ? '#1b5e20' : '#999'};
                display: inline-flex;
                align-items: center;
                gap: 6px;
                white-space: nowrap;
            ">
                <span>📊 Month Actual:</span>
                <span style="font-size: 16px; font-weight: 700;">${displayMonthActual.toLocaleString()}</span>
            </span>
        `;
    }
    
    return `
        <div class="revenue-detailed-month-box ${isCurrentMonth ? 'revenue-current-month-box' : 'revenue-next-month-box'}">
            <div class="revenue-month-header-rev" style="
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 8px 12px;
                background: #f8f9fa;
                border-bottom: 2px solid #007bff;
                border-radius: 4px 4px 0 0;
            ">
                <span style="font-size: 15px; font-weight: 700; color: #333;">
                    ${monthLabel}
                    ${isCurrentMonth ? '<span class="revenue-current-month-indicator" style="margin-left: 8px; font-size: 12px; color: #007bff; background: #e3f2fd; padding: 2px 10px; border-radius: 12px;">Current</span>' : ''}
                </span>
                ${monthActualBadge}
            </div>
            
            <div class="revenue-month-block" style="padding: 8px 12px;">
                <div class="revenue-enhanced-inputs-container" style="
                    display: grid;
                    grid-template-columns: ${isCurrentMonth ? '1fr 1fr 1fr 1fr' : '1fr 1fr'};
                    gap: 8px;
                ">
                    <div class="revenue-enhanced-input-group">
                        <label style="font-size: 11px; font-weight: 600; color: #666;">Prev. Plan</label>
                        <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}"
                              readonly class="revenue-main-plan-input ${planInputClass} revenue-number-input" style="width: 100%; padding: 4px 6px; border: 1px solid #ddd; border-radius: 4px; text-align: center;" />
                    </div>
                    
                    <div class="revenue-enhanced-input-group">
                        <label style="font-size: 11px; font-weight: 600; color: #666;">Curr. Plan</label>
                        <input type="text" value="${displayActualValue}" data-type="actual" data-month="${monthKey}"
                              readonly class="revenue-main-current-input ${actualInputClass} revenue-number-input" style="width: 100%; padding: 4px 6px; border: 1px solid #ddd; border-radius: 4px; text-align: center;" data-calc-total="true" />
                    </div>
                    
                    ${isCurrentMonth ? `
                       <div class="revenue-enhanced-input-group">
        <label style="font-size: 11px; font-weight: 600; color: #666;">Further</label>
        <input type="text" value="${displayForecastValue}" data-type="forecast" data-month="${monthKey}"
              readonly class="revenue-main-forecast-input ${forecastInputClass} revenue-number-input" style="width: 100%; padding: 4px 6px; border: 1px solid #ddd; border-radius: 4px; text-align: center; background-color: #f5f5f5;" data-calc-total="true" />
    </div>
                        
                        <div class="revenue-enhanced-input-group">
                            <label style="font-size: 11px; font-weight: 600; color: #666;">Date</label>
                            <input type="date" value="${displayDateValue}" data-type="date" data-month="${monthKey}"
                                  class="revenue-forecast-date-input ${dateInputClass}" style="width: 100%; padding: 4px 6px; border: 1px solid #28a745; border-radius: 4px; background-color: #ffffff;" />
                        </div>
                    ` : ''}
                </div>
            </div>

            <div class="revenue-items-section" style="padding: 0 12px 12px 12px;">
                <div class="revenue-items-header" style="
                    display: grid;
                    grid-template-columns: ${isCurrentMonth ? '1fr 0.8fr 0.8fr 0.8fr 0.8fr' : '1fr 0.8fr 0.8fr'};
                    gap: 4px;
                    padding: 6px 4px;
                    background: #e9ecef;
                    border-radius: 4px 4px 0 0;
                    font-weight: 600;
                    font-size: 11px;
                    color: #495057;
                ">
                    <div>Item</div>
                    <div>Prev. Plan</div>
                    <div>Curr. Plan</div>
                    ${isCurrentMonth ? `
                        <div>Further</div>
                        <div>Date</div>
                    ` : ''}
                </div>
                
                ${Array.from({length: 10}, (_, i) => i + 1).map(itemNum => {
                    const item = items[itemNum] || { name: '', plan: 0, actual: 0, forecast: 0, date: '' };
                    const itemPlanValue = item.plan > 0 ? item.plan.toString() : '';
                    const itemActualValue = item.actual > 0 ? item.actual.toString() : '';
                    const itemForecastValue = (item.forecast || 0) > 0 ? (item.forecast || 0).toString() : '';
                    const itemDateValue = item.date || '';
                    
                    const itemPlanClass = item.plan > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
                    const itemActualClass = item.actual > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
                    const itemForecastClass = (item.forecast || 0) > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
                    const itemDateClass = itemDateValue ? 'revenue-input-with-value' : 'revenue-input-empty';
                    const itemNameClass = item.name ? 'revenue-input-with-value' : 'revenue-input-empty';
                    
                    return `
                        <div class="revenue-item-row ${isCurrentMonth ? 'revenue-row' : ''}" style="
                            display: grid;
                            grid-template-columns: ${isCurrentMonth ? '1fr 0.8fr 0.8fr 0.8fr 0.8fr' : '1fr 0.8fr 0.8fr'};
                            gap: 4px;
                            padding: 3px 4px;
                            border-bottom: 1px solid #f0f0f0;
                            align-items: center;
                        ">
                            <input type="text" placeholder="Item ${itemNum}" value="${escapeHtml(item.name)}" 
                                  data-item="${itemNum}" data-month="${monthKey}" 
                                  class="revenue-item-description-input ${itemNameClass}" 
                                  style="width: 100%; padding: 3px 6px; border: 1px solid #ddd; border-radius: 4px; font-size: 11px; pointer-events: auto !important; cursor: text !important; background-color: #ffffff !important;" />
                            <input type="text" value="${itemPlanValue}" 
                                  data-item-type="plan" data-item="${itemNum}" data-month="${monthKey}" 
                                  readonly class="revenue-item-plan-input ${itemPlanClass} revenue-number-input" style="width: 100%; padding: 3px 6px; border: 1px solid #ddd; border-radius: 4px; text-align: center; font-size: 11px;" />
                            
                            <input type="text" value="${itemActualValue}" 
                                  data-item-type="actual" data-item="${itemNum}" data-month="${monthKey}" 
                                  class="revenue-item-current-input ${itemActualClass} revenue-number-input" style="width: 100%; padding: 3px 6px; border: 1px solid #ddd; border-radius: 4px; text-align: center; font-size: 11px;" data-calc-total="true" />
                            
                            ${isCurrentMonth ? `
                                <input type="text" value="${itemForecastValue}" 
                                      data-item-type="forecast" data-item="${itemNum}" data-month="${monthKey}" 
                                      class="revenue-item-forecast-input ${itemForecastClass} revenue-number-input" style="width: 100%; padding: 3px 6px; border: 1px solid #28a745; border-radius: 4px; text-align: center; font-size: 11px; background-color: #ffffff;" data-calc-total="true" />
                                
                                <input type="date" value="${itemDateValue}" 
                                      data-item-type="date" data-item="${itemNum}" data-month="${monthKey}" 
                                      class="revenue-item-date-input ${itemDateClass}" style="width: 100%; padding: 3px 6px; border: 1px solid #28a745; border-radius: 4px; font-size: 11px; background-color: #ffffff;" />
                            ` : ''}
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
};

      const renderSimpleMonthBox = (monthKey: string, monthLabel: string, data: ForecastMonthData): string => {
        const displayPlanValue = data.plan > 0 ? data.plan.toString() : '';
        const displayActualValue = data.actual > 0 ? data.actual.toString() : '';
        const planInputClass = data.plan > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
        const actualInputClass = data.actual > 0 ? 'revenue-input-with-value' : 'revenue-input-empty';
        
        return `
          <div class="revenue-month-box-rev revenue-simple-month-rev">
            <div class="revenue-month-header-rev">${monthLabel}</div>
            
            <div class="revenue-main-inputs-container-rev">
              <div class="revenue-main-input-group-rev">
                <label>Prev. Plan</label>
                <input type="text" value="${displayPlanValue}" data-type="plan" data-month="${monthKey}" 
                      readonly class="revenue-main-plan-input ${planInputClass} revenue-number-input" />
              </div>
              <div class="revenue-main-input-group-rev">
                <label>Curr. Plan</label>
                <input type="text" value="${displayActualValue}"  id="actualCurrent" data-type="actual" data-month="${monthKey}" 
                      class="revenue-main-current-input ${actualInputClass} revenue-number-input" />
              </div>
            </div>
          </div>
        `;
      };
      const attachForecastEventListeners = (): void => {
        document.querySelectorAll<HTMLInputElement>('.revenue-number-input').forEach(input => {
            allowOnlyNumbers(input);
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-number-input:not([readonly])').forEach(input => {
            input.addEventListener('focus', function() {
                this.setAttribute('data-old-value', getNumericValue(this).toString());
            });
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-main-current-input:not([readonly])').forEach(input => {
            input.addEventListener('input', function() {
                const currentValue = getNumericValue(this);
                const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
                
                this.setAttribute('data-old-value', currentValue.toString());
                
                const isIncreasing = currentValue > oldValue;
                
                if (isIncreasing) {
                    const allowByOBL = allowInputIncrease(this, currentValue);
                    
                    if (!allowByOBL) {
                        setNumericValue(this, oldValue);
                        updateOBLValidationDisplay(this);
                        return;
                    }
                }
                
                if (currentValue === 0) {
                    this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                } else {
                    this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                }

                updateOBLValidationDisplay(this);
            });
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-main-forecast-input:not([readonly])').forEach(input => {
            input.addEventListener('input', function() {
                const currentValue = getNumericValue(this);
                const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
                
                this.setAttribute('data-old-value', currentValue.toString());
                
                const isIncreasing = currentValue > oldValue;
                
                if (isIncreasing) {
                    const allowByOBL = allowInputIncrease(this, currentValue);
                    
                    if (!allowByOBL) {
                        setNumericValue(this, oldValue);
                        updateOBLValidationDisplay(this);
                        return;
                    }
                }
                
                if (currentValue === 0) {
                    this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                } else {
                    this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                }

                updateOBLValidationDisplay(this);
            });
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-item-current-input:not([readonly])').forEach(input => {
            input.addEventListener('input', function() {
                const currentValue = getNumericValue(this);
                const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
                
                this.setAttribute('data-old-value', currentValue.toString());
                
                const isIncreasing = currentValue > oldValue;
                
                if (isIncreasing) {
                    const allowByOBL = allowInputIncrease(this, currentValue);
                    const allowByMonth = allowItemInputIncrease(this, currentValue);
                    
                    if (!allowByOBL || !allowByMonth) {
                        setNumericValue(this, oldValue);
                        updateOBLValidationDisplay(this);
                        return;
                    }
                }
                
                if (currentValue === 0) {
                    this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                } else {
                    this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                }

                updateOBLValidationDisplay(this);
            });
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-item-forecast-input:not([readonly])').forEach(input => {
            input.addEventListener('input', function() {
                const currentValue = getNumericValue(this);
                const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
                
                this.setAttribute('data-old-value', currentValue.toString());
                
                const isIncreasing = currentValue > oldValue;
                
                if (isIncreasing) {
                    const allowByOBL = allowInputIncrease(this, currentValue);
                    const allowByMonth = allowItemInputIncrease(this, currentValue);
                    
                    if (!allowByOBL || !allowByMonth) {
                        setNumericValue(this, oldValue);
                        updateOBLValidationDisplay(this);
                        return;
                    }
                }
                
                if (currentValue === 0) {
                    this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                } else {
                    this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                }

                updateOBLValidationDisplay(this);
            });
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-yearly-current-input-rev:not([readonly])').forEach(input => {
            input.addEventListener('input', function() {
                const currentValue = getNumericValue(this);
                const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
                
                this.setAttribute('data-old-value', currentValue.toString());
                
                const isIncreasing = currentValue > oldValue;
                
                if (isIncreasing) {
                    const allowByOBL = allowInputIncrease(this, currentValue);
                    
                    if (!allowByOBL) {
                        setNumericValue(this, oldValue);
                        updateOBLValidationDisplay(this);
                        return;
                    }
                }
                
                if (currentValue === 0) {
                    this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                } else {
                    this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                }

                updateOBLValidationDisplay(this);
            });
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-forecast-date-input:not([readonly])').forEach(input => {
            input.addEventListener('change', function() {
                if (this.value === '') {
                    this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                } else {
                    this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                }
            });
        });

        document.querySelectorAll<HTMLInputElement>('.revenue-item-date-input:not([readonly])').forEach(input => {
            input.addEventListener('change', function() {
                if (this.value === '') {
                    this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                } else {
                    this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                }
            });
        });

        document.querySelectorAll<HTMLInputElement>('input[data-item]:not([readonly])').forEach(input => {
            if (!input.classList.contains('revenue-number-input')) {
                input.addEventListener('input', function() {
                    if (this.value === '') {
                        this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
                    } else {
                        this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
                    }
                });
            }
        });

 

        document.querySelectorAll<HTMLInputElement>('.revenue-main-forecast-input').forEach(input => {
        // Ensure it's always editable
        input.removeAttribute('readonly');
        input.style.backgroundColor = '#ffffff';
        input.style.pointerEvents = 'auto';
        input.disabled = false;
        
        input.addEventListener('input', function() {
            const currentValue = getNumericValue(this);
            const oldValue = parseInt(this.getAttribute('data-old-value') || '0');
            
            this.setAttribute('data-old-value', currentValue.toString());
            
            const isIncreasing = currentValue > oldValue;
            
            if (isIncreasing) {
                const allowByOBL = allowInputIncrease(this, currentValue);
                
                if (!allowByOBL) {
                    setNumericValue(this, oldValue);
                    updateOBLValidationDisplay(this);
                    return;
                }
            }
            
            if (currentValue === 0) {
                this.className = this.className.replace('revenue-input-with-value', 'revenue-input-empty');
            } else {
                this.className = this.className.replace('revenue-input-empty', 'revenue-input-with-value');
            }

            updateOBLValidationDisplay(this);
        });
    });
    
     // OBL input listener
  oblLastMonthInput.addEventListener('input', function() {
    // Remove existing toast
    const existingToast = document.querySelector('.revenue-obl-error-toast');
    if (existingToast) existingToast.remove();
    
    // Update validation display
    updateOBLValidationDisplay(this);
    
    // Show appropriate toast based on current state
    const oblValue = getNumericValue(oblLastMonthInput);
    const totalCurrent = calculateTotalCurrentValue();
    
    if (oblValue === 0 && totalCurrent === 0) {
      showOBLToast('info', `ℹ️ OBL is zero. No budget limit applied.`);
    } else if (oblValue > 0 && totalCurrent <= oblValue) {
      const remaining = oblValue - totalCurrent;
      const percentage = Math.round((totalCurrent / oblValue) * 100);
      
      if (totalCurrent === oblValue) {
        showOBLToast('success', `✅ OBL FULLY UTILIZED: ${totalCurrent.toLocaleString()} = ${oblValue.toLocaleString()}`);
      } else if (percentage > 90) {
        showOBLToast('warning', `⚠️ OBL nearly reached: ${percentage}% used. ${remaining.toLocaleString()} remaining.`);
      } else {
        showOBLToast('success', `✅ OBL within limit: ${percentage}% used. ${remaining.toLocaleString()} remaining.`);
      }
    } else if (oblValue > 0 && totalCurrent > oblValue) {
      const exceedAmount = totalCurrent - oblValue;
      showOBLToast('danger', `❌ OBL EXCEEDED by ${exceedAmount.toLocaleString()}! Total: ${totalCurrent.toLocaleString()} > OBL: ${oblValue.toLocaleString()}`);
    }
  });

  // ===== GLOBAL INPUT LISTENER FOR ALL CURRENT INPUTS - FIXED =====
  // Use event delegation for better performance
  // document.addEventListener('input', function(e) {
  //   const target = e.target as HTMLElement;
    
  //   // Check if the input is one we care about
  //   if (target.matches('.revenue-item-current-input, .revenue-main-current-input, .revenue-yearly-current-input-rev, #oblLastMonth')) {
  //     // Small delay to let the value update
  //     setTimeout(() => {
  //       // Remove existing toast
  //       const existingToast = document.querySelector('.revenue-obl-error-toast');
  //       if (existingToast) existingToast.remove();
        
  //       // Calculate values
  //       const oblValue = getNumericValue(oblLastMonthInput);
  //       const totalCurrent = calculateTotalCurrentValue();
        
  //       // Update display
  //       totalCurrentValueSpan.textContent = totalCurrent.toLocaleString();
  //       const remaining = oblValue - totalCurrent;
  //       remainingValueSpan.textContent = remaining.toLocaleString();
        
  //       // Update line fill
  //       if (oblValue > 0) {
  //         const percentage = Math.min((totalCurrent / oblValue) * 100, 100);
  //         oblLineFill.style.width = `${percentage}%`;
  //         oblLineFill.className = 'revenue-line-fill';
  //         if (percentage > 90) oblLineFill.classList.add('danger');
  //         else if (percentage > 75) oblLineFill.classList.add('warning');
  //       } else {
  //         oblLineFill.style.width = '0%';
  //         oblLineFill.className = 'revenue-line-fill';
  //       }
        
  //       // Show toast based on state
  //       if (oblValue === 0) {
  //         if (totalCurrent > 0) {
  //           showOBLToast('warning', `⚠️ OBL is zero but values exist (${totalCurrent.toLocaleString()})`);
  //         } else {
  //           showOBLToast('info', `ℹ️ OBL is zero. No budget limit.`);
  //         }
  //       } else if (totalCurrent > oblValue) {
  //         showOBLToast('danger', `❌ OBL EXCEEDED by ${(totalCurrent - oblValue).toLocaleString()}! Total: ${totalCurrent.toLocaleString()} > OBL: ${oblValue.toLocaleString()}`);
  //       } else if (totalCurrent === oblValue) {
  //         showOBLToast('success', `✅ OBL FULLY UTILIZED: ${totalCurrent.toLocaleString()} = ${oblValue.toLocaleString()}`);
  //       } else {
  //         const pct = Math.round((totalCurrent / oblValue) * 100);
  //         const remainingAmt = oblValue - totalCurrent;
  //         if (pct > 90) {
  //           showOBLToast('warning', `⚠️ OBL nearly reached: ${pct}% used. ${remainingAmt.toLocaleString()} remaining.`);
  //         } else if (pct > 75) {
  //           showOBLToast('info', `📊 OBL usage: ${pct}%. ${remainingAmt.toLocaleString()} remaining.`);
  //         } else {
  //           showOBLToast('success', `✅ OBL within limit: ${pct}% used. ${remainingAmt.toLocaleString()} remaining.`);
  //         }
  //       }
  //     }, 50);
  //   }
  // }, true);

// Also trigger validation when any input changes
document.querySelectorAll<HTMLInputElement>('.revenue-item-current-input:not([readonly]), .revenue-main-current-input:not([readonly]), .revenue-yearly-current-input-rev:not([readonly])').forEach(input => {
  input.addEventListener('input', function() {
    // Small delay to allow value to be set
    setTimeout(() => {
      updateOBLValidationDisplay(this);
    }, 50);
  });
});

// ===== OBL REAL-TIME VALIDATION =====
// Force OBL validation on any input change using event delegation

// 1. Remove any existing OBL toast and show fresh on any input change
// document.addEventListener('input', function(e) {
//   const target = e.target as HTMLElement;
  
//   // Check if the input is one we care about
//   if (target.matches('.revenue-item-current-input, .revenue-main-current-input, .revenue-yearly-current-input-rev, #oblLastMonth')) {
//     // Small delay to let the value update
//     setTimeout(() => {
//       // Remove existing toast
//       const existingToast = document.querySelector('.revenue-obl-error-toast');
//       if (existingToast) existingToast.remove();
      
//       // Calculate values
//       const oblValue = getNumericValue(oblLastMonthInput);
//       const totalCurrent = calculateTotalCurrentValue();
      
//       // Update display
//       totalCurrentValueSpan.textContent = totalCurrent.toLocaleString();
//       const remaining = oblValue - totalCurrent;
//       remainingValueSpan.textContent = remaining.toLocaleString();
      
//       // Update line fill
//       if (oblValue > 0) {
//         const percentage = Math.min((totalCurrent / oblValue) * 100, 100);
//         oblLineFill.style.width = `${percentage}%`;
//         oblLineFill.className = 'revenue-line-fill';
//         if (percentage > 90) oblLineFill.classList.add('danger');
//         else if (percentage > 75) oblLineFill.classList.add('warning');
//       } else {
//         oblLineFill.style.width = '0%';
//         oblLineFill.className = 'revenue-line-fill';
//       }
      
//       // Show toast based on state
//       if (oblValue === 0) {
//         if (totalCurrent > 0) {
//           showOBLToast('warning', `⚠️ OBL is zero but values exist (${totalCurrent.toLocaleString()})`);
//         } else {
//           showOBLToast('info', `ℹ️ OBL is zero. No budget limit.`);
//         }
//       } else if (totalCurrent > oblValue) {
//         showOBLToast('danger', `❌ OBL EXCEEDED by ${(totalCurrent - oblValue).toLocaleString()}! Total: ${totalCurrent.toLocaleString()} > OBL: ${oblValue.toLocaleString()}`);
//       } else if (totalCurrent === oblValue) {
//         showOBLToast('success', `✅ OBL FULLY UTILIZED: ${totalCurrent.toLocaleString()} = ${oblValue.toLocaleString()}`);
//       } else {
//         const pct = Math.round((totalCurrent / oblValue) * 100);
//         const remainingAmt = oblValue - totalCurrent;
//         if (pct > 90) {
//           showOBLToast('warning', `⚠️ OBL nearly reached: ${pct}% used. ${remainingAmt.toLocaleString()} remaining.`);
//         } else if (pct > 75) {
//           showOBLToast('info', `📊 OBL usage: ${pct}%. ${remainingAmt.toLocaleString()} remaining.`);
//         } else {
//           showOBLToast('success', `✅ OBL within limit: ${pct}% used. ${remainingAmt.toLocaleString()} remaining.`);
//         }
//       }
//     }, 50);
//   }
// }, true);



        document.querySelectorAll<HTMLInputElement>('.revenue-item-current-input:not([readonly])').forEach(input => {
            input.addEventListener('input', function() {
                const monthKey = this.dataset.month;
                if (monthKey) {
                    validateSingleMonthItems(monthKey, this);
                }
            });
        });

const calculateMonthTotals = (monthKey: string): void => {
    const itemCurrentInputs = document.querySelectorAll<HTMLInputElement>(
        `input.revenue-item-current-input[data-month="${monthKey}"]`
    );
    const itemForecastInputs = document.querySelectorAll<HTMLInputElement>(
        `input.revenue-item-forecast-input[data-month="${monthKey}"]`
    );
    
    let totalCurrent = 0;
    let totalForecast = 0;
    
    itemCurrentInputs.forEach(input => {
        totalCurrent += getNumericValue(input);
    });
    
    itemForecastInputs.forEach(input => {
        totalForecast += getNumericValue(input);
    });

    // Update Curr. Plan main input
    const mainCurrentInput = document.querySelector<HTMLInputElement>(
        `input.revenue-main-current-input[data-month="${monthKey}"]`
    );
    if (mainCurrentInput) {
        setNumericValue(mainCurrentInput, totalCurrent);
        mainCurrentInput.dispatchEvent(new Event('input'));
    }
    
    // ✅ Update main forecast input (READONLY - calculated from items)
    const mainForecastInput = document.querySelector<HTMLInputElement>(
        `input.revenue-main-forecast-input[data-month="${monthKey}"]`
    );
    if (mainForecastInput) {
        setNumericValue(mainForecastInput, totalForecast);
        mainForecastInput.dispatchEvent(new Event('input'));
    }
};
   document.querySelectorAll<HTMLInputElement>('.revenue-item-current-input:not([readonly]), .revenue-item-forecast-input:not([readonly])').forEach(input => {
    input.addEventListener('input', function() {
      const monthKey = this.dataset.month;
      if (monthKey) {
        calculateMonthTotals(monthKey);
        validateSingleMonthItems(monthKey, this);
        updateOBLValidationDisplay(this);
      }
    });
  });
        const validationInputs = document.querySelectorAll<HTMLInputElement>(`
            .revenue-main-current-input:not([readonly]),
            .revenue-item-current-input:not([readonly]),
            .revenue-yearly-current-input-rev:not([readonly]),
            .revenue-main-forecast-input:not([readonly]),
            .revenue-item-forecast-input:not([readonly])
        `);

        validationInputs.forEach(input => {
            input.addEventListener('input', function() {
                setTimeout(() => {
                    updateOBLValidationDisplay(this);
                }, 100);
            });
        });
      };
 
// ============================================================
// Updated editForecast with RevenueActual loading
// ============================================================
const editForecast = async (id: number): Promise<void> => {
    editingId = id;
    const forecast = forecasts.find(f => f.Id === id);
    if (!forecast) {
        toast("error", "Forecast not found");
        return;
    }
    
    // Get project for permission check
    const project = projects.find(p => p.Id === forecast.Project?.Id);
    
    // Check if user can view this forecast
    if (!canRead()) {
        toast("error", "❌ You don't have permission to view this forecast");
        return;
    }
    
    // Check if project is assigned to user (for non-admin/non-GH)
    const assignedProjects = getAssignedProjects(projects);
    const isAssigned = assignedProjects.some(p => p.Id === forecast.Project?.Id);
    const isGHHeadUser = isGHHead();
    const isFullControlUser = hasFullControl();
    
    if (!isFullControlUser && !isGHHeadUser && !isAssigned) {
        toast("error", "❌ You don't have permission to view this project");
        return;
    }
    
    // Check if user can edit this project
    const canEdit = canEditProject(project, forecast);
    const isFrozen = forecast.Freeze || false;
    
    // ✅ Show form FIRST
    showForm(true, project, forecast);
    
    // Load remarks
    if (forecast.Remarks) {
        const remarksData = forecast.Remarks;
        if (remarksData.includes('|||')) {
            const parts = remarksData.split('|||');
            if (remarksInternal) {
                remarksInternal.value = parts[0] || '';
            }
            if (remarksSprintCell) {
                remarksSprintCell.value = parts[1] || '';
            }
        } else {
            if (remarksInternal) {
                remarksInternal.value = remarksData;
            }
        }
    }
    
    let forecastData: ForecastData = {};
    let revenueActualData: { [key: string]: number } = {};
    
    try {
        // Load ForecastData
        let forecastDataString = forecast.ForecastData || "{}";
        forecastDataString = forecastDataString.trim();
        
        if (!forecastDataString || forecastDataString === '""' || forecastDataString === "null") {
            forecastDataString = "{}";
        }
        
        forecastData = JSON.parse(forecastDataString);
        
        // Load RevenueActual separately
        let revenueActualString = forecast.RevenueActual || "{}";
        revenueActualString = revenueActualString.trim();
        
        if (!revenueActualString || revenueActualString === '""' || revenueActualString === "null") {
            revenueActualString = "{}";
        }
        
        revenueActualData = JSON.parse(revenueActualString);
        console.log("📊 Loaded RevenueActual in editForecast:", revenueActualData);
        
    } catch (e) {
        forecastData = createFreshForecastStructure();
        revenueActualData = {};
        toast("warning", "Corrupted forecast data detected. Loaded empty structure.");
    }
    
    // Apply progression
    forecastData = propagateMonthValues(forecastData);
    
    if (forecast.Project) {
        projectSelect.value = String(forecast.Project.Id);
        onProjectChange(forecast.Project.Id, forecast);
    }
    
    // ============================================================
    // ✅ Apply freeze state to form after rendering
    // ============================================================
    setTimeout(() => {
        // If frozen OR user can't edit, set read-only for most fields
        // const isReadOnly = isFrozen || !canEdit;
        setFormReadOnly(isFrozen, canEdit);
        
        // ✅ SHOW SAVE BUTTON - always show if user can edit the project
        const saveBtn = document.querySelector('.revenue-btn-primary[type="submit"]') as HTMLButtonElement;
        if (saveBtn) {
            // Only hide if user doesn't have edit permission at all
            saveBtn.style.display = canEdit ? '' : 'none';
            
            // Change button text and style based on freeze state
            if (isFrozen) {
                saveBtn.textContent = "💾 Save Frozen Changes";
                saveBtn.title = "Save Item, Further and Date changes";
                saveBtn.style.backgroundColor = '#28a745';
                saveBtn.style.borderColor = '#28a745';
                saveBtn.style.color = '#ffffff';
                saveBtn.style.fontWeight = 'bold';
                saveBtn.style.cursor = 'pointer';
                saveBtn.setAttribute('type', 'submit');
            } else {
                saveBtn.textContent = '💾 Save Revenue Plan';
                saveBtn.title = '';
                saveBtn.style.backgroundColor = '';
                saveBtn.style.borderColor = '';
                saveBtn.style.color = '';
                saveBtn.style.fontWeight = '';
                saveBtn.style.cursor = '';
                saveBtn.setAttribute('type', 'submit');
            }
             
        }
        
        const formTitleEl = document.querySelector("#formTitle") as HTMLElement;
        if (formTitleEl) {
            if (isFrozen) {
                formTitleEl.innerHTML = '🔒 Edit Forecast (Locked By Admin)';
                formTitleEl.style.color = '#856404';
            } else if (!canEdit) {
                formTitleEl.innerHTML = '🔒 Edit Forecast (Read Only)';
                formTitleEl.style.color = '#856404';
            } else {
                formTitleEl.innerHTML = 'Edit Forecast';
                formTitleEl.style.color = '';
            }
        }
        
        // ✅ Show/hide OBL section based on freeze state
        const oblContainer = document.querySelector('.revenue-obl-section-container') as HTMLElement;
        if (oblContainer) {
            if (isFrozen) {
                oblContainer.style.opacity = '0.6';
                oblContainer.style.pointerEvents = 'none';
            } else {
                oblContainer.style.opacity = '1';
                oblContainer.style.pointerEvents = '';
            }
        }
        
        // ✅ Disable project selection when frozen
        if (projectSelect) {
            projectSelect.disabled = true; // Always disabled in edit mode
        }
        
        // Show toast notification about frozen state
        if (isFrozen) {
            showOBLToast("info", "🔒 Project is frozen. Item, Further and Date fields are editable.");
        } else if (!canEdit) {
            showOBLToast('info', '🔒 You have view-only access to this project.');
        } else {
            showOBLToast('success', '🔓 All fields are editable. Click "Save Revenue Plan" to save.');
        }
        
    }, 300);
    
    toast("info", `Viewing forecast for ${forecast.Title}`);
};
 
// ============================================================
// SAVE REVENUE PLAN / SAVE FURTHER CHANGES
// ============================================================
// ONE native submit handler for both buttons.
//
// Normal project:
//   "Save Revenue Plan"
//   -> saves editable Plan / Curr. Plan / Further / Date /
//      detailed items / yearly data / RevenueActual
//
// Frozen project:
//   "Save Further Changes"
//   -> saves ONLY Further + Date + item Further + item Date
//   -> preserves revenue-locked Curr. Plan / Actual / Yearly values
// ============================================================

form.addEventListener("submit", async (e: SubmitEvent): Promise<void> => {
    e.preventDefault();
    e.stopPropagation();

    console.log("============================================");
    console.log("💾 REVENUE FORM SUBMIT STARTED");
    console.log("💾 Editing ID:", editingId);

    // ------------------------------------------------------------
    // 1. Get selected project
    // ------------------------------------------------------------
    const projectId = parseInt(projectSelect.value, 10);
    const project = projects.find(p => p.Id === projectId);

    if (!project) {
        toast("error", "Please select a project");
        return;
    }

    // ------------------------------------------------------------
    // 2. Get existing forecast
    // ------------------------------------------------------------
    const existingForecast = editingId
        ? forecasts.find(f => f.Id === editingId)
        : undefined;

    // ------------------------------------------------------------
    // 3. Permission validation
    // ------------------------------------------------------------
    if (editingId) {
        if (!canEditProject(project, existingForecast)) {
            toast("error", "❌ You don't have permission to edit this forecast");
            return;
        }
    } else {
        if (!canCreateForecast()) {
            toast("error", "❌ You don't have permission to create forecasts");
            return;
        }
    }

    // ------------------------------------------------------------
    // 4. Determine frozen state
    // ------------------------------------------------------------
    const isFrozen = existingForecast?.Freeze === true;

    console.log("🔒 Is Frozen:", isFrozen);

    // ------------------------------------------------------------
    // 5. Confirm frozen save
    // ------------------------------------------------------------
    console.log("🔍 Before frozen confirmation");

if (editingId && isFrozen) {

    console.log("🔒 Frozen project - testing direct save");

    const confirmSave = await Promise.resolve({
        isConfirmed: true
    });

    console.log("✅ Frozen save confirmed:", confirmSave.isConfirmed);

    if (!confirmSave.isConfirmed) {
        toast("info", "Save cancelled");
        return;
    }
}

    // ------------------------------------------------------------
    // 6. New/existing project validation
    // ------------------------------------------------------------
    const isNewProject =
        !editingId &&
        !forecasts.some(f => f.Project?.Id === projectId);

    if (
        !isNewProject &&
        forecasts.some(
            f => f.Project?.Id === projectId && f.Id !== editingId
        )
    ) {
        toast("error", "Forecast already exists for this project!");
        return;
    }

    // ------------------------------------------------------------
    // 7. OBL validation
    // ------------------------------------------------------------
    if (!isFrozen) {
        const oblValue = getNumericValue(oblLastMonthInput);

        if (isNewProject && oblValue === 0) {
            const confirmZeroOBL = await Swal.fire({
                icon: "question",
                title: "Zero OBL Value",
                text: "You're setting OBL to zero for a new project. This means there's no budget limit. Continue?",
                showCancelButton: true,
                confirmButtonText: "Yes, Continue",
                cancelButtonText: "No, Set OBL"
            });

            if (!confirmZeroOBL.isConfirmed) {
                oblLastMonthInput.focus();
                return;
            }
        }

        const totalCurrent = calculateTotalCurrentValue();

        if (oblValue > 0 && totalCurrent > oblValue) {
            toast("error", "Total current value cannot exceed OBL!");
            return;
        }
    }

    // ------------------------------------------------------------
    // 8. Disable Save button while saving
    // ------------------------------------------------------------
    const saveButton = form.querySelector(
        'button[type="submit"]'
    ) as HTMLButtonElement | null;

    if (saveButton) {
        saveButton.disabled = true;
        saveButton.dataset.saving = "true";
    }

    try {
        // ========================================================
        // 9. Load existing ForecastData
        // ========================================================
        let forecastData: ForecastData = {};
        let revenueActualData: { [key: string]: number } = {};

        if (existingForecast) {
            const existingData = safeJsonParse(
                existingForecast.ForecastData,
                {}
            );

            // Deep clone so original SharePoint data is never mutated
            forecastData = JSON.parse(
                JSON.stringify(existingData)
            );

            revenueActualData = safeJsonParse(
                existingForecast.RevenueActual,
                {}
            );

            console.log(
                "📊 Existing RevenueActual:",
                revenueActualData
            );
        }

        // --------------------------------------------------------
        // 10. Create fresh structure for new record
        // --------------------------------------------------------
        if (Object.keys(forecastData).length === 0) {
            forecastData = createFreshForecastStructure();
        }

        // ========================================================
        // 11. Get all storage months
        // ========================================================
        const allStorageMonths = getAllMonthsForStorage();
        const currentMonthKey = formatMonthKey(new Date());

        const currentMonthIndex =
            allStorageMonths.indexOf(currentMonthKey);

        let detailedMonths: string[] = [];

        if (currentMonthIndex !== -1) {
            detailedMonths = allStorageMonths.slice(
                currentMonthIndex,
                Math.min(
                    currentMonthIndex + 3,
                    allStorageMonths.length
                )
            );
        } else {
            detailedMonths = allStorageMonths.slice(36, 39);
        }

        console.log("📅 Current month:", currentMonthKey);
        console.log("📅 Detailed months:", detailedMonths);

        // ========================================================
        // 12. Collect monthly data from DOM
        // ======================================================== 
allStorageMonths.forEach((monthKey: string) => {
  const existingMonthData =
    forecastData[monthKey] as
      | ForecastMonthData
      | undefined;

  const monthData: ForecastMonthData = {
    plan: Number(existingMonthData?.plan) || 0,
    actual: Number(existingMonthData?.actual) || 0,
    monthActual:
      Number(existingMonthData?.monthActual) || 0,
    forecast:
      Number(existingMonthData?.forecast) || 0,
    date: existingMonthData?.date || "",
    items: existingMonthData?.items
      ? JSON.parse(
          JSON.stringify(existingMonthData.items)
        )
      : {}
  };

  const mainPlanInput =
    document.querySelector<HTMLInputElement>(
      `.revenue-main-plan-input[data-month="${monthKey}"]`
    );

  const mainCurrentInput =
    document.querySelector<HTMLInputElement>(
      `.revenue-main-current-input[data-month="${monthKey}"]`
    );

  const mainFurtherInput =
    document.querySelector<HTMLInputElement>(
      `.revenue-main-forecast-input[data-month="${monthKey}"]`
    );

  const mainDateInput =
    document.querySelector<HTMLInputElement>(
      `.revenue-forecast-date-input[data-month="${monthKey}"]`
    );

  if (isFrozen) {
    // Frozen:
    // preserve Plan, Curr. Plan, Actual and yearly values.

    if (mainFurtherInput) {
      monthData.forecast =
        getNumericValue(mainFurtherInput);
    }

    if (mainDateInput) {
      // Allow the user to clear the date.
      monthData.date = mainDateInput.value;
    }

    // Item name, Item Further and Item Date remain editable.
    monthData.items = collectDetailedItemsFromDOM(
      monthKey,
      monthData.items,
      true
    );
  } else {
    // Normal editable forecast.

    if (mainPlanInput) {
      monthData.plan =
        getNumericValue(mainPlanInput);
    }

    if (mainCurrentInput) {
      monthData.actual =
        getNumericValue(mainCurrentInput);
    }

    if (mainFurtherInput) {
      monthData.forecast =
        getNumericValue(mainFurtherInput);
    }

    if (mainDateInput) {
      monthData.date = mainDateInput.value;
    }

    if (detailedMonths.includes(monthKey)) {
      monthData.items = collectDetailedItemsFromDOM(
        monthKey,
        monthData.items,
        false
      );
    }
  }

  forecastData[monthKey] = monthData;
});

        // ========================================================
        // 13. Yearly data
        // ========================================================
        if (!isFrozen) {

            const yearlyPlanInputs =
                document.querySelectorAll<HTMLInputElement>(
                    ".revenue-yearly-plan-input-rev"
                );

            const existingYearly =
                forecastData.yearly || {};

            if (yearlyPlanInputs.length > 0) {

                const updatedYearlyData: YearlyForecastData = {
                    ...existingYearly
                };

                const years = new Set<string>();

                yearlyPlanInputs.forEach(
                    (input: HTMLInputElement) => {
                        const year = input.dataset.year;

                        if (year) {
                            years.add(year);
                        }
                    }
                );

                Array.from(years)
                    .sort()
                    .forEach((year: string) => {

                        const planInput =
                            document.querySelector<HTMLInputElement>(
                                `.revenue-yearly-plan-input-rev[data-year="${year}"]`
                            );

                        const currentInput =
                            document.querySelector<HTMLInputElement>(
                                `.revenue-yearly-current-input-rev[data-year="${year}"]`
                            );

                        if (planInput && currentInput) {

                            updatedYearlyData[year] = {
                                plan: getNumericValue(planInput),
                                actual: getNumericValue(currentInput)
                            };
                        }
                    });

                forecastData.yearly =
                    updatedYearlyData;

            } else if (
                existingYearly &&
                Object.keys(existingYearly).length > 0
            ) {

                forecastData.yearly =
                    existingYearly;
            }

        } else {

            // Frozen:
            // preserve existing yearly data exactly.
            console.log(
                "🔒 Frozen: yearly data preserved"
            );
        }

        // ========================================================
        // 14. Apply progression only for normal projects
        // ========================================================
        let finalData = forecastData;

        if (!isFrozen) {

            console.log(
                "🔓 Applying forecast progression..."
            );

            finalData =
                propagateCollectionValues(
                    forecastData
                );

        } else {

            console.log(
                "🔒 Frozen: progression skipped"
            );
        }

        // ========================================================
        // 15. RevenueActual
        // ========================================================
        if (!isFrozen) {

            const currentMonthInput =
                document.querySelector<HTMLInputElement>(
                    `input.revenue-main-current-input[data-month="${currentMonthKey}"]`
                );

            if (currentMonthInput) {

                const currentValue =
                    getNumericValue(currentMonthInput);

                revenueActualData[currentMonthKey] =
                    currentValue;

                console.log(
                    `📊 RevenueActual ${currentMonthKey}:`,
                    currentValue
                );
            }

            Object.keys(revenueActualData).forEach(
                (monthKey: string) => {

                    const month =
                        finalData[monthKey] as ForecastMonthData;

                    if (month) {
                        month.monthActual =
                            revenueActualData[monthKey];
                    }
                }
            );
        } else {

            // Frozen:
            // RevenueActual remains unchanged.
            console.log(
                "🔒 Frozen: RevenueActual preserved"
            );
        }

        // ========================================================
        // 16. Build SharePoint payload
        // ========================================================
        const digest = await getDigest();

        const internalRemark =
            remarksInternal?.value || "";

        const sprintCellRemark =
            remarksSprintCell?.value || "";

        const combinedRemarks =
            internalRemark + "|||" + sprintCellRemark;

        const forecastDataString =
            JSON.stringify(finalData);

        let revenueActualString =
            JSON.stringify(revenueActualData);

        // --------------------------------------------------------
        // RevenueActual SharePoint field length protection
        // --------------------------------------------------------
        if (revenueActualString.length > 255) {

            console.warn(
                "⚠️ RevenueActual too long:",
                revenueActualString.length
            );

            const cleanedRevenueActual: {
                [key: string]: number
            } = {};

            Object.keys(revenueActualData).forEach(
                (key: string) => {

                    const value =
                        revenueActualData[key];

                    if (
                        value > 0 &&
                        /^\d{4}-\d{2}$/.test(key)
                    ) {
                        cleanedRevenueActual[key] =
                            value;
                    }
                }
            );

            revenueActualString =
                JSON.stringify(
                    cleanedRevenueActual
                );
        }

        const payload: any = {
            __metadata: {
                type: "SP.Data.Revenue_x0020_Forecast_x0020_ListListItem"
            },

            Title:
                generateForecastTitle(
                    project,
                    finalData
                ),

            ProjectId:
                project.Id,

            ProfitCentre:
                project.PC || "",

            ForecastData:
                forecastDataString,

            RevenueActual:
                revenueActualString,

            Remarks:
                combinedRemarks,

            UpdatedDate:
                new Date().toISOString()
        };

        // OBL is only set when creating a new project.
        if (!editingId && isNewProject) {

            payload.OBL =
                getNumericValue(
                    oblLastMonthInput
                );
        }

        // CreatedDate only for new record.
        if (!editingId) {

            payload.CreatedDate =
                new Date().toISOString();
        }

        console.log(
            "============================================"
        );
        console.log(
            "📤 SHAREPOINT SAVE PAYLOAD"
        );
        console.log(
            "📤 Editing ID:",
            editingId
        );
        console.log(
            "📤 Frozen:",
            isFrozen
        );
        console.log(
            "📤 ForecastData length:",
            forecastDataString.length
        );
        console.log(
            "📤 Payload:",
            payload
        );

        // ========================================================
        // 17. SharePoint URL
        // ========================================================
        const url = editingId
            ? `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${editingId})`
            : `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;

        // ========================================================
        // 18. SharePoint headers
        // ========================================================
        const headers: Record<string, string> = {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest
        };

        // Existing record = MERGE
        if (editingId) {

            headers["IF-MATCH"] = "*";
            headers["X-HTTP-Method"] = "MERGE";

            console.log(
                `🔄 Updating SharePoint item ${editingId}`
            );

        } else {

            console.log(
                "➕ Creating new SharePoint item"
            );
        }

        // ========================================================
        // 19. SEND TO SHAREPOINT
        // ========================================================
        const response = await fetch(
            url,
            {
                method: "POST",
                headers,
                body: JSON.stringify(payload)
            }
        );

        console.log(
            "📥 SharePoint response:",
            response.status,
            response.statusText
        );

        // ========================================================
        // 20. Handle SharePoint response
        // ========================================================
        if (!response.ok) {

            const errorText =
                await response.text();

            console.error(
                "❌ SharePoint save failed:",
                response.status,
                errorText
            );

            toast(
                "error",
                `Error saving forecast: ${response.status}`
            );

            return;
        }

        // ========================================================
        // 21. SUCCESS
        // ========================================================
        console.log(
            "✅ Revenue forecast saved successfully"
        );

        toast(
              "success",
              isFrozen
                ? "✅ Frozen changes saved successfully!"
                : editingId
                  ? "✅ Revenue Plan updated successfully!"
                  : "✅ Revenue Plan saved successfully!"
            );

        // --------------------------------------------------------
        // Reload DB data so UI contains the saved values
        // --------------------------------------------------------
        await loadForecasts();

        // Rebuild pagination using freshly loaded data
        initializePagination(
            filteredData.length
                ? filteredData
                : forecasts
        );

        // Close form
        hideForm();

        // Reset form state
        resetForm();

        console.log(
            "============================================"
        );
        console.log(
            "✅ REVENUE SAVE COMPLETED"
        );
        console.log(
            "============================================"
        );

    } catch (error) {

        console.error(
            "❌ Error saving revenue forecast:",
            error
        );

        toast(
            "error",
            "Error saving forecast!"
        );

    } finally {

        // --------------------------------------------------------
        // Re-enable Save button
        // --------------------------------------------------------
        if (saveButton) {
            saveButton.disabled = false;
            saveButton.dataset.saving = "false";
        }
    }
}); 
const initializeFilters = (): void => {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  
  filterYear.innerHTML = '<option value="">All Years</option>';
  for (let year = currentYear - 1; year <= currentYear + 2; year++) {
    const selected = year === currentYear ? 'selected' : '';
    filterYear.innerHTML += `<option value="${year}" ${selected}>${year}</option>`;
  }
  
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  filterMonth.innerHTML = '<option value="">All Months</option>';
  for (let month = 1; month <= 12; month++) {
    const selected = month === currentMonth ? 'selected' : '';
    filterMonth.innerHTML += `<option value="${month}" ${selected}>${monthNames[month - 1]}</option>`;
  }

  // Get assigned projects for the current user
  // const assignedProjects = getAssignedProjects(projects);
  
  // ✅ Use getAssignedProjectValues helper
  const assignedProjectTitles = getAssignedProjectValues('Title');
  const assignedCustomers = getAssignedProjectValues('CustomerName');
   const assignedManagers = getAssignedProjectValues('ProjectManager');
  const assignedGroupHeads = getAssignedProjectValues('GroupHead1');
  const assignedReferences = getAssignedProjectValues('ProjectReference');

  // ✅ FILTER: Project dropdown - ONLY show assigned projects
  filterProject.innerHTML = '<option value="">All Projects</option>' + 
    assignedProjectTitles.map(project => `<option value="${project}">${project}</option>`).join("");

  // ✅ FILTER: Customer dropdown - ONLY customers from assigned projects
  filterCustomer.innerHTML = '<option value="">All Customers</option>' + 
    assignedCustomers.map(customer => `<option value="${customer}">${customer}</option>`).join("");

  // ✅ FILTER: Project Manager dropdown - ONLY managers from assigned projects
  filterProjectManager.innerHTML = '<option value="">All Managers</option>' + 
    assignedManagers.map(manager => `<option value="${manager}">${manager}</option>`).join("");

  // ✅ FILTER: Group Head dropdown - ONLY group heads from assigned projects
  filterGroupHead.innerHTML = '<option value="">All Group Heads</option>' + 
    assignedGroupHeads.map(head => `<option value="${head}">${head}</option>`).join("");

  // ✅ FILTER: Project Reference dropdown - ONLY references from assigned projects
  filterProjectReference.innerHTML = '<option value="">All References</option>' + 
    assignedReferences.map(ref => `<option value="${ref}">${ref}</option>`).join("");
};

const filterTable = (): void => {
  const year = filterYear.value;
  const month = filterMonth.value;
  const project = filterProject.value;
  const customer = filterCustomer.value;
  const projectManager = filterProjectManager.value;
  const groupHead = filterGroupHead.value;
  const projectReference = filterProjectReference.value; 
  
  let filtered = [...forecasts];

  // ✅ Filter by assigned projects for non-admin/non-GH users
  const assignedProjects = getAssignedProjects(projects);
  const assignedProjectTitles = new Set(assignedProjects.map(p => p.Title));
  
  const isGHHeadUser = isGHHead();
  const isFullControlUser = hasFullControl();
  
  console.log('🔍 filterTable - User roles:', { isGHHeadUser, isFullControlUser });
  console.log('🔍 Assigned project titles:', Array.from(assignedProjectTitles));
  console.log('🔍 Total forecasts before filter:', filtered.length);
  
  if (!isGHHeadUser && !isFullControlUser) {
    const beforeCount = filtered.length;
    filtered = filtered.filter(forecast => {
      const projectTitle = forecast.Project?.Title;
      const isAssigned = projectTitle && assignedProjectTitles.has(projectTitle);
      if (!isAssigned) {
        console.log(`🔍 Filtering out: ${projectTitle} (not assigned to user)`);
      }
      return isAssigned;
    });
    console.log(`🔍 Filtered from ${beforeCount} to ${filtered.length} records (non-GH restriction)`);
  }

  // ✅ FILTER OUT EMPTY PROJECT TITLES
  const beforeEmptyFilter = filtered.length;
  filtered = filtered.filter(forecast => {
    const projectTitle = forecast.Project?.Title;
    const isValid = projectTitle && projectTitle.trim() !== '';
    if (!isValid) {
      console.log(`⚠️ Filtering out record with empty project title:`, forecast);
    }
    return isValid;
  });
  console.log(`🔍 Removed ${beforeEmptyFilter - filtered.length} records with empty project titles`);

  // Apply other filters
  filtered = filtered.filter(forecast => { 
    if (year && month) {
      const monthKey = `${year}-${month.padStart(2, "0")}`;
      const data: ForecastData = safeJsonParse(forecast.ForecastData, {});
      if (!(monthKey in data)) return false;
    }
    
    if (project && forecast.Project?.Title !== project) return false;
    
    if (customer) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.CustomerName !== customer) return false;
    }
    
    // ✅ Project Manager - Person/Group type
    if (projectManager) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      const managerName = getProjectManagerDisplayName(proj?.ProjectManager);
      if (managerName !== projectManager) return false;
    }
    
    // ✅ Group Head - Person/Group type
    if (groupHead) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      const groupHeadName = getGroupHeadDisplayName(proj?.GroupHead1);
      if (groupHeadName !== groupHead) return false;
    }
    
    if (projectReference) {
      const proj = projects.find(p => p.Title === forecast.Project?.Title);
      if (proj?.ProjectReference !== projectReference) return false;
    }
    
    return true;
  }); 
  
  console.log('🔍 Final filtered count:', filtered.length);
  
  // Always use the current pageSize value from the dropdown
  if (pageSizeSelect) {
    pageSize = parseInt(pageSizeSelect.value) || 10;
  }
  
  if (filtered.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="20" style="text-align:center;padding:20px;">No records found for selected filters</td></tr>`;
    
    const totalsHeader = document.querySelector("#totalsHeader") as HTMLElement;
    if (totalsHeader) totalsHeader.innerHTML = '';
    
    filteredData = [];
    currentPage = 1;
    calculateTotalPages();
    updatePaginationControls();
    renderCurrentPage();
  } else {
    // ✅ Set filteredData to the filtered array
    filteredData = filtered;
    currentPage = 1;
    calculateTotalPages();
    updatePaginationControls();
    renderCurrentPage();
    
    const displayMonths = getDisplayMonths();
    const currentMonthKey = formatMonthKey(new Date());
    setTimeout(() => {
      renderTotalsHeader(displayMonths, currentMonthKey);
    }, 100);
  }
};

      // const applyAutoProgression = async (): Promise<void> => { 
      //   if (forecasts.length === 0) { 
      //     return;
      //   }

      //   const digest = await getDigest();
      //   let progressedCount = 0;
      //   let errorCount = 0;
        
      //   for (const forecast of forecasts) {
      //     try {
      //       if (!forecast.ForecastData) { 
      //         continue;
      //       }
            
      //       const originalData = safeJsonParse(forecast.ForecastData, {});
             
      //       if (checkIfNeedsProgression(originalData)) {  
      //         const progressedData = propagateCollectionValues(originalData);
              
      //         const payload = {
      //           __metadata: { type: "SP.Data.Revenue_x0020_Forecast_x0020_ListListItem" },
      //           ForecastData: JSON.stringify(progressedData),
      //           UpdatedDate: new Date().toISOString()
      //         };
              
      //         const response = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`, {
      //           method: "POST",
      //           headers: {
      //             Accept: "application/json;odata=verbose",
      //             "Content-Type": "application/json;odata=verbose",
      //             "X-RequestDigest": digest,
      //             "IF-MATCH": "*",
      //             "X-HTTP-Method": "MERGE"
      //           },
      //           body: JSON.stringify(payload)
      //         });
              
      //         if (response.ok) {
      //           progressedCount++; 
      //         } else {
      //           errorCount++; 
      //         }
              
      //         await new Promise(resolve => setTimeout(resolve, 100));
      //       } else { 
      //       }
      //     } catch (error) {
      //       errorCount++; 
      //     }
      //   }
        
      //   if (progressedCount > 0) { 
      //     await loadForecasts();
      //     toast("success", `Monthly and yearly data progressed for ${progressedCount} revenue forecasts`);
      //   } else if (errorCount > 0) { 
      //     toast("warning", `Some errors occurred during monthly and yearly progression`);
      //   } else { 
      //   }
      // };

const checkIfNeedsProgression = (forecastData: ForecastData): boolean => {
    const now = new Date();
    const currentMonthKey = formatMonthKey(now);
    
    const months = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
    
    if (months.length === 0) return true;
    
    // Get the LAST month in the data (most recent)
    const lastDataMonth = months[months.length - 1];
    
    // Get the ideal months structure
    const idealMonths = generateIdealMonthStructure();
    const lastIdealMonth = idealMonths[idealMonths.length - 1];
    
    // Check if the data already has the current month
    const hasCurrentMonth = months.includes(currentMonthKey);
    
    // If the data doesn't have the current month, we need progression
    if (!hasCurrentMonth) {
        return true;
    }
    
    // If the last data month is older than the last ideal month, progression is needed
    const monthlyProgressionNeeded = lastDataMonth < lastIdealMonth;
    
    // Check yearly progression
    const currentYear = now.getFullYear();
    let yearlyProgressionNeeded = false;
    
    if (forecastData.yearly) {
        const years = Object.keys(forecastData.yearly).map(y => parseInt(y)).sort();
        yearlyProgressionNeeded = years.length > 0 && years[0] < currentYear;
    } else {
        yearlyProgressionNeeded = true;
    }
    
    return monthlyProgressionNeeded || yearlyProgressionNeeded;
};
 
const propagateCollectionValues = (forecastData: ForecastData): ForecastData => {
    const updatedData: ForecastData = { ...forecastData };
    
    if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) {
        const longTermMonths = generateIdealMonthStructure().slice(6);
        const lastMonthKey = longTermMonths[longTermMonths.length - 1];
        updatedData.yearly = createFreshYearlyStructure(lastMonthKey);
    }

    const originalMonths = Object.keys(forecastData).filter(key => key.match(/^\d{4}-\d{2}$/)).sort();
    const idealMonths = generateIdealMonthStructure();
    const isNewMonth = originalMonths[0] !== idealMonths[0];
     
    // ✅ monthActual stays inside the data - only 1 argument
    const monthlyProgressed = propagateMonthValues(updatedData);
    const yearlyProgressed = propagateYearlyValues(monthlyProgressed, isNewMonth); 
    return yearlyProgressed;
};

const propagateYearlyValues = (forecastData: ForecastData, isNewMonth: boolean = false): ForecastData => {
    if (!isNewMonth) { 
        return forecastData;
    }

    const updatedData: ForecastData = { ...forecastData };
    
    if (!updatedData.yearly || Object.keys(updatedData.yearly).length === 0) { 
        return updatedData;
    }

    const yearlyData = updatedData.yearly; 
    const updatedYearlyData: YearlyForecastData = {};

    Object.keys(yearlyData).forEach(year => {
        const yearData = yearlyData[year];
        if (yearData) {
            updatedYearlyData[year] = {
                plan: yearData.actual,
                actual: 0
            };
        }
    });

    updatedData.yearly = updatedYearlyData; 
    return updatedData;
};

      const importActualDatas = (): void => { 
        const modalHTMLRev = `
          <div class="revenue-import-modal" style="display: none;">
            <div class="revenue-import-modal-content">
              <div class="revenue-import-modal-header">
                <h3>Import Monthly Actual Revenue Data</h3>
                <button class="revenue-close-modal">&times;</button>
              </div>

              <div class="revenue-import-section">
                <h4>Step 1: Download Template</h4>
                <button class="revenue-btn-primary" id="downloadTemplate">⬇️ Download Template</button>
              </div>

              <div class="revenue-import-section">
                <h4>Step 2: Upload Excel File</h4>
                <div class="revenue-file-upload-area" id="fileUploadArea">
                  <div class="revenue-upload-icon">📁</div>
                  <p>Click to upload or drag & drop Excel file</p>
                  <p><small>Supported format: Excel with Project Reference, Month, and Actual Revenue columns</small></p>
                  <input type="file" id="excelFile" class="revenue-file-input" accept=".xlsx,.xls">
                  <div class="revenue-file-info" id="fileInfo"></div>
                </div>
              </div>

              <div class="revenue-import-section" id="previewSection" style="display:none;">
                <h4>Step 3: Preview & Import</h4>
                <div class="revenue-import-preview" id="importPreview"></div>
                <div class="revenue-import-actions">
                  <button class="revenue-btn-secondary" id="cancelImport">Cancel</button>
                  <button class="revenue-btn-primary" id="confirmImport">Import Data</button>
                </div>
                <div class="revenue-import-status" id="importStatus"></div>
              </div>
            </div>
          </div>
        `;

        const existingModal = document.querySelector('.revenue-import-modal');
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML("beforeend", modalHTMLRev);
        const modal = document.querySelector(".revenue-import-modal") as HTMLElement;
        
        setTimeout(() => {
            // Only the visibility toggle stays in JS: .revenue-import-modal and
            // .revenue-import-modal-content in src/styles/revenue.css already declare the
            // position, size, colours and shadow these lines assigned - with !important - so
            // the inline values were being overridden anyway.
            modal.style.display = "flex";
        }, 10);

        const fileUploadArea = document.querySelector("#fileUploadArea") as HTMLElement;
        const excelFileInput = document.querySelector("#excelFile") as HTMLInputElement;
        const fileInfo = document.querySelector("#fileInfo") as HTMLElement;
        const previewSection = document.querySelector("#previewSection") as HTMLElement;
        const importPreview = document.querySelector("#importPreview") as HTMLElement;
        const confirmImport = document.querySelector("#confirmImport") as HTMLButtonElement;
        const cancelImport = document.querySelector("#cancelImport") as HTMLButtonElement;
        const closeModal = document.querySelector(".revenue-close-modal") as HTMLButtonElement;
        const importStatus = document.querySelector("#importStatus") as HTMLElement;
        const downloadTemplateBtn = document.querySelector("#downloadTemplate") as HTMLButtonElement;

        let importData: any[] = [];
        let listEntityType: string = "";

        const monthMap: { [key: string]: number } = {
            jan: 1, january: 1, "jan-": 1,
            feb: 2, february: 2, "feb-": 2,
            mar: 3, march: 3, "mar-": 3,
            apr: 4, april: 4, "apr-": 4,
            may: 5, "may-": 5,
            jun: 6, june: 6, "jun-": 6,
            jul: 7, july: 7, "jul-": 7,
            aug: 8, august: 8, "aug-": 8,
            sep: 9, september: 9, "sep-": 9,
            oct: 10, october: 10, "oct-": 10,
            nov: 11, november: 11, "nov-": 11,
            dec: 12, december: 12, "dec-": 12,
        };

        const parseMonth = (monthStr: string): string => {
            if (!monthStr) return "";

            if (/^\d{4}-\d{2}$/.test(monthStr)) {
                return monthStr;
            }

            const match = monthStr.toLowerCase().match(/([a-z]+)[-\s]*'?(\d{2,4})?/);
            if (match) {
                const monthName = match[1];
                let year = match[2];

                const monthNum = monthMap[monthName];
                if (monthNum) {
                    if (!year) {
                        year = new Date().getFullYear().toString();
                    } else if (year.length === 2) {
                        const currentYear = new Date().getFullYear();
                        const century = Math.floor(currentYear / 100) * 100;
                        const yearNum = parseInt(year);
                        year = (century + yearNum).toString();
                    }

                    return `${year}-${monthNum.toString().padStart(2, "0")}`;
                }
            }

            return "";
        };

        const getListEntityTypeForImport = async (): Promise<string> => {
            if (listEntityType) return listEntityType;
            const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`, {
                headers: { Accept: "application/json;odata=verbose" },
            });
            const data = await res.json();
            listEntityType = data.d.ListItemEntityTypeFullName; 
            return listEntityType;
        };

// ============================================================
// Updated updateRevenueData - stores ONLY values > 0
// ============================================================
const updateRevenueData = (existingData: string, month: string, actualRevenue: number): string => {
    let finalData: { [key: string]: number } = {};

    // Parse existing data
    if (existingData && existingData.trim() !== "" && existingData !== "{}" && existingData !== "null" && existingData !== "undefined") {
        try {
            const parsed = JSON.parse(existingData);
            finalData = { ...parsed };
        } catch (parseError) {
            finalData = {};
        }
    } else {
        finalData = {};
    }

    // Update the specific month
    if (actualRevenue > 0) {
        finalData[month] = actualRevenue;
    } else {
        // If value is 0, remove it to keep data compact
        delete finalData[month];
    }

    // Return compact JSON with only values > 0
    const result: { [key: string]: number } = {};
    Object.keys(finalData).forEach(key => {
        if (finalData[key] > 0) {
            result[key] = finalData[key];
        }
    });

    return JSON.stringify(result);
};

        fileUploadArea.addEventListener("click", () => excelFileInput.click());
        fileUploadArea.addEventListener("revenue-dragover", (e) => {
            e.preventDefault();
            fileUploadArea.classList.add("revenue-dragover");
        });
        fileUploadArea.addEventListener("dragleave", () => fileUploadArea.classList.remove("revenue-dragover"));
        fileUploadArea.addEventListener("drop", (e) => {
            e.preventDefault();
            fileUploadArea.classList.remove("revenue-dragover");
            const files = e.dataTransfer?.files;
            if (files && files[0]) {
                excelFileInput.files = files;
                handleFileSelection(files[0]);
            }
        });
        excelFileInput.addEventListener("change", (e) => {
            const files = (e.target as HTMLInputElement).files;
            if (files && files[0]) handleFileSelection(files[0]);
        });

        const handleFileSelection = async (file: File) => { 
            if (!file.name.toLowerCase().match(/\.(xlsx|xls)$/)) {
                toast("error", "Please select an Excel file (.xlsx or .xls)");
                return;
            }

            fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`;

            try {
                const parsedData = await parseExcelFile(file); 
                if (validateImportData(parsedData)) { 
                    importData = parsedData;
                    showImportPreview(parsedData);
                    previewSection.style.display = "block";
                    previewSection.style.opacity = "1"; 
                } else { 
                    toast("error", "Invalid Excel format. Please check the required columns.");
                }
            } catch (error) { 
                toast("error", "Error reading Excel file");
            }
        };

        const parseExcelFile = (file: File): Promise<any[]> => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const data = new Uint8Array(e.target?.result as ArrayBuffer);
                        const workbook = XLSX.read(data, { type: "array" });
                        const sheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[sheetName];

                        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); 
                        if (jsonData.length < 2) { 
                            return resolve([]);
                        }

                        const headers = jsonData[0] as string[];  
                        const rows: any[] = [];

                        for (let i = 1; i < jsonData.length; i++) {
                            const rowData = jsonData[i] as any[];
                            if (!rowData || rowData.length === 0) continue;

                            const row: any = {};

                            headers.forEach((header, idx) => {
                                if (header && rowData[idx] !== undefined && rowData[idx] !== null) {
                                    row[header.trim()] = rowData[idx];
                                }
                            });

                            if (row["Month"] || row["month"]) {
                                let monthValue = row["Month"] || row["month"];

                                if (typeof monthValue === "number") {
                                    const excelDate = new Date(Math.round((monthValue - 25569) * 86400 * 1000));
                                    const yyyy = excelDate.getFullYear();
                                    const mm = String(excelDate.getMonth() + 1).padStart(2, "0");
                                    monthValue = `${yyyy}-${mm}`;
                                }

                                const monthStr = monthValue.toString();
                                row.parsedMonth = parseMonth(monthStr); 
                            }

                            const hasProjectRef = row["Project Reference"] || row["project_reference"];
                            const hasMonth = row.parsedMonth;

                            if (hasProjectRef && hasMonth) {
                                rows.push(row); 
                            } else { 
                            }
                        } 
                        resolve(rows);
                    } catch (err) { 
                        reject(err);
                    }
                };
                reader.onerror = (error) => {
                    console.error("❌ FileReader error:", error);
                    reject(new Error("Failed to read file"));
                };
                reader.readAsArrayBuffer(file);
            });
        };

        const validateImportData = (data: any[]): boolean => { 
            if (data.length === 0) { 
                return false;
            } 
            const first = data[0];
            const keys = Object.keys(first).map((k) => k.toLowerCase()); 
            const hasProjectRef = keys.some((k) => k.includes("project") && k.includes("reference"));
            const hasMonth = keys.some((k) => k.includes("month"));
            const hasRevenue = keys.some((k) => k.includes("actual") && (k.includes("revenue") || k.includes("rev")));

            console.log("✅ Validation results:", { hasProjectRef, hasMonth, hasRevenue, dataLength: data.length });

            return hasProjectRef && hasMonth;
        };

        const showImportPreview = (data: any[]) => { 
            const monthSummary: { [key: string]: number } = {};

            data.forEach((row) => {
                const month = row.parsedMonth;
                if (month) {
                    monthSummary[month] = (monthSummary[month] || 0) + 1;
                }
            });

            const monthSummaryText = Object.keys(monthSummary)
                .map((month) => {
                    return `${month}: ${monthSummary[month]} records`;
                })
                .join(", ");

            const previewHTML = `
                <div style="padding: 20px; background: #f8f9fa; border-radius: 8px;">
                    <h4 style="color: #28a745; margin-bottom: 15px;">✅ File Ready for Import</h4>
                    <p><strong>Found ${data.length} records to import:</strong></p>
                    <p><strong>Month Summary:</strong> ${monthSummaryText || "No months found"}</p>
                    <div class="revenue-preview-table-container" style="max-height: 400px; overflow-y: auto;">
                        <table class="revenue-preview-table" style="width: 100%; border-collapse: collapse;">
                            <thead style="background: #007bff; color: white;">
                                <tr>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Project Reference</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Month</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Actual Revenue</th>
                                    <th style="padding: 10px; border: 1px solid #ddd;">Project Match</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data.slice(0, 10).map((row, index) => {
                                    const projectRef = row["Project Reference"] || row["project_reference"] || "N/A";
                                    const month = row["Month"] || row["month"] || "N/A";
                                    const actualRevenue = row["Actual Revenue"] || row["actual_revenue"] || row["Actual"] || row["actual"] || "0";
                                    const project = projects.find((p) => p.ProjectReference === projectRef);

                                    return `
                                            <tr style="${index % 2 === 0 ? "background: #f8f9fa;" : "background: white;"}">
                                                <td style="padding: 8px; border: 1px solid #ddd;">${projectRef}</td>
                                                <td style="padding: 8px; border: 1px solid #ddd;">${month} (${row.parsedMonth || "Invalid"})</td>
                                                <td style="padding: 8px; border: 1px solid #ddd;">${actualRevenue}</td>
                                                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${project ? "✅" : "❌"}</td>
                                            </tr>
                                        `;
                                }).join("")}
                            </tbody>
                        </table>
                    </div>
                    ${data.length > 10 ? `<p style="margin-top: 10px; font-style: italic;">... and ${data.length - 10} more records</p>` : ""}
                    <div style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 5px;">
                        <p style="margin: 0; color: #0056b3;"><strong>Ready to import?</strong> Click the "Import Data" button below.</p>
                        <p style="margin: 5px 0 0 0; font-size: 12px;"><strong>Note:</strong> Only the imported month will be updated, all other data preserved</p>
                    </div>
                </div>`;

            importPreview.innerHTML = previewHTML; 
        };

        const performImport = async () => {
            confirmImport.disabled = true;
            confirmImport.textContent = "Importing...";
            importStatus.style.display = "block";
            importStatus.textContent = "Updating Revenue Data...";

            let success = 0,
                error = 0,
                notFound = 0,
                invalidMonth = 0,
                skipped = 0;
            const entityType = await getListEntityTypeForImport(); 
            for (const row of importData) {
                const projectRef = row["Project Reference"] || row["project_reference"];
                const month = row.parsedMonth;
                const actualRevenue = parseFloat(row["Actual Revenue"] || row["actual_revenue"] || row["Actual"] || row["actual"] || "0");
                if (!month) { 
                    invalidMonth++;
                    continue;
                }

                const project = projects.find((p) => p.ProjectReference === projectRef);
                if (!project) { 
                    notFound++;
                    continue;
                }

                const forecast = forecasts.find((f) => f.Project?.Title === project.Title);
                if (!forecast?.Id) { 
                    notFound++;
                    continue;
                }

                try {
                    const digest = await getDigest(); 
                    const currentForecastResponse = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})?$select=Id,RevenueActual`, {
                        method: "GET",
                        headers: {
                            Accept: "application/json;odata=verbose",
                        },
                    });

                    if (!currentForecastResponse.ok) {
                        throw new Error(`Failed to fetch current data: ${currentForecastResponse.status}`);
                    }

                    const currentData = await currentForecastResponse.json();
                    const currentRevenueData = currentData.d.RevenueActual || "{}"; 
                    const updatedRevenueData = updateRevenueData(currentRevenueData, month, actualRevenue); 
                    try {
                        const before = JSON.parse(currentRevenueData);
                        const after = JSON.parse(updatedRevenueData);
                        const changedMonths = Object.keys(after).filter((m) => before[m] !== after[m]);
                        console.log(`🔍 CHANGED MONTHS: ${changedMonths.join(", ")}`);
                    } catch (e) { 
                    }

                    const payload = {
                        __metadata: { type: entityType },
                        RevenueActual: updatedRevenueData,
                        UpdatedDate: new Date().toISOString(),
                    }; 
                    const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${listName}')/items(${forecast.Id})`, {
                        method: "POST",
                        headers: {
                            Accept: "application/json;odata=verbose",
                            "Content-Type": "application/json;odata=verbose",
                            "X-RequestDigest": digest,
                            "IF-MATCH": "*",
                            "X-HTTP-Method": "MERGE",
                        },
                        body: JSON.stringify(payload),
                    });

                    if (res.ok) {
                        success++; 
                    } else {
                        error++;
                        const text = await res.text();
                        console.warn(`⚠️ Failed for ${projectRef} (${month}):`, text);
                    }

                    await new Promise((r) => setTimeout(r, 100));
                } catch (err) {
                    error++;
                    console.error(`❌ Error updating ${projectRef} (${month}):`, err);
                }
            }

            skipped = importData.length - (success + error + notFound + invalidMonth);

            importStatus.className = "revenue-import-status success";
            importStatus.innerHTML = `
            <strong>Import Complete!</strong>

            ✅ Success: ${success} records imported

            ❌ Errors: ${error} records

            🔍 Project Not Found: ${notFound} records

            📅 Invalid Month: ${invalidMonth} records

            ⏭️ Skipped: ${skipped} records

            <small>Only the imported month was updated, all other data preserved</small>
        `;

            await loadForecasts();
            initializePagination(forecasts);

            confirmImport.disabled = false;
            confirmImport.textContent = "Import Data";
        };

        downloadTemplateBtn.addEventListener("click", () => {
            if (!projects || projects.length === 0) {
                toast("error", "No projects available to create template");
                return;
            }

            const wsData = [["Project Reference", "Month", "Actual Revenue"]];

            projects.forEach((p) => {
                wsData.push([p.ProjectReference || "", "", ""]);
            });

            const ws = XLSX.utils.aoa_to_sheet(wsData);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Revenue Template");

            const fileName = `Revenue_Import_Template.xlsx`;

            XLSX.writeFile(wb, fileName);
        });

        const closeModalHandler = () => modal.remove();
        closeModal.addEventListener("click", closeModalHandler);
        cancelImport.addEventListener("click", closeModalHandler);
        modal.addEventListener("click", (e) => {
            if (e.target === modal) closeModalHandler();
        });

        confirmImport.addEventListener("click", performImport);
      };

const initialize = async (): Promise<void> => {
    try {
        await authManager.initialize({ siteUrl });

        console.log(`🔑 Permission Level: ${getPermissionLevel().toUpperCase()}`);
        console.log(`👤 User: ${getCurrentUserFullName()}`);
        console.log(`📋 User Groups:`, getUserGroups());
        console.log(`✅ Has Full Control: ${hasFullControl()}`);
        console.log(`✅ Can Contribute: ${canContribute()}`);
        console.log(`✅ Can Freeze: ${canFreeze()}`);
        console.log(`✅ Is GH Head: ${isGHHead()}`);

        await loadProjects();
        await loadForecasts();
        
        console.log("🚀 Total forecasts loaded:", forecasts.length);
        
        // Initialize page size from dropdown
        if (pageSizeSelect) {
            pageSize = parseInt(pageSizeSelect.value) || 10;
            console.log(`📊 Initial page size set to: ${pageSize}`);
        }
        
        if (forecasts.length > 0) {
            await applyAutoProgression();
            await loadForecasts();
        }
        
        initializeFilters();
        
        // Setup pagination event listeners
        setupPaginationEventListeners();
        
        // Call filterTable() to apply project filtering
        filterTable();
        
        // Update UI based on permissions
        updateUIBasedOnPermissions();
        
        // Only attach import button if user has permission
        if (canImportData()) {
            importActualBtns.addEventListener("click", importActualDatas);
        }
         
        console.log("✅ Application initialized successfully");
        console.log(`🔑 Permission Level: ${getPermissionLevel().toUpperCase()}`);
        console.log(`🔒 Freeze permission: ${canFreeze() ? 'ENABLED' : 'DISABLED'}`);
        
    } catch (error) {
        console.error("❌ Failed to initialize application:", error);
        toast("error", "Failed to initialize application");
    }
};
      // ========== EVENT LISTENERS ==========

       
          
      backBtn.addEventListener("click", hideForm);
      
      projectSelect.addEventListener("change", (e) => {
        if (editingId) {
          toast("warning", "Cannot change project in edit mode");
          const forecast = forecasts.find(f => f.Id === editingId);
          if (forecast?.Project) {
            projectSelect.value = String(forecast.Project.Id);
          }
          return;
        }

        const projectId = parseInt((e.target as HTMLSelectElement).value);
        if (projectId) {
          const project = projects.find(p => p.Id === projectId);
          if (project) {
            const existingForecast = forecasts.find(f => f.Project?.Id === projectId);
            if (existingForecast && !editingId) {
              Swal.fire({
                icon: "question",
                title: "Existing Forecast Found",
                text: `A forecast already exists for ${project.Title}. Would you like to edit it?`,
                showCancelButton: true,
                confirmButtonText: "Yes, Edit",
                cancelButtonText: "No, Create New"
              }).then((result) => {
                if (result.isConfirmed) {
                  editingId = existingForecast.Id;
                  showForm(true);
                  onProjectChange(projectId, existingForecast);
                } else {
                  onProjectChange(projectId);
                }
              });
            } else {
              onProjectChange(projectId, existingForecast);
            }
          }
        }
      });

      // Pagination event listeners
      firstPageBtn.addEventListener("click", () => goToPage(1));
      prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
      nextPageBtn.addEventListener("click", () => goToPage(currentPage + 1));
      lastPageBtn.addEventListener("click", () => goToPage(totalPages));

      // Filter event listeners
      filterYear.addEventListener("change", filterTable);
      filterMonth.addEventListener("change", filterTable);
      filterProject.addEventListener("change", filterTable);
      filterCustomer.addEventListener("change", filterTable);
      filterProjectManager.addEventListener("change", filterTable);
      filterGroupHead.addEventListener("change", filterTable);
      filterProjectReference.addEventListener("change", filterTable);

      // Action button event listeners
      exportBtn.addEventListener("click", exportToExcelWithFullStyle);
      exportDetailsBtn.addEventListener("click", exportDetailedItemsToExcel);
      const exportHistoricalBtn = document.querySelector(".revenue-export-historical-btn") as HTMLButtonElement;
      if (exportHistoricalBtn) {
        exportHistoricalBtn.addEventListener("click", exportHistoricalToExcel);
      }
      clearFiltersBtn.addEventListener("click", clearFilters);

      // Initialize the application      
      initialize();
    }, 100);
  }   
};
