// auth.ts
// ============================================
// SHARED ROLE-BASED ACCESS CONTROL SYSTEM
// ============================================

// Declare SharePoint global variable
declare const _spPageContextInfo: any;

// ============================================
// PERMISSION LEVELS DEFINITION
// ============================================

export const PERMISSION_LEVELS = {
  FULL_CONTROL: 'full_control' as const,
  CONTRIBUTE: 'contribute' as const,
  READ: 'read' as const,
  READ_ALL: 'read_all' as const,
  NONE: 'none' as const
} as const;

export type PermissionLevel = typeof PERMISSION_LEVELS[keyof typeof PERMISSION_LEVELS];

// ============================================
// GROUP TO PERMISSION MAPPING
// ============================================

export const GROUP_PERMISSIONS: Record<string, PermissionLevel> = {
  'KRIYA_Admin_Full': PERMISSION_LEVELS.FULL_CONTROL,
  'KRIYA_GH_Heads': PERMISSION_LEVELS.CONTRIBUTE,
  'KRIYA_PM_Managers': PERMISSION_LEVELS.CONTRIBUTE,
  'KRIYA_Engg_Lead': PERMISSION_LEVELS.READ,
  'KRIYA_Engg_Sub1': PERMISSION_LEVELS.READ,
  'KRIYA_Engg_Sub2': PERMISSION_LEVELS.READ,
  'KRIYA_Engg_Mgr': PERMISSION_LEVELS.READ,
  'KRIYA_SC_Team': PERMISSION_LEVELS.READ_ALL,
  'KRIYA_Controlling': PERMISSION_LEVELS.READ_ALL,
};

// ============================================
// INTERFACES
// ============================================

export interface AuthConfig {
  siteUrl: string;
  listName?: string;
  projectListName?: string;
  isCollection?: boolean;
}

export interface UserContext {
  userGroups: string[];
  userPermissionLevel: PermissionLevel;
  currentUserFullName: string;
  currentUserLogin: string;
  isSiteAdmin: boolean;
}

// ============================================
// AUTH MANAGER CLASS
// ============================================

class AuthManager {
  private static instance: AuthManager;
  private context: UserContext;
  private _config: AuthConfig | null;
  private _initialized: boolean;

  private constructor() {
    this.context = {
      userGroups: [],
      userPermissionLevel: PERMISSION_LEVELS.NONE,
      currentUserFullName: '',
      currentUserLogin: '',
      isSiteAdmin: false
    };
    this._config = null;
    this._initialized = false;
  }

  // ============================================
  // SINGLETON INSTANCE
  // ============================================

  public static getInstance(): AuthManager {
    if (!AuthManager.instance) {
      AuthManager.instance = new AuthManager();
    }
    return AuthManager.instance;
  }

  // ============================================
  // INITIALIZATION
  // ============================================

 public async initialize(config: AuthConfig): Promise<void> {
  if (this._initialized) {
    console.log('🔑 Auth already initialized');
    return;
  }

  this._config = config;

  try {
    // Get current user login
    const currentUserLogin = typeof _spPageContextInfo !== 'undefined'
      ? _spPageContextInfo.userLoginName
      : '';

    // ✅ Get user full name - make sure this is working
    const currentUserFullName = await this.fetchCurrentUserFullName(config.siteUrl);
    
    console.log(`✅ Current user full name from SharePoint: "${currentUserFullName}"`);

    // Get user groups
    const userGroups = await this.fetchUserGroups(config.siteUrl);

    // Check site admin
    const isSiteAdmin = typeof _spPageContextInfo !== 'undefined'
      ? _spPageContextInfo.isSiteAdmin
      : false;

    // Determine permission level
    const userPermissionLevel = this.determinePermissionLevel(userGroups, isSiteAdmin);

    // Update context
    this.context = {
      userGroups,
      userPermissionLevel,
      currentUserFullName,
      currentUserLogin,
      isSiteAdmin
    };

    this._initialized = true;

    console.log(`👤 User: ${currentUserFullName} (${currentUserLogin})`);
    console.log(`📋 User Groups:`, userGroups);
    console.log(`🔑 Permission: ${userPermissionLevel.toUpperCase()}`);

  } catch (error) {
    console.error('Error initializing authentication:', error);
    this.context.userPermissionLevel = PERMISSION_LEVELS.NONE;
    this._initialized = true;
  }
}

  // ============================================
  // PRIVATE HELPER METHODS
  // ============================================

  private async fetchCurrentUserFullName(siteUrl: string): Promise<string> {
    try {
      const response = await fetch(`${siteUrl}/_api/web/currentuser`, {
        headers: { Accept: 'application/json;odata=verbose' }
      });
      const data = await response.json();
      return data.d?.Title || '';
    } catch (error) {
      console.error('Error getting user name:', error);
      return '';
    }
  }

  private async fetchUserGroups(siteUrl: string): Promise<string[]> {
    try {
      const response = await fetch(`${siteUrl}/_api/web/currentuser/groups`, {
        headers: { Accept: 'application/json;odata=verbose' }
      });
      const data = await response.json();
      const groups = data.d?.results || [];
      return groups.map((group: any) => group.Title || group.LoginName);
    } catch (error) {
      console.error('Error getting user groups:', error);
      return [];
    }
  }

  private determinePermissionLevel(
    userGroups: string[],
    isSiteAdmin: boolean
  ): PermissionLevel {
    // Site admins get full control
    if (isSiteAdmin) {
      return PERMISSION_LEVELS.FULL_CONTROL;
    }

    let highestLevel: PermissionLevel = PERMISSION_LEVELS.NONE;

    for (const group of userGroups) {
      const permission = GROUP_PERMISSIONS[group];

      if (!permission) continue;

      // FULL_CONTROL has highest priority - return immediately
      if (permission === PERMISSION_LEVELS.FULL_CONTROL) {
        return PERMISSION_LEVELS.FULL_CONTROL;
      }

      // CONTRIBUTE - second highest priority
      if (permission === PERMISSION_LEVELS.CONTRIBUTE) {
        highestLevel = PERMISSION_LEVELS.CONTRIBUTE;
        continue;
      }

      // READ_ALL - third highest priority (only if we haven't set CONTRIBUTE)
      if (permission === PERMISSION_LEVELS.READ_ALL && 
          highestLevel !== PERMISSION_LEVELS.CONTRIBUTE) {
        highestLevel = PERMISSION_LEVELS.READ_ALL;
        continue;
      }

      // READ - lowest priority (only if we haven't set anything higher)
      if (permission === PERMISSION_LEVELS.READ && 
          highestLevel === PERMISSION_LEVELS.NONE) {
        highestLevel = PERMISSION_LEVELS.READ;
      }
    }

    return highestLevel;
  }

  private isInContributeGroup(userGroups: string[]): boolean {
    const contributeGroups = [
      'KRIYA_GH_Heads',
      'KRIYA_PM_Managers'
    ];
    return userGroups.some(group => contributeGroups.includes(group));
  }

  private isInReadGroup(userGroups: string[]): boolean {
    const readGroups = [
      'KRIYA_Engg_Lead',
      'KRIYA_Engg_Sub1',
      'KRIYA_Engg_Sub2',
      'KRIYA_Engg_Mgr'
    ];
    return userGroups.some(group => readGroups.includes(group));
  }

  // ============================================
  // HELPER: GET MANAGER NAME FROM PROJECT
  // ============================================

  private getManagerName(project: any, field: string): string {
    if (!project || !project[field]) return '';
    
    const manager = project[field];
    
    // If it's an object with Title property (expanded user)
    if (typeof manager === 'object' && manager.Title) {
      return manager.Title;
    }
    
    // If it's a string (direct value)
    if (typeof manager === 'string') {
      return manager;
    }
    
    return '';
  }

  // ============================================
  // PUBLIC PERMISSION CHECK METHODS
  // ============================================

  public hasFullControl(): boolean {
    return this.context.userPermissionLevel === PERMISSION_LEVELS.FULL_CONTROL;
  }

  public canContribute(): boolean {
    return this.context.userPermissionLevel === PERMISSION_LEVELS.CONTRIBUTE ||
           this.context.userPermissionLevel === PERMISSION_LEVELS.FULL_CONTROL;
  }

  public canRead(): boolean {
    return this.context.userPermissionLevel !== PERMISSION_LEVELS.NONE;
  }

  public canReadAllProjects(): boolean {
    return this.context.userPermissionLevel === PERMISSION_LEVELS.READ_ALL ||
           this.context.userPermissionLevel === PERMISSION_LEVELS.FULL_CONTROL;
  }

  public canFreeze(): boolean {
    return this.hasFullControl();
  }

  public isGHHead(): boolean {
    return this.context.userGroups.some(group => group === 'KRIYA_GH_Heads');
  }

  public isPMManager(): boolean {
    return this.context.userGroups.some(group => group === 'KRIYA_PM_Managers');
  }

  public isEngineeringUser(): boolean {
    return this.isInReadGroup(this.context.userGroups);
  }

  public getUserGroups(): string[] {
    return [...this.context.userGroups];
  }

  public getCurrentUserFullName(): string {
    return this.context.currentUserFullName;
  }

  public getCurrentUserLogin(): string {
    return this.context.currentUserLogin;
  }

  public getPermissionLevel(): PermissionLevel {
    return this.context.userPermissionLevel;
  }

  public isInitialized(): boolean {
    return this._initialized;
  }

  public getConfig(): AuthConfig | null {
    return this._config;
  }

  // ============================================
  // PROJECT-BASED PERMISSION CHECKS
  // ============================================

  public canEditProject(
    project?: any
  ): boolean {
    // Full Control users can edit everything
    if (this.hasFullControl()) return true;

    // READ_ALL users (SC_Team, Controlling) - Read only all projects
    if (this.context.userPermissionLevel === PERMISSION_LEVELS.READ_ALL) return false;

    // READ users (Engineering roles) - Read only their projects
    if (this.context.userPermissionLevel === PERMISSION_LEVELS.READ) return false;

    // Contribute users need to be in specific groups with project-based access
    if (this.context.userPermissionLevel === PERMISSION_LEVELS.CONTRIBUTE) {
      // Check if user is in any contribute group
      if (!this.isInContributeGroup(this.context.userGroups)) {
        return false;
      }

      // GH Heads can edit all projects
      if (this.context.userGroups.includes('KRIYA_GH_Heads')) {
        return true;
      }

      // PM Managers can ONLY edit their own projects
      // Check if the user is the Project Manager
      const projectManager = this.getManagerName(project, 'ProjectManager');
      if (projectManager) {
        return projectManager.toLowerCase() === this.context.currentUserFullName.toLowerCase();
      }

      return false;
    }

    return false;
  }

  public canCreateRecord(): boolean {
    return this.canContribute();
  }

  public canViewForm(
    isEdit: boolean = false,
    project?: any
  ): boolean {
    if (!this.canRead()) return false;

    if (isEdit) {
      return this.canEditProject(project);
    }

    return this.canCreateRecord();
  }

  // ============================================
  // GET ASSIGNED PROJECTS
  // ============================================

 public getAssignedProjects<T extends {
  Id: number;
  Title: string;
  ProjectManager?: string | { Title: string; Email?: string };
  EnggLead?: string | { Title: string };
  EnggSubLead1?: string | { Title: string };
  EnggSubLead2?: string | { Title: string };
  EngineeringManagers?: string | { Title: string };
  GroupHead1?: string | { Title: string };
}>(
  allProjects: T[]
): T[] {
  // ✅ FULL CONTROL users see all projects
  if (this.hasFullControl()) {
    console.log('✅ Full Control - showing all projects');
    return allProjects;
  }

  // ✅ READ_ALL users see all projects but read-only
  if (this.canReadAllProjects()) {
    console.log('✅ Read All - showing all projects (read-only)');
    return allProjects;
  }

  // ✅ GH Heads see all projects (they can edit)
  if (this.context.userGroups.some(group => group === 'KRIYA_GH_Heads')) {
    console.log('✅ GH Head - showing all projects');
    return allProjects;
  }

  const userFullName = this.context.currentUserFullName.trim();
  
  // ✅ Log for debugging
  console.log(`🔍 Checking projects for user: ${userFullName}`);

  // ✅ Check if user is in any engineering group (READ users)
  if (this.context.userPermissionLevel === PERMISSION_LEVELS.READ) {
    const assigned = allProjects.filter(project => {
      // Check all manager fields
      const managerFields = [
        'ProjectManager',
        'EnggLead',
        'EnggSubLead1',
        'EnggSubLead2',
        'EngineeringManagers',
        'GroupHead1'
      ];

      for (const field of managerFields) {
        const managerData = project[field as keyof typeof project];
        if (!managerData) continue;
        
        let managerName = '';
        if (typeof managerData === 'object' && managerData !== null) {
          // Handle Person/Group object
          managerName = (managerData as any).Title || '';
        } else if (typeof managerData === 'string') {
          managerName = managerData;
        }
        
        if (managerName && managerName.toLowerCase() === userFullName.toLowerCase()) {
          console.log(`✅ User matches ${field}: ${managerName}`);
          return true;
        }
      }
      return false;
    });
    
    console.log(`📋 Engineering User (${userFullName}) found ${assigned.length} assigned projects (read-only) out of ${allProjects.length}`);
    return assigned;
  }

  // ✅ PM Managers: Filter by Project Manager (they can edit their projects)
  if (this.context.userGroups.some(group => group === 'KRIYA_PM_Managers')) {
    const assigned = allProjects.filter(project => {
      const pmData = project.ProjectManager;
      if (!pmData) return false;
      
      let pmName = '';
      if (typeof pmData === 'object' && pmData !== null) {
        pmName = (pmData as any).Title || '';
      } else if (typeof pmData === 'string') {
        pmName = pmData;
      }
      
      return pmName.toLowerCase() === userFullName.toLowerCase();
    });

    console.log(`📋 PM Manager (${userFullName}) found ${assigned.length} assigned projects out of ${allProjects.length}`);
    console.log('📋 Assigned projects:', assigned.map(project => project.Title));

    return assigned;
  }

  // ✅ Default: If user has no specific role, they shouldn't see any projects
  console.log(`⚠️ User ${userFullName} has no assigned projects (not in any specific role)`);
  return [];
}

  public getAssignedProjectValues<T extends {
    Id: number;
    Title: string;
    ProjectManager?: string | { Title: string };
    [key: string]: any;
  }>(
    allProjects: T[],
    key: string
  ): string[] {
    const assigned = this.getAssignedProjects(allProjects);
    const values = new Set<string>();

    for (const project of assigned) {
      let value = project[key];

      if (!value) continue;

      // Handle manager fields with object values
      if (typeof value === 'object' && value.Title) {
        value = value.Title;
      }

      if (typeof value === 'string' && value.trim()) {
        values.add(value.trim());
      }
    }

    return Array.from(values).sort();
  }

  // ============================================
  // UI UPDATE METHODS
  // ============================================

  public updateUIBasedOnPermissions(selectors: {
    importBtn?: string;
    exportBtn?: string;
    addBtn?: string;
    saveBtn?: string;
    freezeCheckboxes?: string;
  } = {}): void {
    const canContribute = this.canContribute();
    const canExport = this.canRead();
    const canFreeze = this.canFreeze();
    const isReadOnly = this.context.userPermissionLevel === PERMISSION_LEVELS.READ ||
                       this.context.userPermissionLevel === PERMISSION_LEVELS.READ_ALL;

    // Import button
    if (selectors.importBtn) {
      const button = document.querySelector(selectors.importBtn) as HTMLElement;
      if (button) {
        button.style.display = canContribute ? '' : 'none';
      }
    }

    // Export button
    if (selectors.exportBtn) {
      const button = document.querySelector(selectors.exportBtn) as HTMLElement;
      if (button) {
        button.style.display = canExport ? '' : 'none';
      }
    }

    // Add button
    if (selectors.addBtn) {
      const button = document.querySelector(selectors.addBtn) as HTMLElement;
      if (button) {
        button.style.display = canContribute ? '' : 'none';
      }
    }

    // Save button
    if (selectors.saveBtn) {
      const button = document.querySelector(selectors.saveBtn) as HTMLElement;
      if (button) {
        button.style.display = canContribute ? '' : 'none';
      }
    }

    // Freeze checkboxes
    if (selectors.freezeCheckboxes) {
      document.querySelectorAll(selectors.freezeCheckboxes).forEach(element => {
        const checkbox = element as HTMLInputElement;
        checkbox.disabled = !canFreeze;
        checkbox.style.pointerEvents = canFreeze ? 'auto' : 'none';
      });
    }

    // Show read-only indicator if needed
    if (isReadOnly) {
      const header = document.querySelector('.page-header h1') as HTMLElement;
      if (header && !header.textContent?.includes('(Read Only)')) {
        header.textContent += ' (Read Only)';
      }
    }
  }

  // ============================================
  // SHAREPOINT UTILITIES
  // ============================================

  public async getDigest(siteUrl: string): Promise<string> {
    const response = await fetch(`${siteUrl}/_api/contextinfo`, {
      method: 'POST',
      headers: { Accept: 'application/json;odata=verbose' }
    });
    const data = await response.json();
    return data.d.GetContextWebInformation.FormDigestValue;
  }

  public async getListEntityType(siteUrl: string, listName: string): Promise<string> {
    try {
      const response = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${listName}')?$select=ListItemEntityTypeFullName`,
        {
          headers: { Accept: 'application/json;odata=verbose' }
        }
      );
      const data = await response.json();
      return data.d.ListItemEntityTypeFullName;
    } catch (error) {
      console.error('Error getting entity type:', error);
      return `SP.Data.${listName.replace(/ /g, '_x0020_')}ListItem`;
    }
  }

  // ============================================
  // RESET AUTH (for testing)
  // ============================================

  public reset(): void {
    this._initialized = false;
    this.context = {
      userGroups: [],
      userPermissionLevel: PERMISSION_LEVELS.NONE,
      currentUserFullName: '',
      currentUserLogin: '',
      isSiteAdmin: false
    };
    this._config = null;
  }
}

// ============================================
// EXPORT SINGLETON INSTANCE
// ============================================

export const authManager = AuthManager.getInstance();

// ============================================
// CONVENIENCE EXPORT FUNCTIONS
// ============================================

export const getAuth = (): AuthManager => authManager;

// Permission check functions
export const hasFullControl = (): boolean => authManager.hasFullControl();
export const canContribute = (): boolean => authManager.canContribute();
export const canRead = (): boolean => authManager.canRead();
export const canReadAllProjects = (): boolean => authManager.canReadAllProjects();
export const canFreeze = (): boolean => authManager.canFreeze();
export const isGHHead = (): boolean => authManager.isGHHead();
export const isPMManager = (): boolean => authManager.isPMManager();
export const isEngineeringUser = (): boolean => authManager.isEngineeringUser();

// User info functions
export const getUserGroups = (): string[] => authManager.getUserGroups();
export const getCurrentUserFullName = (): string => authManager.getCurrentUserFullName();
export const getCurrentUserLogin = (): string => authManager.getCurrentUserLogin();
export const getPermissionLevel = (): PermissionLevel => authManager.getPermissionLevel();

// Project-based permission functions
export const canEditProject = (
  project?: any
): boolean => authManager.canEditProject(project);

export const canCreateRecord = (): boolean => authManager.canCreateRecord();

export const canViewForm = (
  isEdit: boolean = false,
  project?: any
): boolean => authManager.canViewForm(isEdit, project);

// Project filtering functions
export const getAssignedProjects = <T extends {
  Id: number;
  Title: string;
  ProjectManager?: string | { Title: string };
  EnggLead?: string | { Title: string };
  EnggSubLead1?: string | { Title: string };
  EnggSubLead2?: string | { Title: string };
  EngineeringManagers?: string | { Title: string };
  GroupHead1?: string | { Title: string };
}>(
  allProjects: T[]
): T[] => authManager.getAssignedProjects(allProjects);

export const getAssignedProjectValues = <T extends {
  Id: number;
  Title: string;
  ProjectManager?: string | { Title: string };
  [key: string]: any;
}>(
  allProjects: T[],
  key: string
): string[] => authManager.getAssignedProjectValues(allProjects, key);

// UI update function
export const updateUIBasedOnPermissions = (selectors?: {
  importBtn?: string;
  exportBtn?: string;
  addBtn?: string;
  saveBtn?: string;
  freezeCheckboxes?: string;
}): void => authManager.updateUIBasedOnPermissions(selectors);

// SharePoint utility functions
export const getDigest = (siteUrl: string): Promise<string> =>
  authManager.getDigest(siteUrl);

export const getListEntityType = (siteUrl: string, listName: string): Promise<string> =>
  authManager.getListEntityType(siteUrl, listName);

// ============================================
// DEFAULT EXPORT
// ============================================

export default {
  authManager,
  PERMISSION_LEVELS,
  GROUP_PERMISSIONS,
  hasFullControl,
  canContribute,
  canRead,
  canReadAllProjects,
  canFreeze,
  isGHHead,
  isPMManager,
  isEngineeringUser,
  getUserGroups,
  getCurrentUserFullName,
  getCurrentUserLogin,
  getPermissionLevel,
  canEditProject,
  canCreateRecord,
  canViewForm,
  getAssignedProjects,
  getAssignedProjectValues,
  updateUIBasedOnPermissions,
  getDigest,
  getListEntityType
};