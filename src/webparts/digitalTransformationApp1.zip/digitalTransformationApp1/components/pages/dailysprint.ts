declare const _spPageContextInfo: any;
import "../styles/common.css";
import "../styles/dailySprint.css";
import Swal from "sweetalert2";

import {
  authManager,
  getCurrentUserFullName,
  getPermissionLevel,
  getUserGroups,
  getAssignedProjects,
  canCreateRecord,
  canReadAllProjects,
  getDigest as getAuthDigest,
  getListEntityType
} from "./auth";

/* ============================================================
   TYPES + MODULE STATE
   ============================================================ */

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string; Email?: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead1?: string | { Title: string; Email?: string };
  GroupHead1Id?: number;
  EnggLead?: string | { Title: string; Email?: string };
}

interface MonthEntry {
  plan: number;
  actual: number;
  forecast: number;
  /** optional previous-cycle plan snapshot, if the list stores it */
  prevPlan?: number;
  previousPlan?: number;
}
type MonthMap = Record<string, MonthEntry>;

interface ForecastRecord {
  Id: number;
  Title: string;
  Project?: { Id: number; Title: string };
  ProfitCentre?: string;
  /** internal name OBL — on the Collection list this is the Receivables value */
  OBL?: number | string;
  ForecastData?: string;
  CollectionData?: string;
  RevenueActual?: string;
  /** optional JSON snapshot of last cycle's plans: { "2026-07": 1234, ... } */
  PreviousPlanData?: string;
  Remarks?: string | null;
  /** dedicated columns; internal names are the encoded display names */
  'REMARKS_x0028_INTERNAL_x0029_'?: string | null;
  'REMARKS_x0028_SPRINTCELL_x0029_'?: string | null;
  Freeze?: boolean;
  /**
   * Collection "Receivables".
   * ⚠️ The list's DISPLAY name is "ReceivableValue" but its INTERNAL name is
   * `OBL` (see List Settings → the column's FldEdit link says Field=OBL).
   * REST/$select only accepts internal names, so we read `OBL` here.
   * Note this means OBL and Receivables are the SAME underlying column on the
   * Collection list — Collection has no separate OBL figure.
   */
  NormalDue?: number | string;
  NormalOverdue?: number | string;
  RetentionDue?: number | string;
  RetentionOverdue?: number | string;
  /** display name "GstTds", internal name GSTTDS */
  GSTTDS?: number | string;
  WHT?: number | string;
}

interface IPageModule {
  content: string;
  style?: string;
  script?: () => void;
}

type ViewMode = 'revenue' | 'collection';
type SortDirection = 'asc' | 'desc';
type SortColumn =
  | 'projectRef' | 'project' | 'customer' | 'groupHead' | 'projectManager' | 'enggLead'
  | 'obl' | 'receivables'
  | 'prevPlan' | 'plan' | 'actual' | 'further' | 'forecast'
  | 'm2PrevPlan' | 'm2Plan' | 'm3PrevPlan' | 'm3Plan';

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** how many months the sprint view projects forward (current + 2) */
const HORIZON_MONTHS = 3;

let currentViewMode: ViewMode = 'revenue';
let activeMonthKey: string = '';
/** [currentMonthKey, nextMonthKey, monthAfterKey] */
let horizonKeys: string[] = [];
let pageMounted: boolean = false;
let dataLoaded: boolean = false;
let projects: ProjectItem[] = [];
let revenueForecasts: ForecastRecord[] = [];
let collectionItems: ForecastRecord[] = [];

// ─── pagination state ───────────────────────────────
let currentPage = 1;
let pageSize = 10;
let totalPages = 1;
let filteredData: ForecastRecord[] = [];

// ─── sort state ─────────────────────────────────────
let sortColumn: SortColumn | '' = '';
let sortDirection: SortDirection = 'asc';

/* ============================================================
   PURE HELPERS
   ============================================================ */

const toast = (icon: "success" | "error" | "info" | "warning", title: string): void => {
  void Swal.fire({ toast: true, icon, title, position: "top-end", timer: 2000, showConfirmButton: false });
};

const getSafeString = (value: unknown, defaultValue: string = "-"): string => {
  if (value === null || value === undefined) return defaultValue;
  if (typeof value === 'string') return value.trim() || defaultValue;
  if (typeof value === 'object' && 'Title' in (value as object)) {
    return String((value as { Title?: string }).Title || '').trim() || defaultValue;
  }
  return String(value) || defaultValue;
};

const getPersonDisplayName = (value: string | { Title: string } | undefined, fallback: string): string => {
  if (!value) return fallback;
  if (typeof value === "object" && value !== null) return value.Title || fallback;
  return value;
};

const getGroupHeadDisplayName = (v: ProjectItem['GroupHead1']): string => getPersonDisplayName(v, "");
const getProjectManagerDisplayName = (v: ProjectItem['ProjectManager']): string => getPersonDisplayName(v, "");
const getEnggLeadDisplayName = (v: ProjectItem['EnggLead']): string => getPersonDisplayName(v, "-");

const pad2 = (n: number | string): string => String(n).padStart(2, "0");

const safeJsonParse = (jsonString: string | undefined | null, fallback: MonthMap = {}): MonthMap => {
  if (!jsonString || !jsonString.trim() || jsonString.trim() === '""' || jsonString.trim() === "null") {
    return fallback;
  }
  try {
    const parsed = JSON.parse(jsonString.trim());
    return parsed && typeof parsed === 'object' ? parsed as MonthMap : fallback;
  } catch (error) {
    console.error("JSON parse error:", error, "Input:", jsonString);
    return fallback;
  }
};

const safeNumberMap = (jsonString: string | undefined | null): Record<string, number> => {
  if (!jsonString || !jsonString.trim() || jsonString.trim() === '""' || jsonString.trim() === "null") return {};
  try {
    const parsed = JSON.parse(jsonString.trim());
    return parsed && typeof parsed === 'object' ? parsed as Record<string, number> : {};
  } catch {
    return {};
  }
};

const escapeAttr = (value: string): string =>
  value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const dataField = (mode: ViewMode): "ForecastData" | "CollectionData" =>
  mode === 'revenue' ? 'ForecastData' : 'CollectionData';

const SPRINT_CELL_FIELD = 'REMARKS_x0028_SPRINTCELL_x0029_';
const INTERNAL_REMARKS_FIELD = 'REMARKS_x0028_INTERNAL_x0029_';

const splitRemarks = (remarks: string | null | undefined): { internal: string; sprintCell: string } => {
  const raw = remarks || "";
  if (raw.includes('|||')) {
    const parts = raw.split('|||');
    return { internal: parts[0] || "", sprintCell: parts[1] || "" };
  }
  return { internal: raw, sprintCell: "" };
};

const inr = (n: number): string => Math.round(Number(n) || 0).toLocaleString('en-IN');

/**
 * "Concerns" text. Prefers the dedicated `REMARKS (SPRINT CELL)` column, and
 * falls back to the legacy `Remarks` field split on '|||' for older rows.
 */
const getConcerns = (item: ForecastRecord): string => {
  const dedicated = (item as any)[SPRINT_CELL_FIELD];
  if (typeof dedicated === 'string' && dedicated.trim()) return dedicated.trim();
  return splitRemarks(item.Remarks).sprintCell.trim();
};

/** Columns are "Single line of text" in SharePoint, so strip commas/spaces before Number(). */
const toNum = (v: unknown): number => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  if (typeof v !== 'string') return 0;
  const n = Number(v.replace(/[,\s₹]/g, ''));
  return Number.isFinite(n) ? n : 0;
};

/** Receivables — display name "ReceivableValue", internal name `OBL`. */
const getReceivables = (item: ForecastRecord): number => toNum(item.OBL);

/** "2026-07" → "2026-08" (rolls the year over correctly) */
const addMonths = (key: string, delta: number): string => {
  const [ys, ms] = key.split('-');
  const y = parseInt(ys, 10);
  const m = parseInt(ms, 10) - 1 + delta;
  const ny = y + Math.floor(m / 12);
  const nm = ((m % 12) + 12) % 12;
  return `${ny}-${pad2(nm + 1)}`;
};

/** "2026-07" → "Jul'26" */
const shortMonthLabel = (key: string): string => {
  const [y, m] = key.split('-');
  return `${MONTHS[parseInt(m, 10) - 1]}'${y.slice(2)}`;
};

const buildHorizon = (startKey: string): string[] =>
  Array.from({ length: HORIZON_MONTHS }, (_, i) => addMonths(startKey, i));

const siteUrl: string =
  typeof _spPageContextInfo !== "undefined"
    ? _spPageContextInfo.webAbsoluteUrl
    : window.location.origin + "/sites/DigitalTransformationTest";

const revenueListName = "Revenue Forecast List";
const collectionListName = "Collection List";
const projectListName = "Project List";

/* ============================================================
   LEFT COLUMN SEQUENCE — differs per view, per the sprint sheet
   ------------------------------------------------------------
   Revenue:     Project reference · Customer Name · Project · GH · PM ·
                Engg Lead · Concerns · OBL
   Collection:  Project reference · Customer Name · Project · GH · PM ·
                Concerns · Receivables
   "Concerns" is the Remarks(Sprint call) cell pulled from the
   Revenue / Collection page — it sits in the LEFT block, not at the end.
   ============================================================ */

type LeftColKey =
  | 'projectRef' | 'customer' | 'project' | 'gh' | 'pm'
  | 'enggLead' | 'concerns' | 'obl' | 'receivables';

interface LeftColDef {
  key: LeftColKey;
  label: string;
  width: number;
  align?: 'left' | 'center' | 'right';
  /** enables the ▲▼ sort buttons, mapped to this SortColumn */
  sort?: SortColumn;
}

const LEFT_COLUMNS: Record<ViewMode, LeftColDef[]> = {
  revenue: [
    { key: 'projectRef',  label: 'Project reference', width: 120, sort: 'projectRef' },
    { key: 'customer',    label: 'Customer Name',     width: 150, sort: 'customer' },
    { key: 'project',     label: 'Project',           width: 180, sort: 'project' },
    { key: 'gh',          label: 'GH',                width: 90, align: 'center', sort: 'groupHead' },
    { key: 'pm',          label: 'PM',                width: 90, align: 'center', sort: 'projectManager' },
    { key: 'enggLead',    label: 'Engg Lead',         width: 110, align: 'center', sort: 'enggLead' },
    { key: 'concerns',    label: 'Concerns',          width: 180 },
    { key: 'obl',         label: 'OBL',               width: 110, align: 'right', sort: 'obl' }
  ],
  collection: [
    { key: 'projectRef',  label: 'Project reference', width: 120, sort: 'projectRef' },
    { key: 'customer',    label: 'Customer Name',     width: 150, sort: 'customer' },
    { key: 'project',     label: 'Project',           width: 180, sort: 'project' },
    { key: 'gh',          label: 'GH',                width: 90, align: 'center', sort: 'groupHead' },
    { key: 'pm',          label: 'PM',                width: 90, align: 'center', sort: 'projectManager' },
    { key: 'concerns',    label: 'Concerns',          width: 180 },
    { key: 'receivables', label: 'Receivables',       width: 130, align: 'right', sort: 'receivables' }
  ]
};

const leftCols = (): LeftColDef[] => LEFT_COLUMNS[currentViewMode];

/** cumulative left offset for sticky positioning */
const leftOffset = (index: number): number =>
  leftCols().slice(0, index).reduce((sum, c) => sum + c.width, 0);

/** total columns = left block + 5 (current month) + 2 per future month */
const totalCols = (): number =>
  leftCols().length + 5 + 2 * (HORIZON_MONTHS - 1);

/* ============================================================
   CONTENT
   ============================================================ */

const content: string = `
<div class="daily-sprint-page">

  <div class="daily-sprint-header">
    <div class="daily-sprint-title">
      <h1>Daily Sprint</h1>
      <span id="activeViewIndicator" class="daily-sprint-view-indicator">📊 Revenue View</span>
    </div>

    <div class="daily-sprint-header-actions">
      <div class="daily-sprint-view-toggle">
        <button id="toggleRevenue" type="button" class="daily-sprint-toggle-btn toggle-btn-active">Revenue</button>
        <button id="toggleCollection" type="button" class="daily-sprint-toggle-btn toggle-btn-inactive">Collection</button>
      </div>
    </div>
  </div>

  <div class="daily-sprint-table-section">

    <div class="daily-sprint-filters">
      <label class="daily-sprint-filter">Year
        <select id="sprintFilterYear"><option value="">All Years</option></select>
      </label>
      <label class="daily-sprint-filter">Month
        <select id="sprintFilterMonth"><option value="">All Months</option></select>
      </label>
      <label class="daily-sprint-filter">Project
        <select id="sprintFilterProject"><option value="">All Projects</option></select>
      </label>
      <label class="daily-sprint-filter">Customer
        <select id="sprintFilterCustomer"><option value="">All Customers</option></select>
      </label>
      <label class="daily-sprint-filter">Project Manager
        <select id="sprintFilterProjectManager"><option value="">All Managers</option></select>
      </label>
      <label class="daily-sprint-filter">Group Head
        <select id="sprintFilterGroupHead"><option value="">All Group Heads</option></select>
      </label>
      <label class="daily-sprint-filter">Project Reference
        <select id="sprintFilterProjectReference"><option value="">All References</option></select>
      </label>
      <label class="daily-sprint-filter">Engg Lead
        <select id="sprintFilterEnggLead"><option value="">All Engg Leads</option></select>
      </label>
      <button type="button" class="daily-sprint-clear-filters-btn">Clear filters</button>
    </div>

    <!-- 🔐 AUTO-SYNC BAR (only visible to roles with create rights: Admin / GH Head / PM Manager).
         Mirrors the Revenue and Collection page sync bars - console-only reporting. -->
    <div id="sprintSyncBar"
         style="display:none; margin:6px 0 10px 0; align-items:center; gap:12px; flex-wrap:wrap;">
      <button type="button" id="sprintSyncProjectsBtn"
              style="padding:6px 14px; border:1px solid #0078d4; background:#ffffff; color:#0078d4;
                     border-radius:4px; cursor:pointer; font-size:13px; font-weight:600;"
              title="Compare Project List with the active forecast list and add any missing project row">➕ Sync Projects</button>
      <span id="sprintSyncHint" style="font-size:12px; color:#6c757d;"></span>
    </div>

    <div class="sprint-data-container">
        <table class="daily-sprint-table">
          <thead id="sprintTotalsHeader"></thead>
          <thead id="sprintMonthColumnsHeader"></thead>
          <tbody class="sprint-table-body">
            <tr><td colspan="20" class="daily-sprint-empty">Loading data…</td></tr>
          </tbody>
        </table>

      <div class="sprint-pagination-container">
        <div class="sprint-pagination-controls">
          <div class="sprint-pagination-size-selector">
            <label for="sprintPageSize">Show:</label>
            <select id="sprintPageSize" class="sprint-page-size-select">
              <option value="10">10</option>
              <option value="25">25</option>
              <option value="50">50</option>
              <option value="100">100</option>
            </select>
            <span>per page</span>
          </div>

          <div class="sprint-pagination-navigation">
            <button class="sprint-pagination-btn" id="sprintFirstPage" disabled>First</button>
            <button class="sprint-pagination-btn" id="sprintPrevPage" disabled>Previous</button>
            <div class="sprint-pagination-info">Page <span id="sprintCurrentPage">1</span> of <span id="sprintTotalPages">1</span></div>
            <div class="sprint-pagination-pages" id="sprintPageNumbers"></div>
            <button class="sprint-pagination-btn" id="sprintNextPage" disabled>Next</button>
            <button class="sprint-pagination-btn" id="sprintLastPage" disabled>Last</button>
            <div class="sprint-pagination-info">Showing <span id="sprintStartItem">0</span>-<span id="sprintEndItem">0</span> of <span id="sprintTotalItems">0</span> records</div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
`;

/* ============================================================
   STYLE — sticky thead rows + sticky left columns
   ============================================================ */

const style: string = `
  
`;

/* ============================================================
   DATA LOADING
   ============================================================ */

const loadProjects = async (): Promise<void> => {
  try {
    const res = await fetch(
      `${siteUrl}/_api/web/lists/getbytitle('${projectListName}')/items` +
      `?$select=Id,Title,CustomerName,GroupHead1/Title,GroupHead1Id,PC,ProjectReference,ProjectManager/Title,ProjectManagerId,EnggLead/Title,EnggLeadId` +
      `&$expand=GroupHead1,ProjectManager,EnggLead`,
      { headers: { Accept: "application/json;odata=verbose" } }
    );
    const data = await res.json();
    const raw: ProjectItem[] = data?.d?.results || [];

    const byTitle = new Map<string, ProjectItem>();
    raw.forEach(p => {
      if (p && p.Title && !byTitle.has(p.Title)) byTitle.set(p.Title, p);
    });
    projects = Array.from(byTitle.values());
    console.log('📋 Projects loaded:', projects.length);
  } catch (error) {
    console.error("Error loading projects:", error);
    toast("error", "Failed to load projects");
  }
};

const normalizeRecords = (rows: any[], jsonFields: string[]): ForecastRecord[] =>
  rows.map(row => {
    const out: any = { ...row };
    jsonFields.forEach(field => {
      out[field] = typeof row[field] === 'string' ? row[field] : JSON.stringify(row[field] || {});
    });
    out.Freeze = row.Freeze || false;
    return out as ForecastRecord;
  });

/**
 * `PreviousPlanData` is an OPTIONAL column. If a list doesn't have it, SharePoint
 * rejects the whole $select with 400 and we'd load zero rows. So we try with it
 * once, and transparently fall back to a $select without it.
 */
/**
 * Fields that may not exist on every list. Rather than guessing, we let
 * SharePoint tell us: its 400 body names the offending column
 * ("The field or property 'X' does not exist."), so we drop exactly that one
 * and retry. This self-heals for ANY missing column, not just a known list.
 */
const OPTIONAL_FIELDS = ['PreviousPlanData', SPRINT_CELL_FIELD, INTERNAL_REMARKS_FIELD];

/** per-list memo of columns SharePoint has rejected, so we only pay the retry once */
const unsupportedFields: Record<string, Set<string>> = {};

/** pull the bad field name out of an SP error payload */
const parseMissingField = (body: string): string | null => {
  const m = body.match(/field or property '([^']+)' does not exist/i);
  return m ? m[1] : null;
};

const fetchListItems = async (
  listName: string,
  baseSelect: string[],
  extra: string = ''
): Promise<any[]> => {
  const bad = unsupportedFields[listName] || (unsupportedFields[listName] = new Set());

  const build = (fields: string[]): string =>
    `${siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listName)}')/items` +
    `?$select=${fields.join(',')}&$expand=Project&$top=5000${extra}`;

  const attempt = async (fields: string[]): Promise<Response> =>
    fetch(build(fields), { headers: { Accept: "application/json;odata=verbose" } });

  let fields = [...baseSelect, ...OPTIONAL_FIELDS].filter(f => !bad.has(f));
  let res = await attempt(fields);

  // Drop rejected columns one at a time until the query is accepted.
  for (let i = 0; i < OPTIONAL_FIELDS.length + 2 && !res.ok; i++) {
    const body = await res.text();
    const missing = parseMissingField(body);
    if (!missing) {
      throw new Error(`HTTP ${res.status} loading "${listName}": ${body}`);
    }
    const match = fields.find(f => f === missing || f.split('/')[0] === missing);
    if (!match) {
      throw new Error(
        `HTTP ${res.status} loading "${listName}": column '${missing}' is missing ` +
        `but is required by this page.`
      );
    }
    console.warn(
      `⚠️ "${listName}": column '${match}' does not exist — dropping it and retrying. ` +
      `Check List Settings for its INTERNAL name (the Field= value in the column's edit URL).`
    );
    bad.add(match);
    fields = fields.filter(f => f !== match);
    res = await attempt(fields);
  }

  if (!res.ok) {
    throw new Error(`HTTP ${res.status} loading "${listName}": ${await res.text()}`);
  }

  const data = await res.json();
  return data?.d?.results || [];
};

const loadRevenueForecasts = async (): Promise<void> => {
  try {
    const rows = await fetchListItems(revenueListName, [
      'Id', 'Title', 'Project/Id', 'Project/Title', 'ProfitCentre', 'OBL',
      'ForecastData', 'RevenueActual', 'Remarks', 'Created', 'Modified', 'Freeze'
    ]);
    revenueForecasts = normalizeRecords(rows, ['ForecastData', 'RevenueActual', 'PreviousPlanData']);
    console.log("✅ Revenue forecasts loaded:", revenueForecasts.length);
  } catch (error) {
    console.error("Error loading revenue forecasts:", error);
    toast("error", "Failed to load revenue data");
  }
};

const loadCollectionItems = async (): Promise<void> => {
  try {
    const rows = await fetchListItems(collectionListName, [
      'Id', 'Title', 'Project/Id', 'Project/Title', 'ProfitCentre', 'OBL',
      'CollectionData', 'RevenueActual', 'Remarks', 'Created', 'Modified', 'Freeze',
      // 'OBL' is the internal name of the column displayed as "ReceivableValue"
      'NormalDue', 'NormalOverdue', 'RetentionDue', 'RetentionOverdue', 'GSTTDS', 'WHT'
    ]);
    collectionItems = normalizeRecords(rows, ['CollectionData', 'RevenueActual', 'PreviousPlanData']);
    console.log("✅ Collection items loaded:", collectionItems.length);
  } catch (error) {
    console.error("Error loading collection items:", error);
    toast("error", "Failed to load collection data");
  }
};

const currentRecords = (): ForecastRecord[] =>
  currentViewMode === 'revenue' ? revenueForecasts : collectionItems;


/* ============================================================
   AUTO-SYNC MISSING PROJECTS → REVENUE FORECAST LIST / COLLECTION LIST
   Mirrors the Revenue and Collection page implementations 1:1:
   - 🔐 RBAC: runs only for roles with create rights
     (canCreateRecord → Admin FULL_CONTROL / GH Heads / PM Managers)
     and only adds projects inside the role's visible scope
     (canReadAllProjects → all; otherwise assigned projects only).
   - Skeleton rows are identical to what the Revenue/Collection pages
     create (empty ForecastData / CollectionData structure).
   - Idempotent: existing rows are never duplicated or overwritten.
   - Console-only reporting (no status line / toast for added rows).
   ============================================================ */

type SyncJson = { [key: string]: any };
interface SyncItemRow {
  name: string;
  plan: number;
  actual: number;
  forecast: number;
  date: string;
}

const syncMonthKey = (date: Date): string =>
  `${date.getFullYear()}-${pad2(date.getMonth() + 1)}`;

/** Revenue skeleton - same month grid as the Revenue page:
 *  36 historical + 3 detailed (current + next 2) + 15 future months. */
const syncIdealForecastMonths = (): string[] => {
  const months: string[] = [];
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  for (let i = -36; i < 0; i++) months.push(syncMonthKey(new Date(year, month + i, 1)));
  for (let i = 0; i < 3; i++) months.push(syncMonthKey(new Date(year, month + i, 1)));
  for (let i = 3; i < 18; i++) months.push(syncMonthKey(new Date(year, month + i, 1)));
  return Array.from(new Set(months)).sort();
};

const syncEmptyForecastItems = (): { [key: string]: SyncItemRow } => {
  const items: { [key: string]: SyncItemRow } = {};
  for (let i = 1; i <= 10; i++) {
    items[i.toString()] = { name: '', plan: 0, actual: 0, forecast: 0, date: '' };
  }
  return items;
};

const syncFreshYearlyForecast = (lastMonthKey?: string): { [key: string]: { plan: number; actual: number } } => {
  const yearlyData: { [key: string]: { plan: number; actual: number } } = {};
  let startYear: number;
  if (lastMonthKey) {
    startYear = parseInt(lastMonthKey.split('-')[0], 10);
  } else {
    const futureDate = new Date();
    futureDate.setMonth(futureDate.getMonth() + 15);
    startYear = futureDate.getFullYear();
  }
  const endYear = startYear + 4;
  for (let year = startYear; year <= endYear; year++) {
    yearlyData[year.toString()] = { plan: 0, actual: 0 };
  }
  return yearlyData;
};

/** Empty ForecastData JSON - byte-identical shape to the Revenue page's
 *  createFreshForecastStructure(). */
const syncFreshForecastStructure = (): SyncJson => {
  const months = syncIdealForecastMonths();
  const freshData: SyncJson = {};
  const currentMonthKey = syncMonthKey(new Date());
  const currentMonthIndex = months.indexOf(currentMonthKey);
  const detailedStartIndex = currentMonthIndex !== -1 ? currentMonthIndex : 36;

  months.forEach((monthKey, index) => {
    const isDetailedMonth = index >= detailedStartIndex && index < detailedStartIndex + 3;
    freshData[monthKey] = {
      plan: 0,
      actual: 0,
      forecast: 0,
      monthActual: 0,
      items: isDetailedMonth ? syncEmptyForecastItems() : {}
    };
  });

  freshData.yearly = syncFreshYearlyForecast(months[months.length - 1]);
  return freshData;
};

/** Collection skeleton - same month grid as the Collection page:
 *  3 + 33 historical, 3 detailed (current + next 2), 16 future months. */
const syncIdealCollectionMonths = (): string[] => {
  const months: string[] = [];
  const now = new Date();
  for (let i = -3; i < 0; i++) {
    const d = new Date(now);
    d.setMonth(d.getMonth() + i);
    months.push(syncMonthKey(d));
  }
  for (let i = -36; i < -3; i++) {
    const d = new Date(now);
    d.setMonth(d.getMonth() + i);
    months.push(syncMonthKey(d));
  }
  for (let i = 0; i < 3; i++) {
    const d = new Date(now);
    d.setMonth(d.getMonth() + i);
    months.push(syncMonthKey(d));
  }
  for (let i = 3; i < 19; i++) {
    const d = new Date(now);
    d.setMonth(d.getMonth() + i);
    months.push(syncMonthKey(d));
  }
  return months.sort();
};

const syncCollectionCategory = (name: string): SyncItemRow =>
  ({ name, plan: 0, actual: 0, forecast: 0, date: '' });

const syncCollectionCategories = (simple: boolean): { [key: string]: SyncItemRow } => {
  if (simple) {
    return { Normal: syncCollectionCategory('Normal'), Retention: syncCollectionCategory('Retention') };
  }
  return {
    'Normal': syncCollectionCategory('Normal'),
    'Normal Overdue': syncCollectionCategory('Normal Overdue'),
    'Retention': syncCollectionCategory('Retention'),
    'Retention Overdue': syncCollectionCategory('Retention Overdue')
  };
};

const syncFreshYearlyCollection = (lastMonthKey?: string): SyncJson => {
  const yearlyData: SyncJson = {};
  let startYear: number;
  if (lastMonthKey) {
    startYear = parseInt(lastMonthKey.split('-')[0], 10);
  } else {
    startYear = new Date().getFullYear() + 1;
  }
  const endYear = startYear + 3;
  for (let year = startYear; year <= endYear; year++) {
    yearlyData[year.toString()] = {
      plan: 0,
      actual: 0,
      items: {
        Normal: { name: 'Normal', plan: 0, actual: 0 },
        Retention: { name: 'Retention', plan: 0, actual: 0 }
      }
    };
  }
  return yearlyData;
};

/** Empty CollectionData JSON - byte-identical shape to the Collection page's
 *  createFreshCollectionStructure(). */
const syncFreshCollectionStructure = (): SyncJson => {
  const months = syncIdealCollectionMonths();
  const freshData: SyncJson = {};
  const currentMonthKey = syncMonthKey(new Date());
  const currentMonthIndex = months.indexOf(currentMonthKey);
  const detailedStartIndex = currentMonthIndex !== -1 ? currentMonthIndex : 36;

  months.forEach((monthKey, index) => {
    const isDetailedMonth = index >= detailedStartIndex && index < detailedStartIndex + 3;
    let items: { [key: string]: SyncItemRow } | {} = {};
    if (isDetailedMonth) {
      items = syncCollectionCategories(false);
    } else if (index >= detailedStartIndex + 3) {
      items = syncCollectionCategories(true);
    }
    freshData[monthKey] = {
      plan: 0,
      actual: 0,
      monthActual: 0,
      forecast: 0,
      date: '',
      items
    };
  });

  freshData.yearly = syncFreshYearlyCollection(months[months.length - 1]);
  return freshData;
};

/** Title format used by the Revenue page Add-form:
 *  "<Project> - <Year> Forecast - <sum of monthly actuals>" */
const syncForecastTitle = (project: ProjectItem, data: SyncJson): string => {
  const currentYear = new Date().getFullYear();
  let totalValue = 0;
  Object.keys(data).forEach(key => {
    if (key.match(/^\d{4}-\d{2}$/)) {
      const monthData = data[key];
      if (monthData) totalValue += Number(monthData.actual) || 0;
    }
  });
  return `${project.Title} - ${currentYear} Forecast - ${totalValue.toLocaleString()}`;
};

/** Title format used by the Collection page Add-form:
 *  "<Project> - <Year> Collection - <sum of monthly actuals>" */
const syncCollectionTitle = (project: ProjectItem, data: SyncJson): string => {
  const currentYear = new Date().getFullYear();
  let totalValue = 0;
  Object.keys(data).forEach(key => {
    if (key.match(/^\d{4}-\d{2}$/)) {
      const monthData = data[key];
      if (monthData) totalValue += Number(monthData.actual) || 0;
    }
  });
  return `${project.Title} - ${currentYear} Collection - ${totalValue.toLocaleString()}`;
};

/** Cached check: does Revenue Forecast List have a 'ProjectReference'
 *  column, and is it plain text or a Lookup to Project List? */
let sprintRevenueRefField: { exists: boolean; type: string } | null = null;
const syncRevenueRefField = async (): Promise<{ exists: boolean; type: string }> => {
  if (sprintRevenueRefField) return sprintRevenueRefField;
  try {
    const res = await fetch(
      `${siteUrl}/_api/web/lists/getbytitle('${revenueListName}')/fields?$filter=InternalName eq 'ProjectReference'&$select=InternalName,TypeAsString,ReadOnlyField`,
      { headers: { Accept: "application/json;odata=verbose" } }
    );
    const data = await res.json();
    const results = data?.d?.results || [];
    if (results.length > 0) {
      sprintRevenueRefField = { exists: true, type: String(results[0].TypeAsString || "Text") };
      console.log(`📋 Revenue Forecast List ProjectReference column type = ${sprintRevenueRefField.type}`);
    } else {
      sprintRevenueRefField = { exists: false, type: "" };
      console.log("📋 Revenue Forecast List has no ProjectReference column");
    }
  } catch (error) {
    console.error("⚠️ Could not check Revenue ProjectReference column:", error);
    sprintRevenueRefField = { exists: false, type: "" };
  }
  return sprintRevenueRefField;
};

/** Cached check: does Collection List have a 'ProjectReference' column,
 *  and is it plain text or a Lookup to Project List? */
let sprintCollectionRefField: { exists: boolean; type: string } | null = null;
const syncCollectionRefField = async (): Promise<{ exists: boolean; type: string }> => {
  if (sprintCollectionRefField) return sprintCollectionRefField;
  try {
    const res = await fetch(
      `${siteUrl}/_api/web/lists/getbytitle('${collectionListName}')/fields?$filter=InternalName eq 'ProjectReference'&$select=InternalName,TypeAsString,ReadOnlyField`,
      { headers: { Accept: "application/json;odata=verbose" } }
    );
    const data = await res.json();
    const results = data?.d?.results || [];
    if (results.length > 0) {
      sprintCollectionRefField = { exists: true, type: String(results[0].TypeAsString || "Text") };
      console.log(`📋 Collection List ProjectReference column type = ${sprintCollectionRefField.type}`);
    } else {
      sprintCollectionRefField = { exists: false, type: "" };
      console.log("📋 Collection List has no ProjectReference column");
    }
  } catch (error) {
    console.error("⚠️ Could not check Collection ProjectReference column:", error);
    sprintCollectionRefField = { exists: false, type: "" };
  }
  return sprintCollectionRefField;
};

interface SyncTargetConfig {
  /** SharePoint list that receives the rows */
  listName: string;
  /** display label used in console summaries, e.g. "Revenue auto-sync" */
  summaryLabel: string;
  /** rows currently loaded from that list (never duplicated) */
  records: ForecastRecord[];
  /** empty skeleton JSON for a new row */
  skeleton: () => SyncJson;
  /** row title in the same format the page's own Add-form uses */
  titleFor: (project: ProjectItem, fresh: SyncJson) => string;
  /** cached ProjectReference column probe */
  probeRef: () => Promise<{ exists: boolean; type: string }>;
  /** extra JSON field of that list (ForecastData / CollectionData) */
  jsonField: 'ForecastData' | 'CollectionData';
  /** re-load the list from SharePoint (runs after rows were added) */
  reload: () => Promise<void>;
}

const syncMissingRows = async (cfg: SyncTargetConfig): Promise<void> => {
  if (!canCreateRecord()) {
    console.log('👁️ No create rights - sync skipped (Admin/GH Head/PM Manager only)');
    return;
  }

  if (!projects || projects.length === 0) {
    console.log('⚠️ Project List is empty - nothing to sync');
    return;
  }

  try {
    const visibleProjects = canReadAllProjects()
      ? projects
      : getAssignedProjects(projects);

    // Safety re-check against SharePoint itself: the in-memory list may be
    // empty/stale, so never create rows for projects that already exist.
    let serverRows: any[] = [];
    try {
      const chkRes = await fetch(
        `${siteUrl}/_api/web/lists/getbytitle('${cfg.listName}')/items?$select=Id,ProjectId,Title&$top=5000`,
        { headers: { Accept: "application/json;odata=verbose" } }
      );
      if (chkRes.ok) serverRows = (await chkRes.json())?.d?.results || [];
    } catch (chkErr) {
      console.error(`⚠️ ${cfg.summaryLabel} safety-check fetch failed:`, chkErr);
    }

    // If the list really has rows on SharePoint but the page loaded 0, the
    // main load is broken - creating rows now would duplicate everything.
    if (serverRows.length > 0 && cfg.records.length === 0) {
      console.warn(
        `⚠️ ${cfg.listName} already has ${serverRows.length} row(s) on SharePoint but the page loaded 0 - ` +
        `sync stopped to avoid duplicates. Check the main list load.`
      );
      return;
    }

    const existsOnServer = (p: ProjectItem): boolean =>
      serverRows.some(c => Number(c.ProjectId) === p.Id);

    const existsInMemory = (p: ProjectItem): boolean =>
      cfg.records.some(r =>
        r.Project?.Id === p.Id || (r.Project && r.Project.Title === p.Title)
      );

    const missingProjects = visibleProjects.filter(p => !existsOnServer(p) && !existsInMemory(p));

    if (missingProjects.length === 0) {
      console.log(`✅ In sync: all ${visibleProjects.length} visible project(s) have a ${cfg.listName} row`);
      return;
    }

    console.log(`🆕 ${missingProjects.length} missing: ${missingProjects.map(p => p.Title).join(', ')}`);

    const digest = await getAuthDigest(siteUrl);
    const entityType = await getListEntityType(siteUrl, cfg.listName);
    let added = 0;
    let failed = 0;
    const errors: string[] = [];

    for (const project of missingProjects) {
      let ok = false;
      // Up to 3 payload variants (same as the Revenue/Collection pages):
      //   1 = full create - ProjectReference lookup id as STRING + OBL as STRING
      //   2 = without ProjectReference (column may be read-only/misconfigured)
      //   3 = without OBL too (column may be read-only/absent)
      for (let attempt = 1; attempt <= 3 && !ok; attempt++) {
        try {
          const freshData = cfg.skeleton();

          // odata=verbose values must be STRINGs (Edm.String): lookup ids and
          // numeric fields sent as JSON numbers get a 400 "Cannot convert a
          // primitive value to the expected type 'Edm.String'".
          const payload: any = {
            __metadata: { type: entityType },
            Title: cfg.titleFor(project, freshData),
            ProjectId: project.Id.toString(),
            ProfitCentre: project.PC || "",
            Remarks: "",
            OBL: String(project.PC ? 100000 : 0),
            CreatedDate: new Date().toISOString(),
            UpdatedDate: new Date().toISOString()
          };
          payload[cfg.jsonField] = JSON.stringify(freshData);
          if (cfg.jsonField === 'ForecastData') {
            payload.RevenueActual = "{}";
          }

          // Store Project Reference when the column exists - same rule as the
          // Revenue/Collection page syncs: a LOOKUP column receives the target
          // item ID as a string (ProjectReferenceId), a text column receives
          // the text.
          const refField = await cfg.probeRef();
          if (refField.exists && attempt === 1) {
            if (refField.type === "Lookup") {
              payload.ProjectReferenceId = String(project.Id);
            } else {
              payload.ProjectReference = project.ProjectReference || "";
            }
          }
          if (attempt >= 2) {
            delete payload.ProjectReference;
            delete payload.ProjectReferenceId;
          }
          if (attempt >= 3) {
            delete payload.OBL;
          }

          const res = await fetch(`${siteUrl}/_api/web/lists/getbytitle('${cfg.listName}')/items`, {
            method: "POST",
            headers: {
              Accept: "application/json;odata=verbose",
              "Content-Type": "application/json;odata=verbose",
              "X-RequestDigest": digest
            },
            body: JSON.stringify(payload)
          });

          if (res.ok) {
            ok = true;
            added++;
            console.log(`✅ Added: ${project.Title}${project.ProjectReference ? ' (' + project.ProjectReference + ')' : ''}`);
          } else {
            const bodyText = await res.text();
            let message = `HTTP ${res.status}`;
            try {
              const errJson = JSON.parse(bodyText);
              message = errJson?.error?.message?.value || message;
            } catch (e) { /* keep http message */ }
            console.error(`❌ Attempt ${attempt} failed for ${project.Title}: ${bodyText}`);
            if (attempt === 2) {
              failed++;
              errors.push(`${project.Title} -> ${message}`);
            }
          }
        } catch (projectError) {
          console.error(`❌ Attempt ${attempt} error for ${project.Title}:`, projectError);
          if (attempt === 2) {
            failed++;
            errors.push(`${project.Title} -> ${projectError instanceof Error ? projectError.message : String(projectError)}`);
          }
        }
        if (!ok) await new Promise(resolve => setTimeout(resolve, 300));
      }
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    if (added > 0) {
      await cfg.reload();
      console.log(`➕ ${cfg.summaryLabel} added ${added} project(s)` + (failed > 0 ? ` (${failed} failed)` : ""));
    } else if (failed > 0) {
      console.error(`❌ ${cfg.summaryLabel} failed for ${failed} project(s): ${errors.join(' | ')}`);
    }
  } catch (error) {
    console.error(`❌ ${cfg.summaryLabel} failed:`, error);
  }
};

/** Auto-sync: Project List → Revenue Forecast List (one row per missing
 *  visible project, empty ForecastData skeleton). Same logic as the Revenue
 *  page. Console-only reporting. */
const syncMissingProjectsToRevenueList = async (): Promise<void> => {
  await syncMissingRows({
    listName: revenueListName,
    summaryLabel: 'Revenue auto-sync',
    records: revenueForecasts,
    skeleton: syncFreshForecastStructure,
    titleFor: syncForecastTitle,
    probeRef: syncRevenueRefField,
    jsonField: 'ForecastData',
    reload: loadRevenueForecasts
  });
};

/** Auto-sync: Project List → Collection List (one row per missing visible
 *  project, empty CollectionData skeleton). Same logic as the Collection
 *  page. Console-only reporting. */
const syncMissingProjectsToCollectionList = async (): Promise<void> => {
  await syncMissingRows({
    listName: collectionListName,
    summaryLabel: 'Collection auto-sync',
    records: collectionItems,
    skeleton: syncFreshCollectionStructure,
    titleFor: syncCollectionTitle,
    probeRef: syncCollectionRefField,
    jsonField: 'CollectionData',
    reload: loadCollectionItems
  });
};

/* ============================================================
   PAGE MODULE
   ============================================================ */

const sprintPage: IPageModule = {
  content,
  style,

  script: () => {
    const remount = pageMounted;
    pageMounted = true;

    /* ---------- DOM LOOKUPS ---------- */
    const root = (document.querySelector('.daily-sprint-page') || document) as HTMLElement;
    const q = <T extends Element>(sel: string): T | null => root.querySelector(sel) as T | null;

    const toggleRevenueBtn = q<HTMLButtonElement>("#toggleRevenue");
    const toggleCollectionBtn = q<HTMLButtonElement>("#toggleCollection");
    const activeViewIndicator = q<HTMLElement>("#activeViewIndicator");
    const sprintTableBody = q<HTMLElement>(".sprint-table-body");
    const sprintTotalsHeader = q<HTMLElement>("#sprintTotalsHeader");
    const sprintMonthColumnsHeader = q<HTMLElement>("#sprintMonthColumnsHeader");

    const pageSizeSelect = q<HTMLSelectElement>("#sprintPageSize");
    const firstPageBtn = q<HTMLButtonElement>("#sprintFirstPage");
    const prevPageBtn  = q<HTMLButtonElement>("#sprintPrevPage");
    const nextPageBtn  = q<HTMLButtonElement>("#sprintNextPage");
    const lastPageBtn  = q<HTMLButtonElement>("#sprintLastPage");
    const currentPageSpan = q<HTMLElement>("#sprintCurrentPage");
    const totalPagesSpan  = q<HTMLElement>("#sprintTotalPages");
    const pageNumbersDiv  = q<HTMLElement>("#sprintPageNumbers");
    const startItemSpan   = q<HTMLElement>("#sprintStartItem");
    const endItemSpan     = q<HTMLElement>("#sprintEndItem");
    const totalItemsSpan  = q<HTMLElement>("#sprintTotalItems");

    const filterYear = q<HTMLSelectElement>("#sprintFilterYear");
    const filterMonth = q<HTMLSelectElement>("#sprintFilterMonth");
    const filterProject = q<HTMLSelectElement>("#sprintFilterProject");
    const filterCustomer = q<HTMLSelectElement>("#sprintFilterCustomer");
    const filterProjectManager = q<HTMLSelectElement>("#sprintFilterProjectManager");
    const filterGroupHead = q<HTMLSelectElement>("#sprintFilterGroupHead");
    const filterProjectReference = q<HTMLSelectElement>("#sprintFilterProjectReference");
    const filterEnggLead = q<HTMLSelectElement>("#sprintFilterEnggLead");
    const clearFiltersBtn = q<HTMLButtonElement>(".daily-sprint-clear-filters-btn");

    const required: Array<[string, Element | null]> = [
      [".sprint-table-body", sprintTableBody],
      ["#toggleRevenue", toggleRevenueBtn],
      ["#toggleCollection", toggleCollectionBtn],
      ["#sprintFilterYear", filterYear],
      ["#sprintPageSize", pageSizeSelect],
      ["#sprintTotalsHeader", sprintTotalsHeader],
      ["#sprintMonthColumnsHeader", sprintMonthColumnsHeader]
    ];
    const missing = required.filter(([, el]) => !el).map(([s]) => s);
    if (missing.length) console.error(`❌ sprint page: missing element(s): ${missing.join(", ")}`);

    /* ---------- PER-MONTH VALUE READERS ---------- */

    /** Actual revenue for a month, read from the separate RevenueActual column. */
    const getActual = (item: ForecastRecord, monthKey: string): number => {
      const map = safeNumberMap(item.RevenueActual);
      const n = Number(map[monthKey]);
      return Number.isFinite(n) ? n : 0;
    };

    const getMonthEntry = (item: ForecastRecord, monthKey: string): MonthEntry =>
      safeJsonParse(item[dataField(currentViewMode)])[monthKey] || { plan: 0, actual: 0, forecast: 0 };

    /** Previous (last cycle's) plan for a month.
     *  Priority: PreviousPlanData["YYYY-MM"] → monthEntry.prevPlan / previousPlan → 0 */
    const getPrevPlan = (item: ForecastRecord, monthKey: string): number => {
      const snap = safeNumberMap(item.PreviousPlanData);
      if (Number.isFinite(Number(snap[monthKey]))) return Number(snap[monthKey]) || 0;
      const md = getMonthEntry(item, monthKey);
      const v = md.prevPlan ?? md.previousPlan;
      return Number.isFinite(Number(v)) ? Number(v) || 0 : 0;
    };

    const getCurrPlan = (item: ForecastRecord, monthKey: string): number =>
      getMonthEntry(item, monthKey).plan || 0;

    const getFurther = (item: ForecastRecord, monthKey: string): number =>
      getMonthEntry(item, monthKey).forecast || 0;

    const getForecast = (item: ForecastRecord, monthKey: string): number =>
      getActual(item, monthKey) + getFurther(item, monthKey);

    /* ---------- TOTALS (all three months) ---------- */
    interface MonthTotals { prevPlan: number; plan: number; actual: number; further: number; forecast: number; }

    const computeTotals = (data: ForecastRecord[]): MonthTotals[] =>
      horizonKeys.map(key => {
        const t: MonthTotals = { prevPlan: 0, plan: 0, actual: 0, further: 0, forecast: 0 };
        data.forEach(item => {
          t.prevPlan += getPrevPlan(item, key);
          t.plan     += getCurrPlan(item, key);
          t.actual   += getActual(item, key);
          t.further  += getFurther(item, key);
        });
        t.forecast = t.actual + t.further;
        return t;
      });

    /* ---------- HEADER RENDERING ---------- */

    const sortBtns = (col: SortColumn): string => {
      const asc = sortColumn === col && sortDirection === 'asc';
      const desc = sortColumn === col && sortDirection === 'desc';
      return `
        <div class="sprint-sort-buttons-container">
          <button class="sprint-sort-btn sprint-sort-asc${asc ? ' active' : ''}" data-sort="${col}" data-direction="asc" title="Sort Ascending">▲</button>
          <button class="sprint-sort-btn sprint-sort-desc${desc ? ' active' : ''}" data-sort="${col}" data-direction="desc" title="Sort Descending">▼</button>
        </div>`;
    };

    const subTh = (col: SortColumn, label: string, extraClass = ''): string => `
      <th class="sprint-subheader ${extraClass}" data-col="${col}">
        <div class="sprint-sort-header-container">
          <span class="sprint-header-label">${label}</span>
          ${sortBtns(col)}
        </div>
      </th>`;

    /** inline sticky-left geometry for a left column at position `i` */
    const leftCellStyle = (i: number): string => {
      const c = leftCols()[i];
      const off = leftOffset(i);
      return `left:${off}px; width:${c.width}px; min-width:${c.width}px; max-width:${c.width}px;`;
    };

    const leftCellClass = (i: number, prefix: 'th' | 'td'): string => {
      const c = leftCols()[i];
      const last = i === leftCols().length - 1;
      return [
        'sprint-left-cell',
        `sprint-${prefix}-${c.key}`,
        `sprint-col-${c.key}`,
        c.align ? `align-${c.align}` : '',
        last ? 'sprint-left-last' : ''
      ].filter(Boolean).join(' ');
    };

    const renderMonthColumnsHeader = (): void => {
      if (!sprintMonthColumnsHeader) return;

      const [m1, m2, m3] = horizonKeys;
      const m1Label = `${shortMonthLabel(m1)} (Current Month)`;

      /* Left block — sequence comes from LEFT_COLUMNS[currentViewMode] */
      const leftHeaders = leftCols().map((c, i) => `
          <th class="${leftCellClass(i, 'th')}" style="${leftCellStyle(i)}" rowspan="2">
            <div class="sprint-sort-header-container">
              <span class="sprint-header-label">${c.label}</span>
              ${c.sort ? sortBtns(c.sort) : ''}
            </div>
          </th>`).join('');

      /* Row 2 — month group bar: current month spans 5 cols, each future month spans 2 */
      const row2 = `
        <tr class="sprint-month-header">
          ${leftHeaders}

          <th class="month-current month-sep" colspan="5">
            <div class="sprint-sort-header-container">
              <span class="sprint-header-label">${m1Label}</span>
              ${sortBtns('forecast')}
            </div>
          </th>

          <th class="month-future month-sep" colspan="2">
            <div class="sprint-sort-header-container">
              <span class="sprint-header-label">${shortMonthLabel(m2)}</span>
              ${sortBtns('m2Plan')}
            </div>
          </th>

          <th class="month-future month-sep" colspan="2">
            <div class="sprint-sort-header-container">
              <span class="sprint-header-label">${shortMonthLabel(m3)}</span>
              ${sortBtns('m3Plan')}
            </div>
          </th>
        </tr>`;

      /* Row 3 — sub-columns */
      const row3 = `
        <tr class="sprint-subheader-row">
          ${subTh('prevPlan', 'Previous Plan', 'month-sep')}
          ${subTh('plan',     'Current Plan')}
          ${subTh('actual',   'Actuals')}
          ${subTh('further',  'Further')}
          ${subTh('forecast', 'Forecast')}

          ${subTh('m2PrevPlan', 'Previous Plan', 'month-sep')}
          ${subTh('m2Plan',     'Current Plan')}

          ${subTh('m3PrevPlan', 'Previous Plan', 'month-sep')}
          ${subTh('m3Plan',     'Current Plan')}
        </tr>`;

      sprintMonthColumnsHeader.innerHTML = row2 + row3;

      // table must be at least as wide as left block + month columns
      const table = root.querySelector<HTMLTableElement>('.daily-sprint-table');
      if (table) {
        const leftWidth = leftCols().reduce((sum, c) => sum + c.width, 0);
        table.style.minWidth = `${leftWidth + 5 * 105 + 4 * 105}px`;
      }
    };

    const renderTotalsHeader = (): void => {
      if (!sprintTotalsHeader) return;
      const allData = currentRecords();
      const filtered = filteredData;
      const all = computeTotals(allData);
      const filt = computeTotals(filtered);
      const showFiltered = filtered.length > 0 && filtered.length !== allData.length;

      const sumOf = (rows: ForecastRecord[], read: (r: ForecastRecord) => number): number =>
        rows.reduce((acc, r) => acc + (Number(read(r)) || 0), 0);

      const buildRow = (
        label: string, t: MonthTotals[], labelClass: string,
        rows: ForecastRecord[]
      ): string => {
        const cols = leftCols();
        const oblTotal  = sumOf(rows, r => toNum(r.OBL));
        const recvTotal = sumOf(rows, getReceivables);

        // The trailing money column (OBL on Revenue, Receivables on Collection)
        // keeps its own cell so its total lines up under the header. Everything
        // before it collapses into ONE merged label cell:
        //   Revenue    → 7 merged (Project reference … Concerns) + OBL
        //   Collection → 6 merged (Project reference … Concerns) + Receivables
        const moneyIdx = cols.findIndex(c => c.key === 'obl' || c.key === 'receivables');
        const mergeCount = moneyIdx === -1 ? cols.length : moneyIdx;

        // merged cell spans the combined width of the columns it replaces so the
        // sticky-left geometry still matches the body rows
        const mergedWidth = cols.slice(0, mergeCount).reduce((sum, c) => sum + c.width, 0);
        const mergedStyle = `left:0px; width:${mergedWidth}px; min-width:${mergedWidth}px; max-width:${mergedWidth}px;`;

        const mergedCell = `
          <th class="sprint-left-cell sprint-th-merged ${labelClass}"
              style="${mergedStyle}" colspan="${mergeCount}">${label}</th>`;

        const moneyCell = moneyIdx === -1 ? '' : `
          <th class="${leftCellClass(moneyIdx, 'th')} sprint-totals-num"
              style="${leftCellStyle(moneyIdx)}">${
            cols[moneyIdx].key === 'obl' ? inr(oblTotal) : inr(recvTotal)
          }</th>`;

        return `
        <tr class="sprint-totals-detail">
          ${mergedCell}${moneyCell}

          <th class="sprint-totals-num month-sep">${inr(t[0].prevPlan)}</th>
          <th class="sprint-totals-num">${inr(t[0].plan)}</th>
          <th class="sprint-totals-num">${inr(t[0].actual)}</th>
          <th class="sprint-totals-num">${inr(t[0].further)}</th>
          <th class="sprint-totals-forecast">${inr(t[0].forecast)}</th>

          <th class="sprint-totals-num month-sep">${inr(t[1].prevPlan)}</th>
          <th class="sprint-totals-num">${inr(t[1].plan)}</th>

          <th class="sprint-totals-num month-sep">${inr(t[2].prevPlan)}</th>
          <th class="sprint-totals-num">${inr(t[2].plan)}</th>
        </tr>`;
      };

      const band = `
        <tr class="sprint-totals-bar">
          <th colspan="${totalCols()}">
            📊 Daily Sprint Totals — ${horizonKeys.map(shortMonthLabel).join(' · ')}
          </th>
        </tr>`;

      let html = band;
      if (allData.length > 0) html += buildRow('All Projects', all, 'sprint-totals-label', allData);
      if (showFiltered)       html += buildRow('Filtered', filt, 'sprint-totals-label-filtered', filtered);

      sprintTotalsHeader.innerHTML = html;
      applyStickyHeaderOffsets();
    };

    /**
     * Assign a cumulative `top` to every header row so that all thead rows
     * (totals band → totals detail → month bar → sub-columns) stack and stay
     * pinned while the table body scrolls underneath.
     */
    /**
     * Find the app's fixed/sticky main header (SharePoint suite bar, SPA
     * chrome, etc.) so our table header parks directly beneath it instead of
     * sliding underneath. Returns its bottom edge in px.
     */
    /**
     * position:sticky silently stops working if ANY ancestor has an overflow
     * other than visible (or a transform/filter/contain, which create a
     * containing block). SPFx wraps web parts in several such divs. Walk up
     * from the table and neutralise the offenders, remembering the nearest
     * real scrolling ancestor so we can listen to the right scroll events.
     */
    let scrollParent: HTMLElement | Window = window;

    /**
     * READ-ONLY. Find the element that actually scrolls our table.
     *
     * ⚠️ This deliberately does NOT modify any ancestor. An earlier version
     * force-set overflow/transform on ancestors to "unlock" sticky, but those
     * are the host app's own layout nodes — clobbering them broke page
     * scrolling and hid the sidebar (which is positioned with a transform).
     * We only ever style elements inside our own root.
     */
    /** ancestors we relaxed, so we can put them back exactly as they were */
    const patchedAncestors: Array<{ el: HTMLElement; prev: string }> = [];

    /**
     * Find the element that actually scrolls our table, and clear the one
     * thing that silently defeats sticky: a NON-scrolling ancestor with
     * overflow hidden/clip between us and that scroller.
     *
     * ⚠️ Deliberately conservative. An earlier version rewrote overflow AND
     * transform on every ancestor, which broke the host page's scrolling and
     * hid the sidebar (positioned via transform). Now we:
     *   - stop at the scroller and never look past it
     *   - only touch elements that clip WITHOUT scrolling (a no-op for layout)
     *   - never touch transform/filter/contain
     *   - record every change so restoreAncestors() can undo it
     */
    const detectScrollParent = (): void => {
      const table = root.querySelector<HTMLElement>('.daily-sprint-table');
      if (!table) { scrollParent = window; return; }

      const clipping: Array<HTMLElement> = [];
      let el: HTMLElement | null = table.parentElement;
      let found: HTMLElement | Window = window;

      while (el && el !== document.body && el !== document.documentElement) {
        const cs = getComputedStyle(el);
        const scrolls = /(auto|scroll|overlay)/.test(cs.overflowY)
                      && el.scrollHeight > el.clientHeight + 1;
        if (scrolls) { found = el; break; }   // reached the scrollport - stop

        // clips but never scrolls => harmless to relax, fatal to sticky if left
        if (/(hidden|clip)/.test(cs.overflowY) && el.scrollHeight <= el.clientHeight + 1) {
          clipping.push(el);
        }
        el = el.parentElement;
      }

      clipping.forEach(node => {
        if (patchedAncestors.some(p => p.el === node)) return;
        patchedAncestors.push({ el: node, prev: node.style.overflow });
        node.style.overflow = 'visible';
      });

      scrollParent = found;
    };

    /** put every ancestor we relaxed back the way we found it */
    const restoreAncestors = (): void => {
      patchedAncestors.forEach(({ el, prev }) => { el.style.overflow = prev; });
      patchedAncestors.length = 0;
    };

    /**
     * Find the app's fixed/sticky main header (SharePoint suite bar, SPA
     * chrome, etc.) so our table header parks directly beneath it instead of
     * sliding underneath. Returns its bottom edge in px.
     */
    const measureAppHeaderOffset = (): number => {
      const candidates = [
        '#SuiteNavPlaceHolder', '#spSiteHeader', '#sp-appBar', '#sp-appBar-mobile',
        '.od-TopBar', '.ms-CommandBar', '.sp-appBar',
        '[class*="commandBarWrapper"]', '[data-automation-id="pageCommandBar"]',
        '.app-header', '.main-header', 'header.sticky', '[data-sprint-header]'
      ];

      // collect every docked bar first
      const bars: Array<{ top: number; bottom: number }> = [];
      const seen = new Set<HTMLElement>();
      candidates.forEach(sel => {
        let nodes: NodeListOf<HTMLElement>;
        try { nodes = document.querySelectorAll<HTMLElement>(sel); } catch { return; }
        nodes.forEach(el => {
          if (seen.has(el)) return;
          seen.add(el);
          const cs = getComputedStyle(el);
          if (cs.position !== 'fixed' && cs.position !== 'sticky') return;
          if (cs.display === 'none' || cs.visibility === 'hidden') return;
          const r = el.getBoundingClientRect();
          if (r.height > 0 && r.top < 200) bars.push({ top: r.top, bottom: r.bottom });
        });
      });

      // Chrome bars STACK (suite bar at 0, command bar beneath it). Walk the
      // chain: start at the viewport top and keep absorbing any bar that
      // begins at/above the current bottom edge.
      bars.sort((a, b) => a.top - b.top);
      let bottom = 0;
      let grew = true;
      while (grew) {
        grew = false;
        bars.forEach(bar => {
          if (bar.top <= bottom + 4 && bar.bottom > bottom) {
            bottom = bar.bottom;
            grew = true;
          }
        });
      }
      return Math.round(bottom);
    };

    /**
     * Stack every thead row with a cumulative `top`, starting below the app
     * header, so all four rows stay pinned to the MAIN header while the page
     * scrolls.
     */
    const applyStickyHeaderOffsets = (): void => {
      const rows: HTMLTableRowElement[] = [];
      if (sprintTotalsHeader) rows.push(...Array.from(sprintTotalsHeader.querySelectorAll('tr')));
      if (sprintMonthColumnsHeader) rows.push(...Array.from(sprintMonthColumnsHeader.querySelectorAll('tr')));

      detectScrollParent();

      // `top` on a sticky cell is measured from the top edge of its scrollport.
      // When the window scrolls, that edge IS the viewport top, so the app
      // header's bottom is the right offset. But when an inner region scrolls
      // (SharePoint modern), the region already starts below the app header —
      // using the viewport figure would push our header that much too far down.
      const headerBottom = measureAppHeaderOffset();
      let base = headerBottom;
      if (scrollParent !== window) {
        const portTop = (scrollParent as HTMLElement).getBoundingClientRect().top;
        base = Math.max(0, headerBottom - portTop);
      }
      root.style.setProperty('--sprint-header-offset', `${base}px`);

      let offset = base;
      rows.forEach((row, idx) => {
        const height = row.getBoundingClientRect().height;
        row.querySelectorAll<HTMLElement>('th, td').forEach(cell => {
          cell.style.position = 'sticky';
          cell.style.top = `${offset}px`;
          // later rows must paint over earlier ones when they collapse together
          const isLeftSticky = /sprint-(th|td)-/.test(cell.className);
          cell.style.zIndex = String((isLeftSticky ? 30 : 20) + idx);
        });
        offset += height;
      });
    };

    /* ---------- BODY RENDERING ---------- */
    const renderTableBody = (rows: ForecastRecord[]): void => {
      if (!sprintTableBody) return;
      if (rows.length === 0) {
        sprintTableBody.innerHTML = `<tr><td colspan="${totalCols()}" class="daily-sprint-empty">No data found</td></tr>`;
        return;
      }

      const [m1, m2, m3] = horizonKeys;

      sprintTableBody.innerHTML = rows.map(item => {
        const projectTitle = item.Project?.Title || "-";
        const proj = projects.find(p => p.Title === projectTitle);

        const projectRef = getSafeString(proj?.ProjectReference);
        const customerName = getSafeString(proj?.CustomerName);
        const groupHeadName = getGroupHeadDisplayName(proj?.GroupHead1) || "-";
        const pmName = getProjectManagerDisplayName(proj?.ProjectManager) || "-";
        const enggLeadName = getEnggLeadDisplayName(proj?.EnggLead);
        const sprintCell = getConcerns(item);
        const receivables = getReceivables(item);

        return `
          <tr data-item-id="${item.Id}">
            ${leftCols().map((c, i) => {
              const style = leftCellStyle(i);
              const cls = leftCellClass(i, 'td');
              switch (c.key) {
                case 'projectRef':
                  return `<td class="${cls}" style="${style}">${escapeAttr(projectRef)}</td>`;
                case 'customer':
                  return `<td class="${cls}" style="${style}">${escapeAttr(customerName)}</td>`;
                case 'project':
                  return `<td class="${cls}" style="${style}font-weight:600;color:#333;">${escapeAttr(projectTitle)}</td>`;
                case 'gh':
                  return `<td class="${cls}" style="${style}">${escapeAttr(groupHeadName)}</td>`;
                case 'pm':
                  return `<td class="${cls}" style="${style}">${escapeAttr(pmName)}</td>`;
                case 'enggLead':
                  return `<td class="${cls}" style="${style}"><span class="daily-sprint-pill">${escapeAttr(enggLeadName)}</span></td>`;
                case 'concerns':
                  return `<td class="${cls}" style="${style}" title="${escapeAttr(sprintCell)}">${escapeAttr(sprintCell || '-')}</td>`;
                case 'obl':
                  return `<td class="${cls}" style="${style}">${inr(toNum(item.OBL))}</td>`;
                case 'receivables':
                  return `<td class="${cls}" style="${style}">${inr(receivables)}</td>`;
                default:
                  return `<td class="${cls}" style="${style}"></td>`;
              }
            }).join('')}

            <td class="num prevplan month-sep">${inr(getPrevPlan(item, m1))}</td>
            <td class="num plan">${inr(getCurrPlan(item, m1))}</td>
            <td class="num actual">${inr(getActual(item, m1))}</td>
            <td class="num">${inr(getFurther(item, m1))}</td>
            <td class="num forecast">${inr(getForecast(item, m1))}</td>

            <td class="num prevplan future-cell month-sep">${inr(getPrevPlan(item, m2))}</td>
            <td class="num plan future-cell">${inr(getCurrPlan(item, m2))}</td>

            <td class="num prevplan future-cell month-sep">${inr(getPrevPlan(item, m3))}</td>
            <td class="num plan future-cell">${inr(getCurrPlan(item, m3))}</td>
          </tr>`;
      }).join('');
    };

    /* ---------- FILTERS ---------- */
    const selectedOr = (sel: HTMLSelectElement | null, fallback: string): string =>
      (sel && sel.value) ? sel.value : fallback;

    const syncMonthSelection = (): void => {
      const year = selectedOr(filterYear, String(new Date().getFullYear()));
      const month = pad2(selectedOr(filterMonth, String(new Date().getMonth() + 1)));
      activeMonthKey = `${year}-${month}`;
      horizonKeys = buildHorizon(activeMonthKey);
    };

    const initializeFilters = (): void => {
      if (!filterYear || !filterMonth) return;
      const currentYear = new Date().getFullYear();

      filterYear.innerHTML = '<option value="">All Years</option>' +
        Array.from({ length: 4 }, (_, i) => currentYear - 1 + i)
          .map(y => `<option value="${y}"${y === currentYear ? ' selected' : ''}>${y}</option>`)
          .join('');

      filterMonth.innerHTML = '<option value="">All Months</option>' +
        MONTHS.map((m, i) => `<option value="${i + 1}"${i + 1 === new Date().getMonth() + 1 ? ' selected' : ''}>${m}</option>`)
          .join('');

      const assignedProjects = getAssignedProjects(projects);

      const collect = (read: (p: ProjectItem) => string | undefined): string => {
        const values = new Set<string>();
        assignedProjects.forEach(p => {
          const value = read(p);
          if (value && value.trim()) values.add(value.trim());
        });
        return Array.from(values).sort()
          .map(v => `<option value="${escapeAttr(v)}">${escapeAttr(v)}</option>`)
          .join('');
      };

      const fill = (sel: HTMLSelectElement | null, allLabel: string, read: (p: ProjectItem) => string | undefined): void => {
        if (sel) sel.innerHTML = `<option value="">${allLabel}</option>` + collect(read);
      };

      fill(filterProject, 'All Projects', p => p.Title);
      fill(filterCustomer, 'All Customers', p => p.CustomerName);
      fill(filterProjectManager, 'All Managers', p => getProjectManagerDisplayName(p.ProjectManager));
      fill(filterGroupHead, 'All Group Heads', p => getGroupHeadDisplayName(p.GroupHead1));
      fill(filterProjectReference, 'All References', p => p.ProjectReference);
      fill(filterEnggLead, 'All Engg Leads', p => getEnggLeadDisplayName(p.EnggLead));
    };

    /* ---------- SORT ---------- */
    const getSortValue = (item: ForecastRecord, col: SortColumn): string | number => {
      const projectTitle = item.Project?.Title || '';
      const proj = projects.find(p => p.Title === projectTitle);
      const [m1, m2, m3] = horizonKeys;

      switch (col) {
        case 'projectRef':     return proj?.ProjectReference || '';
        case 'project':        return projectTitle;
        case 'customer':       return proj?.CustomerName || '';
        case 'groupHead':      return getGroupHeadDisplayName(proj?.GroupHead1);
        case 'projectManager': return getProjectManagerDisplayName(proj?.ProjectManager);
        case 'enggLead':       return getEnggLeadDisplayName(proj?.EnggLead);
        case 'obl':            return toNum(item.OBL);
        case 'receivables':    return getReceivables(item);

        case 'prevPlan':       return getPrevPlan(item, m1);
        case 'plan':           return getCurrPlan(item, m1);
        case 'actual':         return getActual(item, m1);
        case 'further':        return getFurther(item, m1);
        case 'forecast':       return getForecast(item, m1);

        case 'm2PrevPlan':     return getPrevPlan(item, m2);
        case 'm2Plan':         return getCurrPlan(item, m2);
        case 'm3PrevPlan':     return getPrevPlan(item, m3);
        case 'm3Plan':         return getCurrPlan(item, m3);
        default:               return '';
      }
    };

    const sortData = (data: ForecastRecord[]): ForecastRecord[] => {
      if (!sortColumn) return [...data];
      const col: SortColumn = sortColumn;
      return [...data].sort((a, b) => {
        const va = getSortValue(a, col);
        const vb = getSortValue(b, col);
        if (typeof va === 'number' && typeof vb === 'number') {
          return sortDirection === 'asc' ? va - vb : vb - va;
        }
        const sa = String(va).toLowerCase();
        const sb = String(vb).toLowerCase();
        return sortDirection === 'asc' ? sa.localeCompare(sb) : sb.localeCompare(sa);
      });
    };

    const toggleSort = (col: SortColumn, direction?: SortDirection): void => {
      if (direction) {
        sortColumn = col;
        sortDirection = direction;
      } else if (sortColumn === col) {
        sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
      } else {
        sortColumn = col;
        sortDirection = 'asc';
      }
      renderMonthColumnsHeader();
      renderCurrentPage();
      applyStickyHeaderOffsets();
    };

    /* ---------- PAGINATION ---------- */
    const calculateTotalPages = (): void => {
      totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
    };

    const updatePageNumbers = (): void => {
      if (!pageNumbersDiv) return;
      pageNumbersDiv.innerHTML = "";
      if (filteredData.length === 0) return;

      const max = 5;
      let start = Math.max(1, currentPage - Math.floor(max / 2));
      const end = Math.min(totalPages, start + max - 1);
      if (end - start + 1 < max) start = Math.max(1, end - max + 1);

      if (start > 1) {
        const dots = document.createElement("button");
        dots.className = "sprint-page-number";
        dots.textContent = "…";
        dots.disabled = true;
        pageNumbersDiv.appendChild(dots);
      }
      for (let i = start; i <= end; i++) {
        const b = document.createElement("button");
        b.className = `sprint-page-number${i === currentPage ? " active" : ""}`;
        b.textContent = String(i);
        b.addEventListener("click", () => goToPage(i));
        pageNumbersDiv.appendChild(b);
      }
      if (end < totalPages) {
        const dots = document.createElement("button");
        dots.className = "sprint-page-number";
        dots.textContent = "…";
        dots.disabled = true;
        pageNumbersDiv.appendChild(dots);
      }
    };

    const updatePaginationControls = (): void => {
      if (currentPageSpan) currentPageSpan.textContent = String(currentPage);
      if (totalPagesSpan)  totalPagesSpan.textContent  = String(totalPages);

      if (filteredData.length === 0) {
        if (startItemSpan) startItemSpan.textContent = "0";
        if (endItemSpan)   endItemSpan.textContent   = "0";
        if (totalItemsSpan) totalItemsSpan.textContent = "0";
      } else {
        const start = (currentPage - 1) * pageSize + 1;
        const end   = Math.min(currentPage * pageSize, filteredData.length);
        if (startItemSpan) startItemSpan.textContent = String(start);
        if (endItemSpan)   endItemSpan.textContent   = String(end);
        if (totalItemsSpan) totalItemsSpan.textContent = String(filteredData.length);
      }

      if (pageSizeSelect) pageSizeSelect.value = String(pageSize);

      const noData = filteredData.length === 0;
      if (firstPageBtn) firstPageBtn.disabled = noData || currentPage === 1;
      if (prevPageBtn)  prevPageBtn.disabled  = noData || currentPage === 1;
      if (nextPageBtn)  nextPageBtn.disabled  = noData || currentPage >= totalPages;
      if (lastPageBtn)  lastPageBtn.disabled  = noData || currentPage >= totalPages;

      updatePageNumbers();
    };

    const goToPage = (page: number): void => {
      if (page < 1 || page > totalPages || page === currentPage) return;
      if (filteredData.length === 0) return;
      currentPage = page;
      updatePaginationControls();
      renderCurrentPage();
      // bring the table top just under the pinned header, on whichever
      // element actually scrolls (window, or an SPFx inner region)
      const table = root.querySelector<HTMLElement>('.daily-sprint-table');
      if (table) {
        const gap = measureAppHeaderOffset() + 8;
        if (scrollParent === window) {
          const top = window.scrollY + table.getBoundingClientRect().top - gap;
          window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
        } else {
          const host = scrollParent as HTMLElement;
          const delta = table.getBoundingClientRect().top - host.getBoundingClientRect().top;
          host.scrollTo({ top: Math.max(0, host.scrollTop + delta - 8), behavior: 'smooth' });
        }
      }
    };

    const changePageSize = (newSize: number): void => {
      pageSize = (!newSize || newSize <= 0) ? 10 : newSize;
      currentPage = 1;
      calculateTotalPages();
      updatePaginationControls();
      renderCurrentPage();
    };

    const renderCurrentPage = (): void => {
      const sorted = sortData(filteredData);
      if (sorted.length === 0) {
        renderTableBody([]);
        renderTotalsHeader();
        return;
      }
      if (currentPage > totalPages) currentPage = totalPages;
      const startIndex = (currentPage - 1) * pageSize;
      const endIndex   = Math.min(startIndex + pageSize, sorted.length);
      renderTableBody(sorted.slice(startIndex, endIndex));
      renderTotalsHeader();
    };

    /* ---------- FILTER ---------- */
    const filterTable = (): void => {
      syncMonthSelection();

      const year = filterYear?.value || "";
      const month = filterMonth?.value || "";
      const project = filterProject?.value || "";
      const customer = filterCustomer?.value || "";
      const manager = filterProjectManager?.value || "";
      const head = filterGroupHead?.value || "";
      const reference = filterProjectReference?.value || "";
      const lead = filterEnggLead?.value || "";

      const matches = (item: ForecastRecord): boolean => {
        const projectTitle = item.Project?.Title;
        if (!projectTitle) return false;

        // keep the row if ANY month in the 3-month horizon has data
        if (year && month) {
          const data = safeJsonParse(item[dataField(currentViewMode)]);
          const actuals = safeNumberMap(item.RevenueActual);
          const hasAny = horizonKeys.some(k => (k in data) || (k in actuals));
          if (!hasAny) return false;
        }
        if (project && projectTitle !== project) return false;

        if (customer || manager || head || reference || lead) {
          const proj = projects.find(p => p.Title === projectTitle);
          if (!proj) return false;
          if (customer && proj.CustomerName !== customer) return false;
          if (manager && getProjectManagerDisplayName(proj.ProjectManager) !== manager) return false;
          if (head && getGroupHeadDisplayName(proj.GroupHead1) !== head) return false;
          if (reference && proj.ProjectReference !== reference) return false;
          if (lead && getEnggLeadDisplayName(proj.EnggLead) !== lead) return false;
        }
        return true;
      };

      filteredData = currentRecords().filter(matches);
      currentPage = 1;
      calculateTotalPages();
      updatePaginationControls();
      renderMonthColumnsHeader();   // month labels follow the Year/Month filter
      renderCurrentPage();
      applyStickyHeaderOffsets();
    };

    const clearFilters = (): void => {
      [filterYear, filterMonth, filterProject, filterCustomer, filterProjectManager,
       filterGroupHead, filterProjectReference, filterEnggLead]
        .forEach(sel => { if (sel) sel.value = ""; });
      filterTable();
      toast("info", "All filters cleared");
    };

    /* ---------- VIEW MODE ---------- */
    const paintViewMode = (): void => {
      const mode = currentViewMode;
      toggleRevenueBtn?.classList.toggle('toggle-btn-active', mode === 'revenue');
      toggleRevenueBtn?.classList.toggle('toggle-btn-inactive', mode !== 'revenue');
      toggleCollectionBtn?.classList.toggle('toggle-btn-active', mode === 'collection');
      toggleCollectionBtn?.classList.toggle('toggle-btn-inactive', mode !== 'collection');
      if (activeViewIndicator) {
        activeViewIndicator.textContent = mode === 'revenue' ? '📊 Revenue View' : '📋 Collection View';
      }
      refreshSyncBar();
    };

    /**
     * 🔐 RBAC SYNC BAR. Visible only to roles with create rights
     * (canCreateRecord → Admin / GH Head / PM Manager) and always follows the
     * active view: Revenue view syncs Project List → Revenue Forecast List,
     * Collection view syncs Project List → Collection List.
     */
    const refreshSyncBar = (): void => {
      const bar = q<HTMLElement>("#sprintSyncBar");
      if (!bar) return;
      const allowed = canCreateRecord();
      bar.style.display = allowed ? 'flex' : 'none';
      const hint = q<HTMLElement>("#sprintSyncHint");
      if (hint) {
        // hint.textContent = allowed
        //   ? (currentViewMode === 'revenue'
        //       ? 'Project List → Revenue Forecast List: any visible project without a forecast row is added automatically.'
        //       : 'Project List → Collection List: any visible project without a collection row is added automatically.')
        //   : '';
      }
    };

    const runSyncForCurrentView = async (): Promise<void> => {
      const btn = q<HTMLButtonElement>("#sprintSyncProjectsBtn");
      if (btn) btn.disabled = true;
      try {
        if (currentViewMode === 'revenue') {
          await syncMissingProjectsToRevenueList();
        } else {
          await syncMissingProjectsToCollectionList();
        }
        syncMonthSelection();
        filterTable();
      } catch (error) {
        console.error("❌ Sync failed:", error);
      } finally {
        if (btn) btn.disabled = false;
        refreshSyncBar();
      }
    };

    const refreshData = async (): Promise<void> => {
      await (currentViewMode === 'revenue' ? loadRevenueForecasts() : loadCollectionItems());
      syncMonthSelection();
      filterTable();
    };

    const setViewMode = (mode: ViewMode): void => {
      if (currentViewMode === mode) return;
      currentViewMode = mode;
      sortColumn = '';               // sort keys differ between the two layouts
      paintViewMode();
      renderMonthColumnsHeader();    // left column sequence differs per view
      void refreshData().then(() =>
        toast('info', mode === 'revenue' ? 'Switched to Revenue View' : 'Switched to Collection View')
      );
    };

    /* ---------- EVENT BINDING ---------- */
    const bind = (): void => {
      toggleRevenueBtn?.addEventListener("click", () => setViewMode('revenue'));
      toggleCollectionBtn?.addEventListener("click", () => setViewMode('collection'));

      [filterYear, filterMonth, filterProject, filterCustomer, filterProjectManager,
       filterGroupHead, filterProjectReference, filterEnggLead]
        .forEach(sel => sel?.addEventListener("change", filterTable));

      clearFiltersBtn?.addEventListener("click", clearFilters);

      // 🔐 Manual re-run of the auto-sync for the active view (button only
      // visible to create-role users). Console-only reporting.
      const sprintSyncProjectsBtn = q<HTMLButtonElement>("#sprintSyncProjectsBtn");
      sprintSyncProjectsBtn?.addEventListener("click", () => {
        void runSyncForCurrentView();
      });

      pageSizeSelect?.addEventListener("change", (e) => {
        changePageSize(parseInt((e.target as HTMLSelectElement).value, 10));
      });
      firstPageBtn?.addEventListener("click", () => goToPage(1));
      prevPageBtn ?.addEventListener("click", () => goToPage(currentPage - 1));
      nextPageBtn ?.addEventListener("click", () => goToPage(currentPage + 1));
      lastPageBtn ?.addEventListener("click", () => goToPage(totalPages));

      sprintMonthColumnsHeader?.addEventListener('click', (e: Event) => {
        const btn = (e.target as HTMLElement).closest('.sprint-sort-btn') as HTMLButtonElement | null;
        if (!btn) return;
        const col = btn.dataset.sort as SortColumn | undefined;
        if (!col) return;
        toggleSort(col, (btn.dataset.direction as SortDirection) || undefined);
      });
    };

    /* ---------- INIT ---------- */
    const initialize = async (): Promise<void> => {
      try {
        syncMonthSelection();
        paintViewMode();
        renderMonthColumnsHeader();
        bind();

        if (remount && dataLoaded) {
          syncMonthSelection();
          filterTable();
          console.log("✅ Daily Sprint page re-mounted (cached data)");
          return;
        }

        await authManager.initialize({ siteUrl });
        console.log(`👤 ${getCurrentUserFullName()} | ${getPermissionLevel().toUpperCase()} | [${getUserGroups().join(", ")}]`);

        await loadProjects();
        await Promise.all([loadRevenueForecasts(), loadCollectionItems()]);

        // 🔐 AUTO-SYNC (same as the Revenue & Collection pages): add a row for
        // every visible project missing from each list - empty skeleton JSON,
        // idempotent, never duplicates/overwrites. Only roles with create
        // rights run it; reporting is console-only.
        await syncMissingProjectsToRevenueList();
        await syncMissingProjectsToCollectionList();

        // show the manual Sync button only to roles that can create rows
        refreshSyncBar();

        dataLoaded = true;

        initializeFilters();
        syncMonthSelection();
        filterTable();

        console.log("✅ Daily Sprint page initialized — horizon:", horizonKeys.join(', '));
      } catch (error) {
        console.error("❌ Failed to initialize sprint page:", error);
        toast("error", "Failed to initialize page");
      }
    };

    // keep sticky offsets accurate after layout / resize / content changes
    window.requestAnimationFrame(() => {
      applyStickyHeaderOffsets();
      teardownWhenDetached();
    });
    // If the SPA swaps pages, undo our ancestor tweaks so other pages are
    // unaffected. (SPFx removes the web part node from the DOM.)
    const teardownWhenDetached = (): void => {
      const host = root as HTMLElement;
      if (!host || !host.isConnected) return;
      const obs = new MutationObserver(() => {
        if (!host.isConnected) {
          restoreAncestors();
          obs.disconnect();
        }
      });
      obs.observe(document.body, { childList: true, subtree: true });
    };

    const scheduleStickyRecalc = (): void => {
      clearTimeout((window as any)._sprintStickyResizeTimer);
      (window as any)._sprintStickyResizeTimer = setTimeout(applyStickyHeaderOffsets, 120);
    };
    window.addEventListener('resize', scheduleStickyRecalc);
    // app chrome may collapse/expand as the page scrolls — re-measure lazily
    window.addEventListener('scroll', scheduleStickyRecalc, { passive: true });
    // SPFx often scrolls an inner region rather than the window
    document.addEventListener('scroll', scheduleStickyRecalc, { passive: true, capture: true });

    void initialize();
  }
};

export default sprintPage;
export { sprintPage };
