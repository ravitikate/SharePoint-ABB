 
import 'sweetalert2/dist/sweetalert2.min.css'; 
import "../styles/dashboard.css";
// import {
//   authManager,
//   canCreate,
//   canDelete,
//   canRead,
//   canEditProject,
//   getAssignedProjects,
//   updateUIBasedOnPermissions
// } from './auth';
// declare const _spPageContextInfo: any;

const dashboardContent = `
  <div class="kpi-dashboard">
    <header class="header">
      <h1>PROJECT PERFORMANCE DASHBOARD</h1>
      <div class="header-meta">
        <span>Period <b>Jan-25</b></span>
        <span>As on <b>31-Jan-2025</b></span>
        <span>Currency <b>INR</b></span>
      </div>
    </header>

    <main class="board">
      <section class="card identity">
        <div class="id-row"><span>PM</span><b>All</b></div>
        <div class="id-row"><span>Date</span><b>31-Jan-2025</b></div>
        <div class="id-row"><span>Month</span><b>Jan-25</b></div>
        <div class="id-row"><span>PR</span><b>All</b></div>
      </section>

      <section class="card obl">
        <div class="card-title">OBL</div>
        <div class="kpi-num">9,140,362</div>
        <div class="delta red">(-2.84%)</div>
      </section>

      <section class="card receivables">
        <div class="recv-head">
          <span class="card-title">Total Receivables</span>
          <span class="kpi-num recv-head-num">4,127,071</span>
          <span class="delta red recv-head-delta">(+18.64%)</span>
        </div>
        <div class="recv-grid">
          <div class="recv-cell">
            <div class="delta red">(+74.93%)</div>
            <div class="kpi-num">1,444,466</div>
            <div class="lbl">Normal</div>
          </div>
          <div class="recv-cell">
            <div class="delta green">(+11.93%)</div>
            <div class="kpi-num">1,023,367</div>
            <div class="lbl">Normal OverDue</div>
          </div>
          <div class="recv-cell">
            <div class="delta red">(+24.63%)</div>
            <div class="kpi-num">58,611</div>
            <div class="lbl">GST TDS</div>
          </div>
          <div class="recv-divider"></div>
          <div class="recv-cell recv-total">
            <div class="delta green">(+6.17%)</div>
            <div class="kpi-num">1,890,288</div>
            <div class="lbl">Total OverDue</div>
          </div>
          <div class="recv-cell">
            <div class="delta red">(+26.54%)</div>
            <div class="kpi-num">669,655</div>
            <div class="lbl">Retention</div>
          </div>
          <div class="recv-cell">
            <div class="delta red">(+1.67%)</div>
            <div class="kpi-num">866,921</div>
            <div class="lbl">Retention OverDue</div>
          </div>
          <div class="recv-cell">
            <div class="delta red">(+3.38%)</div>
            <div class="kpi-num">64,050</div>
            <div class="lbl">IT TDS / Others</div>
          </div>
          <div class="recv-cell recv-total">
            <div class="delta red">(+11.2%)</div>
            <div class="kpi-num">1,536,576</div>
            <div class="lbl">Total Retention</div>
          </div>
        </div>
      </section>

      <section class="card top-right">
        <div class="metric-line">
          <div class="name magenta">BIES</div>
          <div class="kpi-num">1,602,063</div>
          <div class="delta green">(+9.51%)</div>
        </div>
        <div class="metric-line">
          <div class="name" style="color:var(--navy)">NWC</div>
          <div class="kpi-num red">182,284</div>
          <div class="delta red"> </div>
        </div>

        <table class="pr-table">
          <thead>
            <tr>
              <th>PR+ Quality</th>
              <th>Average / Count in Masterdata</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>No of projects in PR+</td><td>2,414</td></tr>
            <tr><td>Submitted</td><td>1,860 · 77.13%</td></tr>
            <tr><td>Not Submitted</td><td>554 · 22.87%</td></tr>
            <tr><td>Approved</td><td>2,248 · 93.13%</td></tr>
          </tbody>
        </table>

      </section>

      <section class="card revenue">
        <div class="rev-group">
          <div class="g-title">Month — Jan-25</div>
          <div class="pair">
            <div class="pair-box">
              <div class="lbl">Revenue Plan</div>
              <div class="kpi-num">547,946</div>
            </div>
            <div class="pair-box">
              <div class="lbl">Revenue Actuals</div>
              <div class="kpi-num green">264,507</div>
              <div class="delta red">(40.63%)</div>
              <div class="bar low"><i style="width:40.63%"></i></div>
            </div>
            <div class="pair-box">
              <div class="lbl">Collection Plan</div>
              <div class="kpi-num">664,507</div>
            </div>
            <div class="pair-box">
              <div class="lbl">Collection Actuals</div>
              <div class="kpi-num green">364,507</div>
              <div class="delta red">(49.63%)</div>
              <div class="bar low"><i style="width:49.63%"></i></div>
            </div>
          </div>
        </div>

        <div class="rev-group">
          <div class="g-title">YTD — Till Dec</div>
          <div class="pair">
            <div class="pair-box">
              <div class="lbl">YTD Revenue Plan</div>
              <div class="kpi-num">12,342,875</div>
            </div>
            <div class="pair-box">
              <div class="lbl">YTD Revenue Actuals</div>
              <div class="kpi-num green">8,594,344</div>
              <div class="delta blue">(69.63%)</div>
              <div class="bar mid"><i style="width:69.63%"></i></div>
            </div>
            <div class="pair-box">
              <div class="lbl">YTD Collection Plan</div>
              <div class="kpi-num">12,856,516</div>
            </div>
            <div class="pair-box">
              <div class="lbl">YTD Collection Actuals</div>
              <div class="kpi-num green">9,851,948</div>
              <div class="delta green">(76.63%)</div>
              <div class="bar"><i style="width:76.63%"></i></div>
            </div>
          </div>
        </div>
      </section>

      <section class="card procurement">
        <div class="card-title">Procurement Pending</div>
        <div class="list">
          <div class="list-row warn"><span class="name">RFQ Pending</span><span class="val">12</span></div>
          <div class="list-row warn"><span class="name">Offer Pending</span><span class="val">8</span></div>
          <div class="list-row"><span class="name">TC Pending</span><span class="val">5</span></div>
          <div class="list-row"><span class="name">Order Closure Pending</span><span class="val">3</span></div>
          <div class="list-row warn"><span class="name">PR Pending</span><span class="val">18</span></div>
          <div class="list-row warn"><span class="name">PO Pending</span><span class="val">9</span></div>
          <div class="list-row"><span class="name">Document Approval Pending</span><span class="val">7</span></div>
          <div class="list-row"><span class="name">MFC Pending</span><span class="val">4</span></div>
          <div class="list-row"><span class="name">Inspection Pending</span><span class="val">6</span></div>
          <div class="list-row warn"><span class="name">Dispatch Pending</span><span class="val">11</span></div>
          <div class="list-row"><span class="name">Delivery Pending</span><span class="val">2</span></div>
        </div>
      </section>

      <section class="card documents">
        <div class="card-title">Total Documents — DCI</div>
        <div class="list">
          <div class="list-row"><span class="name">Total Documents</span><span class="val">156</span></div>
          <div class="list-row warn"><span class="name">Not Submitted</span><span class="val">23</span></div>
          <div class="list-row warn"><span class="name">Not Approved</span><span class="val">8</span></div>
          <div class="list-row warn"><span class="name">Revised — Not Submitted / Approved with comments</span><span class="val">5</span></div>
          <div class="list-row ok"><span class="name">Approved</span><span class="val">98</span></div>
          <div class="list-row warn"><span class="name">Rejected</span><span class="val">12</span></div>
          <div class="list-row"><span class="name">Retained for Information</span><span class="val">10</span></div>
        </div>
      </section>

      <section class="card projects">
        <div class="p-item">
          <div class="lbl">Total Projects</div>
          <div class="kpi-num">2,414</div>
          <div class="delta green">(+33)</div>
        </div>
        <div class="p-item">
          <div class="lbl">REL</div>
          <div class="kpi-num">233</div>
        </div>
        <div class="p-item">
          <div class="lbl">TECO</div>
          <div class="kpi-num">85</div>
        </div>
        <div class="p-item">
          <div class="lbl">SO</div>
          <div class="kpi-num">2,096</div>
        </div>
      </section>

      <section class="card delivery">
        <div class="alert">
          <div class="lbl">Delivery Date Crossed</div>
          <div class="kpi-num">14</div>
        </div>
        <div class="alert">
          <div class="lbl">To cross in 45 days</div>
          <div class="kpi-num">27</div>
        </div>
      </section>
    </main>
  </div>
`;

const dashboardStyle = `
/* src/webparts/digitalTransformationApp1/components/pages/dashboard.css */


`;

const dashboardScript = (): void => {
  console.log("Dashboard loaded");
};

export default {
  content: dashboardContent,   
  style: dashboardStyle,
  script: dashboardScript
};
