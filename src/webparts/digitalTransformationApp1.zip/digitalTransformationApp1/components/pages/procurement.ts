import Swal from "sweetalert2";
import * as XLSX from "xlsx-js-style";
import { saveAs } from "file-saver";
import "../styles/common.css";
import "../styles/procurement.css";
import {
  authManager,
  hasFullControl,
  canContribute,
  canRead,
  canFreeze,
  isGHHead,
  getUserGroups,
  getCurrentUserFullName,
  getPermissionLevel,
  canEditProject,
  canCreateRecord,
  canReadAllProjects,
  getAssignedProjects,
  isPMManager,
  isEngineeringUser,
  updateUIBasedOnPermissions
} from "./auth";

declare const _spPageContextInfo: any;

interface ProjectItem {
  Id: number;
  Title: string;
  CustomerName?: string;
  ProjectManagerId?: number;
  ProjectManager?: string | { Title: string; Email?: string };
  PC?: string;
  ProjectReference?: string;
  GroupHead1?: string | { Title: string; Email?: string };  // ✅ Changed to Person/Group
  GroupHead1Id?: number;  // ✅ Person/Group ID
}

interface ProcurementForecastItem {
  Description: string;
  FCMQuantity: number | null;
  EnggQuantity: number | null;
  Status: string;
  Make: string;
  Model: string;
  Remarks: string;

  RfqPlan: string;
  RfqActual: string;
  RfqForecast: string;
  OfferPlan: string;
  OfferActual: string;
  OfferForecast: string;
  TechPlan: string;
  TechActual: string;
  TechForecast: string;
  OrderPlan: string;
  OrderActual: string;
  OrderForecast: string;
  PRPlan: string;
  PRActual: string;
  PRForecast: string;
  POPlan: string;
  POActual: string;
  POForecast: string;
  DocPlan: string;
  DocActual: string;
  DocForecast: string;
  MfgPlan: string;
  MfgActual: string;
  MfgForecast: string;
  InspPlan: string;
  InspActual: string;
  InspForecast: string;
  DispPlan: string;
  DispActual: string;
  DispForecast: string;
  DeliveryPlan: string;
  DeliveryActual: string;
  DeliveryForecast: string;
}

interface FieldMappings {
  ProcurementForecast: string;
  Project: string;
}

interface ValidationError {
  type: 'error' | 'warning' | 'info';
  message: string;
  row?: number;
  column?: string;
}

// Status order based on workflow
const statusOptions = [
  "RFQ Pending",
  "Offer Pending",
  "TC pending",
  "Order Closure pending",
  "PR pending",
  "PO pending",
  "Document Approval Pending",
  "MFC Pending",
  "Inspection Pending",
  "Dispatch Pending",
  "Delivery Pending",
  "Delivered",
];

const procurementContent = `
<div class="project-page fade-in">
  <section class="table-section card">
    <div class="page-header stick">
      <div class="page-header-left">
        <button class="btn-primary show-form-btn">+ Add Procurement</button>
      </div>
      <h1>Procurement Tracker</h1>
    </div>
    
    <!-- 🔍 Filter bar: row 1 = label-less dropdowns + Reset (like the reference) -->
    <div class="table-actions">
      <div class="filter-row">
        <div class="tableColp4">
          <select id="filterProject"><option value="">All Projects</option></select>
        </div>
        <div class="tableColp4">
          <select id="filterCustomer"><option value="">All Customers</option></select>
        </div>
        <div class="tableColp4">
          <select id="filterProjectManager"><option value="">All Managers</option></select>
        </div>
        <div class="tableColp4">
          <select id="filterGroupHead"><option value="">All Group Heads</option></select>
        </div>
        <div class="tableColp4">
          <select id="filterProjectReference"><option value="">All References</option></select>
        </div>
        <div class="tableColp4 action-col">
          <button type="button" class="btn-secondary clear-filters-btn">Reset Filter</button>
        </div>

        <div class="tableColp4 filter-actions-row">
           <button type="button" class="btn-secondary export-excel-btn">📊 Download Excel</button>
        </div>
      </div>

      <!-- 🔘 Row 2: action buttons -->
     

    <!-- ✅ Main table: OUTER-STICKY header -->
    <!--    The page scrolls vertically (not an inner box), so the header  -->
    <!--    runs up, touches the main header and pins below it.             -->
    <div class="table-scroll-wrapper main-table-scroll">
      <table id="procurementTable" class="modern-table">
        <thead class="sticky-main-header">
          <tr>
            <th class="sticky-main-col main-col-1">Project Reference</th>
            <th class="sticky-main-col main-col-2">Customer</th>
            <th class="sticky-main-col main-col-3">Project</th>
            <th class="sticky-main-col main-col-4">Group Head</th>
            <th class="sticky-main-col main-col-5">Project Manager</th>
            <th>Total Line Items</th>
            <th>RFQ Pending</th>
            <th>Offer Pending</th>
            <th>TC pending</th>
            <th>Order Closure pending</th>
            <th>PR pending</th>
            <th>PO pending</th>
            <th>Document Approval Pending</th>
            <th>MFC Pending</th>
            <th>Inspection Pending</th>
            <th>Dispatch Pending</th>
            <th>Delivery Pending</th>
            <th>Delivered</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="procurementBody"></tbody>
      </table>
    </div>
    <div class="pagination-row">
      <div class="page-size-selector">
        <label for="pageSizeSelect">Show:</label>
        <select id="pageSizeSelect" class="page-size-select">
          <option value="10">10</option>
          <option value="25">25</option>
          <option value="50">50</option>
          <option value="100">100</option>
        </select>
        <span>per page</span>
        <span class="pagination-info" id="paginationInfo">Showing 0-0 of 0 records</span>
      </div>
      <div class="pagination"></div>
    </div>
  </section>

  <section class="form-section card" style="display:none;">
    <div class="page-header">
      <h1 id="formTitle">Add Procurement</h1>
    </div>
    <form id="procurementForm">
      <!-- Project Info Section -->
      <div class="project-info-wrapper">
        <div class="project-info-left">
          <div class="detail-item project-select-container">
            <span class="detail-label">Select Project</span>
            <select id="projectSelect" class="detail-value project-select" required></select>
          </div>
          <div class="detail-item">
            <span class="detail-label">Project</span>
            <span class="detail-value" id="projectNameDisplay">-</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Project Reference</span>
            <span class="detail-value" id="projectRefDisplay">-</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Project Center</span>
            <span class="detail-value" id="projectCenterDisplay">-</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Project Manager</span>
            <span class="detail-value" id="projectManagerDisplay">-</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Group Head</span>
            <span class="detail-value" id="groupHeadDisplay">-</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Customer</span>
            <span class="detail-value" id="customerDisplay">-</span>
          </div>
        </div>
        <div id="existingDataAlert" class="alert alert-info" style="display: none;">
          <strong>ℹ️ Existing Data Found!</strong> This project already has procurement data. You can view and edit it below.
        </div>
      </div>

      <!-- Procurement Table -->
      <div class="procurement-inputs" id="procurementContainerTable" style="display:none;">
        <div class="table-container">
          <table class="procurement-table">
            <thead>
              <tr> 
                <th class="sticky-col col-1" rowspan="2">
                  <div class="description-header-content">
                    <input
                      type="text"
                      id="descriptionFilter"
                      class="description-filter"
                      placeholder="Filter Description..."
                      aria-label="Filter Description"
                      autocomplete="off"
                    >
                    <span class="description-header-title">Description</span>
                  </div>
                </th>
                <th class="sticky-col col-2" rowspan="2">FCM Qty</th>
                <th class="sticky-col col-3" rowspan="2">Engg Qty</th>
                <th class="sticky-col col-4" rowspan="2">Status</th>
                <th class="sticky-col col-5" rowspan="2">Make</th>
                <th class="sticky-col col-6" rowspan="2">Model</th> 
                <th colspan="3">RFQ / Engg</th>
                <th colspan="3">Vendor Offer / SCM</th>
                <th colspan="3">Technical Clearance / ENGG</th>
                <th colspan="3">Order Finalization / SCM</th>
                <th colspan="3">PR / PM</th>
                <th colspan="3">Purchase Order / SCM</th>
                <th colspan="3">Document Approval / ENGG</th>
                <th colspan="3">Manufacturing Clearance / ENGG</th>
                <th colspan="3">Inspection</th>
                <th colspan="3">Material Dispatch</th>
                <th colspan="3">Delivery at Site</th>
                <th rowspan="2">Remarks</th>
                <th rowspan="2">Actions</th>
              </tr>
              <tr>
                ${Array(11).fill("<th>Plan</th><th>Actual</th><th>Forecast</th>").join("")}
              </tr>
            </thead>
            <tbody id="procurementContainer"></tbody>
            <tfoot>
              <tr>
                <td colspan="6" class="sticky-footer">
                  <button type="button" class="add-procurement-row btn-secondary">+ Add Line Item</button>
                </td>
                <td colspan="49"></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      
      <div class="form-actions">
        <button type="submit" class="btn-primary">💾 Save</button>
        <button type="button" class="btn-secondary back-to-table">⬅ Back</button>
      </div>
    </form>
  </section>
</div>
`;
export default {
  content: procurementContent,
  script: () => {
    setTimeout(async () => {
      // Configuration
      const siteUrl =
        typeof _spPageContextInfo !== "undefined"
          ? _spPageContextInfo.webAbsoluteUrl
          : window.location.origin + "/sites/DigitalTransformationTest";

      const listName = "ProcurementTracker";
      const apiBase = `${siteUrl}/_api/web/lists/getbytitle('${listName}')/items`;

      // State variables
      let fieldMappings: FieldMappings = {
        ProcurementForecast: "ProcurementForecast",
        Project: "Project",
      };

      let listEntityTypeName: string = "";
      let projects: ProjectItem[] = [];
      let editingId: number | null = null;
      let procurementData: any[] = [];
      let currentTableData: any[] = []; // data currently shown (respects filters) - used by pagination
      let currentPage = 1;
      let pageSize = 10;

      // ============================================ //
      // STATUS ORDER - 12 Steps                      //
      // ============================================ //
      const isFilled = (v?: string | null): boolean =>
        !!v && String(v).trim() !== "";

      const getStatusFromActualDates = (
        item?: Partial<ProcurementForecastItem>
      ): string => {
        if (!item) return "RFQ Pending";

        if (!isFilled(item.RfqActual)) return "RFQ Pending";
        if (!isFilled(item.OfferActual)) return "Offer Pending";
        if (!isFilled(item.TechActual)) return "TC pending";
        if (!isFilled(item.OrderActual)) return "Order Closure pending";
        if (!isFilled(item.PRActual)) return "PR pending";
        if (!isFilled(item.POActual)) return "PO pending";
        if (!isFilled(item.DocActual)) return "Document Approval Pending";
        if (!isFilled(item.MfgActual)) return "MFC Pending";
        if (!isFilled(item.InspActual)) return "Inspection Pending";
        if (!isFilled(item.DispActual)) return "Dispatch Pending";
        if (!isFilled(item.DeliveryActual)) return "Delivery Pending";

        return "Delivered";
      };

      // ============================================ //
      // OVERDUE ACTUAL DATE (Plan crossed, Actual empty)
      // -> red border on the Actual date input.
      // Border is removed as soon as Actual is filled.
      // ============================================ //
      const STAGE_PREFIXES = [
        "rfq",
        "offer",
        "tech",
        "order",
        "pr",
        "po",
        "doc",
        "mfg",
        "insp",
        "disp",
        "delivery",
      ];

      const getTodayISO = (): string => {
        const now = new Date();
        return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(
          2,
          "0"
        )}-${String(now.getDate()).padStart(2, "0")}`;
      };

      // Plan date is "crossed" when it is strictly before today
      const isPlanCrossed = (planValue: string): boolean => {
        if (!isFilled(planValue)) return false;
        const plan = new Date(planValue);
        if (isNaN(plan.getTime())) return false;
        const planISO = `${plan.getFullYear()}-${String(
          plan.getMonth() + 1
        ).padStart(2, "0")}-${String(plan.getDate()).padStart(2, "0")}`;
        return planISO < getTodayISO();
      };

      const isActualOverdue = (planValue: string, actualValue: string): boolean =>
        isPlanCrossed(planValue) && !isFilled(actualValue);

      const updateOverdueHighlights = (row: HTMLTableRowElement): void => {
        STAGE_PREFIXES.forEach((prefix) => {
          const planInput = row.querySelector(
            `input[name="${prefix}_plan"]`
          ) as HTMLInputElement | null;
          const actualInput = row.querySelector(
            `input[name="${prefix}_actual"]`
          ) as HTMLInputElement | null;
          if (!actualInput) return;

          const overdue = isActualOverdue(
            planInput?.value || "",
            actualInput.value || ""
          );

          if (overdue) {
            actualInput.classList.add("actual-overdue");
            actualInput.title = `Plan date (${
              planInput?.value || ""
            }) has passed - please update the Actual date`;
          } else {
            actualInput.classList.remove("actual-overdue");
            actualInput.removeAttribute("title");
          }
        });
      };

      const wireOverdueHighlights = (row: HTMLTableRowElement): void => {
        STAGE_PREFIXES.forEach((prefix) => {
          ["plan", "actual"].forEach((kind) => {
            const input = row.querySelector(
              `input[name="${prefix}_${kind}"]`
            ) as HTMLInputElement | null;
            if (!input) return;
            input.addEventListener("change", () => updateOverdueHighlights(row));
            input.addEventListener("input", () => updateOverdueHighlights(row));
          });
        });
        updateOverdueHighlights(row);
      };

      // ============================================ //
      // ENGG QTY GREY OUT LOGIC                      //
      // ============================================ //
      const updateEnggQtyState = (row: HTMLTableRowElement): void => {
        const poActualInput = row.querySelector(
          'input[name="po_actual"]'
        ) as HTMLInputElement | null;
        const enggQtyInput = row.querySelector(
          'input[name="engg_qty"]'
        ) as HTMLInputElement | null;
        const enggQtyWrapper = row.querySelector(
          '.engg-qty-wrapper'
        ) as HTMLElement | null;

        if (!poActualInput || !enggQtyInput) return;

        const isPOActualFilled = isFilled(poActualInput.value);

        if (isPOActualFilled) {
          enggQtyInput.disabled = true;
          enggQtyInput.classList.add('engg-qty-disabled');
          if (enggQtyWrapper) {
            if (!enggQtyWrapper.querySelector('.lock-icon')) {
              const lockIcon = document.createElement('span');
              lockIcon.className = 'lock-icon';
              lockIcon.textContent = '🔒';
              lockIcon.title = 'Engg Qty is locked after PO Actual date is filled';
              enggQtyWrapper.appendChild(lockIcon);
            }
          }
        } else {
          enggQtyInput.disabled = false;
          enggQtyInput.classList.remove('engg-qty-disabled');
          if (enggQtyWrapper) {
            const lockIcon = enggQtyWrapper.querySelector('.lock-icon');
            if (lockIcon) lockIcon.remove();
          }
        }
      };

      const wireEnggQtyLock = (row: HTMLTableRowElement): void => {
        const poActualInput = row.querySelector(
          'input[name="po_actual"]'
        ) as HTMLInputElement | null;

        if (poActualInput) {
          poActualInput.addEventListener('change', () => updateEnggQtyState(row));
          poActualInput.addEventListener('input', () => updateEnggQtyState(row));
        }

        updateEnggQtyState(row);
      };

      const recalcRowStatus = (row: HTMLTableRowElement): void => {
        const statusDisplay = row.querySelector(
          '.status-text-display'
        ) as HTMLElement | null;
        if (!statusDisplay) return;

        const getVal = (name: string): string =>
          (row.querySelector(`input[name="${name}"]`) as HTMLInputElement)
            ?.value || "";

        const newStatus = getStatusFromActualDates({
          RfqActual: getVal("rfq_actual"),
          OfferActual: getVal("offer_actual"),
          TechActual: getVal("tech_actual"),
          OrderActual: getVal("order_actual"),
          PRActual: getVal("pr_actual"),
          POActual: getVal("po_actual"),
          DocActual: getVal("doc_actual"),
          MfgActual: getVal("mfg_actual"),
          InspActual: getVal("insp_actual"),
          DispActual: getVal("disp_actual"),
          DeliveryActual: getVal("delivery_actual"),
        });

        statusDisplay.textContent = newStatus;
        statusDisplay.className = 'status-text-display';
        if (newStatus === 'Delivered') {
          statusDisplay.classList.add('delivered');
        }

        updateEnggQtyState(row);
      };

      const wireStatusAutoLink = (row: HTMLTableRowElement): void => {
        const actualInputNames = [
          "rfq_actual",
          "offer_actual",
          "tech_actual",
          "order_actual",
          "pr_actual",
          "po_actual",
          "doc_actual",
          "mfg_actual",
          "insp_actual",
          "disp_actual",
          "delivery_actual",
        ];

        actualInputNames.forEach((name) => {
          const input = row.querySelector(
            `input[name="${name}"]`
          ) as HTMLInputElement | null;
          if (input) {
            input.addEventListener("change", () => {
              recalcRowStatus(row);
            });
            input.addEventListener("input", () => {
              recalcRowStatus(row);
            });
          }
        });

        recalcRowStatus(row);
        wireEnggQtyLock(row);
        wireOverdueHighlights(row);
      };

      // DOM Elements
      const projectSelect = document.getElementById("projectSelect") as HTMLSelectElement;
      const showFormBtn = document.querySelector(".show-form-btn") as HTMLButtonElement;
      const exportExcelBtn = document.querySelector(".export-excel-btn") as HTMLButtonElement;
      const formSection = document.querySelector(".form-section") as HTMLElement;
      const tableSection = document.querySelector(".table-section") as HTMLElement;
      const backBtn = document.querySelector(".back-to-table") as HTMLButtonElement;
      const procurementContainer = document.getElementById("procurementContainer") as HTMLElement;
      const procurementContainerTable = document.getElementById("procurementContainerTable") as HTMLElement;
      const tableBody = document.getElementById("procurementBody") as HTMLElement;
      const paginationDiv = document.querySelector(".pagination") as HTMLElement;
      const form = document.getElementById("procurementForm") as HTMLFormElement;
      const formTitle = document.getElementById("formTitle") as HTMLHeadingElement;
      const existingDataAlert = document.getElementById("existingDataAlert") as HTMLDivElement;
      // Description filter for the Edit Procurement table
      const descriptionFilter = document.getElementById(
        "descriptionFilter"
      ) as HTMLInputElement | null;

      // Project Info Display Elements
      const projectNameDisplay = document.getElementById("projectNameDisplay") as HTMLElement;
      const projectRefDisplay = document.getElementById("projectRefDisplay") as HTMLElement;
      const projectCenterDisplay = document.getElementById("projectCenterDisplay") as HTMLElement;
      const projectManagerDisplay = document.getElementById("projectManagerDisplay") as HTMLElement;
      const groupHeadDisplay = document.getElementById("groupHeadDisplay") as HTMLElement;
      const customerDisplay = document.getElementById("customerDisplay") as HTMLElement;

      // Filter Elements
      const filterProject = document.getElementById("filterProject") as HTMLSelectElement;
      const filterCustomer = document.getElementById("filterCustomer") as HTMLSelectElement;
      const filterProjectManager = document.getElementById("filterProjectManager") as HTMLSelectElement;
      const filterGroupHead = document.getElementById("filterGroupHead") as HTMLSelectElement;
      const filterProjectReference = document.getElementById("filterProjectReference") as HTMLSelectElement;
      const clearFiltersBtn = document.querySelector(".table-actions .clear-filters-btn") as HTMLButtonElement;

      setTimeout(() => {
        if (filterProject) {
          filterProject.addEventListener("change", filterData);
        }
        if (filterCustomer) {
          filterCustomer.addEventListener("change", filterData);
        }
        if (filterProjectManager) {
          filterProjectManager.addEventListener("change", filterData);
        }
        if (filterGroupHead) {
          filterGroupHead.addEventListener("change", filterData);
        }
        if (filterProjectReference) {
          filterProjectReference.addEventListener("change", filterData);
        }
        if (clearFiltersBtn) {
          clearFiltersBtn.addEventListener("click", clearFilters);
        }
      }, 500);

      // Utility Functions
      const toast = (
        msg: string,
        type: "success" | "error" | "warning" = "success"
      ) => {
        Swal.fire({
          toast: true,
          position: "top-end",
          icon: type,
          title: msg,
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
        });
      };

      // ============================================ //
      // ROLE-BASED ACCESS (same as SEIBIES / auth.ts) //
      //   • a role may OPEN an EXISTING procurement    //
      //     plan when it can edit it, when it is a     //
      //     READ_ALL role (opens read-only if not      //
      //     editable), or when the project is assigned //
      //     to it.                                     //
      //   • creating a NEW plan requires create rights //
      //     (FULL_CONTROL / CONTRIBUTE).               //
      // ============================================ //
      const canViewProcurementForm = (
        isEdit: boolean = false,
        project?: ProjectItem
      ): boolean => {
        if (!canRead()) return false;

        if (isEdit) {
          if (canEditProject(project)) return true;
          if (canReadAllProjects()) return true;
          if (
            project &&
            getAssignedProjects(projects).some((p) => p.Id === project.Id)
          )
            return true;
          return false;
        }

        return canCreateRecord();
      };

      // Show / hide the Save button based on the current role + mode
      const applySaveButtonVisibility = (
        isEditMode: boolean,
        project?: ProjectItem | null
      ): void => {
        const saveBtn = form.querySelector(
          'button[type="submit"]'
        ) as HTMLButtonElement | null;
        if (!saveBtn) return;
        const canSave = isEditMode
          ? canEditProject(project || undefined)
          : canCreateRecord();
        saveBtn.style.display = canSave ? "inline-flex" : "none";
      };

      const showExportProgress = (message: string): void => {
        Swal.fire({
          title: "Exporting...",
          text: message,
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading();
          },
        });
      };

      const hideExportProgress = (): void => {
        Swal.close();
      };

      const getRequestDigest = async (): Promise<string> => {
        try {
          const res = await fetch(`${siteUrl}/_api/contextinfo`, {
            method: "POST",
            headers: {
              Accept: "application/json;odata=verbose",
              "Content-Type": "application/json;odata=verbose",
            },
          });
          if (!res.ok)
            throw new Error(`Failed to get request digest: ${res.status}`);
          const data = await res.json();
          return data.d.GetContextWebInformation.FormDigestValue;
        } catch (error) {
          console.error("Error getting request digest:", error);
          throw error;
        }
      };

      // Field discovery functions
      const discoverListFields = async (): Promise<{
        fields: any[];
        entityType: string;
      }> => {
        try {
          const listRes = await fetch(
            `${siteUrl}/_api/web/lists/getbytitle('${listName}')`,
            {
              headers: { Accept: "application/json;odata=verbose" },
            }
          );
          if (!listRes.ok)
            throw new Error(`Failed to get list: ${listRes.status}`);
          const listData = await listRes.json();
          const entityType = listData.d.ListItemEntityTypeFullName;

          const fieldsRes = await fetch(
            `${siteUrl}/_api/web/lists/getbytitle('${listName}')/fields`,
            {
              headers: { Accept: "application/json;odata=verbose" },
            }
          );
          if (!fieldsRes.ok)
            throw new Error(`Failed to get fields: ${fieldsRes.status}`);
          const fieldsData = await fieldsRes.json();
          const fields = fieldsData.d.results;

          return { fields, entityType };
        } catch (error) {
          console.error("Error discovering fields:", error);
          throw error;
        }
      };

      const createFieldMappings = (fields: any[]): FieldMappings => {
        const mappings: FieldMappings = {
          ProcurementForecast: "ProcurementForecast",
          Project: "Project",
        };

        const systemNames = [
          "Id",
          "ID",
          "Title",
          "Created",
          "Modified",
          "Author",
          "Editor",
        ];

        // Only real, user-visible, writable columns are candidates
        const candidates = (fields || []).filter((field) => {
          const internalName: string = field.InternalName || "";
          if (!internalName || internalName.startsWith("_")) return false;
          if (systemNames.includes(internalName)) return false;
          if (field.Hidden === true) return false;
          if (field.ReadOnlyField === true) return false;
          if (field.FromBaseType === true) return false;
          return true;
        });

        const hasExact = (internal: string, type: string): boolean =>
          candidates.some(
            (f) => f.InternalName === internal && f.TypeAsString === type
          );

        // --- ProcurementForecast (Note / multi-line text) ---
        if (!hasExact("ProcurementForecast", "Note")) {
          const noteField = candidates.find((field) => {
            if (field.TypeAsString !== "Note") return false;
            const t = (field.Title || "").toLowerCase().replace(/\s+/g, "");
            const n = (field.InternalName || "").toLowerCase();
            return (
              t.includes("procurement") ||
              n.includes("procurement") ||
              t.includes("forecast") ||
              n.includes("forecast") ||
              t.includes("data")
            );
          });
          if (noteField) mappings.ProcurementForecast = noteField.InternalName;
        }

        // --- Project (Lookup) ---
        if (!hasExact("Project", "Lookup")) {
          const lookupField =
            candidates.find(
              (field) =>
                field.TypeAsString === "Lookup" &&
                (field.Title || "").toLowerCase().replace(/\s+/g, "") ===
                  "project"
            ) ||
            candidates.find((field) => {
              if (field.TypeAsString !== "Lookup") return false;
              const t = (field.Title || "").toLowerCase().replace(/\s+/g, "");
              const n = (field.InternalName || "").toLowerCase();
              return t.includes("project") || n.includes("project");
            });
          if (lookupField) mappings.Project = lookupField.InternalName;
        }

        console.log("Procurement field mappings:", mappings);
        return mappings;
      };

      const testFieldMappings = async (): Promise<boolean> => {
        try {
          const testQuery = `${apiBase}?$select=Id,${fieldMappings.Project}/Id&$top=1&$expand=${fieldMappings.Project}`;
          const testRes = await fetch(testQuery, {
            headers: { Accept: "application/json;odata=verbose" },
          });

          if (testRes.ok) {
            return true;
          } else {
            let errorText = "";
            try {
              errorText = await testRes.text();
            } catch {
              /* ignore */
            }
            console.error(
              `Field mappings test: FAILED (${testRes.status}) for query: ${testQuery}`,
              errorText
            );
            return false;
          }
        } catch (error) {
          console.error("Field mappings test error:", error);
          return false;
        }
      };

      const renderProjectDetails = (project: ProjectItem | null): void => {
        if (!project) {
          if (projectNameDisplay) projectNameDisplay.textContent = "-";
          if (projectRefDisplay) projectRefDisplay.textContent = "-";
          if (projectCenterDisplay) projectCenterDisplay.textContent = "-";
          if (projectManagerDisplay) projectManagerDisplay.textContent = "-";
          if (groupHeadDisplay) groupHeadDisplay.textContent = "-";
          if (customerDisplay) customerDisplay.textContent = "-";
          return;
        }

        const managerName = getProjectManagerDisplayName(project.ProjectManager);
        const groupHeadName = getGroupHeadDisplayName(project.GroupHead1);

        if (projectNameDisplay) projectNameDisplay.textContent = project.Title || "-";
        if (projectRefDisplay) projectRefDisplay.textContent = project.ProjectReference || "-";
        if (projectCenterDisplay) projectCenterDisplay.textContent = project.PC || "-";
        if (projectManagerDisplay) projectManagerDisplay.textContent = managerName || "-";
        if (groupHeadDisplay) groupHeadDisplay.textContent = groupHeadName || "-";
        if (customerDisplay) customerDisplay.textContent = project.CustomerName || "-";
      };

      const initApp = async (): Promise<void> => {
        try {
          // ✅ Initialize shared authentication (same as SEIBIES)
          await authManager.initialize({ siteUrl });

          console.log(`🔑 Permission Level: ${getPermissionLevel().toUpperCase()}`);
          console.log(`👤 User: ${getCurrentUserFullName()}`);
          console.log(`📋 User Groups:`, getUserGroups());
          console.log(`✅ Has Full Control: ${hasFullControl()}`);
          console.log(`✅ Can Contribute: ${canContribute()}`);
          console.log(`✅ Can Freeze: ${canFreeze()}`);
          console.log(`✅ Is GH Head: ${isGHHead()}`);
          console.log(`✅ Is PM Manager: ${isPMManager()}`);
          console.log(`✅ Is Engineering User: ${isEngineeringUser()}`);

          const { fields, entityType } = await discoverListFields();
          listEntityTypeName = entityType;
          fieldMappings = createFieldMappings(fields);

          const mappingsValid = await testFieldMappings();
          if (!mappingsValid) {
            throw new Error(
              "Field mappings are invalid. Please check the field names in your SharePoint list."
            );
          }

          await loadProjects();
          const dataLoaded = await fetchData();
          attachFilterEventListeners();
          if (!dataLoaded) return;

          initializeFilters();
          renderTable(procurementData);

          toast("Procurement tracker initialized successfully", "success");

          // ✅ Apply role-based UI visibility (same as SEIBIES)
          updateUIBasedOnPermissions({
            exportBtn: ".export-excel-btn",
            addBtn: ".show-form-btn",
            saveBtn: 'button[type="submit"]'
          });
        } catch (error) {
          console.error("Initialization error:", error);
          const message =
            error instanceof Error ? error.message : String(error);
          showTableMessage(`Failed to load data: ${message}`);
          toast(
            `Failed to initialize application: ${message}`,
            "error"
          );
        }
      };

      // Shows a message row inside the main table (so an error is never silent)
      const showTableMessage = (message: string): void => {
        if (!tableBody) return;
        tableBody.innerHTML = `<tr><td colspan="19" style="text-align:center;padding:20px;color:#c62828;">${escapeHtml(
          message
        )}</td></tr>`;
      };

      const attachFilterEventListeners = (): void => {
        filterProject.addEventListener("change", filterData);
        filterCustomer.addEventListener("change", filterData);
        filterProjectManager.addEventListener("change", filterData);
        filterGroupHead.addEventListener("change", filterData);
        filterProjectReference.addEventListener("change", filterData);

        const clearFiltersBtn = document.querySelector(
          ".table-actions .clear-filters-btn"
        ) as HTMLButtonElement;

        if (clearFiltersBtn) {
          clearFiltersBtn.addEventListener("click", clearFilters);
        }
      };

      const loadProjects = async (): Promise<void> => {
        try {
          const listPath = `${siteUrl}/_api/web/lists/getbytitle('Project List')/items`;
          const headers = { Accept: "application/json;odata=verbose" };

          // ✅ Preferred query: GroupHead1 / ProjectManager as Person fields (expanded)
          let res = await fetch(
            `${listPath}?$select=Id,Title,CustomerName,GroupHead1/Title,GroupHead1Id,PC,ProjectReference,ProjectManager/Title,ProjectManagerId&$expand=GroupHead1,ProjectManager&$top=5000`,
            { headers }
          );

          // ✅ Fallback: if the expand fails (e.g. those columns are plain text, or
          // a column name differs) retrieve the plain columns instead of failing.
          if (!res.ok) {
            console.warn(
              `Project List expanded query failed (${res.status}); retrying without $expand`
            );
            res = await fetch(
              `${listPath}?$select=Id,Title,CustomerName,GroupHead1,PC,ProjectReference,ProjectManager&$top=5000`,
              { headers }
            );
          }
          if (!res.ok) {
            console.warn(
              `Project List plain query failed (${res.status}); retrying with all columns`
            );
            res = await fetch(`${listPath}?$top=5000`, { headers });
          }
          if (!res.ok)
            throw new Error(`Failed to load projects: ${res.status}`);

          const data = await res.json();
          const allProjects: any[] = data?.d?.results || [];

          // Map to ProjectItem with proper Person/Group handling
          const mappedProjects: ProjectItem[] = allProjects.map((p: any) => ({
            Id: p.Id,
            Title: p.Title || "",
            CustomerName: p.CustomerName || "",
            GroupHead1: p.GroupHead1 || "",
            GroupHead1Id: p.GroupHead1Id,
            PC: p.PC || "",
            ProjectReference: p.ProjectReference || "",
            ProjectManager: p.ProjectManager || "",
            ProjectManagerId: p.ProjectManagerId
          }));

          const uniqueProjects = Array.from(
            new Map(mappedProjects.map((p: ProjectItem) => [p.Title, p])).values()
          );

          projects = uniqueProjects;
          console.log(`Loaded ${projects.length} projects from Project List`);

          // ✅ Role access (same as SEIBIES): dropdowns only show assigned projects
          const assignedProjects = getAssignedProjects(projects);

          projectSelect.innerHTML =
            '<option value="">Select Project</option>' +
            assignedProjects
              .map((p) => `<option value="${p.Id}">${p.Title}</option>`)
              .join("");

          filterProject.innerHTML =
            '<option value="">All Projects</option>' +
            [...new Set(assignedProjects.map((p) => p.Title))]
              .sort()
              .map((project) => `<option value="${project}">${project}</option>`)
              .join("");
        } catch (error) {
          console.error("Error loading projects:", error);
          toast("Failed to load projects", "error");
        }
      };

      // Helper functions for Person/Group display
      const getGroupHeadDisplayName = (groupHead: string | { Title: string; Email?: string } | undefined): string => {
        if (!groupHead) return "";
        if (typeof groupHead === "object" && groupHead !== null) {
          return groupHead.Title || "";
        }
        return groupHead;
      };

      const getProjectManagerDisplayName = (manager: string | { Title: string; Email?: string } | undefined): string => {
        if (!manager) return "";
        if (typeof manager === "object" && manager !== null) {
          return manager.Title || "";
        }
        return manager;
      };

      const parseProcurementForecast = (
        procurementForecastJson: string
      ): ProcurementForecastItem[] | null => {
        if (!procurementForecastJson) return null;

        try {
          const parsed = JSON.parse(procurementForecastJson);
          return Array.isArray(parsed) ? parsed : [parsed];
        } catch (error) {
          console.error("Error parsing ProcurementForecast JSON:", error);
          return null;
        }
      };

      const calculateProjectStatusCounts = (
        procurementItems: ProcurementForecastItem[]
      ): { [key: string]: number } => {
        const counts: { [key: string]: number } = {};

        statusOptions.forEach((status) => {
          counts[status] = 0;
        });

        procurementItems.forEach((item) => {
          if (item.Status && counts.hasOwnProperty(item.Status)) {
            counts[item.Status]++;
          }
        });

        return counts;
      };

      const fetchData = async (): Promise<boolean> => {
        try {
          const headers = { Accept: "application/json;odata=verbose" };
          const projectField = fieldMappings.Project;
          const forecastField = fieldMappings.ProcurementForecast;

          const selectFields = [
            "Id",
            "Title",
            forecastField,
            `${projectField}Id`,
            `${projectField}/Id`,
            `${projectField}/Title`,
          ].filter((field) => field && !field.startsWith("_"));

          const query = `${apiBase}?$select=${selectFields.join(
            ","
          )}&$expand=${projectField}&$top=5000`;

          let res = await fetch(query, { headers });

          // ✅ Fallback: if the expanded query is rejected by SharePoint,
          // load the raw items instead of showing an empty table.
          if (!res.ok) {
            let errorText = "";
            try {
              errorText = await res.text();
            } catch {
              /* ignore */
            }
            console.warn(
              `Procurement query failed (${res.status}) for: ${query}`,
              errorText
            );
            res = await fetch(`${apiBase}?$top=5000`, { headers });
          }

          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

          const data = await res.json();
          procurementData = data?.d?.results || [];
          console.log(
            `Loaded ${procurementData.length} procurement records from ${listName}`
          );

          // ✅ Role access (same as SEIBIES): a non-READ_ALL role only sees the
          // procurement of projects assigned to it (GH Heads / PM Managers get ALL).
          if (!canReadAllProjects() && projects.length > 0) {
            const assignedProjectTitles = new Set(
              getAssignedProjects(projects).map((p) => p.Title)
            );
            procurementData = procurementData.filter((item) => {
              const projectData = resolveProjectForItem(item);
              const projectTitle =
                item[fieldMappings.Project]?.Title || projectData?.Title || "";
              return projectTitle && assignedProjectTitles.has(projectTitle);
            });
            console.log(
              `Role-filtered to ${procurementData.length} procurement records`
            );
          }

          initializeFilters();
          renderTable(procurementData);
          return true;
        } catch (error) {
          console.error("Error fetching data:", error);
          const message =
            error instanceof Error ? error.message : String(error);
          showTableMessage(`Failed to fetch data: ${message}`);
          toast(`Failed to fetch data: ${message}`, "error");
          return false;
        }
      };

      const initializeFilters = (): void => {
        // ✅ Role access (same as SEIBIES): dropdowns derive from the projects this
        // role can see (GH Heads / PM Managers / READ_ALL get all projects).
        const assignedProjects = getAssignedProjects(projects);
        const filterSource = canReadAllProjects() ? projects : assignedProjects;

        const uniqueCustomers = [
          ...new Set(filterSource.map((p) => p.CustomerName).filter(Boolean)),
        ].sort() as string[];
        filterCustomer.innerHTML =
          '<option value="">All Customers</option>' +
          uniqueCustomers
            .map(
              (customer) => `<option value="${customer}">${customer}</option>`
            )
            .join("");

        // ✅ ProjectManager - Person/Group type
        const uniqueManagers = [
          ...new Set(
            filterSource
              .map((p) => getProjectManagerDisplayName(p.ProjectManager))
              .filter(Boolean)
          ),
        ].sort() as string[];
        filterProjectManager.innerHTML =
          '<option value="">All Managers</option>' +
          uniqueManagers
            .map((manager) => `<option value="${manager}">${manager}</option>`)
            .join("");

        // ✅ GroupHead1 - Person/Group type
        const uniqueGroupHeads = [
          ...new Set(
            filterSource
              .map((p) => getGroupHeadDisplayName(p.GroupHead1))
              .filter(Boolean)
          ),
        ].sort() as string[];
        filterGroupHead.innerHTML =
          '<option value="">All Group Heads</option>' +
          uniqueGroupHeads
            .map((head) => `<option value="${head}">${head}</option>`)
            .join("");

        const uniqueReferences = [
          ...new Set(
            filterSource.map((p) => p.ProjectReference).filter(Boolean)
          ),
        ].sort() as string[];
        filterProjectReference.innerHTML =
          '<option value="">All References</option>' +
          uniqueReferences
            .map((ref) => `<option value="${ref}">${ref}</option>`)
            .join("");
      };

      const filterData = (): void => {
        const project = filterProject.value;
        const customer = filterCustomer.value;
        const projectManager = filterProjectManager.value;
        const groupHead = filterGroupHead.value;
        const projectReference = filterProjectReference.value;

        const filtered = procurementData.filter((item) => {
          const projectData = resolveProjectForItem(item);
          const projectTitle =
            item[fieldMappings.Project]?.Title || projectData?.Title || "";

          if (project && projectTitle !== project) return false;
          if (customer && projectData?.CustomerName !== customer) return false;

          // ✅ ProjectManager - Person/Group type
          if (projectManager) {
            const managerName = getProjectManagerDisplayName(projectData?.ProjectManager);
            if (managerName !== projectManager) return false;
          }

          // ✅ GroupHead1 - Person/Group type
          if (groupHead) {
            const groupHeadName = getGroupHeadDisplayName(projectData?.GroupHead1);
            if (groupHeadName !== groupHead) return false;
          }

          if (
            projectReference &&
            projectData?.ProjectReference !== projectReference
          )
            return false;

          return true;
        });

        currentPage = 1;
        renderTable(filtered);
      };

      const clearFilters = (): void => {
        filterProject.value = "";
        filterCustomer.value = "";
        filterProjectManager.value = "";
        filterGroupHead.value = "";
        filterProjectReference.value = "";

        currentPage = 1;
        renderTable(procurementData);
        toast("Filters cleared", "success");
      };

      const formatDate = (dateString: string): string => {
        if (!dateString) return "";
        try {
          const date = new Date(dateString);
          return isNaN(date.getTime())
            ? dateString
            : date.toLocaleDateString("en-GB");
        } catch {
          return dateString;
        }
      };

      const formatDateForInput = (dateString: string): string => {
        if (!dateString) return "";
        try {
          const date = new Date(dateString);
          return isNaN(date.getTime()) ? "" : date.toISOString().split("T")[0];
        } catch {
          return "";
        }
      };

      const formatDateForExcel = (dateString: string): string => {
        if (!dateString) return "";
        try {
          const date = new Date(dateString);
          if (isNaN(date.getTime())) return "";
          return date.toISOString().split("T")[0];
        } catch {
          return "";
        }
      };
      const escapeHtml = (unsafe: string | number): string => {
        const safeString = String(unsafe);
        return safeString
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
      };

      // ✅ Edit title like SEIBIES: "Edit Procurement Plan - <Project> (<Ref>)"
      const setEditTitle = (project?: ProjectItem | null): void => {
        if (!formTitle) return;
        const name = project?.Title || "";
        const ref = project?.ProjectReference || "";
        formTitle.textContent = name
          ? `Edit Procurement Plan - ${name}${ref ? ` (${ref})` : ""}`
          : "Edit Procurement Plan";
        formSection.classList.add("edit-mode");
      };

      const openEditForm = (id: number): void => {
        const record = procurementData.find((d) => d.Id === id);
        if (!record) {
          toast("Record not found", "error");
          return;
        }

        // ✅ Role access (same as SEIBIES): only permitted roles may open the edit form
        const guardProjectId =
          record[`${fieldMappings.Project}Id`] ||
          (record[fieldMappings.Project] && record[fieldMappings.Project].Id);
        const guardProject =
          guardProjectId !== undefined && guardProjectId !== null
            ? projects.find((p) => p.Id === guardProjectId)
            : undefined;
        if (!canViewProcurementForm(true, guardProject)) {
          toast("❌ You don't have permission to view this procurement plan", "error");
          return;
        }

        editingId = id;
        formSection.style.display = "block";
        tableSection.style.display = "none";
        formTitle.textContent = "Edit Procurement Plan";
        existingDataAlert.style.display = "block";

        resetDescriptionFilter();

        formSection.classList.remove("view-mode");
        projectSelect.disabled = true;

        const projectId =
          record[`${fieldMappings.Project}Id`] ||
          (record[fieldMappings.Project] && record[fieldMappings.Project].Id);

        if (projectId) {
          projectSelect.value = projectId.toString();
          const project = projects.find((p) => p.Id === projectId);
          if (project) {
            renderProjectDetails(project);
          }
          onProjectChange(projectId, true);
          setEditTitle(project);
        } else {
          setEditTitle(null);
        }
        applySaveButtonVisibility(true, guardProject);
        window.scrollTo({ top: 0, behavior: "auto" });

        procurementContainer.innerHTML = "";
        const procurementItems =
          parseProcurementForecast(record[fieldMappings.ProcurementForecast]) ||
          [];

        procurementItems.forEach((item) => {
          procurementContainer.appendChild(createProcurementRow(item));
        });

        const addMoreBtn = document.querySelector(
          ".add-procurement-row"
        ) as HTMLButtonElement;
        if (addMoreBtn) addMoreBtn.style.display = "block";

        const submitBtn = form.querySelector(
          'button[type="submit"]'
        ) as HTMLButtonElement;
        if (submitBtn) {
          submitBtn.textContent = "💾 Save Procurement";
        }
        // Re-apply role-based visibility (overrides the inline default)
        applySaveButtonVisibility(true, guardProject);

        addImportButtonToEditMode(projectId, record);
      };

      // ============================================ //
      // OUTER-STICKY HEADER (main table)             //
      //   The page scrolls vertically. The main      //
      //   header is sticky at top:0. The table       //
      //   header is sticky at top = main header      //
      //   height, so it 'touches' the main header    //
      //   and pins below it. No per-cell JS offset.  //
      // ============================================ //
      const updateMainTableStickyOffset = (): void => {
        const section = document.querySelector(".table-section") as HTMLElement | null;
        const header = section?.querySelector(".page-header") as HTMLElement | null;
        if (!section || !header) return;
        // Fall back to a sensible minimum in case offsetHeight is 0 (e.g.
        // before fonts/images load), so the table header never sticks at
        // top:0 on top of the page header.
        const headerH = Math.max(header.offsetHeight || 0, 58);
        section.style.setProperty("--sticky-header-top", `${headerH}px`);
      };

      // Re-measure after the page fully loads (fonts / layout settled) so the
      // offset matches the real page-header height and both stay pinned.
      if (document.readyState === "complete") {
        setTimeout(updateMainTableStickyOffset, 100);
      } else {
        window.addEventListener("load", () => setTimeout(updateMainTableStickyOffset, 100), { once: true });
      }

      const updatePaginationInfo = (total: number): void => {
        const info = document.getElementById("paginationInfo");
        if (!info) return;
        if (total === 0) {
          info.textContent = "Showing 0-0 of 0 records";
          return;
        }
        const startItem = (currentPage - 1) * pageSize + 1;
        const endItem = Math.min(currentPage * pageSize, total);
        info.textContent = `Showing ${startItem}-${endItem} of ${total} records`;
      };

      // ============================================ //
      // MAIN TABLE RENDER                            //
      // - Only Project Reference is the edit link    //
      // - Row actions handled via event delegation   //
      //   (see tableBody click listener below)       //
      // ============================================ //
      // ✅ Find the Project List entry for a procurement item — by lookup Id
      // first (most reliable), then by lookup Title.
      const resolveProjectForItem = (item: any): ProjectItem | undefined => {
        const lookup = item?.[fieldMappings.Project];
        const lookupId =
          (lookup && typeof lookup === "object" ? lookup.Id : undefined) ??
          item?.[`${fieldMappings.Project}Id`];
        const lookupTitle =
          lookup && typeof lookup === "object" ? lookup.Title : undefined;

        let projectData: ProjectItem | undefined;
        if (lookupId !== undefined && lookupId !== null) {
          projectData = projects.find((p) => p.Id === Number(lookupId));
        }
        if (!projectData && lookupTitle) {
          projectData = projects.find((p) => p.Title === lookupTitle);
        }
        return projectData;
      };

      const renderTable = (data: any[]): void => {
        currentTableData = data;
        const start = (currentPage - 1) * pageSize;
        const pageData = data.slice(start, start + pageSize);

        tableBody.innerHTML = "";

        if (pageData.length > 0) {
          pageData.forEach((item) => {
            const projectData = resolveProjectForItem(item);
            const projectTitle =
              item[fieldMappings.Project]?.Title || projectData?.Title || "";
            const procurementItems =
              parseProcurementForecast(
                item[fieldMappings.ProcurementForecast]
              ) || [];

            const statusCounts = calculateProjectStatusCounts(procurementItems);
            const totalLineItems = procurementItems.length;

            const managerName = getProjectManagerDisplayName(projectData?.ProjectManager);
            const groupHeadName = getGroupHeadDisplayName(projectData?.GroupHead1);

            // ✅ Only Project Reference is clickable. If a project has no reference,
            // fall back to "#Id" so every row still has an edit link.
            const projectRefLabel =
              projectData?.ProjectReference || `#${item.Id}`;

            const row = document.createElement("tr");
            row.innerHTML = `
              <td class="sticky-main-col main-col-1">
                <span class="clickable-link" data-id="${item.Id}" title="Click to edit">${escapeHtml(projectRefLabel)}</span>
              </td>
              <td class="sticky-main-col main-col-2" title="${escapeHtml(projectData?.CustomerName || "")}">${escapeHtml(projectData?.CustomerName || "")}</td>
              <td class="sticky-main-col main-col-3" title="${escapeHtml(projectTitle)}"><span class="project-name-text">${escapeHtml(projectTitle)}</span></td>
              <td class="sticky-main-col main-col-4" title="${escapeHtml(groupHeadName)}">${escapeHtml(groupHeadName)}</td>
              <td class="sticky-main-col main-col-5" title="${escapeHtml(managerName)}">${escapeHtml(managerName)}</td>
              <td class="total-line-items-col" style="text-align: center; font-weight: 600; background-color: #f0f7ff;">${totalLineItems}</td>
              <td style="text-align: center; font-weight: bold; background-color: #e3f2fd;">${statusCounts["RFQ Pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #fff3e0;">${statusCounts["Offer Pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #e8f5e8;">${statusCounts["TC pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #fce4ec;">${statusCounts["Order Closure pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #f3e5f5;">${statusCounts["PR pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #e0f2f1;">${statusCounts["PO pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #fff8e1;">${statusCounts["Document Approval Pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #e8f5e8;">${statusCounts["MFC Pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #fff3e0;">${statusCounts["Inspection Pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #e3f2fd;">${statusCounts["Dispatch Pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #fce4ec;">${statusCounts["Delivery Pending"] || 0}</td>
              <td style="text-align: center; font-weight: bold; background-color: #e8f5e8;">${statusCounts["Delivered"] || 0}</td>
              <td class="actions-cell">
                <button type="button" class="view-btn" data-id="${item.Id}" title="View">👁️</button>
              </td>
            `;
            tableBody.appendChild(row);
          });
        } else {
          const noDataRow = document.createElement("tr");
          noDataRow.innerHTML = `<td colspan="19" style="text-align:center;padding:20px;">No records found</td>`;
          tableBody.appendChild(noDataRow);
        }

        renderPagination(Math.ceil(data.length / pageSize));
        updatePaginationInfo(data.length);
        updateMainTableStickyOffset();
      };

      // ✅ Event delegation for the main table (edit link / view).
      // Attached once, so it keeps working after every re-render.
      tableBody.addEventListener("click", (e) => {
        const target = e.target as HTMLElement;

        const viewBtn = target.closest(".view-btn") as HTMLElement | null;
        if (viewBtn) {
          e.preventDefault();
          e.stopPropagation();
          const id = parseInt(viewBtn.dataset.id || "0", 10);
          if (id > 0) viewData(id);
          return;
        }

        const link = target.closest(".clickable-link") as HTMLElement | null;
        if (link) {
          e.preventDefault();
          const id = parseInt(link.dataset.id || "0", 10);
          if (id > 0) openEditForm(id);
        }
      });

      const renderPagination = (totalPages: number): void => {
        paginationDiv.innerHTML = "";
        if (totalPages <= 1) return;

        for (let i = 1; i <= totalPages; i++) {
          const btn = document.createElement("button");
          btn.textContent = i.toString();
          btn.className = i === currentPage ? "active" : "";
          btn.addEventListener("click", () => {
            currentPage = i;
            renderTable(currentTableData);
          });
          paginationDiv.appendChild(btn);
        }
      };

      const viewData = (id: number): void => {
        // ✅ Role access (same as SEIBIES): view requires at least read access
        if (!canRead()) {
          toast("❌ You don't have permission to view procurement data", "error");
          return;
        }
        const record = procurementData.find((d) => d.Id === id);
        if (!record) {
          toast("Record not found", "error");
          return;
        }

        editingId = id;
        formSection.style.display = "block";
        tableSection.style.display = "none";
        formTitle.textContent = "View Procurement";
        existingDataAlert.style.display = "none";

        formSection.classList.remove("edit-mode");
        formSection.classList.add("view-mode");

        const projectId =
          record[`${fieldMappings.Project}Id`] ||
          (record[fieldMappings.Project] && record[fieldMappings.Project].Id);

        if (projectId) {
          const project = projects.find((p) => p.Id === projectId);
          if (project) {
            projectSelect.value = projectId.toString();
            renderProjectDetails(project);
          }
        }

        projectSelect.disabled = true;

        procurementContainer.innerHTML = "";
        const procurementItems =
          parseProcurementForecast(record[fieldMappings.ProcurementForecast]) ||
          [];

        procurementItems.forEach((item) => {
          procurementContainer.appendChild(createViewProcurementRow(item));
        });

        const addMoreBtn = document.querySelector(
          ".add-procurement-row"
        ) as HTMLButtonElement;
        if (addMoreBtn) addMoreBtn.style.display = "none";

        const submitBtn = form.querySelector(
          'button[type="submit"]'
        ) as HTMLButtonElement;
        if (submitBtn) {
          submitBtn.style.display = "none";
        }

        const existingExportBtns = document.querySelectorAll(
          ".export-project-excel-btn, .export-top-btn"
        );
        existingExportBtns.forEach((btn) => btn.remove());

        const exportBtn = document.createElement("button");
        exportBtn.type = "button";
        exportBtn.className = "btn-primary export-project-excel-btn";
        exportBtn.textContent = "📊 Export BOM Excel";
        exportBtn.style.marginBottom = "15px";
        exportBtn.style.display = "block";

        exportBtn.addEventListener("click", () =>
          exportProjectToExcel(projectId, record)
        );

        const procurementContainerTable = document.getElementById(
          "procurementContainerTable"
        ) as HTMLElement;

        procurementContainerTable.parentNode?.insertBefore(
          exportBtn,
          procurementContainerTable
        );

        procurementContainerTable.style.display = "block";
      };

      // ============================================ //
      // DESCRIPTION FILTER - EDIT MODE             //
      // ============================================ //
      const filterEditTableByDescription = (): void => {
        const searchText = (descriptionFilter?.value || "").trim().toLowerCase();
        const rows = Array.from(
          procurementContainer.querySelectorAll("tr")
        ) as HTMLTableRowElement[];

        rows.forEach((row) => {
          const descriptionInput = row.querySelector(
            'input[name="description"]'
          ) as HTMLInputElement | null;

          if (!descriptionInput) return;

          const description = descriptionInput.value.trim().toLowerCase();
          row.style.display =
            !searchText || description.includes(searchText) ? "" : "none";
        });
      };

      const resetDescriptionFilter = (): void => {
        if (descriptionFilter) {
          descriptionFilter.value = "";
        }

        const rows = Array.from(
          procurementContainer.querySelectorAll("tr")
        ) as HTMLTableRowElement[];

        rows.forEach((row) => {
          row.style.display = "";
        });
      };

      const createViewProcurementRow = (
        data: ProcurementForecastItem
      ): HTMLTableRowElement => {
        const row = document.createElement("tr");

        const getDisplayValue = (
          field: keyof ProcurementForecastItem
        ): string => {
          if (!data) return "";
          const value = data[field];

          if (value === null || value === undefined || value === "") return "";

          if (
            field.includes("Plan") ||
            field.includes("Actual") ||
            field.includes("Forecast")
          ) {
            return formatDate(String(value));
          }

          if (
            (field === "FCMQuantity" || field === "EnggQuantity") &&
            typeof value === "number"
          ) {
            return value.toString();
          }

          return String(value);
        };

        // Red highlight for overdue Actual cells in view mode too
        const actualClass = (
          planField: keyof ProcurementForecastItem,
          actualField: keyof ProcurementForecastItem
        ): string =>
          isActualOverdue(
            String(data?.[planField] ?? ""),
            String(data?.[actualField] ?? "")
          )
            ? " actual-overdue"
            : "";

        const statusValue = getDisplayValue("Status");
        const descriptionValue = escapeHtml(getDisplayValue("Description"));

        row.innerHTML = `
          <td class="sticky-col col-1">
            <div class="view-field description-view" title="${descriptionValue}">
              ${descriptionValue}
            </div>
          </td>
          <td class="sticky-col col-2"><div class="view-field">${getDisplayValue(
            "FCMQuantity"
          )}</div></td>
          <td class="sticky-col col-3"><div class="view-field">${getDisplayValue(
            "EnggQuantity"
          )}</div></td>
          <td class="sticky-col col-4"><div class="view-field status-badge" data-status="${escapeHtml(
            statusValue
          )}">${escapeHtml(statusValue)}</div></td>
          <td class="sticky-col col-5"><div class="view-field">${escapeHtml(
            getDisplayValue("Make")
          )}</div></td>
          <td class="sticky-col col-6"><div class="view-field">${escapeHtml(
            getDisplayValue("Model")
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("RfqPlan")}</div></td>
          <td><div class="view-field${actualClass("RfqPlan", "RfqActual")}">${getDisplayValue("RfqActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "RfqForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("OfferPlan")}</div></td>
          <td><div class="view-field${actualClass("OfferPlan", "OfferActual")}">${getDisplayValue(
            "OfferActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "OfferForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("TechPlan")}</div></td>
          <td><div class="view-field${actualClass("TechPlan", "TechActual")}">${getDisplayValue(
            "TechActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "TechForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("OrderPlan")}</div></td>
          <td><div class="view-field${actualClass("OrderPlan", "OrderActual")}">${getDisplayValue(
            "OrderActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "OrderForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("PRPlan")}</div></td>
          <td><div class="view-field${actualClass("PRPlan", "PRActual")}">${getDisplayValue("PRActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "PRForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("POPlan")}</div></td>
          <td><div class="view-field${actualClass("POPlan", "POActual")}">${getDisplayValue("POActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "POForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("DocPlan")}</div></td>
          <td><div class="view-field${actualClass("DocPlan", "DocActual")}">${getDisplayValue("DocActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DocForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("MfgPlan")}</div></td>
          <td><div class="view-field${actualClass("MfgPlan", "MfgActual")}">${getDisplayValue("MfgActual")}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "MfgForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("InspPlan")}</div></td>
          <td><div class="view-field${actualClass("InspPlan", "InspActual")}">${getDisplayValue(
            "InspActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "InspForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue("DispPlan")}</div></td>
          <td><div class="view-field${actualClass("DispPlan", "DispActual")}">${getDisplayValue(
            "DispActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DispForecast"
          )}</div></td>

          <td><div class="view-field">${getDisplayValue(
            "DeliveryPlan"
          )}</div></td>
          <td><div class="view-field${actualClass("DeliveryPlan", "DeliveryActual")}">${getDisplayValue(
            "DeliveryActual"
          )}</div></td>
          <td><div class="view-field">${getDisplayValue(
            "DeliveryForecast"
          )}</div></td>

          <td><div class="view-field remarks-view">${escapeHtml(
            getDisplayValue("Remarks")
          )}</div></td>
          <td></td>
        `;

        return row;
      };

      // ============================================ //
      // IMPORT FUNCTIONS (simplified)                //
      // ============================================ //

      const collectValidationErrors = (data: any[], headers: string[]): ValidationError[] => {
        const errors: ValidationError[] = [];

        if (!data || data.length === 0) {
          errors.push({
            type: 'error',
            message: 'No data found in the Excel file.'
          });
          return errors;
        }

        const requiredColumns = ['description', 'status', 'make'];
        const missingColumns = requiredColumns.filter(col =>
          !headers.some(h => h.toLowerCase().includes(col) || h.toLowerCase() === col)
        );

        if (missingColumns.length > 0) {
          errors.push({
            type: 'error',
            message: `Missing required columns: ${missingColumns.join(', ')}`
          });
        }

        return errors;
      };

      const showValidationErrors = (errors: ValidationError[], container: HTMLElement): void => {
        const existingErrorList = container.querySelector('.error-list');
        if (existingErrorList) existingErrorList.remove();

        if (errors.length === 0) return;

        const errorList = document.createElement('div');
        errorList.className = 'error-list show';

        const criticalErrors = errors.filter(e => e.type === 'error');
        const warnings = errors.filter(e => e.type === 'warning');

        let html = `
          <div class="error-title">
            ⚠️ ${criticalErrors.length > 0 ? `${criticalErrors.length} Critical Error(s) Found` : 'Validation Issues Found'}
          </div>
          <ul class="error-items">
        `;

        criticalErrors.forEach(err => {
          html += `<li class="error-critical">${err.message}</li>`;
        });

        warnings.forEach(err => {
          html += `<li class="error-warning">${err.message}</li>`;
        });

        html += `</ul>`;

        if (criticalErrors.length > 0) {
          html += `
            <div style="margin-top: 10px; padding: 8px 12px; background: #dc3545; color: white; border-radius: 4px; font-size: 13px; font-weight: 600;">
              ❌ ${criticalErrors.length} critical error(s) must be fixed before importing
            </div>
          `;
        }

        errorList.innerHTML = html;

        const previewSection = container.querySelector('#previewSection');
        if (previewSection) {
          previewSection.insertAdjacentElement('afterend', errorList);
        } else {
          container.appendChild(errorList);
        }
      };

      const parseExcelFile = (file: File): Promise<any[]> => {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();

          reader.onload = (e) => {
            try {
              if (!e.target?.result) {
                reject(new Error("Failed to read file"));
                return;
              }

              const data = new Uint8Array(e.target.result as ArrayBuffer);
              const workbook = XLSX.read(data, {
                type: "array",
                cellDates: true,
                raw: false,
              });

              const sheetName = workbook.SheetNames[0];
              const worksheet = workbook.Sheets[sheetName];

              const jsonData = XLSX.utils.sheet_to_json(worksheet, {
                header: 1,
                defval: "",
              });

              if (jsonData.length < 2) {
                return resolve([]);
              }

              let headers: string[];
              let dataStartRow = 1;

              if (
                jsonData.length >= 2 &&
                Array.isArray(jsonData[0]) &&
                Array.isArray(jsonData[1])
              ) {
                const firstRow = jsonData[0] as string[];
                const secondRow = jsonData[1] as string[];

                if (
                  firstRow.some(
                    (cell) =>
                      cell && typeof cell === "string" && cell.includes("/")
                  ) &&
                  secondRow.some(
                    (cell) =>
                      cell &&
                      typeof cell === "string" &&
                      (cell.toLowerCase().includes("desc") ||
                        cell.toLowerCase().includes("status"))
                  )
                ) {
                  headers = secondRow;
                  dataStartRow = 2;
                } else {
                  headers = firstRow;
                }
              } else {
                headers = jsonData[0] as string[];
              }

              const rows: any[] = [];

              const headerMap: { [key: string]: string } = {};
              headers.forEach((header, idx) => {
                if (header && typeof header === "string") {
                  const cleanHeader = header.toString().trim().toLowerCase();

                  if (
                    cleanHeader.includes("desc") ||
                    cleanHeader.includes("item")
                  ) {
                    headerMap[cleanHeader] = "description";
                  } else if (
                    cleanHeader.includes("vendor") ||
                    cleanHeader.includes("supplier")
                  ) {
                    headerMap[cleanHeader] = "vendor";
                  } else if (
                    cleanHeader.includes("fcm") &&
                    (cleanHeader.includes("qty") ||
                      cleanHeader.includes("quantity"))
                  ) {
                    headerMap[cleanHeader] = "fcmquantity";
                  } else if (
                    cleanHeader.includes("engg") &&
                    (cleanHeader.includes("qty") ||
                      cleanHeader.includes("quantity"))
                  ) {
                    headerMap[cleanHeader] = "enggquantity";
                  } else if (cleanHeader.includes("status")) {
                    headerMap[cleanHeader] = "status";
                  } else if (
                    cleanHeader.includes("make") ||
                    cleanHeader.includes("manufacturer")
                  ) {
                    headerMap[cleanHeader] = "make";
                  } else if (
                    cleanHeader.includes("model") ||
                    cleanHeader.includes("part")
                  ) {
                    headerMap[cleanHeader] = "model";
                  } else if (cleanHeader.includes("remark")) {
                    headerMap[cleanHeader] = "remarks";
                  } else {
                    headerMap[cleanHeader] = cleanHeader;
                  }
                }
              });

              for (let i = dataStartRow; i < jsonData.length; i++) {
                const rowData = jsonData[i] as any[];
                if (
                  !rowData ||
                  rowData.every(
                    (cell) =>
                      cell === "" || cell === null || cell === undefined
                  )
                ) {
                  continue;
                }

                const row: any = {};

                headers.forEach((header, idx) => {
                  if (
                    header &&
                    rowData[idx] !== undefined &&
                    rowData[idx] !== null &&
                    rowData[idx] !== ""
                  ) {
                    const cleanHeader = header
                      .toString()
                      .trim()
                      .toLowerCase();
                    const mappedHeader =
                      headerMap[cleanHeader] || cleanHeader;

                    let value = rowData[idx];
                    if (typeof value === "object" && value instanceof Date) {
                      value = value.toISOString().split("T")[0];
                    } else if (typeof value === "number") {
                      value = value.toString();
                    } else if (typeof value === "string") {
                      value = value.trim();
                    }

                    row[mappedHeader] = value;
                  }
                });

                if (row.description || row.make || row.status || row.vendor) {
                  rows.push(row);
                }
              }

              resolve(rows);
            } catch (err) {
              reject(err);
            }
          };

          reader.onerror = (error) => {
            console.error("FileReader error:", error);
            reject(new Error("Failed to read file"));
          };

          reader.onabort = () => {
            reject(new Error("File reading was aborted"));
          };

          try {
            reader.readAsArrayBuffer(file);
          } catch (error) {
            reject(new Error(`Cannot read file: ${error}`));
          }
        });
      };

      const showImportPreview = (data: any[], errors: ValidationError[], container: HTMLElement): void => {
        const errorRows = new Set(errors.filter(e => e.row).map(e => e.row));

        const previewHTML = `
          <div style="padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <h4 style="color: #28a745; margin-bottom: 15px;">📋 Data Preview</h4>
            <p><strong>Found ${data.length} records:</strong></p>
            <div class="preview-table-container">
              <table class="preview-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>FCM Qty</th>
                    <th>Engg Qty</th>
                    <th>Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  ${data
                    .slice(0, 20)
                    .map((row, index) => {
                      const rowNum = index + 1;
                      const hasError = errorRows.has(rowNum);
                      return `
                        <tr class="${hasError ? 'row-invalid' : 'row-valid'}">
                          <td style="text-align: center;">${rowNum}</td>
                          <td>${row.description || "N/A"}</td>
                          <td>${row.status || "N/A"}</td>
                          <td>${row.make || "N/A"}</td>
                          <td>${row.model || "N/A"}</td>
                          <td style="text-align: right;">${row.fcmquantity || "N/A"}</td>
                          <td style="text-align: right;">${row.enggquantity || "N/A"}</td>
                          <td>${row.remarks || "N/A"}</td>
                        </tr>
                      `;
                    })
                    .join("")}
                </tbody>
              </table>
            </div>
            ${data.length > 20 ? `<p style="margin-top: 10px; font-style: italic; color: #6c757d;">... and ${data.length - 20} more records</p>` : ""}
            <div style="margin-top: 15px; padding: 12px; background: #e7f3ff; border-radius: 5px;">
              <p style="margin: 0; color: #0056b3; font-size: 14px;">
                <strong>⚠️ Important:</strong> This will replace existing procurement data for this project.
              </p>
            </div>
          </div>
        `;

        const importPreview = container.querySelector('#importPreview') as HTMLElement;
        if (importPreview) {
          importPreview.innerHTML = previewHTML;
        }
      };

      const addImportButtonToEditMode = (
        projectId: number,
        record: any
      ): void => {
        const existingImportBtns = document.querySelectorAll(
          ".import-excel-edit-btn"
        );
        existingImportBtns.forEach((btn) => btn.remove());

        const importBtn = document.createElement("button");
        importBtn.type = "button";
        importBtn.className = "btn-primary import-excel-edit-btn";
        importBtn.textContent = "📥 UPLOAD";
        importBtn.style.marginBottom = "15px";
        importBtn.style.marginRight = "10px";
        importBtn.style.display = "inline-block";

        importBtn.addEventListener("click", () =>
          importExcelForEdit(projectId, record)
        );

        const procurementContainerTable = document.getElementById(
          "procurementContainerTable"
        ) as HTMLElement;

        procurementContainerTable.parentNode?.insertBefore(
          importBtn,
          procurementContainerTable
        );
      };

      const importExcelForEdit = (projectId: number, record: any): void => {
        const modalHTML = `
          <div class="import-modal">
            <div class="import-modal-content">
              <div class="import-modal-header">
                <h3>Import Procurement Data from Excel</h3>
                <button class="close-modal">&times;</button>
              </div>

              <div class="import-section">
                <h4>Step 1: Download Template</h4>
                <p>Download the template file with the correct structure for import.</p>
                <button class="btn-primary" id="downloadEditTemplate">⬇️ Download Template</button>
              </div>

              <div class="import-section">
                <h4>Step 2: Upload Excel File</h4>
                <div class="file-upload-area" id="fileUploadArea">
                  <div class="upload-icon">📁</div>
                  <p><strong>Click to upload or drag & drop Excel file</strong></p>
                  <p><small>Supported format: .xlsx, .xls (Max: 10MB)</small></p>
                  <input type="file" id="excelFile" class="file-input" accept=".xlsx,.xls">
                  <div class="file-info" id="fileInfo"></div>
                </div>
              </div>

              <div class="import-section" id="previewSection" style="display:none;">
                <h4>Step 3: Preview & Validate</h4>
                <div class="import-preview" id="importPreview"></div>
                <div class="import-actions">
                  <button class="btn-secondary" id="cancelImport">Cancel</button>
                  <button class="btn-primary" id="confirmImport" disabled>Import Data</button>
                </div>
                <div class="import-status" id="importStatus"></div>
              </div>
            </div>
          </div>
        `;

        document.body.insertAdjacentHTML("beforeend", modalHTML);
        const modal = document.querySelector(".import-modal") as HTMLElement;

        const fileUploadArea = document.getElementById("fileUploadArea") as HTMLElement;
        const excelFileInput = document.getElementById("excelFile") as HTMLInputElement;
        const fileInfo = document.getElementById("fileInfo") as HTMLElement;
        const previewSection = document.getElementById("previewSection") as HTMLElement;
        const confirmImport = document.getElementById("confirmImport") as HTMLButtonElement;
        const cancelImport = document.getElementById("cancelImport") as HTMLButtonElement;
        const closeModal = document.querySelector(".close-modal") as HTMLButtonElement;
        const importStatus = document.getElementById("importStatus") as HTMLElement;
        const downloadTemplateBtn = document.getElementById("downloadEditTemplate") as HTMLButtonElement;

        let importData: any[] = [];
        let importHeaders: string[] = [];

        fileUploadArea.addEventListener("click", () => excelFileInput.click());

        fileUploadArea.addEventListener("dragover", (e) => {
          e.preventDefault();
          fileUploadArea.classList.add("dragover");
        });

        fileUploadArea.addEventListener("dragleave", () => {
          fileUploadArea.classList.remove("dragover");
        });

        fileUploadArea.addEventListener("drop", (e) => {
          e.preventDefault();
          fileUploadArea.classList.remove("dragover");
          const files = e.dataTransfer?.files;
          if (files && files[0]) {
            excelFileInput.files = files;
            handleFileSelection(files[0]);
          }
        });

        excelFileInput.addEventListener("change", (e) => {
          const files = (e.target as HTMLInputElement).files;
          if (files && files[0]) handleFileSelection(files[0]);
        });

        const handleFileSelection = async (file: File) => {
          const errorList = modal.querySelector('.error-list');
          if (errorList) errorList.remove();
          importStatus.className = 'import-status';
          importStatus.style.display = 'none';
          confirmImport.disabled = true;

          if (!file.name.toLowerCase().match(/\.(xlsx|xls)$/)) {
            fileInfo.textContent = 'Please select an Excel file (.xlsx or .xls)';
            fileInfo.className = 'file-info error';
            return;
          }

          if (file.size > 10 * 1024 * 1024) {
            fileInfo.textContent = 'File size too large. Please use files under 10MB.';
            fileInfo.className = 'file-info error';
            return;
          }

          fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`;
          fileInfo.className = 'file-info';
          fileInfo.style.color = '#0078d4';

          try {
            const parsedData = await parseExcelFile(file);

            if (!parsedData || parsedData.length === 0) {
              fileInfo.textContent = 'No valid data found in the Excel file.';
              fileInfo.className = 'file-info error';
              return;
            }

            if (parsedData.length > 0) {
              importHeaders = Object.keys(parsedData[0]);
            }

            importData = parsedData;

            const validationErrors = collectValidationErrors(parsedData, importHeaders);

            showImportPreview(parsedData, validationErrors, modal);

            if (validationErrors.length > 0) {
              showValidationErrors(validationErrors, modal);

              const hasCriticalErrors = validationErrors.some(e => e.type === 'error');
              if (hasCriticalErrors) {
                confirmImport.disabled = true;
                importStatus.className = 'import-status error';
                importStatus.style.display = 'block';
                importStatus.textContent = '❌ Critical errors found. Please fix the issues and try again.';
                return;
              }
            }

            confirmImport.disabled = false;
            previewSection.style.display = "block";

            importStatus.className = 'import-status success';
            importStatus.style.display = 'block';
            importStatus.textContent = `✅ Found ${parsedData.length} valid row(s) to import.`;

          } catch (error) {
            console.error("Excel parsing error:", error);
            fileInfo.textContent = `Error reading Excel file: ${error}`;
            fileInfo.className = 'file-info error';
          }
        };

        downloadTemplateBtn.addEventListener("click", () => {
          const project = projects.find((p) => p.Id === projectId);

          const currentProcurementItems =
            parseProcurementForecast(
              record[fieldMappings.ProcurementForecast]
            ) || [];

          const headers = [
            "Description",
            "Status",
            "Make",
            "Model",
            "FCMQuantity",
            "EnggQuantity",
            "Remarks",
            "RfqPlan",
            "RfqActual",
            "RfqForecast",
            "OfferPlan",
            "OfferActual",
            "OfferForecast",
            "TechPlan",
            "TechActual",
            "TechForecast",
            "OrderPlan",
            "OrderActual",
            "OrderForecast",
            "PRPlan",
            "PRActual",
            "PRForecast",
            "POPlan",
            "POActual",
            "POForecast",
            "DocPlan",
            "DocActual",
            "DocForecast",
            "MfgPlan",
            "MfgActual",
            "MfgForecast",
            "InspPlan",
            "InspActual",
            "InspForecast",
            "DispPlan",
            "DispActual",
            "DispForecast",
            "DeliveryPlan",
            "DeliveryActual",
            "DeliveryForecast",
          ];

          const wsData: string[][] = [headers];

          if (currentProcurementItems.length > 0) {
            currentProcurementItems.forEach((item) => {
              const row = [
                item.Description || "",
                item.Status || "RFQ Pending",
                item.Make || "",
                item.Model || "",
                item.FCMQuantity?.toString() || "",
                item.EnggQuantity?.toString() || "",
                item.Remarks || "",
                formatDateForExcel(item.RfqPlan) || "",
                formatDateForExcel(item.RfqActual) || "",
                formatDateForExcel(item.RfqForecast) || "",
                formatDateForExcel(item.OfferPlan) || "",
                formatDateForExcel(item.OfferActual) || "",
                formatDateForExcel(item.OfferForecast) || "",
                formatDateForExcel(item.TechPlan) || "",
                formatDateForExcel(item.TechActual) || "",
                formatDateForExcel(item.TechForecast) || "",
                formatDateForExcel(item.OrderPlan) || "",
                formatDateForExcel(item.OrderActual) || "",
                formatDateForExcel(item.OrderForecast) || "",
                formatDateForExcel(item.PRPlan) || "",
                formatDateForExcel(item.PRActual) || "",
                formatDateForExcel(item.PRForecast) || "",
                formatDateForExcel(item.POPlan) || "",
                formatDateForExcel(item.POActual) || "",
                formatDateForExcel(item.POForecast) || "",
                formatDateForExcel(item.DocPlan) || "",
                formatDateForExcel(item.DocActual) || "",
                formatDateForExcel(item.DocForecast) || "",
                formatDateForExcel(item.MfgPlan) || "",
                formatDateForExcel(item.MfgActual) || "",
                formatDateForExcel(item.MfgForecast) || "",
                formatDateForExcel(item.InspPlan) || "",
                formatDateForExcel(item.InspActual) || "",
                formatDateForExcel(item.InspForecast) || "",
                formatDateForExcel(item.DispPlan) || "",
                formatDateForExcel(item.DispActual) || "",
                formatDateForExcel(item.DispForecast) || "",
                formatDateForExcel(item.DeliveryPlan) || "",
                formatDateForExcel(item.DeliveryActual) || "",
                formatDateForExcel(item.DeliveryForecast) || "",
              ];
              wsData.push(row);
            });
          } else {
            const emptyRow = Array(headers.length).fill("");
            emptyRow[1] = "RFQ Pending";
            wsData.push(emptyRow);
          }

          const ws = XLSX.utils.aoa_to_sheet(wsData);

          const headerStyle = {
            font: { bold: true, color: { rgb: "FFFFFF" }, sz: 11 },
            fill: { patternType: "solid", fgColor: { rgb: "2F5597" } },
            alignment: {
              horizontal: "center",
              vertical: "center",
              wrapText: true,
            },
            border: {
              top: { style: "medium", color: { rgb: "000000" } },
              bottom: { style: "medium", color: { rgb: "000000" } },
              left: { style: "medium", color: { rgb: "000000" } },
              right: { style: "medium", color: { rgb: "000000" } },
            },
          };

          for (let col = 0; col < headers.length; col++) {
            const address = XLSX.utils.encode_cell({ r: 0, c: col });
            ws[address].s = headerStyle;
          }

          ws["!cols"] = [
            { wch: 30 }, { wch: 15 }, { wch: 15 }, { wch: 15 },
            { wch: 12 }, { wch: 12 }, { wch: 20 },
            ...Array(33).fill({ wch: 10 })
          ];

          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "Procurement Data");

          const timestamp = new Date().toISOString().split("T")[0];
          const fileName = `Procurement_Template_${project?.Title?.replace(/[^a-zA-Z0-9]/g, "_") || "Project"}_${timestamp}.xlsx`;

          XLSX.writeFile(wb, fileName);

          toast(
            `Template downloaded with ${currentProcurementItems.length} existing items`,
            "success"
          );
        });

        const performImport = async () => {
          confirmImport.disabled = true;
          confirmImport.textContent = "Importing...";
          importStatus.className = "import-status info";
          importStatus.style.display = "block";
          importStatus.textContent = "⏳ Processing procurement data...";

          try {
            const procurementItems: ProcurementForecastItem[] = importData.map(
              (row) => {
                const item: ProcurementForecastItem = {
                  Description: row.description || "",
                  FCMQuantity: row.fcmquantity
                    ? parseFloat(row.fcmquantity)
                    : null,
                  EnggQuantity: row.enggquantity
                    ? parseFloat(row.enggquantity)
                    : null,
                  Status: row.status || "RFQ Pending",
                  Make: row.make || row.manufacturer || "",
                  Model: row.model || row.partnumber || "",
                  Remarks: row.remarks || "",
                  RfqPlan: row.rfqplan || "",
                  RfqActual: row.rfqactual || "",
                  RfqForecast: row.rfqforecast || "",
                  OfferPlan: row.offerplan || "",
                  OfferActual: row.offeractual || "",
                  OfferForecast: row.offerforecast || "",
                  TechPlan: row.techplan || "",
                  TechActual: row.techactual || "",
                  TechForecast: row.techforecast || "",
                  OrderPlan: row.orderplan || "",
                  OrderActual: row.orderactual || "",
                  OrderForecast: row.orderforecast || "",
                  PRPlan: row.prplan || "",
                  PRActual: row.practual || "",
                  PRForecast: row.prforecast || "",
                  POPlan: row.poplan || "",
                  POActual: row.poactual || "",
                  POForecast: row.poforecast || "",
                  DocPlan: row.docplan || "",
                  DocActual: row.docactual || "",
                  DocForecast: row.docforecast || "",
                  MfgPlan: row.mfgplan || "",
                  MfgActual: row.mfgactual || "",
                  MfgForecast: row.mfgforecast || "",
                  InspPlan: row.inspplan || "",
                  InspActual: row.inspactual || "",
                  InspForecast: row.inspforecast || "",
                  DispPlan: row.dispplan || "",
                  DispActual: row.dispactual || "",
                  DispForecast: row.dispforecast || "",
                  DeliveryPlan: row.deliveryplan || "",
                  DeliveryActual: row.deliveryactual || "",
                  DeliveryForecast: row.deliveryforecast || "",
                };

                item.Status = getStatusFromActualDates(item);

                return item;
              }
            );

            await submitImportedData(procurementItems, projectId);

            importStatus.className = "import-status success";
            importStatus.textContent = `✅ Successfully imported ${procurementItems.length} procurement items!`;

            setTimeout(() => {
              modal.remove();
              toast(`Successfully imported ${procurementItems.length} procurement items!`, "success");
              resetForm();
              fetchData();
            }, 1000);

          } catch (error) {
            console.error("Import error:", error);
            importStatus.className = "import-status error";
            importStatus.innerHTML = `<strong>❌ Import Failed:</strong> ${error}`;
            toast("Failed to import and save data", "error");
            confirmImport.disabled = false;
            confirmImport.textContent = "Import Data";
          }
        };

        const submitImportedData = async (
          procurementItems: ProcurementForecastItem[],
          projId: number
        ): Promise<void> => {
          try {
            const digest = await getRequestDigest();

            if (!projId) {
              throw new Error("No project selected");
            }

            const existingRecord = procurementData.find(
              (item) =>
                item[`${fieldMappings.Project}Id`] === projId ||
                (item[fieldMappings.Project] &&
                  item[fieldMappings.Project].Id === projId)
            );

            const itemData: any = {
              __metadata: { type: listEntityTypeName },
              [`${fieldMappings.Project}Id`]: projId,
              [fieldMappings.ProcurementForecast]:
                JSON.stringify(procurementItems),
            };

            const headers: HeadersInit = {
              Accept: "application/json;odata=verbose",
              "Content-Type": "application/json;odata=verbose",
              "X-RequestDigest": digest,
            };

            let url = apiBase;

            if (editingId || existingRecord) {
              const recordId = editingId || existingRecord.Id;
              url = `${apiBase}(${recordId})`;
              headers["IF-MATCH"] = "*";
              headers["X-HTTP-Method"] = "MERGE";
            }

            const response = await fetch(url, {
              method: "POST",
              headers: headers,
              body: JSON.stringify(itemData),
            });

            if (!response.ok) {
              const errorText = await response.text();
              throw new Error(
                `HTTP error! status: ${response.status}, details: ${errorText}`
              );
            }

          } catch (error) {
            console.error("Error submitting imported data:", error);
            throw error;
          }
        };

        const closeModalHandler = () => {
          const errorList = modal.querySelector('.error-list');
          if (errorList) errorList.remove();
          modal.remove();
        };

        closeModal.addEventListener("click", closeModalHandler);
        cancelImport.addEventListener("click", closeModalHandler);
        modal.addEventListener("click", (e) => {
          if (e.target === modal) closeModalHandler();
        });

        confirmImport.addEventListener("click", performImport);
      };

      const onProjectChange = (
        selectedId: number,
        isEditing: boolean = false
      ): void => {
        const project = projects.find((p) => p.Id === selectedId);
        if (!project) {
          renderProjectDetails(null);
          return;
        }

        renderProjectDetails(project);
        procurementContainerTable.style.display = "block";

        if (!isEditing) {
          const existingRecord = procurementData.find(
            (item) =>
              item[`${fieldMappings.Project}Id`] === selectedId ||
              (item[fieldMappings.Project] &&
                item[fieldMappings.Project].Id === selectedId)
          );

          if (existingRecord) {
            existingDataAlert.style.display = "block";
            setEditTitle(project);
            editingId = existingRecord.Id;

            const procurementItems =
              parseProcurementForecast(
                existingRecord[fieldMappings.ProcurementForecast]
              ) || [];
            procurementContainer.innerHTML = "";

            procurementItems.forEach((item) => {
              procurementContainer.appendChild(createProcurementRow(item));
            });
          } else {
            existingDataAlert.style.display = "none";
            formTitle.textContent = "Add Procurement";
            formSection.classList.remove("edit-mode");
            editingId = null;

            procurementContainer.innerHTML = "";
            procurementContainer.appendChild(createProcurementRow());
          }
        }
      };

      const createProcurementRow = (
        data?: ProcurementForecastItem
      ): HTMLTableRowElement => {
        const row = document.createElement("tr");

        const getFieldValue = (
          field: keyof ProcurementForecastItem
        ): string => {
          if (!data) return "";
          const value = data[field];
          if (value === null || value === undefined) return "";

          if (
            field.includes("Plan") ||
            field.includes("Actual") ||
            field.includes("Forecast")
          ) {
            return formatDateForInput(String(value));
          }

          if (
            (field === "FCMQuantity" || field === "EnggQuantity") &&
            typeof value === "number"
          ) {
            return value.toString();
          }

          return String(value);
        };

        // Initial overdue class for an Actual input (Plan crossed & Actual empty)
        const actualCls = (
          planField: keyof ProcurementForecastItem,
          actualField: keyof ProcurementForecastItem
        ): string =>
          isActualOverdue(getFieldValue(planField), getFieldValue(actualField))
            ? " actual-overdue"
            : "";

        const initialStatus = getStatusFromActualDates(data);
        const poActualValue = getFieldValue("POActual");
        const isPOActualFilled = isFilled(poActualValue);

        row.innerHTML = `
          <td class="sticky-col col-1"><input type="text" name="description" class="form-control description-input" placeholder="Description" value="${escapeHtml(
            getFieldValue("Description")
          )}" required></td>
          <td class="sticky-col col-2"><input type="number" name="fcm_qty" class="form-control number-input" placeholder="FCM Qty" value="${getFieldValue(
            "FCMQuantity"
          )}" step="0.01" min="0"></td>
          <td class="sticky-col col-3">
            <div class="engg-qty-wrapper">
              <input type="number" name="engg_qty" class="form-control number-input engg-qty-input" placeholder="Engg Qty" value="${getFieldValue(
                "EnggQuantity"
              )}" step="0.01" min="0" ${isPOActualFilled ? 'disabled' : ''}>
              ${isPOActualFilled ? '<span class="lock-icon">🔒</span>' : ''}
            </div>
            ${isPOActualFilled ? '<small style="color:#6c757d; font-size:9px; display:block;">Locked </small>' : ''}
          </td>
          <td class="sticky-col col-4">
            <span class="status-text-display ${initialStatus === 'Delivered' ? 'delivered' : ''}" name="status_display">${initialStatus}</span>

          </td>
          <td class="sticky-col col-5"><input type="text" name="make" class="form-control" placeholder="Make" value="${escapeHtml(
            getFieldValue("Make")
          )}"></td>
          <td class="sticky-col col-6"><input type="text" name="model" class="form-control" placeholder="Model" value="${escapeHtml(
            getFieldValue("Model")
          )}"></td>
          <!-- RFQ / Engg -->
          <td><input type="date" name="rfq_plan" class="form-control" value="${getFieldValue(
            "RfqPlan"
          )}"></td>
          <td><input type="date" name="rfq_actual" class="form-control${actualCls("RfqPlan", "RfqActual")}" value="${getFieldValue(
            "RfqActual"
          )}"></td>
          <td><input type="date" name="rfq_forecast" class="form-control" value="${getFieldValue(
            "RfqForecast"
          )}"></td>

          <!-- Vendor Offer / SCM -->
          <td><input type="date" name="offer_plan" class="form-control" value="${getFieldValue(
            "OfferPlan"
          )}"></td>
          <td><input type="date" name="offer_actual" class="form-control${actualCls("OfferPlan", "OfferActual")}" value="${getFieldValue(
            "OfferActual"
          )}"></td>
          <td><input type="date" name="offer_forecast" class="form-control" value="${getFieldValue(
            "OfferForecast"
          )}"></td>

          <!-- Technical Clearance / ENGG -->
          <td><input type="date" name="tech_plan" class="form-control" value="${getFieldValue(
            "TechPlan"
          )}"></td>
          <td><input type="date" name="tech_actual" class="form-control${actualCls("TechPlan", "TechActual")}" value="${getFieldValue(
            "TechActual"
          )}"></td>
          <td><input type="date" name="tech_forecast" class="form-control" value="${getFieldValue(
            "TechForecast"
          )}"></td>

          <!-- Order Finalization / SCM -->
          <td><input type="date" name="order_plan" class="form-control" value="${getFieldValue(
            "OrderPlan"
          )}"></td>
          <td><input type="date" name="order_actual" class="form-control${actualCls("OrderPlan", "OrderActual")}" value="${getFieldValue(
            "OrderActual"
          )}"></td>
          <td><input type="date" name="order_forecast" class="form-control" value="${getFieldValue(
            "OrderForecast"
          )}"></td>

          <!-- PR / PM -->
          <td><input type="date" name="pr_plan" class="form-control" value="${getFieldValue(
            "PRPlan"
          )}"></td>
          <td><input type="date" name="pr_actual" class="form-control${actualCls("PRPlan", "PRActual")}" value="${getFieldValue(
            "PRActual"
          )}"></td>
          <td><input type="date" name="pr_forecast" class="form-control" value="${getFieldValue(
            "PRForecast"
          )}"></td>

          <!-- Purchase Order / SCM -->
          <td><input type="date" name="po_plan" class="form-control" value="${getFieldValue(
            "POPlan"
          )}"></td>
          <td><input type="date" name="po_actual" class="form-control${actualCls("POPlan", "POActual")}" value="${getFieldValue(
            "POActual"
          )}"></td>
          <td><input type="date" name="po_forecast" class="form-control" value="${getFieldValue(
            "POForecast"
          )}"></td>

          <!-- Document Approval / ENGG -->
          <td><input type="date" name="doc_plan" class="form-control" value="${getFieldValue(
            "DocPlan"
          )}"></td>
          <td><input type="date" name="doc_actual" class="form-control${actualCls("DocPlan", "DocActual")}" value="${getFieldValue(
            "DocActual"
          )}"></td>
          <td><input type="date" name="doc_forecast" class="form-control" value="${getFieldValue(
            "DocForecast"
          )}"></td>

          <!-- Manufacturing Clearance / ENGG -->
          <td><input type="date" name="mfg_plan" class="form-control" value="${getFieldValue(
            "MfgPlan"
          )}"></td>
          <td><input type="date" name="mfg_actual" class="form-control${actualCls("MfgPlan", "MfgActual")}" value="${getFieldValue(
            "MfgActual"
          )}"></td>
          <td><input type="date" name="mfg_forecast" class="form-control" value="${getFieldValue(
            "MfgForecast"
          )}"></td>

          <!-- Inspection -->
          <td><input type="date" name="insp_plan" class="form-control" value="${getFieldValue(
            "InspPlan"
          )}"></td>
          <td><input type="date" name="insp_actual" class="form-control${actualCls("InspPlan", "InspActual")}" value="${getFieldValue(
            "InspActual"
          )}"></td>
          <td><input type="date" name="insp_forecast" class="form-control" value="${getFieldValue(
            "InspForecast"
          )}"></td>

          <!-- Material Dispatch -->
          <td><input type="date" name="disp_plan" class="form-control" value="${getFieldValue(
            "DispPlan"
          )}"></td>
          <td><input type="date" name="disp_actual" class="form-control${actualCls("DispPlan", "DispActual")}" value="${getFieldValue(
            "DispActual"
          )}"></td>
          <td><input type="date" name="disp_forecast" class="form-control" value="${getFieldValue(
            "DispForecast"
          )}"></td>

          <!-- Delivery at Site -->
          <td><input type="date" name="delivery_plan" class="form-control" value="${getFieldValue(
            "DeliveryPlan"
          )}"></td>
          <td><input type="date" name="delivery_actual" class="form-control${actualCls("DeliveryPlan", "DeliveryActual")}" value="${getFieldValue(
            "DeliveryActual"
          )}"></td>
          <td><input type="date" name="delivery_forecast" class="form-control" value="${getFieldValue(
            "DeliveryForecast"
          )}"></td>

          <td><input type="text" name="remarks" class="form-control" placeholder="Remarks" value="${escapeHtml(
            getFieldValue("Remarks")
          )}"></td>
          <td><button type="button" class="remove-row btn-danger">🗑️</button></td>
        `;

        wireStatusAutoLink(row);

        return row;
      };
      form.addEventListener("submit", async (e) => {
        e.preventDefault();

        if (!projectSelect.value) {
          toast("Please select a project", "error");
          return;
        }

        const rows = Array.from(procurementContainer.querySelectorAll("tr"));
        if (rows.length === 0) {
          toast("Please add at least one procurement item", "error");
          return;
        }

        try {
          const digest = await getRequestDigest();
          const projectId = parseInt(projectSelect.value);
          const submittingProject = projects.find((p) => p.Id === projectId);

          // ✅ Role access on save (same as SEIBIES)
          if (editingId) {
            if (!canEditProject(submittingProject)) {
              toast("❌ You don't have permission to edit this procurement plan", "error");
              return;
            }
          } else {
            if (!canCreateRecord()) {
              toast("❌ You don't have permission to create procurement plans", "error");
              return;
            }
          }

          const procurementItems: ProcurementForecastItem[] = rows.map(
            (row) => {
              const inputs = row.querySelectorAll("input, select");
              const item: ProcurementForecastItem = {
                Description: "",
                FCMQuantity: null,
                EnggQuantity: null,
                Status: "",
                Make: "",
                Model: "",
                Remarks: "",
                RfqPlan: "",
                RfqActual: "",
                RfqForecast: "",
                OfferPlan: "",
                OfferActual: "",
                OfferForecast: "",
                TechPlan: "",
                TechActual: "",
                TechForecast: "",
                OrderPlan: "",
                OrderActual: "",
                OrderForecast: "",
                PRPlan: "",
                PRActual: "",
                PRForecast: "",
                POPlan: "",
                POActual: "",
                POForecast: "",
                DocPlan: "",
                DocActual: "",
                DocForecast: "",
                MfgPlan: "",
                MfgActual: "",
                MfgForecast: "",
                InspPlan: "",
                InspActual: "",
                InspForecast: "",
                DispPlan: "",
                DispActual: "",
                DispForecast: "",
                DeliveryPlan: "",
                DeliveryActual: "",
                DeliveryForecast: "",
              };

              inputs.forEach((input) => {
                const element = input as HTMLInputElement | HTMLSelectElement;
                const name = element.name;
                const value = element.value;

                if (!name) return;

                switch (name) {
                  case "description": item.Description = value; break;
                  case "fcm_qty": item.FCMQuantity = value ? parseFloat(value) : null; break;
                  case "engg_qty": {
                    const enggInput = input as HTMLInputElement;
                    if (!enggInput.disabled) {
                      item.EnggQuantity = value ? parseFloat(value) : null;
                    }
                    break;
                  }
                  case "make": item.Make = value; break;
                  case "model": item.Model = value; break;
                  case "remarks": item.Remarks = value; break;
                  case "rfq_plan": item.RfqPlan = value; break;
                  case "rfq_actual": item.RfqActual = value; break;
                  case "rfq_forecast": item.RfqForecast = value; break;
                  case "offer_plan": item.OfferPlan = value; break;
                  case "offer_actual": item.OfferActual = value; break;
                  case "offer_forecast": item.OfferForecast = value; break;
                  case "tech_plan": item.TechPlan = value; break;
                  case "tech_actual": item.TechActual = value; break;
                  case "tech_forecast": item.TechForecast = value; break;
                  case "order_plan": item.OrderPlan = value; break;
                  case "order_actual": item.OrderActual = value; break;
                  case "order_forecast": item.OrderForecast = value; break;
                  case "pr_plan": item.PRPlan = value; break;
                  case "pr_actual": item.PRActual = value; break;
                  case "pr_forecast": item.PRForecast = value; break;
                  case "po_plan": item.POPlan = value; break;
                  case "po_actual": item.POActual = value; break;
                  case "po_forecast": item.POForecast = value; break;
                  case "doc_plan": item.DocPlan = value; break;
                  case "doc_actual": item.DocActual = value; break;
                  case "doc_forecast": item.DocForecast = value; break;
                  case "mfg_plan": item.MfgPlan = value; break;
                  case "mfg_actual": item.MfgActual = value; break;
                  case "mfg_forecast": item.MfgForecast = value; break;
                  case "insp_plan": item.InspPlan = value; break;
                  case "insp_actual": item.InspActual = value; break;
                  case "insp_forecast": item.InspForecast = value; break;
                  case "disp_plan": item.DispPlan = value; break;
                  case "disp_actual": item.DispActual = value; break;
                  case "disp_forecast": item.DispForecast = value; break;
                  case "delivery_plan": item.DeliveryPlan = value; break;
                  case "delivery_actual": item.DeliveryActual = value; break;
                  case "delivery_forecast": item.DeliveryForecast = value; break;
                }
              });

              item.Status = getStatusFromActualDates(item);

              return item;
            }
          );

          const existingRecord = procurementData.find(
            (item) =>
              item[`${fieldMappings.Project}Id`] === projectId ||
              (item[fieldMappings.Project] &&
                item[fieldMappings.Project].Id === projectId)
          );

          const itemData: any = {
            __metadata: { type: listEntityTypeName },
            [`${fieldMappings.Project}Id`]: projectId,
            [fieldMappings.ProcurementForecast]:
              JSON.stringify(procurementItems),
          };

          const headers: HeadersInit = {
            Accept: "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": digest,
          };

          let url = apiBase;

          if (editingId || existingRecord) {
            const recordId = editingId || existingRecord.Id;
            url = `${apiBase}(${recordId})`;
            headers["IF-MATCH"] = "*";
            headers["X-HTTP-Method"] = "MERGE";
          }

          const response = await fetch(url, {
            method: "POST",
            headers: headers,
            body: JSON.stringify(itemData),
          });

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(
              `HTTP error! status: ${response.status}, details: ${errorText}`
            );
          }

          toast(
            `Procurement data ${editingId || existingRecord ? 'updated' : 'added'} successfully! ${procurementItems.length} item(s) saved`,
            "success"
          );

          resetForm();
          await fetchData();
        } catch (error) {
          console.error("Error saving procurement:", error);
          toast("Failed to save procurement data", "error");
        }
      });

      const resetForm = (): void => {
        resetDescriptionFilter();

        editingId = null;
        form.reset();
        formSection.style.display = "none";
        tableSection.style.display = "block";
        procurementContainer.innerHTML = "";
        procurementContainerTable.style.display = "none";
        renderProjectDetails(null);
        existingDataAlert.style.display = "none";
        formTitle.textContent = "Add Procurement";
        projectSelect.disabled = false;
        projectSelect.value = "";

        formSection.classList.remove("view-mode");
        formSection.classList.remove("edit-mode");

        const actionBtns = document.querySelectorAll(
          ".export-project-excel-btn, .export-top-btn, .import-excel-edit-btn"
        );
        actionBtns.forEach((btn) => btn.remove());

        const addMoreBtn = document.querySelector(
          ".add-procurement-row"
        ) as HTMLButtonElement;
        if (addMoreBtn) addMoreBtn.style.display = "block";

        const submitBtn = form.querySelector(
          'button[type="submit"]'
        ) as HTMLButtonElement;
        if (submitBtn) {
          submitBtn.style.display = "inline-flex";
        }

        updateMainTableStickyOffset();
      };

      const exportProjectToExcel = async (
        projectId: number,
        record: any
      ): Promise<void> => {
        // ✅ Role guard (same as SEIBIES): export needs at least read access
        if (!canRead()) {
          toast("❌ You don't have permission to export data", "error");
          return;
        }

        showExportProgress("Preparing project data for export...");

        try {
          const currentRecord = procurementData.find((d) => d.Id === record.Id);
          if (!currentRecord) {
            hideExportProgress();
            toast("Record not found", "error");
            return;
          }

          const project = projects.find((p) => p.Id === projectId);
          if (!project) {
            hideExportProgress();
            toast("Project not found", "error");
            return;
          }

          const procurementItems =
            parseProcurementForecast(
              currentRecord[fieldMappings.ProcurementForecast]
            ) || [];

          if (procurementItems.length === 0) {
            hideExportProgress();
            toast("No procurement data to export for this project", "warning");
            return;
          }

          const wb = XLSX.utils.book_new();
          const managerName = getProjectManagerDisplayName(project.ProjectManager);
          const groupHeadName = getGroupHeadDisplayName(project.GroupHead1);
          // Sheet 1: Project Summary
          const projectSummaryData = [
            ["PROJECT SUMMARY", ""],
            ["", ""],
            ["Project Information", ""],
            ["Project Name", project.Title || ""],
            ["Customer", project.CustomerName || ""],
            ["Project Manager", managerName],
            ["Group Head", groupHeadName],
            ["Project Reference", project.ProjectReference || ""],
            ["Profit Centre", project.PC || ""],
            ["", ""],
            ["Procurement Summary", ""],
            ["Total Procurement Items", procurementItems.length],
            ["", ""],
            ["Status-wise Breakdown", ""],
          ];

          const statusCounts = calculateProjectStatusCounts(procurementItems);
          statusOptions.forEach((status) => {
            projectSummaryData.push([status, statusCounts[status] || 0]);
          });
          projectSummaryData.push(["", ""]);
          projectSummaryData.push(["TOTAL ITEMS", procurementItems.length]);

          const projectSummaryWs = XLSX.utils.aoa_to_sheet(projectSummaryData);
          XLSX.utils.book_append_sheet(wb, projectSummaryWs, "Cover Sheet");

          // Sheet 2: Procurement Details
          const headerRow1 = [
            "Sr No", "Description Of Item", "Quantity", "Unit", "Make", "Model",
            "RFQ / Engg", "", "",
            "Offer / SCM", "", "",
            "Technical Clearance / ENGG", "", "",
            "PR / PM", "", "",
            "Purchase Order / SCM", "", "",
            "Manufacturing Clearance / ENGG", "", "",
            "Status", "Remarks", "WEIGHTAGE"
          ];

          const headerRow2 = [
            "Sr No", "Description Of Item", "Quantity", "Unit", "Make", "Model",
            "Plan", "Actual", "Forecast",
            "Plan", "Actual", "Forecast",
            "Plan", "Actual", "Forecast",
            "Plan", "Actual", "Forecast",
            "Plan", "Actual", "Forecast",
            "Plan", "Actual", "Forecast",
            "Status", "Remarks", "WEIGHTAGE"
          ];

          const procurementWs = XLSX.utils.aoa_to_sheet([headerRow1, headerRow2]);

          procurementItems.forEach((procItem, index) => {
            const row = [
              index + 1,
              procItem.Description || "",
              procItem.FCMQuantity || procItem.EnggQuantity || "",
              "",
              procItem.Make || "",
              procItem.Model || "",
              formatDateForExcel(procItem.RfqPlan) || "",
              formatDateForExcel(procItem.RfqActual) || "",
              formatDateForExcel(procItem.RfqForecast) || "",
              formatDateForExcel(procItem.OfferPlan) || "",
              formatDateForExcel(procItem.OfferActual) || "",
              formatDateForExcel(procItem.OfferForecast) || "",
              formatDateForExcel(procItem.TechPlan) || "",
              formatDateForExcel(procItem.TechActual) || "",
              formatDateForExcel(procItem.TechForecast) || "",
              formatDateForExcel(procItem.PRPlan) || "",
              formatDateForExcel(procItem.PRActual) || "",
              formatDateForExcel(procItem.PRForecast) || "",
              formatDateForExcel(procItem.POPlan) || "",
              formatDateForExcel(procItem.POActual) || "",
              formatDateForExcel(procItem.POForecast) || "",
              formatDateForExcel(procItem.MfgPlan) || "",
              formatDateForExcel(procItem.MfgActual) || "",
              formatDateForExcel(procItem.MfgForecast) || "",
              procItem.Status || "",
              procItem.Remarks || "",
              "",
            ];
            XLSX.utils.sheet_add_aoa(procurementWs, [row], { origin: `A${index + 3}` });
          });

          XLSX.utils.book_append_sheet(wb, procurementWs, "BOM Standard Format");

          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const data = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });

          const timestamp = new Date().toISOString().split("T")[0];
          const fileName = `Procurement_${project.Title.replace(/[^a-zA-Z0-9]/g, "_")}_${timestamp}.xlsx`;

          saveAs(data, fileName);

          hideExportProgress();
          toast(`Excel file exported successfully!`, "success");
        } catch (error) {
          hideExportProgress();
          console.error("Project export error:", error);
          toast("Failed to export project Excel file", "error");
        }
      };

      const exportToExcel = async (): Promise<void> => {
        // ✅ Role guard (same as SEIBIES): export needs at least read access
        if (!canRead()) {
          toast("❌ You don't have permission to export data", "error");
          return;
        }

        showExportProgress("Preparing data for export...");

        try {
          const project = filterProject.value;
          const customer = filterCustomer.value;
          const projectManager = filterProjectManager.value;
          const groupHead = filterGroupHead.value;
          const projectReference = filterProjectReference.value;

          const filteredData = procurementData.filter((item) => {
            const projectData = resolveProjectForItem(item);
            const projectTitle =
              item[fieldMappings.Project]?.Title || projectData?.Title || "";

            if (project && projectTitle !== project) return false;
            if (customer && projectData?.CustomerName !== customer) return false;
            if (projectManager) {
              const managerName =
                typeof projectData?.ProjectManager === "object"
                  ? projectData.ProjectManager?.Title
                  : projectData?.ProjectManager;
              if (managerName !== projectManager) return false;
            }
            if (groupHead) {
              const groupHeadName = getGroupHeadDisplayName(projectData?.GroupHead1);
              if (groupHeadName !== groupHead) return false;
            }
            if (projectReference && projectData?.ProjectReference !== projectReference) return false;

            return true;
          });

          if (filteredData.length === 0) {
            hideExportProgress();
            toast("No data to export", "warning");
            return;
          }

          const headers = [
            "Project Reference", "Customer", "Project", "Group Head", "Project Manager",
            "Total Line Items",
            "RFQ Pending", "Offer Pending", "TC pending", "Order Closure pending",
            "PR pending", "PO pending", "Document Approval Pending", "MFC Pending",
            "Inspection Pending", "Dispatch Pending", "Delivery Pending", "Delivered"
          ];

          const dataRows: any[][] = [];

          filteredData.forEach((item) => {
            const projectData = resolveProjectForItem(item);
            const projectTitle =
              item[fieldMappings.Project]?.Title || projectData?.Title || "";
            const procurementItems =
              parseProcurementForecast(
                item[fieldMappings.ProcurementForecast]
              ) || [];

            const statusCounts = calculateProjectStatusCounts(procurementItems);
            const totalLineItems = procurementItems.length;

            const managerName = typeof projectData?.ProjectManager === "object"
              ? projectData?.ProjectManager?.Title || ""
              : projectData?.ProjectManager || "";
            const groupHeadName = getGroupHeadDisplayName(projectData?.GroupHead1);
            dataRows.push([
              projectData?.ProjectReference || "",
              projectData?.CustomerName || "",
              projectTitle,
              groupHeadName,
              managerName,
              totalLineItems,
              statusCounts["RFQ Pending"] || 0,
              statusCounts["Offer Pending"] || 0,
              statusCounts["TC pending"] || 0,
              statusCounts["Order Closure pending"] || 0,
              statusCounts["PR pending"] || 0,
              statusCounts["PO pending"] || 0,
              statusCounts["Document Approval Pending"] || 0,
              statusCounts["MFC Pending"] || 0,
              statusCounts["Inspection Pending"] || 0,
              statusCounts["Dispatch Pending"] || 0,
              statusCounts["Delivery Pending"] || 0,
              statusCounts["Delivered"] || 0
            ]);
          });

          const wsData = [headers, ...dataRows];
          const ws = XLSX.utils.aoa_to_sheet(wsData);

          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "Procurement Summary");

          const excelBuffer = XLSX.write(wb, {
            bookType: "xlsx",
            type: "array",
          });
          const data = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });

          const timestamp = new Date().toISOString().split("T")[0];
          const filterInfo = [
            project ? `Project-${project}` : "",
            customer ? `Customer-${customer}` : "",
            projectManager ? `Manager-${projectManager}` : "",
            groupHead ? `Group-${groupHead}` : "",
            projectReference ? `Reference-${projectReference}` : "",
          ].filter(Boolean).join("_");

          const fileName = filterInfo
            ? `Procurement_Summary_${filterInfo}_${timestamp}.xlsx`
            : `Procurement_Summary_${timestamp}.xlsx`;

          saveAs(data, fileName);

          hideExportProgress();
          toast(`Excel exported successfully! ${filteredData.length} projects`, "success");
        } catch (error) {
          hideExportProgress();
          console.error("Export error:", error);
          toast("Failed to export Excel report", "error");
        }
      };

      // Event Listeners
      showFormBtn.addEventListener("click", () => {
        // ✅ Role access (same as SEIBIES): create requires create rights
        if (!canViewProcurementForm(false)) {
          toast("❌ You don't have permission to create procurement plans", "error");
          return;
        }
        resetForm();
        formSection.style.display = "block";
        tableSection.style.display = "none";
        renderProjectDetails(null);
        procurementContainerTable.style.display = "block";
        procurementContainer.innerHTML = "";
        procurementContainer.appendChild(createProcurementRow());
        formTitle.textContent = "Add Procurement";
        existingDataAlert.style.display = "none";
        resetDescriptionFilter();
        projectSelect.disabled = false;
        projectSelect.value = "";
        applySaveButtonVisibility(false);
      });

      backBtn.addEventListener("click", resetForm);

      projectSelect.addEventListener("change", (e) => {
        const selectedId = parseInt((e.target as HTMLSelectElement).value);
        if (selectedId) {
          const existingRecord = procurementData.find(
            (item) =>
              item[`${fieldMappings.Project}Id`] === selectedId ||
              (item[fieldMappings.Project] &&
                item[fieldMappings.Project].Id === selectedId)
          );

          if (existingRecord) {
            existingDataAlert.style.display = "block";
            setEditTitle(projects.find((p) => p.Id === selectedId) || null);
            editingId = existingRecord.Id;

            const procurementItems =
              parseProcurementForecast(
                existingRecord[fieldMappings.ProcurementForecast]
              ) || [];
            procurementContainer.innerHTML = "";

            procurementItems.forEach((item) => {
              procurementContainer.appendChild(createProcurementRow(item));
            });
          } else {
            existingDataAlert.style.display = "none";
            formTitle.textContent = "Add Procurement";
            formSection.classList.remove("edit-mode");
            editingId = null;

            procurementContainer.innerHTML = "";
            procurementContainer.appendChild(createProcurementRow());
          }

          onProjectChange(selectedId, !!existingRecord);
        } else {
          procurementContainerTable.style.display = "none";
          renderProjectDetails(null);
          existingDataAlert.style.display = "none";
          formTitle.textContent = "Add Procurement";
          formSection.classList.remove("edit-mode");
          procurementContainer.innerHTML = "";
          procurementContainer.appendChild(createProcurementRow());
        }
      });

      document
        .querySelector(".add-procurement-row")
        ?.addEventListener("click", () => {
          procurementContainer.appendChild(createProcurementRow());
          filterEditTableByDescription();
        });

      descriptionFilter?.addEventListener("input", filterEditTableByDescription);

      procurementContainer.addEventListener("input", (e) => {
        const target = e.target as HTMLInputElement;
        if (target.name === "description") {
          filterEditTableByDescription();
        }
      });

      procurementContainer.addEventListener("click", (e) => {
        const target = e.target as HTMLElement;
        if (target.classList.contains("remove-row")) {
          const row = target.closest("tr");
          if (row && procurementContainer.children.length > 1) {
            row.remove();
          } else {
            toast("At least one row is required", "warning");
          }
        }
      });

      filterProject.addEventListener("change", filterData);
      filterCustomer.addEventListener("change", filterData);
      filterProjectManager.addEventListener("change", filterData);
      filterGroupHead.addEventListener("change", filterData);
      filterProjectReference.addEventListener("change", filterData);
      clearFiltersBtn.addEventListener("click", clearFilters);

      exportExcelBtn.addEventListener("click", exportToExcel);

      // ✅ Page size selector (10 / 25 / 50 / 100) - like SEIBIES
      const pageSizeSelect = document.getElementById("pageSizeSelect") as HTMLSelectElement | null;
      if (pageSizeSelect) {
        pageSizeSelect.value = pageSize.toString();
        pageSizeSelect.addEventListener("change", (e) => {
          const newSize = parseInt((e.target as HTMLSelectElement).value, 10);
          if (!newSize || newSize === pageSize) return;
          pageSize = newSize;
          currentPage = 1;
          renderTable(currentTableData.length ? currentTableData : procurementData);
          toast(`Showing ${pageSize} records per page`, "success");
        });
      }

      // Re-apply the outer-sticky offset when the window is resized
      window.addEventListener("resize", () => {
        clearTimeout((window as any)._procurementStickyResizeTimer);
        (window as any)._procurementStickyResizeTimer = setTimeout(updateMainTableStickyOffset, 150);
      });

      // Re-apply when coming back from the form (table is visible again)
      updateMainTableStickyOffset();

      await initApp();
    }, 100);
  },
}; 
