import { WebPartContext } from '@microsoft/sp-webpart-base';
import { authManager, hasFullControl, canContribute, isGHHead, getUserGroups } from './pages/auth';

export interface ISidebarProps {
  context: WebPartContext;
}

const icon = (path: string): string =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="#0078d4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${path}</svg>`;

const ICONS: Record<string, string> = {
  dashboard: icon(
    `<rect x="3" y="3" width="7" height="7" rx="1"/>
     <rect x="14" y="3" width="7" height="7" rx="1"/>
     <rect x="3" y="14" width="7" height="7" rx="1"/>
     <rect x="14" y="14" width="7" height="7" rx="1"/>`
  ),
  master: icon(
    `<ellipse cx="12" cy="5" rx="9" ry="3"/>
     <path d="M3 5v6c0 1.66 4 3 9 3s9-1.34 9-3V5"/>
     <path d="M3 11v6c0 1.66 4 3 9 3s9-1.34 9-3v-6"/>`
  ),
  dailysprint: icon(
    `<rect x="3" y="4" width="18" height="18" rx="2"/>
     <line x1="16" y1="2" x2="16" y2="6"/>
     <line x1="8" y1="2" x2="8" y2="6"/>
     <line x1="3" y1="10" x2="21" y2="10"/>
     <polyline points="8 15 11 18 16 13"/>`
  ),
  project: icon(
    `<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>`
  ),
  dci: icon(
    `<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
     <polyline points="14 2 14 8 20 8"/>
     <line x1="16" y1="13" x2="8" y2="13"/>
     <line x1="16" y1="17" x2="8" y2="17"/>
     <line x1="10" y1="9" x2="8" y2="9"/>`
  ),
  procurement: icon(
    `<circle cx="9" cy="21" r="1"/>
     <circle cx="20" cy="21" r="1"/>
     <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>`
  ),
  revenue: icon(
    `<path d="M12 1v22"/>
     <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>`
  ),
  collection: icon(
    `<rect x="2" y="6" width="20" height="12" rx="2"/>
     <circle cx="12" cy="12" r="2.5"/>
     <path d="M6 10v4M18 10v4"/>`
  ),
  invoicing: icon(
    `<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
     <polyline points="14 2 14 8 20 8"/>
     <path d="M12 18v-6"/>
     <path d="M9.5 13.5h4a1.5 1.5 0 0 0 0-3h-3a1.5 1.5 0 0 0 0 3"/>
     <path d="M9.5 15.5h5"/>`
  ),
  inventory: icon(
    `<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
     <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
     <line x1="12" y1="22.08" x2="12" y2="12"/>`
  ),
  seibies: icon(
    `<line x1="18" y1="20" x2="18" y2="10"/>
     <line x1="12" y1="20" x2="12" y2="4"/>
     <line x1="6" y1="20" x2="6" y2="14"/>
     <line x1="3" y1="20" x2="21" y2="20"/>`
  ),
  knowledge: icon(
    `<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
     <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>`
  )
};

const navItem = (page: string, label: string, iconKey: string): string => `
  <li>
    <a href="#" data-page="${page}">
      <span class="icon" data-tooltip="${label}">${ICONS[iconKey]}</span>
      <span class="icon-label">${label}</span>
    </a>
  </li>
`;

/**
 * Initialize authentication for the sidebar
 * This should be called before any permission checks
 */
export const initializeSidebarAuth = async (context: WebPartContext): Promise<void> => {
  const siteUrl = context.pageContext.web.absoluteUrl;
  await authManager.initialize({ siteUrl });
};

/**
 * Get current user's groups using the shared auth module
 */
export const getCurrentUserGroups = async (): Promise<void> => {
  const groups = getUserGroups();
  console.log("Logged-in user belongs to groups:");
  groups.forEach((group: string) => {
    console.log(`Name: ${group}`);
  });
};

/**
 * Check if user is in a specific group using the shared auth module
 */
export const isUserInGroup = (groupName: string): boolean => {
  const groups = getUserGroups();
  return groups.some(group => group.toLowerCase() === groupName.toLowerCase());
};

// Generate sidebar content based on user role
export const getSidebarContent = async (context: WebPartContext): Promise<string> => {
  await initializeSidebarAuth(context);

  const isAdmin = hasFullControl();
  const isGH = isGHHead();
  const canUserContribute = canContribute();
  const userFullName = authManager.getCurrentUserFullName();
  const userGroups = getUserGroups();
  const currentUser = context.pageContext.user;

  console.log("Logged-in User:");
  console.log("Display Name:", currentUser.displayName);
  console.log("Email:", currentUser.email);
  console.log("Login Name:", currentUser.loginName);
  console.log("User ID:", context.pageContext.legacyPageContext.userId);

  await getCurrentUserGroups();

  console.log("All Site Groups (from auth):", userGroups);
  console.log("User Info:", {
    name: currentUser.displayName,
    email: currentUser.email,
    login: currentUser.loginName,
    id: context.pageContext.legacyPageContext.userId,
    fullName: userFullName,
    isAdmin: isAdmin,
    isGH: isGH,
    canContribute: canUserContribute
  });
  console.log("Is Kirya Admin?:", isAdmin);
  console.log("Is GH Head?:", isGH);

  let sidebarItems = navItem("dashboard", "DASHBOARD", "dashboard");

  if (isAdmin) {
    console.log("✅ User IS a Kirya Admin - Adding Master Data menu item");
    sidebarItems += navItem("master", "MASTER DATA", "master");
  } else {
    console.log("❌ User is NOT a Kirya Admin - Master Data menu item hidden");
  }

  // data-page values kept as-is so existing page routing still matches
  sidebarItems +=    
    navItem("project", "PROJECT", "project") +
    navItem("sprint", "DAILY SPRINT", "dailysprint") +
    navItem("revenue", "REVENUE PLAN", "revenue") +
    navItem("collection", "COLLECTION PLAN", "collection") +
    navItem("dci", "DCI", "dci") +
    navItem("procurement", "PROCUREMENT PLAN", "procurement") +   
    navItem("invoicing", "INVOICING PLANNING", "invoicing") +
    navItem("inventory", "INVENTORY LIQUIDATION", "inventory") +
    navItem("seibies", "SEI BIES LIQUIDATION", "seibies") +
    navItem("knowledge", "KNOWLEDGE BASE", "knowledge");

  // 🔧 FIXED: return only the <ul> - the WebPart already wraps this in
  // <aside class="dt-sidebar">. Previously this returned ANOTHER
  // <div class="dt-sidebar"> inside the aside → duplicated sidebar
  // container (double width/padding/shadow + duplicate styling).
  return `
    <ul class="dt-sidebar-list">
      ${sidebarItems}
    </ul>
  `;
};

export const sidebarStyle = `
@font-face {
  font-family: 'ABBvoiceOffice';
  src: url('../../assets/ABBvoiceOffice_Rg.ttf') format('truetype');
  font-weight: 600;
  font-style: normal;
  font-display: swap;
}

/* Apply ABB font to entire application */
html,
body,  
.page,
.page * {
  font-family: 'ABBvoiceOffice';
}

.dt-sidebar {
  background: #ffffff;
  box-shadow: 0 1px 6px -2px #eee, 0 2px 6px 1px #eee, 0 1px 4px 2px #eee;
  width: 225px;
  padding: 8px 6px 8px 8px;
  transition: width 0.3s ease;
  height: 100%;
  max-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
  font-family: ABBvoiceOffice;
  box-sizing: border-box;
}

.dt-sidebar.collapsed {
  width: 60px;
  padding: 8px 6px;
  overflow-x: visible;
  overflow-y: auto;
}

.dt-sidebar ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.dt-sidebar li {
  margin: 2px 0;
}

.dt-sidebar a {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  color: #4d5f71;
  text-decoration: none;
  border-radius: 8px;
  position: relative;
  white-space: nowrap;
}

.dt-sidebar a:hover {
  background: #e7e7ff;
  color: #696cff;
}

.dt-sidebar a.active {
  background: #e7e7ff;
  color: #696cff;
}

.dt-sidebar.collapsed a {
  justify-content: center;
  padding: 8px;
}

.dt-sidebar.collapsed .icon-label {
  display: none;
}

.icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  position: relative;
  flex-shrink: 0;
  width: 22px;
  height: 22px;
}

.icon svg {
  display: block;
  width: 20px;
  height: 20px;
}

/* Collapsed: tooltip to the right so it is not clipped by vertical scroll */
.dt-sidebar.collapsed .icon[data-tooltip]:hover::after {
  content: attr(data-tooltip);
  position: absolute;
  left: calc(100% + 14px);
  top: 50%;
  transform: translateY(-50%);
  background: #333;
  color: #fff;
  font-size: 11px;
  padding: 4px 8px;
  border-radius: 4px;
  white-space: nowrap;
  z-index: 9999;
  pointer-events: none;
}

.dt-sidebar.collapsed .icon[data-tooltip]:hover::before {
  content: '';
  position: absolute;
  left: calc(100% + 4px);
  top: 50%;
  transform: translateY(-50%);
  border-width: 5px;
  border-style: solid;
  border-color: transparent #333 transparent transparent;
  z-index: 9999;
  pointer-events: none;
}

/* Thin scrollbar — only appears when the list overflows */
.dt-sidebar::-webkit-scrollbar {
  width: 6px;
}

.dt-sidebar::-webkit-scrollbar-track {
  background: transparent;
}

.dt-sidebar::-webkit-scrollbar-thumb {
  background: #c5c5d2;
  border-radius: 8px;
}

.dt-sidebar::-webkit-scrollbar-thumb:hover {
  background: #a8a8b8;
}

.dt-sidebar {
  scrollbar-width: thin;
  scrollbar-color: #c5c5d2 transparent;
}
`;

export const sidebarScript = () =>
  console.log("Sidebar loaded with role-based visibility");

export default {
  getContent: getSidebarContent,
  style: sidebarStyle,
  script: sidebarScript
};
